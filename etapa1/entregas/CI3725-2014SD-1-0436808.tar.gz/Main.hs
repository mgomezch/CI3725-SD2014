--  Module Main
--  Universidad Simón Bolívar
--  Laboratorio de Traductores e Interpretadores (CI-3725)
--  Integrante: Arquímedes Darío Carrasquel Blanco
--  Carnet: 04-36808 
--  Proyecto 1

module Main (main) where

import Lexer (alexScanTokens)
import Token
import System.IO
import System.Environment


printElements :: [Token] -> IO()
printElements [] = return ()
printElements (x:xs) = do print x
                          printElements xs


main :: IO()
main =
    do  
        args <- getArgs
        let h = head args
        {-fileName <- getFileName-}
        k <- readFile h
        let x = (alexScanTokens k)
        printElements(x)


{-getFileName =
    do
        hSetBuffering stdout NoBuffering
        putStr "Archivo a Interpretar: "
        filename <- getLine
        return filename-}

