-- Module Token
-- Universidad Simón Bolívar
-- Laboratorio de Traductores e Interpretadores (CI-3725)
-- Integrante: Arquímedes Darío Carrasquel Blanco
-- Carnet: 04-36808 
-- Proyecto 1 


module Token where

data Token = TkProgram { linea, columna :: Int}
           | TkUse { linea, columna :: Int}
           | TkNumber { linea, columna :: Int}
           | TkIn { linea, columna :: Int }
           | TkPrint { linea, columna :: Int }
           | TkRead { linea, columna :: Int }
           | TkIf { linea, columna :: Int }
           | TkThen { linea, columna :: Int }
           | TkElse { linea, columna :: Int }
           | TkEnd { linea, columna :: Int }
           | TkMatrix { linea, columna :: Int }
           | TkBoolean { linea, columna :: Int }
           | TkSet { linea, columna :: Int }
           | TkFor { linea, columna :: Int }
           | TkDo { linea, columna :: Int }
           | TkNot { linea, columna :: Int }
           | TkFalse { linea, columna :: Int }
           | TkTrue { linea, columna :: Int }
           | TkRow { linea, columna :: Int }
           | TkCol { linea, columna :: Int }
           | TkWhile { linea, columna :: Int }
           | TkFunction { linea, columna :: Int }
           | TkReturn { linea, columna :: Int }
           | TkBegin { linea, columna :: Int }
           | TkComa { linea, columna :: Int }
           | TkPuntoYComa { linea, columna :: Int }
           | TkParAbre { linea, columna :: Int }
           | TkParCierra { linea, columna :: Int }
           | TkCorcheteAbre { linea, columna :: Int }
           | TkCorcheteCierra { linea, columna :: Int }
           | TkLlaveAbre { linea, columna :: Int }
           | TkLlaveCierra { linea, columna :: Int }
           | TkDosPuntos { linea, columna :: Int }
           | TkAsignacion { linea, columna :: Int }
           | TkIgual { linea, columna :: Int }
           | TkDesigual { linea, columna :: Int }
           | TkMenor { linea, columna :: Int }
           | TkMenorIgual { linea, columna :: Int }
           | TkMayor { linea, columna :: Int }
           | TkMayorIgual { linea, columna :: Int }
           | TkSuma { linea, columna :: Int }
           | TkResta { linea, columna :: Int }
           | TkMult { linea, columna :: Int }
           | TkDivExacta { linea, columna :: Int }
           | TkRestoExacto { linea, columna :: Int }
           | TkDivEntera { linea, columna :: Int }
           | TkRestoEntero { linea, columna :: Int }
           | TkConjuncion { linea, columna :: Int }
           | TkDisyuncion { linea, columna :: Int }
           | TkTraspuesta { linea, columna :: Int }
           | TkSumaCr { linea, columna :: Int }
           | TkRestaCr { linea, columna :: Int }
           | TkMultCr { linea, columna :: Int }
           | TkDivExactaCr { linea, columna :: Int }
           | TkRestoExactoCr { linea, columna :: Int }
           | TkDivEnteraCr { linea, columna :: Int }
           | TkRestoEnteroCr { linea, columna :: Int }
           | TkString { linea, columna :: Int, identificador :: String }
           | TkNum { linea, columna :: Int, numero :: Integer }
           | TkFloat { linea, columna :: Int }
           | TkIdent { linea, columna :: Int, identificador :: String }
           | TkError { linea, columna :: Int, inesperado :: String }
           deriving (Eq)


instance Show Token where
  show t = case t of
    TkNum i j k           -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkNum("      ++ show k ++ ")"
    TkFloat i j           -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkFloat"
    TkIdent i j k         -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkIdent("    ++ show k ++ ")"
    TkProgram i j         -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkProgram"
    TkUse i j             -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkUse"
    TkNumber i j          -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkNumber"
    TkIn i j              -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkIn"
    TkPrint i j           -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkPrint"
    TkRead i j            -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkRead"
    TkIf i j              -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkIf"
    TkThen i j            -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkThen"
    TkElse i j            -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkElse"
    TkEnd i j             -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkEnd"
    TkMatrix i j          -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkMatrix"
    TkBoolean i j         -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkBoolean"
    TkSet i j             -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkSet"
    TkFor i j             -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkFor"
    TkDo i j              -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkDo"
    TkNot i j             -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkNot"
    TkFalse i j           -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkFalse"
    TkTrue i j            -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkTrue"
    TkRow i j             -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkRow"
    TkCol i j             -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkCol"
    TkWhile i j           -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkWhile"
    TkFunction i j        -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkFunction"
    TkReturn i j          -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkReturn"
    TkBegin i j           -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkBegin"
    TkComa i j            -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkComa"
    TkPuntoYComa i j      -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkPuntoYComa"
    TkParAbre i j         -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkParAbre"
    TkParCierra i j       -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkParCierra"
    TkCorcheteAbre i j    -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkCorcheteAbre"
    TkCorcheteCierra i j  -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkCorcheteCierra"
    TkLlaveAbre i j       -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkLlaveAbre"
    TkLlaveCierra i j     -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkLlaveCierra"
    TkDosPuntos i j       -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkDosPuntos"
    TkAsignacion i j      -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkAsignacion"
    TkIgual i j           -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkIgual"
    TkDesigual i j        -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkDesigual"
    TkMenor i j           -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkMenor"
    TkMenorIgual i j      -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkMenorIgual"
    TkMayor i j           -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkMayor"
    TkMayorIgual i j      -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkMayorIgual"
    TkSuma i j            -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkSuma"
    TkResta i j           -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkResta"
    TkMult i j            -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkMult"
    TkDivExacta i j       -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkDivExacta"
    TkRestoExacto i j     -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkRestoExacto"
    TkDivEntera i j       -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkDivEntera"
    TkRestoEntero i j     -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkRestoEntero"
    TkConjuncion i j      -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkConjuncion"
    TkDisyuncion i j      -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkDisyuncion"
    TkTraspuesta i j      -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkTraspuesta"
    TkSumaCr i j          -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkSumaCr"
    TkRestaCr i j         -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkRestaCr"
    TkMultCr i j          -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkMultCr"
    TkDivExactaCr i j     -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkDivExactaCr"
    TkRestoExactoCr i j   -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkRestoExactoCr"
    TkDivEnteraCr i j     -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkDivEnteraCr"
    TkRestoEnteroCr i j   -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkRestoEnteroCr"
    TkString i j k        -> "Línea " ++ show j ++ " , columna " ++ show i ++ ": TkString("    ++ show k ++ ")"
    TkError i j k         -> "Error: En la línea " ++ show j ++ ", columna " ++ show i ++ " se encuentra el caracter inesperado " ++ show k

