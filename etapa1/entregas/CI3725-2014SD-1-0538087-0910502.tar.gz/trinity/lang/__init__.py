#!/usr/bin/env python
# ------------------------------------------------------------
# __init__.py
#
# Trinity language module
#
# Authors:
# Victor De Ponte, 05-38087, <rdbvictor19@gmail.com>
# Francisco Martinez, 09-10502, <frammnm@gmail.com>
# ------------------------------------------------------------