#!/usr/bin/python

'''
 Traductores e Interpretadores                                                       
 CI-3725  
 
 Integrantes:   
                                                              
	 10-10738 Abelardo Jesus Valino Ovalle                                                
	 10-10353 Andres Rafael Hernandez Monterola

 Lenguaje Trinity            

'''

import sys
from LexerF import *

if __name__ == '__main__':
	
	AnalizadorLex(sys.argv[1])