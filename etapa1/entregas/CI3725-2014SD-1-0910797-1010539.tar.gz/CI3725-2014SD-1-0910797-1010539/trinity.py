#!/usr/bin/python

#Proyecto Traductores e Interpretadores
#TRINITY
#---(Primera Fase)---
#Integrantes:
#Nelson Saturno 09-10797
#Daniel Pelayo 10-10539

import re
import lex
import sys




listaErrores =[]
tokensEncontrados =[]

#Palabras Reservadas:
#Las definimos como un diccionario para evitar
#que las palabras reservadas sean confundidas por
#identificadores simples que estaran definidos luego
palabrasReservadas = {'program':'TokProgram',
											'use':'TokUse',
											'in':'TokIn',
					   					'print':'TokPrint',
					   					'number':'TokNumber',
					   					'read':'TokRead',
					   					'if':'TokIf',
					   					'then':'TokThen',
					   					'else':'TokElse',
					   					'begin':'TokBegin',
					   					'end':'TokEnd',
					   					'matrix':'TokMatrix',
					   					'col':'TokCol',
					   					'row':'TokRow',
					   					'boolean':'TokBoolean',
					   					'true':'TokTrue',
					   					'false':'TokFalse',
					   					'set':'TokSet',
					   					'while':'TokWhile',
					   					'for':'TokFor',
					   					'do':'TokDo',
					   					'not':'TokNot',
					   					'mod':'TokMod',
					   					'div':'TokDiv',
					   					'function':'TokFunction',
					   					'return':'TokReturn'}


#Lista de Tokens aceptados por el lenguaje TRINITY. Se incluyen las palabras reservadas

tokens = ['TokAnd',
					'TokOr',
					'TokEqual',
					'TokEquiv',
					'TokNotEqual',
					'TokGreater',
					'TokLess',
		  		'TokGreaterEqual',
		  		'TokLessEqual',
		  		'TokAdd',
		  		'TokAddCru',
		  		'TokSub',
		  		'TokSubCru',
		  		'TokMult',
		  		'TokMultCru',
		  		'TokExDiv',
		  		'TokExDivCru',
		  		'TokExMod',
		  		'TokExModCru',
		  		'TokModCru',
		  		'TokDivCru',
		  		'TokParI',
		  		'TokParD',
		  		'TokCorI',
		  		'TokCorD',
		  		'TokLlavI',
		  		'TokLlavD',
		  		'TokComa',
		  		'TokID',
		  		'TokString',
		  		'TokDosPtos',
		  		'TokPtoComa'] + list(palabrasReservadas.values())

#Expresiones regulares de los tokens

t_TokAnd = r'\&'
t_TokOr = r'\|'
t_TokEqual = r'\='
t_TokEquiv = r'\=='
t_TokNotEqual = r'\/='
t_TokGreater = r'\>'
t_TokLess = r'\<'
t_TokGreaterEqual = r'\>='
t_TokLessEqual = r'\<='
t_TokAdd = r'\+'
t_TokAddCru = r'\.\+\.'
t_TokSub = r'\-'
t_TokSubCru = r'\.-\.'
t_TokMult = r'\*'
t_TokMultCru = r'\.\*\.'
t_TokExDiv =r'\/'
t_TokExDivCru = r'\./\.'
t_TokExMod = r'\%'
t_TokExModCru = r'\.%\.'
t_TokModCru = r'\.mod\.'
t_TokDivCru = r'\.div\.'  
t_TokParI = r'\('
t_TokParD = r'\)'
t_TokCorI = r'\['
t_TokCorD = r'\]'
t_TokLlavI = r'\{'
t_TokLlavD = r'\}'
t_TokComa = r'\,'
t_TokDosPtos = r'\:'
t_TokPtoComa = r'\;'
t_ignore = ' \t'  #Se ignoran todos los espacios en blanco



#Definimos que hacer cuando nos encontramos con un
#salto de linea
def t_newline(t):
	r'\n+'
	t.lexer.lineno += len(t.value)


#Cuando conseguimos un # significa que se hara un comentario por lo tanto
#ignoraremos esta seccion
def t_COMMENT(t):
	r'\#.*'
	pass


#Se define la expresion regular para los numeros que acepta el Lenguaje
#Ua vez hayado se instancia como un flotante de python
def t_TokNumber(t):
	r'\d+(\.\d+([eE][+-]\d+)?)?'
	t.value = float(t.value)    
   	return t



#Se definen los identificadores que se encontraran en nuestro Lenguaje
#una vez hayados si coinciden con una palabra reservada se cambia su tipo
def t_TokID(t):
	r'[a-zA-Z][a-zA-Z_0-9]*'
	t.type = palabrasReservadas.get(t.value,'TokID')
	return t


#Se definen los strings.
#quitamos los " y especificamos lo que puede ir seguido de un \
def t_TokString(t):
	r'".*(\\")*.*"|".*\\n".*"|"[^"]*"'
	t.value=t.value[1:len(t.value)-1]
	return t


#Funcion que nos dira la columna en la cual el token encontrado se encuentra
#esta funcion no la puede hacer el lexer explicitamente asi que se desarrolla aparte
#La funcion ya se encontraba implementada en la documentacion de PLY
def find_column(input,token):
	last_cr = input.rfind('\n',0,token.lexpos)
	if last_cr < 0:
		last_cr = 0
	column = (token.lexpos - last_cr) + 1
	return column

def find_column2(input,lexpos):
	last_cr = input.rfind('\n',0,lexpos)
	if last_cr < 0:
		last_cr = 0
	column = (lexpos - last_cr)
	return column

#Si se encuentra un error lo almacenaremos en la lista de errores
def t_error(t):
	listaErrores.append(t)
	t.lexer.skip(1)

#Construccion del LEXER
lexer = lex.lex()

#Se abre el archivo de entrada
data = open(sys.argv[1])

#Leemos el archivo y lo almacenamos en daat2 para luego analizarlo lexicograficamente
data2 = data.read()
lexer.input(data2)

#Ciclo que ira consiguiendo los tokens en el archivo de entrada
#mientras los va encontrando los almacena en la lista de tokens
while True:
	tok = lexer.token()
	if not tok: break
	tokensEncontrados.append(tok)

#Impresion de Salida
if (len(listaErrores) == 0):
	nulo = 0
	for a in tokensEncontrados:
		print a.type,a.value,
		if (a.type == "TokID")|(a.type == "TokString"):
			print "'"+a.value+"'",
		print "Linea,columna :" + "(" + str(a.lineno) + "," + str(find_column(data2,a)) + ")"	
	lexer.lineno =1
else:
	for b in listaErrores:
		print "error: caracter inesperado '"+b.value[0]+"' en linea-columna"+"("+str(b.lineno)+","+str(find_column(data2,b)) + ")"
		lexer.lineno =1
	exit()







	


