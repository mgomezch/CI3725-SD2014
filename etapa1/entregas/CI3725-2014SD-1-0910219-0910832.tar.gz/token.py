#!/usr/bin/python

# Author: Victor Suniaga 09-10832
# Author: Jose Delgado 09-10219


class Token:
	def __init__(self, tipo, line, col, code):
		self.type = tipo
		self.line = line
		self.col = col
		self.code = code

	def __str__(self):
		return "Token <Type: %s | Codigo: %s | Linea: %s | Columna: %s>" % (self.type,self.code, self.line, self.col)
	def __repr__(self):
		return self.__str__()

class tokenIf(Token):
	def __init__(self, line, col, code):
		self.type = "IF"
		self.line = line
		self.col = col
		self.code = code

class tokenPrint(Token):
	def __init__(self, line, col, code):
		self.type = "PRINT"
		self.line = line
		self.col = col
		self.code = code

class tokenFalse(Token):
	def __init__(self, line, col, code):
		self.type = "FALSE"
		self.line = line
		self.col = col
		self.code = code

class tokenTrue(Token):
	def __init__(self, line, col, code):
		self.type = "TRUE"
		self.line = line
		self.col = col
		self.code = code

class tokenBoolean(Token):
	def __init__(self, line, col, code):
		self.type = "BOOLEAN"
		self.line = line
		self.col = col
		self.code = code

class tokenNumber(Token):
	def __init__(self, line, col, code):
		self.type = "NUMBER"
		self.line = line
		self.col = col
		self.code = code

class tokenMatrix(Token):
	def __init__(self, line, col, code):
		self.type = "MATRIX"
		self.line = line
		self.col = col
		self.code = code

class tokenRow(Token):
	def __init__(self, line, col, code):
		self.type = "ROW"
		self.line = line
		self.col = col
		self.code = code

class tokenCol(Token):
	def __init__(self, line, col, code):
		self.type = "COL"
		self.line = line
		self.col = col
		self.code = code

class tokenNot(Token):
	def __init__(self, line, col, code):
		self.type = "NOT"
		self.line = line
		self.col = col
		self.code = code

class tokenDiv(Token):
	def __init__(self, line, col, code):
		self.type = "DIV"
		self.line = line
		self.col = col
		self.code = code

class tokenMod(Token):
	def __init__(self, line, col, code):
		self.type = "MOD"
		self.line = line
		self.col = col
		self.code = code

class tokenUse(Token):
	def __init__(self, line, col, code):
		self.type = "USE"
		self.line = line
		self.col = col
		self.code = code

class tokenIn(Token):
	def __init__(self, line, col, code):
		self.type = "IN"
		self.line = line
		self.col = col
		self.code = code

class tokenEnd(Token):
	def __init__(self, line, col, code):
		self.type = "END"
		self.line = line
		self.col = col
		self.code = code

class tokenProgram(Token):
	def __init__(self, line, col, code):
		self.type = "PROGRAM"
		self.line = line
		self.col = col
		self.code = code

class tokenSet(Token):
	def __init__(self, line, col, code):
		self.type = "SET"
		self.line = line
		self.col = col
		self.code = code

class tokenFor(Token):
	def __init__(self, line, col, code):
		self.type = "FOR"
		self.line = line
		self.col = col
		self.code = code

class tokenDo(Token):
	def __init__(self, line, col, code):
		self.type = "DO"
		self.line = line
		self.col = col
		self.code = code

class tokenWhile(Token):
	def __init__(self, line, col, code):
		self.type = "WHILE"
		self.line = line
		self.col = col
		self.code = code

class tokenRead(Token):
	def __init__(self, line, col, code):
		self.type = "READ"
		self.line = line
		self.col = col
		self.code = code

class tokenThen(Token):
	def __init__(self, line, col, code):
		self.type = "THEN"
		self.line = line
		self.col = col
		self.code = code

class tokenElse(Token):
	def __init__(self, line, col, code):
		self.type = "ELSE"
		self.line = line
		self.col = col
		self.code = code

class tokenFunction(Token):
	def __init__(self, line, col, code):
		self.type = "FUNCTION"
		self.line = line
		self.col = col
		self.code = code

class tokenReturn(Token):
	def __init__(self, line, col, code):
		self.type = "RETURN"
		self.line = line
		self.col = col
		self.code = code

class tokenAmpersand(Token):
	def __init__(self, line, col, code):
		self.type = "AMPERSAND"
		self.line = line
		self.col = col
		self.code = code

class tokenPipe(Token):
	def __init__(self, line, col, code):
		self.type = "PIPE"
		self.line = line
		self.col = col
		self.code = code

class tokenDoubleEqual(Token):
	def __init__(self, line, col, code):
		self.type = "DOUBLE EQUAL"
		self.line = line
		self.col = col
		self.code = code

class tokenEqual(Token):
	def __init__(self, line, col, code):
		self.type = "EQUAL"
		self.line = line
		self.col = col
		self.code = code

class tokenNotEqual(Token):
	def __init__(self, line, col, code):
		self.type = "NOT EQUAL"
		self.line = line
		self.col = col
		self.code = code

class tokenLessEqual(Token):
	def __init__(self, line, col, code):
		self.type = "LESS EQUAL"
		self.line = line
		self.col = col
		self.code = code

class tokenGreaterEqual(Token):
	def __init__(self, line, col, code):
		self.type = "GREATER EQUAL"
		self.line = line
		self.col = col
		self.code = code

class tokenLess(Token):
	def __init__(self, line, col, code):
		self.type = "LESS"
		self.line = line
		self.col = col
		self.code = code

class tokenGreater(Token):
	def __init__(self, line, col, code):
		self.type = "GREATER"
		self.line = line
		self.col = col
		self.code = code

class tokenPlus(Token):
	def __init__(self, line, col, code):
		self.type = "PLUS"
		self.line = line
		self.col = col
		self.code = code

class tokenMinus(Token):
	def __init__(self, line, col, code):
		self.type = "MINUS"
		self.line = line
		self.col = col
		self.code = code

class tokenStar(Token):
	def __init__(self, line, col, code):
		self.type = "STAR"
		self.line = line
		self.col = col
		self.code = code

class tokenSlash(Token):
	def __init__(self, line, col, code):
		self.type = "SLASH"
		self.line = line
		self.col = col
		self.code = code

class tokenPercent(Token):
	def __init__(self, line, col, code):
		self.type = "PERCENT"
		self.line = line
		self.col = col
		self.code = code

class tokenSimpleQuote(Token):
	def __init__(self, line, col, code):
		self.type = "SIMPLE QUOTE"
		self.line = line
		self.col = col
		self.code = code

class tokenDotPlusDot(Token):
	def __init__(self, line, col, code):
		self.type = "DOT PLUS DOT"
		self.line = line
		self.col = col
		self.code = code

class tokenDotMinusDot(Token):
	def __init__(self, line, col, code):
		self.type = "DOT MINUS DOT"
		self.line = line
		self.col = col
		self.code = code

class tokenDotStarDot(Token):
	def __init__(self, line, col, code):
		self.type = "DOT STAR DOT"
		self.line = line
		self.col = col
		self.code = code

class tokenDotSlashDot(Token):
	def __init__(self, line, col, code):
		self.type = "DOT SLASH DOT"
		self.line = line
		self.col = col
		self.code = code

class tokenDotPercentDot(Token):
	def __init__(self, line, col, code):
		self.type = "DOT PERCENT DOT"
		self.line = line
		self.col = col
		self.code = code

class tokenDotDivDot(Token):
	def __init__(self, line, col, code):
		self.type = "DOT DIV DOT"
		self.line = line
		self.col = col
		self.code = code

class tokenDotModDot(Token):
	def __init__(self, line, col, code):
		self.type = "DOT MOD DOT"
		self.line = line
		self.col = col
		self.code = code

class tokenOpenParenthesis(Token):
	def __init__(self, line, col, code):
		self.type = "OPEN PARENTHESIS"
		self.line = line
		self.col = col
		self.code = code

class tokenCloseParenthesis(Token):
	def __init__(self, line, col, code):
		self.type = "CLOSE PARENTHESIS"
		self.line = line
		self.col = col
		self.code = code

class tokenOpenSquare(Token):
	def __init__(self, line, col, code):
		self.type = "OPEN SQUARE"
		self.line = line
		self.col = col
		self.code = code

class tokenCloseSquare(Token):
	def __init__(self, line, col, code):
		self.type = "CLOSE SQUARE"
		self.line = line
		self.col = col
		self.code = code

class tokenColon(Token):
	def __init__(self, line, col, code):
		self.type = "COLON"
		self.line = line
		self.col = col
		self.code = code

class tokenComma(Token):
	def __init__(self, line, col, code):
		self.type = "COMMA"
		self.line = line
		self.col = col
		self.code = code

class tokenOpenBrackets(Token):
	def __init__(self, line, col, code):
		self.type = "OPEN BRACKETS"
		self.line = line
		self.col = col
		self.code = code

class tokenCloseBrackets(Token):
	def __init__(self, line, col, code):
		self.type = "CLOSE BRACKETS"
		self.line = line
		self.col = col
		self.code = code


class tokenString(Token):
	def __init__(self, line, col, code):
		self.type = "STRING"
		self.line = line
		self.col = col
		self.code = code

class tokenSemicolon(Token):
	def __init__(self, line, col, code):
		self.type = "SEMICOLON"
		self.line = line
		self.col = col
		self.code = code

class tokenComentario(Token):
	def __init__(self, line, col, code):
		self.type = "COMENTARIO"
		self.line = line
		self.col = col
		self.code = code

class tokenNumbers(Token):
	def __init__(self, line, col, code):
		self.type = "NUMBERS (FLOAT OR DECIMAL)"
		self.line = line
		self.col = col
		self.code = code

class tokenString(Token):
	def __init__(self, line, col, code):
		self.type = "STRING"
		self.line = line
		self.col = col
		self.code = code

class tokenError(Token):
	def __init__(self, line, col, code):
		self.type = "ERROR"
		self.line = line
		self.col = col
		self.code = code