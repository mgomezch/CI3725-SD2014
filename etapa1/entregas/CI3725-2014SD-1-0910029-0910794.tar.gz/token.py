# Archivo: token.py
# Este archivo contiene la clase token y las subclases para
# cada lexema.
# Autores: 
#	- Miguel  Saraiva	09-10794
#	- Gabriel Alvarez	09-10029
# Grupo: 

class Token(object):	
	line = 1
	column = 1
	value = None

	def getValue(self):
		return value

	def getLine(self):
		return self.line

	def getColumn(self):
		return self.column

	def setLine(self,line):
		self.line = line

	def setColumn(self,column):
		self.column = column

	def printToken(self):
		print "Encontrado '"+self.value+"' en columna ",\
			self.getColumn()," fila ",self.getLine()
		
class IF(Token):
	def __init__(self): 
		self.value = "if"

class WHILE(Token):
	def __init__(self):
		self.value = "while"

class FALSE(Token):
	def __init__(self):
		self.value = "false"

class TRUE(Token):
	def __init__(self):
		self.value = "true"

class BOOLEAN(Token):
	def __init__(self):
		self.value = "boolean"

class NUMBER(Token):
	def __init__(self):
		self.value = "number"

class MATRIX(Token):
	def __init__(self):
		self.value = "matrix"

class ROW(Token):
	def __init__(self):
		self.value = "row"

class COL(Token):
	def __init__(self):
		self.value = "col"

class NOT(Token):
	def __init__(self):
		self.value = "not"

class USE(Token):
	def __init__(self):
		self.value = "use"

class DIVIDE(Token):
	def __init__(self):
		self.value = "div"

class MODULE(Token):
	def __init__(self):
		self.value = "mod"

class PRINT(Token):
	def __init__(self):
		self.value = "print"

class IN(Token):
	def __init__(self):
		self.value = "in"

class END(Token):
	def __init__(self):
		self.value = "end"

class SET(Token):
	def __init__(self):
		self.value = "set"

class FOR(Token):
	def __init__(self):
		self.value = "for"

class READ(Token):
	def __init__(self):
		self.value = "read"

class THEN(Token):
	def __init__(self):
		self.value = "then"

class ELSE(Token):
	def __init__(self):
		self.value = "else"

class DO(Token):
	def __init__(self):
		self.value = "do"

class FUNCTION(Token):
	def __init__(self):
		self.value = "function"

class RETURN(Token):
	def __init__(self):
		self.value = "return"

class BEGIN(Token):
	def __init__(self):
		self.value = "begin"

class PROGRAM(Token):
	def __init__(self):
		self.value = "program"

class LBRACKET(Token):
	def __init__(self):
		self.value = "["

class RBRACKET(Token):
	def __init__(self):
		self.value = "]"

class COLON(Token):
	def __init__(self):
		self.value = ":"

class COMMA(Token):
	def __init__(self):
		self.value = ","

class LPAREN(Token):
	def __init__(self):
		self.value = "("

class RPAREN(Token):
	def __init__(self):
		self.value = ")"

class LBRACE(Token):
	def __init__(self):
		self.value = "{"

class RBRACE(Token):
	def __init__(self):
		self.value = "}"

class AMPERSAND(Token):
	def __init__(self):
		self.value = "&"

class PIPE(Token):
	def __init__(self):
		self.value = "|"

class EQUIVALENT(Token):
	def __init__(self):
		self.value = "=="

class DIFFERENT(Token):
	def __init__(self):
		self.value = "/="

class LESS(Token):
	def __init__(self):
		self.value = "<"

class GREATER(Token):
	def __init__(self):
		self.value = ">"

class LEQUAL(Token):
	def __init__(self):
		self.value = "<="

class GEQUAL(Token):
	def __init__(self):
		self.value = ">="

class PLUS(Token):
	def __init__(self):
		self.value = "+"

class MINUS(Token):
	def __init__(self):
		self.value = "-"

class ASTERISK(Token):
	def __init__(self):
		self.value = "*"

class SLASH(Token):
	def __init__(self):
		self.value = "/"

class PERCENT(Token):
	def __init__(self):
		self.value = "%"

class APOSTROPHE(Token):
	def __init__(self):
		self.value = "'"

class CPLUS(Token):
	def __init__(self):
		self.value = ".+."

class CMINUS(Token):
	def __init__(self):
		self.value = ".-."

class CASTERISK(Token):
	def __init__(self):
		self.value = ".*."

class CSLASH(Token):
	def __init__(self):
		self.value = "./."

class CPERCENT(Token):
	def __init__(self):
		self.value = ".%."

class CDIVIDE(Token):
	def __init__(self):
		self.value = ".div."

class CMODULE(Token):
	def __init__(self):
		self.value = ".mod."

class ENTER(Token):
	def __init__(self):
		self.value = "\\"+"n"			#

class QUOTES(Token):
	def __init__(self):
		self.value = "\\\""

class BSLASH(Token):
	def __init__(self):
		self.value = "\\\\"

class SEMICOLON(Token):
	def __init__(self):
		self.value = ";"

class VARNAME(Token):
	def __init__(self,value):
		self.value = value

class HASH(Token):
	def __init__(self):
		self.value = "#"

class EQUAL(Token):
	def __init__(self):
		self.value = "="

class NUMERIC(Token):
	def __init__(self):
		self.value = "numeric"

class TRANSPOSE(Token):
	def __init__(self):
		self.value = "'"

def tokenizer(line, column, value, tokenList):
	if (value == "if"):
		x = IF()
	elif (value =="false"):
		x = FALSE()
	elif (value == "true"):
		x = TRUE()
	elif (value == "boolean"):
		x = BOOLEAN()
	elif (value == "number"):
		x = NUMBER()
	elif (value == "matrix"):
		x = MATRIX()
	elif (value == "row"):
		x = ROW()
	elif (value == "col"):
		x = COL()
	elif (value == "not"):
		x = NOT()
	elif (value == "div"):
		x = DIVIDE()
	elif (value == "mod"):
		x = MODULE()
	elif (value == "print"):
		x = PRINT()
	elif (value == "use"):
		x = USE()
	elif (value == "in"):
		x = IN()
	elif (value == "end"):
		x = END()
	elif (value == "set"):
		x = SET()
	elif (value == "for"):
		x = FOR()
	elif (value == "read"):
		x = READ()
	elif (value == "then"):
		x = THEN()
	elif (value == "else"):
		x = ELSE()
	elif (value == "do"):
		x = DO()
	elif (value == "while"):
		x = WHILE()
	elif (value == "function"):
		x = FUNCTION()
	else:
		x = VARNAME(value)

	x.setLine(line)
	x.setColumn(column)
	tokenList.append(x)
	
def symbolizer(line, column, value, tokenList):
	if (value == "["):
		x = LBRACKET()
	elif (value == "]"):
		x = RBRACKET()
	elif (value == ":"):
		x = COLON()
	elif (value == ","):
		x = COMMA()
	elif (value == "("):
		x = LPAREN()
	elif (value == ")"):
		x = RPAREN()
	elif (value == "{"):
		x = LBRACE()
	elif (value == "}"):
		x = RBRACE()
	elif (value == "&"):
		x = AMPERSAND()
	elif (value == "|"):
		x = PIPE()
	elif (value == "=="):
		x = EQUIVALENT()
	elif (value == "/="):
		x = DIFFERENT()
	elif (value == "<="):
		x = LEQUAL()
	elif (value == ">="):
		x = GEQUAL()
	elif (value == "+"):
		x = PLUS()
	elif (value == "-"):
		x = MINUS()
	elif (value == "<"):
		x = LESS()
	elif (value == ">"):
		x = GREATER()
	elif (value == "*"):
		x = ASTERISK()
	elif (value == "/"):
		x = SLASH()
	elif (value == "%"):
		x = PERCENT()
	elif (value == "\\\\"):
		x = BSLASH()
	elif (value == ".+."):
		x = CPLUS()
	elif (value == ".-."):
		x = CMINUS()
	elif (value == ".*."):
		x = CASTERISK()
	elif (value == "./."):
		x = CSLASH()
	elif (value == ".%."):
		x = CPERCENT()
	elif (value == ".div."):
		x = CDIVIDE()
	elif (value == ".mod."):
		x = CMODULE()
	elif (value == "\\\n"):
		x = ENTER()
	elif (value == "\\\""):
		x = QUOTES()
	elif (value == ";"):
		x = SEMICOLON()
	elif (value == "="):
		x = EQUAL()
	elif (value == "'"):
		x = TRANSPOSE()

	x.setLine(line)
	x.setColumn(column)
	tokenList.append(x)
