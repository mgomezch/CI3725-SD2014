# Proyecto 1.
# Tradutores
# Betzabeh Gonzalez Canonico: 08-10462
# Nilver Viera: 07-41654

import sys

class Lexema:
    def __init__(self, line, col, code):
        self.line = line
        self.col  = col
        self.code = code

class TkProgram(Lexema):
    def __init__(self, line, col, code):
        self.line = line
        self.col  = col
        self.code = None       

class TkRead(Lexema):
    def __init__(self, line, col, code):
        self.line = line
        self.col  = col
        self.code = None       

class TkPrint(Lexema):
    def __init__(self, line, col, code):
        self.line = line
        self.col  = col
        self.code = None       

class TkReturn(Lexema):
    def __init__(self, line, col, code):
        self.line = line
        self.col  = col
        self.code = None       

class TkUse(Lexema):
    def __init__(self, line, col, code):
        self.line = line
        self.col  = col
        self.code = None       

class TkIn(Lexema):
    def __init__(self, line, col, code):
        self.line = line
        self.col  = col
        self.code = None       

class TkEnd(Lexema):
    def __init__(self, line, col, code):
        self.line = line
        self.col  = col
        self.code = None       

class TkIf(Lexema):
    def __init__(self, line, col, code):
        self.line = line
        self.col  = col
        self.code = None       
        print "EXcelente"

class TkThen(Lexema):
    def __init__(self, line, col, code):
        self.line = line
        self.col  = col
        self.code = None       
        
class TkElse(Lexema):
    def __init__(self, line, col, code):
        self.line = line
        self.col  = col
        self.code = None       

class TkFor(Lexema):
    def __init__(self, line, col, code):
        self.line = line
        self.col  = col
        self.code = None       

class TkOd(Lexema):
    def __init__(self, line, col, code):
        self.line = line
        self.col  = col
        self.code = None       

class TkWhile(Lexema):
    def __init__(self, line, col, code):
        self.line = line
        self.col  = col
        self.code = None       

class TkNumber(Lexema):
    def __init__(self, line, col, code):
        self.line = line
        self.col  = col
        self.code = None       

class TkBoolean(Lexema):
    def __init__(self, line, col, code):
        self.line = line
        self.col  = col
        self.code = None       

class TkMod(Lexema):
    def __init__(self, line, col, code):
        self.line = line
        self.col  = col
        self.code = None       

class TkDiv(Lexema):
    def __init__(self, line, col, code):
        self.line = line
        self.col  = col
        self.code = None        

class TkTrue(Lexema):
    def __init__(self, line, col, code):
        self.line = line
        self.col  = col
        self.code = None      

class TkFalse(Lexema):
    def __init__(self, line, col, code):
        self.line = line
        self.col  = col
        self.code = None      

class TkNot(Lexema):
    def __init__(self, line, col, code):
        self.line = line
        self.col  = col
        self.code = None      

class TkMatrix(Lexema):
    def __init__(self, line, col, code):
        self.line = line
        self.col  = col
        self.code = None      

class TkSet(Lexema):
    def __init__(self, line, col, code):
        self.line = line
        self.col  = col
        self.code = None      

class TkMatrix(Lexema):
    def __init__(self, line, col, code):
        self.line = line
        self.col  = col
        self.code = None      

class TkCol(Lexema):
    def __init__(self, line, col, code):
        self.line = line
        self.col  = col
        self.code = None      

class TkRow(Lexema):
    def __init__(self, line, col, code):
        self.line = line
        self.col  = col
        self.code = None       

class TkConjuncion(Lexema):
    def __init__(self, line, col, code):
        self.line = line
        self.col  = col
        self.code = None       

class TkDisjuncion(Lexema):
    def __init__(self, line, col, code):
        self.line = line
        self.col  = col
        self.code = None       

class TkIgual(Lexema):
    def __init__(self, line, col, code):
        self.line = line
        self.col  = col
        self.code = None      

class TkDesigual(Lexema):
    def __init__(self, line, col, code):
        self.line = line
        self.col  = col
        self.code = None      

class TkMenor(Lexema):
    def __init__(self, line, col, code):
        self.line = line
        self.col  = col
        self.code = None      

class TkMenorIgual(Lexema):
    def __init__(self, line, col, code):
        self.line = line
        self.col  = col
        self.code = None      

class TkMayor(Lexema):
    def __init__(self, line, col, code):
        self.line = line
        self.col  = col
        self.code = None        

class TkMayorIgual(Lexema):
    def __init__(self, line, col, code):
        self.line = line
        self.col  = col
        self.code = None        

class TkMult(Lexema):
    def __init__(self, line, col, code):
        self.line = line
        self.col  = col
        self.code = None        

class TkDivision(Lexema):
    def __init__(self, line, col, code):
        self.line = line
        self.col  = col
        self.code = None        

class TkResto(Lexema):
    def __init__(self, line, col, code):
        self.line = line
        self.col  = col
        self.code = None    

class TkSuma(Lexema):
    def __init__(self, line, col, code):
        self.line = line
        self.col  = col
        self.code = None     

class TkResta(Lexema):
    def __init__(self, line, col, code):
        self.line = line
        self.col  = col
        self.code = None

class TkDosPuntos(Lexema):
    def __init__(self, line, col, code):
        self.line = line
        self.col  = col
        self.code = None     

class TkPuntoYComa(Lexema):
    def __init__(self, line, col, code):
        self.line = line
        self.col  = col
        self.code = None       

class TkParAbre(Lexema):
    def __init__(self, line, col, code):
        self.line = line
        self.col  = col
        self.code = None       

class TkParCierra(Lexema):
    def __init__(self, line, col, code):
        self.line = line
        self.col  = col
        self.code = None       

class TkComa(Lexema):
    def __init__(self, line, col, code):
        self.line = line
        self.col  = col
        self.code = None       

class TkAsignacion(Lexema):
    def __init__(self, line, col, code):
        self.line = line
        self.col  = col
        self.code = None       

class TkLlaveAbre(Lexema):
    def __init__(self, line, col, code):
        self.line = line
        self.col  = col
        self.code = None    

class TkLlaveCierra(Lexema):
    def __init__(self, line, col, code):
        self.line = line
        self.col  = col
        self.code = None      

class TkCorCierra(Lexema):
    def __init__(self, line, col, code):
        self.line = line
        self.col  = col
        self.code = None      

class TkCorAbre(Lexema):
    def __init__(self, line, col, code):
        self.line = line
        self.col  = col
        self.code = None      

class TkLlaveCierra(Lexema):
    def __init__(self, line, col, code):
        self.line = line
        self.col  = col
        self.code = None      

class TkLiterales(Lexema):
    def __init__(self, line, col, code):
        self.line = line
        self.col  = col
        self.code = None      

class TkIdent(Lexema):
    def __init__(self, line, col, code):
        self.line = line
        self.col  = col
        self.code = code

class TkNum(Lexema):
    def __init__(self, line, col, code):
        self.line = line
        self.col  = col
        self.code = code
