##############Lexer.py#################
#
#Maneja el uso de expresiones regulares
#
#Angel Franco 07-40913
#Ricardo Vethencourt 09-10894
#######################################
#import collections
import re
import token

#Token = collections.namedtuple('Token', ['typ', 'value', 'line', 'column'])

def newToken(val, line, col):
	if val == 'if':
		returnToken = token.tIf(val, line, col)
	elif val == 'then':
		returnToken = token.tThen(val, line, col)
	elif val == 'for':
		returnToken = token.tFor(val, line, col)
	elif val == 'program':
		returnToken = token.tProgram(val, line, col)
	elif val == 'use':
		returnToken = token.tUse(val, line, col)
	elif val == 'in':
		returnToken = token.tIn(val, line, col)
	elif val == 'print':
		returnToken = token.tPrint(val, line, col)
	elif val == 'read':
		returnToken = token.tRead(val, line, col)
	elif val == 'set':
		returnToken = token.tSet(val, line, col)
	elif val == 'do':
		returnToken = token.tDo(val, line, col)
	elif val == 'else':
		returnToken = token.tElse(val, line, col)
	elif val == 'end':
		returnToken = token.tEnd(val, line, col)
	elif val == 'matrix':
		returnToken = token.tMatrix(val, line, col)
	elif val == 'row':
		returnToken = token.tRow(val, line, col)
	elif val == 'col':
		returnToken = token.tCol(val, line, col)
	elif val == 'boolean':
		returnToken = token.tBoolean(val, line, col)
	elif val == 'true':
		returnToken = token.tTrue(val, line, col)
	elif val == 'false':
		returnToken = token.tfalse(val, line, col)
	elif val == 'not':
		returnToken = token.tNot(val, line, col)
	elif val == '=':
		returnToken = token.tAssign(val, line, col)
	elif val == ';':
		returnToken = token.tSemicolon(val, line, col)
	elif val == ':':
		returnToken = token.tColon(val, line, col)
	elif val == ',':
		returnToken = token.tComa(val, line, col)
	elif val == '"':
		returnToken = token.tQuotes(val, line, col)
	elif val == '#':
		returnToken = token.tComment(val, line, col)
	elif val == '}':
		returnToken = token.tCurlyClose(val, line, col)
	elif val == '{':
		returnToken = token.tCurlyOpen(val, line, col)
	elif val == ']':
		returnToken = token.tBraceClose(val, line, col)
	elif val == '[':
		returnToken = token.tBraceOpen(val, line, col)
	elif val == ')':
		returnToken = token.tParenClose(val, line, col)
	elif val == '(':
		returnToken = token.tParenOpen(val, line, col)
	elif val == '\"':
		returnToken = token.tEscQuotes(val, line, col)
	elif val == '\\':
		returnToken = token.tEscBackslash(val, line, col)
	elif val == '\\n':
		returnToken = token.tEscJump(val, line, col)
	elif val == "'":
		returnToken = token.tTrans(val, line, col)
	elif val == ".%.":
		returnToken = token.tModFloatCrossed(val, line, col)
	elif val == "./.":
		returnToken = token.tDivFloatCrossed(val, line, col)
	elif val == ".mod.":
		returnToken = token.tModCrossed(val, line, col)
	elif val == ".div.":
		returnToken = token.tDivCrossed(val, line, col)
	elif val == ".*.":
		returnToken = token.tMulCrossed(val, line, col)
	elif val == ".-.":
		returnToken = token.tLessCrossed(val, line, col)
	elif val == ".+.":
		returnToken = token.tPlussCrossed(val, line, col)
	elif val == "%":
		returnToken = token.tModFloat(val, line, col)
	elif val == "/":
		returnToken = token.tDivFloat(val, line, col)
	elif val == "mod":
		returnToken = token.tMod(val, line, col)
	elif val == "div":
		returnToken = token.tDiv(val, line, col)
	elif val == "*":
		returnToken = token.tMul(val, line, col)
	elif val == "-":
		returnToken = token.tLess(val, line, col)
	elif val == "+":
		returnToken = token.tPlus(val, line, col)
	elif val == ">":
		returnToken = token.tGreat(val, line, col)
	elif val == "<":
		returnToken = token.tLesser(val, line, col)
	elif val == ">=":
		returnToken = token.tGreatEqual(val, line, col)
	elif val == "<=":
		returnToken = token.tLessEqual(val, line, col)
	elif val == "/=":
		returnToken = token.tNotEqual(val, line, col)
	elif val == "==":
		returnToken = token.tEqual(val, line, col)
	elif val == "|":
		returnToken = token.tOr(val, line, col)
	elif val == "&":
		returnToken = token.tAnd(val, line, col)

	return returnToken

def tokenize(s):
    keywords = {'if', 'then', 'for', 'program','use','in','print','read',
                'set', 'do', 'else', 'end', 'matrix', 'row', 'col', 'boolean',
                'true', 'false', 'not', 'div', 'mod'}
    token_specification = [
        ('number',  r'\d+(\.\d*)?'),
        ('backslashcom',r'\\\"' ),#solo lee la comilla
        ('equal',r'=='),
        ('assign',  r'='),
        ('id',      r'[A-Za-z]+'),
        ('notequal',r'/='),
        ('newline', r'\n'),
        ('plus', r'\+'),
        ('matrixmult',r'\*'),
        ('diff',r'\-'),
        ('skip',    r'[ \t]'),
        ('puntoycoma', r';'),
        ('and', r'&'),
        ('pointpercent', r'\.%\.'),
        ('backslash',r"\\"),
        ('or', r'\|'),
        ('lessorequal',r'<='),
        ('greaterorequal',r'>='),
        ('lessthan',r'<'),
        ('greaterthan',r'>'),
        ('pointplus',r'\.\+\.'),
        ('pointdiff',r'\.\-\.'),
        ('pointmult',r'\.\*\.'),
        ('pointdiv',r'\.div\.'),
        ('pointmod',r'\.mod\.'),
        ('pointslash',r'\./\.'),
        ('slash',r'/'),
        ('percent',r'%'),
        ('abrepar',r'\('),
        ('cierrapar',r'\)'),
        ('abrellave',r'{'),
        ('cierrallave',r'}'),
        ('abrecorch',r'\['),
        ('cierracorch',r'\]'),
        ('coment',r'#'),
        ('comilla',r'"'),
        ('coma',r'\,'),
        ('dosptos',r"\:"),
        ('ptoycoma',r'\;'),
        ('barran', r'\\n'), # lo ignora

    ]
    tok_regex = '|'.join('(?P<%s>%s)' % pair for pair in token_specification)
    get_token = re.compile(tok_regex).match
    line = 1
    pos = line_start = 0
    mo = get_token(s)
    while(True):
        if mo is not None:
            typ = mo.lastgroup
            if typ == 'newline':
                line_start = pos
                line += 1
            if typ == 'coment': #ignorar comentarios
                pos += 1
                mo = get_token(s, pos)
                while (True):
                    pos += 1
                    if mo is not None:
                        typ=mo.lastgroup
                        if typ=='newline':
                            line_start = pos
                            line += 1
                            break
                    	mo = get_token(s, pos)
            elif typ != 'skip':
                val = mo.group(typ)
                if typ == 'id' and val in keywords:
                    typ = val
                    toke=newToken(val,line,mo.start()-line_start)
                    print ('TOKEN CONSEGUIDO:','tipo',typ,'valor',val,'linea',line,'columna',mo.start()-line_start)
            pos = mo.end()
            mo = get_token(s, pos)
        elif pos != len(s): #manejo de simbolos no reconocidos
            print('SIMBOLO NO RECONOCIDO','valor',s[pos:(pos+1)],'linea',line,
                  'columna',pos-line_start)
            pos+=1
            mo = get_token(s, pos)
        elif pos == len(s):
            break
