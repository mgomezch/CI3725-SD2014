##########token.py############
#
#Contiene las clases de token
#
#Angel Franco 07-40913
#Ricardo Vethencourt 09-10894
#############################
import abc

class token:
	'Clase abstracta base para los tipos de lexemas'
	__metaclass__ = abc.ABCMeta

	@abc.abstractmethod
	def __init__(self, valor, linea, columna):
		pass

#Clases concretas para cada token
class tVar(token):
   
   def __init__(self, valor, linea, columna):
      self.valor = valor
      self.linea = linea
      self.columna = columna

class tNum(token):

   def __init__(self, valor, linea, columna):
      self.valor = valor
      self.linea = linea
      self.columna = columna

class tProgram(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = "program"
		self.linea = linea
		self.columna = columna

class tFunction(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = "function"
		self.linea = linea
		self.columna = columna

class tBegin(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = "begin"
		self.linea = linea
		self.columna = columna

class tReturn(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = "return"
		self.linea = linea
		self.columna = columna

class tEnd(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = "end"
		self.linea = linea
		self.columna = columna

class tUse(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = "use"
		self.linea = linea
		self.columna = columna

class tIn(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = "in"
		self.linea = linea
		self.columna = columna

class tPrint(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = "print"
		self.linea = linea
		self.columna = columna

class tRead(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = "read"
		self.linea = linea
		self.columna = columna

class tSet(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = "set"
		self.linea = linea
		self.columna = columna

class tWhile(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = "while"
		self.linea = linea
		self.columna = columna

class tFor(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = "for"
		self.linea = linea
		self.columna = columna

class tDo(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = "do"
		self.linea = linea
		self.columna = columna

class tIf(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = "if"
		self.linea = linea
		self.columna = columna

class tElse(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = "else"
		self.linea = linea
		self.columna = columna

class tThen(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = "then"
		self.linea = linea
		self.columna = columna

class tMatrix(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = "matrix"
		self.linea = linea
		self.columna = columna

class tNumer(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = "number"
		self.linea = linea
		self.columna = columna

class tRow(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = "row"
		self.linea = linea
		self.columna = columna

class tCol(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = "col"
		self.linea = linea
		self.columna = columna

class tBoolean(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = "boolean"
		self.linea = linea
		self.columna = columna

class tTrue(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = "true"
		self.linea = linea
		self.columna = columna

class tFalse(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = "false"
		self.linea = linea
		self.columna = columna

class tNot(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = "not"
		self.linea = linea
		self.columna = columna

class tAnd(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = "&"
		self.linea = linea
		self.columna = columna

class tOr(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = "|"
		self.linea = linea
		self.columna = columna

class tEqual(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = "=="
		self.linea = linea
		self.columna = columna
		
class tNotEqual(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = "/="
		self.linea = linea
		self.columna = columna

class tLessEqual(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = "<="
		self.linea = linea
		self.columna = columna

class tGreatEqual(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = ">="
		self.linea = linea
		self.columna = columna

class tLesser(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = "<"
		self.linea = linea
		self.columna = columna

class tGreat(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = ">"
		self.linea = linea
		self.columna = columna

class tPlus(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = "+"
		self.linea = linea
		self.columna = columna

class tLess(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = "-"
		self.linea = linea
		self.columna = columna

class tMul(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = "*"
		self.linea = linea
		self.columna = columna

class tDiv(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = "div"
		self.linea = linea
		self.columna = columna

class tMod(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = "mod"
		self.linea = linea
		self.columna = columna

class tDivFloat(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = "/"
		self.linea = linea
		self.columna = columna

class tModFloat(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = "%"
		self.linea = linea
		self.columna = columna

class tPlusCrossed(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = ".+."
		self.linea = linea
		self.columna = columna

class tLessCrossed(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = ".-."
		self.linea = linea
		self.columna = columna

class tMulCrossed(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = ".*."
		self.linea = linea
		self.columna = columna

class tDivCrossed(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = ".div."
		self.linea = linea
		self.columna = columna

class tModCrossed(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = ".mod."
		self.linea = linea
		self.columna = columna

class tDivFloatCrossed(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = "./."
		self.linea = linea
		self.columna = columna

class tModFloatCrossed(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = ".%."
		self.linea = linea
		self.columna = columna
		
class tTrans(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = "'"
		self.linea = linea
		self.columna = columna

class tEscJump(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = "\\n"
		self.linea = linea
		self.columna = columna

class tEscBackslash(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = "\\"
		self.linea = linea
		self.columna = columna

class tEscQuotes(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = '\"'
		self.linea = linea
		self.columna = columna

class tParenOpen(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = "("
		self.linea = linea
		self.columna = columna

class tParenClose(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = ")"
		self.linea = linea
		self.columna = columna

class tBraceOpen(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = "["
		self.linea = linea
		self.columna = columna

class tBraceClose(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = "]"
		self.linea = linea
		self.columna = columna

class tCurlyOpen(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = "{"
		self.linea = linea
		self.columna = columna

class tCurlyClose(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = "}"
		self.linea = linea
		self.columna = columna

class tComment(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = "#"
		self.linea = linea
		self.columna = columna

class tQuotes(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = '"'
		self.linea = linea
		self.columna = columna

class tComa(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = ","
		self.linea = linea
		self.columna = columna

class tColon(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = ":"
		self.linea = linea
		self.columna = columna

class tSemicolon(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = ";"
		self.linea = linea
		self.columna = columna

class tAssign(token):
	
	def __init__(self, valor, linea, columna):
		self.valor = "="
		self.linea = linea
		self.columna = columna
