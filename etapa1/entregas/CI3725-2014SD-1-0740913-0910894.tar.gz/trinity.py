#!/usr/bin/env python
##########trinity.py#########
#
#Maneja el archivo de entrada
#
#Angel Franco 07-40913
#Ricardo Vethencourt 09-10894
#############################
import sys
import lexer

archivo = open(sys.argv[1], "r")
buff = archivo.read()
archivo.close()
lexer.tokenize(buff)

