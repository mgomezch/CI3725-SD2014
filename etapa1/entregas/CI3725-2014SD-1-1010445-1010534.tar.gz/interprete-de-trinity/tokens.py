# -*- coding: utf-8 -*-
''' Modulo de tokens
Este modulo contiene las clases
de tokens reconocidos por el lexer y 
otras funciones relacionadas a los 
tokens.
Autores: Jesus Parra
		 Cristian Medina '''

class Token:
	"""Clase abstracta para los tokens """
	
	linea = 0
	col = 0
	
	def __init__(self,col,linea):
		self.col=col
		self.linea=linea
		
	def imprimir(self):
		pass


class T_LlaveR(Token):
	""" Clase para '}' """
	
	def imprimir(self):
		print 'Linea',self.linea,', columna',self.col,': }' 
	
class T_LlaveI(Token):
	""" Clase para '{' """
	
	def imprimir(self):
		print 'Linea',self.linea,', columna',self.col,': {'
	
class T_Coma(Token):
	""" Clase para ',' """
	
	def imprimir(self):
		print 'Linea',self.linea,', columna',self.col,': ,'
	
class T_Number(Token):
	""" Clase para los tipo Number """
	valor = 0
	
	def __init__(self,col,linea,valor):
		self.col=col
		self.linea=linea
		self.valor= float(valor)
		
	def imprimir(self):
		print 'Linea',self.linea,', columna',self.col,': numero:',self.valor

class T_ParentesisR(Token):
	""" Clase para ')' """
	
	def imprimir(self):
		print 'Linea',self.linea,', columna',self.col,': )'
	
class T_ParentesisI(Token):
	""" Clase para '(' """
	
	def imprimir(self):
		print 'Linea',self.linea,', columna',self.col,': ('
	
class T_CorcheteR(Token):
	""" Clase para ']' """
	
	def imprimir(self):
		print 'Linea',self.linea,', columna',self.col,': ]'
	
class T_CorcheteI(Token):
	""" Clase para '[' """
	
	def imprimir(self):
		print 'Linea',self.linea,', columna',self.col,': ['
	  
class T_PalabraR(Token):
	""" Clase para palabras reservadas """
	palabra = ""
	
	def __init__(self,col,linea,valor):
		self.col=col
		self.linea=linea
		self.palabra= valor
		
	def imprimir(self):
		print 'Linea',self.linea,', columna',self.col,':',self.palabra
	  
class T_Obooleano(Token):
	""" Clase para Operadores Booleanos """
	
	operador = ""
	
	def __init__(self,col,linea,valor):
		self.col = col
		self.linea = linea
		self.operador = valor
	
	def imprimir(self):
		print 'Linea',self.linea,', columna',self.col,': operador booleano',self.operador
	
class T_Oaritmetico(Token):
	""" Clase para Operadores Aritmeticos """
	
	operador = ""
	
	def __init__(self,col,linea,valor):
		self.col = col
		self.linea = linea
		self.operador = valor
		
	def imprimir(self):
		print 'Linea',self.linea,', columna',self.col,': operador aritmetico',self.operador
		
class T_Ocruzado(Token):
	""" Clase para Operadores Cruzados """
	
	operador = ""
	
	def __init__(self,col,linea,valor):
		self.col = col
		self.linea = linea
		self.operador = valor
		
	def imprimir(self):
		print 'Linea',self.linea,', columna',self.col,': operador cruzado',self.operador
		
class T_Backslash(Token):
	""" Clase para los '\' """
	
	def imprimir(self):
		print 'Linea',self.linea,', columna',self.col,': \\'

class T_Dospuntos(Token):
	""" Clase para los : """
	
	def imprimir(self):
		print 'Linea',self.linea,', columna',self.col,': :'
	
class T_Comilla(Token):
	""" Clase para los '"' """
	
	def imprimir(self):
		print("\"")
	
class T_Identificador(Token):	
	""" Clase para los identificadores """
	ident = ""
	
	def __init__(self,col,linea,ident):
		self.col = col
		self.linea = linea
		self.ident = ident
		
	def imprimir(self):
		print 'Linea',self.linea,', columna',self.col,': identificador:',self.ident

class T_Igual(Token):
	""" Clase para '=' """
	
	def imprimir(self):
		print 'Linea',self.linea,', columna',self.col,': ='
	
class T_Puntocoma(Token):
	""" Clase para ';' """
	
	def imprimir(self):
		print 'Linea',self.linea,', columna',self.col,': ;'
	
class T_String(Token):
	""" Clase para cadenas de caracteres """
	
	string = ""
	def __init__(self,col,linea,string):
		self.col = col
		self.linea = linea
		self.string = string
		
	def imprimir(self):
		print 'Linea',self.linea,', columna',self.col,': string:',self.string

class T_Comentario(Token):
	""" Clase para los comentarios """
	
	string = ""
	def __init__(self,col,linea,string):
		self.col = col
		self.linea = linea
		self.string = string
		
	def imprimir(self):
		print 'Linea',self.linea,', columna',self.col,': comentario:',self.string

class T_Error(Token):
	""" Clase para errores """
	
	string = ""
	def __init__(self,col,linea,string):
		self.col = col
		self.linea = linea
		self.string = string
		
	def imprimir(self):
		print 'Linea',self.linea,', columna',self.col,': Caracter inesperado:',self.string

