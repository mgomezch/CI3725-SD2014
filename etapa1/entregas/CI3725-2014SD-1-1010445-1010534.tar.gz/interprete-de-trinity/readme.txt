Proyecto de Traductores e Interpretadores

Jesus Adolfo Parra Parra
Cristian Medina

Interprete del lenguaje TRINITY
