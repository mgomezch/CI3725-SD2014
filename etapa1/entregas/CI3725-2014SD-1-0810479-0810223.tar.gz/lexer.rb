#!/usr/bin/env ruby 
# -*- coding: utf-8 -*-
# David Goudet 08-10479
# Susana Charara 08-10223

##################################################################
#                                                                #
# Este proyecto partio de hacer modificaciones pertinentes al    #
# lexer publicado en:                                            #
# https://github.com/dvdalilue/calculatorRR/blob/master/lexer.rb #
#                                                                #
# Tambien se utilizo el siguiente lexer:                         #
# https://github.com/dvdalilue/calculatorRR/blob/master/lexer.rb #
#                                                                #
##################################################################


# Clase  basepara definir los token encontrados 
class Token

  attr_reader :t, :l, :c

  #Definición del token
  def initialize(text,line,col)
    @t = text
    @l = line
    @c = col - text.length
  end

  def to_s
    "Tk#{self.class}: Linea #{@l}, columna #{@c} "
  end
end

# Definicion de los tokens
$tok = {
  'Traspuesta'      =>  /\A\'/                        ,
  'Coma'            =>  /\A\,/                        ,       
  'PuntoYComa'      =>  /\A\;/                        ,       
  'ParAbre'         =>  /\A\(/                        ,       
  'ParCierra'       =>  /\A\)/                        ,       
  'CorcheteAbre'    =>  /\A\[/                        ,       
  'CorcheteCierra'  =>  /\A\]/                        ,       
  'LlaveAbre'       =>  /\A\{/                        ,       
  'LlaveCierra'     =>  /\A\}/                        ,       
  'DosPuntos'       =>  /\A\:/                        ,       
  'Menos'           =>  /\A\-/                        ,      
  'Mas'             =>  /\A\+/                        ,      
  'Mult'            =>  /\A\*/                        ,       
  'Division'        =>  /\A\//                        ,       
  'Modulo'          =>  /\A\%/                        ,
  'PMenosP'         =>  /\A\.\-\./                    ,      
  'PMasP'           =>  /\A\.\+\./                    ,      
  'PMultP'          =>  /\A\.\*\./                    ,       
  'PDivisionP'      =>  /\A\.\/\./                    ,       
  'PModuloP'        =>  /\A\.\%\./                    ,
  'PDivP'           =>  /\A\.div\./                   ,
  'PModP'           =>  /\A\.mod\./                   ,
  'Conjuncion'      =>  /\A\&/                        ,       
  'Disyuncion'      =>  /\A\|/                        ,       
  'MenorIgual'      =>  /\A\<\=/                       ,      
  'Menor'           =>  /\A\</                        , 
  'MayorIgual'      =>  /\A\>\=/                       ,       
  'Mayor'           =>  /\A\>/                        ,
  'IgualIgual'      =>  /\A\=\=/                      ,
  'Igual'           =>  /\A\=/                        ,       
  'Desigual'        =>  /\A\/=/                       ,     
  'Ident'           =>  /\A[a-zA-Z]+([a-zA-Z0-9_])*/  ,   
  'Num'             =>  /\A[0-9]+(.[0-9]+)?/          ,
  'Str'             => /\A".*"/                       ,
  #'Str'             => /\A"((\\[n"(\\)])*([^\\"])*)*"/,

}

# Creacion de la tabla de hash que almacena las palabras reservadas del lenguaje
$rw = Hash::new
# Palabras reservadas
reserved_words = %w(program boolean false true number matrix row col not div mod print use in end set read if then else for do while function return begin)

# Clase para definir los errores encontrados
class ErrorLexicografico < Token
  def to_s
    "Error lexico: \"#{t}\" Linea #{@l}, columna #{@c} "
  end
end

# Se almacena cada palabra reservada en la tabla de hash creada
reserved_words.each do |s|
  $rw[s.capitalize] = /\A#{s}\b/
end

# Unión de los tokens y las palabras reservadas
$tokens = $rw.merge($tok)

# Se crea una subclase para cada token
# Palabras reservadas
class Program < Token; end
class Boolean < Token; end
class False < Token; end
class True < Token; end
class Number < Token; end
class Matrix < Token; end
class Row < Token; end
class Col < Token; end
class Not < Token; end
class Div < Token; end
class Mod < Token; end
class Print < Token; end
class Use < Token; end
class In < Token; end
class End < Token; end
class Set < Token; end
class Read < Token; end
class If < Token; end
class Then < Token; end
class Else < Token; end
class For < Token; end
class Do < Token; end
class While < Token; end
class Function < Token; end
class Return < Token; end
class Begin < Token; end
#Operadores y otros simbolos
class Traspuesta < Token; end
class Coma < Token; end
class PuntoYComa < Token; end
class ParAbre < Token; end
class ParCierra < Token; end
class CorcheteAbre < Token; end
class CorcheteCierra < Token; end
class LlaveAbre < Token; end
class LlaveCierra < Token; end
class DosPuntos < Token; end
class Menos < Token; end
class Mas < Token; end
class Mult < Token; end
class Division < Token; end
class Modulo < Token; end
class PMenosP < Token; end
class PMasP < Token; end
class PMultP < Token; end
class PDivisionP < Token; end
class PModuloP < Token; end
class PDivP < Token; end
class PModP < Token; end
class Conjuncion < Token; end
class Disyuncion < Token; end
class Menor < Token; end
class MenorIgual < Token; end
class Mayor < Token; end
class MayorIgual < Token; end
class Igual < Token; end
class IgualIgual < Token; end
class Desigual < Token; end
class Ident < Token; end
class Num < Token; end
class Str < Token; end
# Subclase para definir literales numericos y guardar su valor
class Num < Token
  def to_s
    "TkDigito(#{@t}): Linea #{@l}, columna #{@c} "
  end
end
# Subclase para definir identificadores y guardar su valor
class Ident < Token
  def to_s
    "TkIdent(#{@t}): Linea #{@l}, columna #{@c} "
  end
end
# Subclase para definir literales de cadena de caracteres y guardar su valor
class Str < Token
  def to_s
    "TkStr(#{@t}): Linea #{@l}, columna #{@c} "
  end
end

# Clase que analiza la entrada

class Lexer

  attr_accessor :line, :col

  attr_reader :input

  def initialize(input)
    @tokens = []
    @line  = 1
    @col   = 0
    @input = input
  end


#Se analiza cada palabra de la entrada

  def catch
    # Se ignora cualquier espacio en blanco y comentarios
    @input =~ /\A(\s|\n|#.*)*/ 
    self.ignore($&.length)

    return if @input.empty? # Se termino de procesar la entrada

    # En caso de que queden palabras por analizar, se comparan contra los tokens
    $tokens.each do |key, value| 
      @input =~ value
      if $&
	break
      end
      
    end
    newclass = ErrorLexicografico

    # Si se encontro un token, se crea una nueva instancia de esa subclase
    if $&
      phrase = @input[0..($&.length-1)]
      self.ignore($&.length)
      $tokens.each { |k,v|
        if phrase =~ v
          newclass = Object::const_get(k)
          break
        end
      }
    else
      @input =~ /\A(\w|\p{punct})+/ # Se busca una nueva palabra de la entrada
      phrase = $&
      self.ignore($&.length)
    end
    newtoken = newclass.new(phrase,@line,@col)
    @tokens << newtoken

    raise newtoken if newtoken == ErrorLexicografico

    return newtoken
  end

# Se consume la porcion de entrada ya reconocida

  def ignore(length)

    return if length.eql?0

    trh = @input[0..(length-1)]
    
    # Se actualiza el string que falta por analizar
    @input = @input[length..@input.length]

    lineas = (trh + " ").lines.to_a.length.pred

    @line += lineas

    if lineas.eql?0
      @col += length
    else
      @col = (trh + " ").lines.to_a[-1].length
    end
  end

# Se imprimen los tokens y errores encontrados
  def out
    @tokens.each { |t|
      puts t.to_s
    }
  end
end
