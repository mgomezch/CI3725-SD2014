require_relative 'Token'
#Creación de la clase llexer
class Lexer
  #Constructor de la clase
  def initialize(input)
    @input = input
    @tokens = []
    @line  = 1
    @col   = 1
  end
  #método saltar usado para ignorar espacios espacios
  def skip(num)
    return if num.eql?0
    
    skiped = @input[0,num]
    @input = @input[num..-1]
    @line += skiped.count("\n")
    
    #se hace un conteo para saber la posición actual en el archivo
    if skiped.count("\n").eql?0
      @col += num
    else
      @col = num - skiped.rindex("\n")
    end
  end

  #método de reconocer algún toker
  def catch
    
    /\A(\#.*|\s)*/ =~ @input
    self.skip($&.length)
    return nil if @input.empty?
    
    #si se reconoce un token en el diccionario entonces se determina su clase
    if $tokens.detect{|k,v| v =~ @input && @x = k}
      self.skip($&.length)
      tknClass = Object::const_get(@x)
    else#si no entonces es un token de error
      @input =~ /\A./
      self.skip(1)
      tknClass = TkError
    end
    
    @tokens << tknClass.new($&,@line,@col)
    return @tokens.last
  end
  #método salida de los tokens
  def out
    @tokens.each{|t| puts t}
  end
end
