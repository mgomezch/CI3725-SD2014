#Diccionario de Tokens a reconocer

$tokens = {
  
  'TkProgram'  => /\Aprogram/,
  'TkUse'  => /\Ause/,
  'TkIn'  => /\Ain/,
  'TkEnd'  => /\Aend/,
  'TkIf'  => /\Aif/,
  'TkThen'  => /\Athen/,
  'TkElse'  => /\Aelse/,
  'TkFor'  => /\Afor/,
  'TkDo'  => /\Ado/,
  'TkWhile'  => /\Awhile/,
  'TkBoolean'  => /\Aboolean/,
  'TkFunction'  => /\Afunction/,
  'TkReturn'  => /\Areturn/,
  'TkBegin'  => /\Abegin/,
  'TkTrue'  => /\Atrue/,
  'TkFalse'  => /\Afalse/,
  'TkRead'  => /\Aread/,
  'TkNumber'  => /\Anumber/,
  'TkMatrix'  => /\Amatrix/,
  'TkCol'  => /\Acol/,
  'TkRow'  => /\Arow/,
  'TkNot'  => /\Anot/,
  'TkPrint'  => /\Aprint/,
  'TkSet'  => /\Aset/,
  'TkSumCross'  => /\A\.\+\./,
  'TkMinusCross' => /\A\.\-\./,
  'TkMultCross'  => /\A\.\*\./,
  'TkDivideCross' => /\A\.\/\./,
  'TkRemainCross'  => /\A\.\%\./,
  'TkDivCross'  => /\A\.div\./,
  'TkModCross'  => /\A\.mod\./,
  'TkSum'      => /\A\+/,
  'TkMinus'      => /\A\-/,
  'TkMult'      => /\A\*/,
  'TkDivide'   => /\A\//,
  'TkRemain'  => /\A\%/,
  'TkDiv'  => /\Adiv/,
  'TkMod'  => /\Amod/,
  'TkInverse'  => /\A\'/,
  'TkAnd'      => /\A\&/,
  'TkOr'     => /\A\|/,
  'TkEqual'  => /\A\=\=/,
  'TkUnequal'  => /\A\/=/,
  'TkOpenP'  => /\A\(/,
  'TkCloseP'  => /\A\)/,
  'TkGreaterEqual'  => /\A\>\=/,
  'TkLessEqual'  => /\A\<\=/,
  'TkGreater'  => /\A>/,
  'TkLess'  => /\A</,
  'TkOpenBrace'  => /\A\{/,
  'TkCloseBrace'  => /\A\}/,
  'TkComma'  => /\A\,/,
  'TkColon'  => /\A\:/,
  'TkCloseBrack'  => /\A\]/,
  'TkOpenBrack'  => /\A\[/,
  'TkAsig'  => /\A\=/,
  'TkSemicol'  => /\A\;/,
  'TkDigit'   => /\A\-?\d+(\.\d+)?/,
  'TkIdentif' => /\A[a-zA-Z](\w)*/,
  'TkString' => /\A\"([^\"\\]|\\n|\\\"|\\\\)*\"/
}

#creación de clase token
class Token
  attr_reader :t, :l, :c
  def initialize(text,line,col)#constructor de la clase
    @t = text
    @l = line
    @c = col - text.length
  end
  
  def to_s#método to_string
    "Token: #{self.class}, text:#{@t}, line:#{@l}, col:#{@c}"
  end
  
end

#creación de la clase ttoken error
class TkError < Token
  def to_s
    "Error lexico en \"#{@t}\" cerca de la linea \"#{@l}\" y columna \"#{@c}\""
  end
end

#crea la clase de los tokens válidos
$tokens.each do |name,_|
  Object::const_set(name, Class::new(Token))
end