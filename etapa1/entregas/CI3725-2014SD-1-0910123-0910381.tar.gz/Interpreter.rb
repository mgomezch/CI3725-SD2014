#!/usr/bin/ruby
require_relative 'Lexer'

#MAIN
def main

  case ARGV.size#si no hay argumento de entrada se le pedirá al usuario un archivo
    when 0
      print "Archivo a interpretar: "
      filename = gets[0..-2]
    when 1 #si hay un argumento de entrada
      filename = ARGV[0]
    else
      puts "USO: #{$0} [archivo]"
      exit -1
  end
  
  begin
    lexer = Lexer::new(File::read(filename))#lectura de archivo
  rescue Errno::ENOENT => e
    puts e
    exit -1
  end
  
  #catalogo = {}
  while go = lexer.catch
    #if catalogo.has_key?(go.class.name)
      #catalogo[go.class.name] << go.t
    #else
      #catalogo[go.class.name] = [go.t]
    #end
    puts go
  end

  #catalogo.sort.each{|k,v| puts "Tipo: #{k} Valores: #{v.sort}"}
end

main