module Main (main) where

import Lexer
import Tokens
import System.Environment
import Control.Monad
import System.Exit

usageError :: IO()
usageError = error $ "Usage: debe haber solo 1 argumento, el archivo a utilizar"

mostrarLex :: String -> IO()
mostrarLex s = do
	codigo <- readFile s
	let listaTokens = alexScanTokens codigo
	mapM_ printTok listaTokens -- tambien sirve for_ (alexScanTokens codigo) printTok
	if noHayError listaTokens
		then exitSuccess
		else exitFailure

printTok :: Token -> IO()
printTok t
  = putStrLn
  $ "Linea " ++ show linea
  ++ ", columna " ++ show columna ++ ": "
  ++ token_name t 
  ++ (case t of
		NumLit _ v -> ": " ++ show v
		StrLit _ v -> ": " ++ v
		Error _ v -> ": " ++ v
		_ -> ""
  )
  where Posicion linea columna = token_posn t



main = do
	args <- getArgs
	let numArgs = length args
	when (numArgs /= 1) usageError
	when (numArgs == 1) (mostrarLex $ args !! 0)


