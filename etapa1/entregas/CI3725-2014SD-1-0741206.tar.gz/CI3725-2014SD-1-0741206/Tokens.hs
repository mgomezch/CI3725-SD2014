module Tokens where

data Posicion =
		Posicion Int Int
		deriving (Eq,Show)

data Token =
		Programa Posicion 		|
		Boolean Posicion 		|
		Falso Posicion 			|
		Verdadero Posicion  	|
		Number Posicion 		|
		Use Posicion			|
		In Posicion				|
		End Posicion			|
		Set Posicion			|
		Read Posicion			|
		If Posicion				|
		Then Posicion			|
		Else Posicion			|
		For Posicion			|
		Do Posicion				|
		While Posicion			|
		Function Posicion		|
		Return Posicion			|
		Begin Posicion			|
		Matrix Posicion			|
		Row Posicion			|
		Col Posicion			|
		Not Posicion			|
		Div Posicion			|
		Mod Posicion			|
		DivCruz Posicion		|
		ModCruz Posicion		|
		Print Posicion			|
		LeftPar Posicion		|
		RightPar Posicion		|
		LeftLlave Posicion		|
		RightLlave Posicion		|
		LeftCorchete Posicion	|
		RightCorchete Posicion	|
		DosPuntos Posicion		|
		Coma Posicion			|
		PuntoComa Posicion		|
		And Posicion			|
		Or Posicion				|
		Igual Posicion			|
		NoIgual Posicion		|
		MenorIgual Posicion		|
		MayorIgual Posicion		|
		Menor Posicion			|
		Mayor Posicion			|
		Asignar Posicion		|
		PlusCruz Posicion		|
		Plus Posicion			|
		MinusCruz Posicion		|
		Minus Posicion			|
		MultiCruz Posicion		|
		Multi Posicion			|
		DividirCruz Posicion	|
		Dividir Posicion		|
		ModuloCruz Posicion		|
		Modulo Posicion			|
		ComillaSimple Posicion	|
		NumLit Posicion Double	|
		StrLit Posicion String	|
		Ident Posicion String	|
		Error Posicion String
		deriving (Eq,Show) --last one without the |

isError :: Token -> Bool
isError t = case t of
				Error _ _ -> True
				_ -> False

noHayError :: [Token] -> Bool
noHayError l = null $ filter isError l


token_posn :: Token -> Posicion
token_posn t = case t of
				(Programa p) -> p
				(Boolean p) -> p
				(Falso p) -> p
				(Verdadero p) -> p
				(Number p) -> p
				(Use p) -> p
				(In p) -> p
				(End p) -> p
				(Set p) -> p
				(Read p) -> p
				(If p) -> p
				(Then p) -> p
				(Else p) -> p
				(For p) -> p
				(Do p) -> p
				(While p) -> p
				(Function p) -> p
				(Return p) -> p
				(Begin p) -> p
				(Matrix p) -> p
				(Row p) -> p
				(Col p) -> p
				(Not p) -> p
				(Div p) -> p
				(Mod p) -> p
				(DivCruz p) -> p
				(ModCruz p) -> p
				(Print p) -> p
				(LeftPar p) -> p
				(RightPar p) -> p
				(LeftLlave p) -> p
				(RightLlave p) -> p
				(LeftCorchete p) -> p
				(RightCorchete p) -> p
				(DosPuntos p) -> p
				(Coma p) -> p
				(PuntoComa p) -> p
				(And p) -> p
				(Or p) -> p
				(Igual p) -> p
				(NoIgual p) -> p
				(MenorIgual p) -> p
				(MayorIgual p) -> p
				(Menor p) -> p
				(Mayor p) -> p
				(Asignar p) -> p
				(PlusCruz p) -> p
				(Plus p) -> p
				(MinusCruz p) -> p
				(Minus p) -> p
				(MultiCruz p) -> p
				(Multi p) -> p
				(DividirCruz p) -> p
				(Dividir p) -> p
				(ModuloCruz p) -> p
				(Modulo p) -> p
				(ComillaSimple p) -> p
				(NumLit p _) -> p
				(StrLit p _) -> p
				(Ident p _) -> p
				(Error p _) -> p

token_name :: Token -> String
token_name t = case t of
				(Programa _) -> "Palabra reservada: program"
				(Boolean _) -> "Palabra reservada: boolean"
				(Falso _) -> "Palabra reservada: false"
				(Verdadero _) -> "Palabra reservada: true"
				(Number _) -> "Palabra reservada: number"
				(Use _) -> "Palabra reservada: use"
				(In _) -> "Palabra reservada: in"
				(End _) -> "Palabra reservada: end"
				(Set _) -> "Palabra reservada: set"
				(Read _) -> "Palabra reservada: read"
				(If _) -> "Palabra reservada: if"
				(Then _) -> "Palabra reservada: then"
				(Else _) -> "Palabra reservada: else"
				(For _) -> "Palabra reservada: for"
				(Do _) -> "Palabra reservada: do"
				(While _) -> "Palabra reservada: while"
				(Function _) -> "Palabra reservada: function"
				(Return _) -> "Palabra reservada: return"
				(Begin _) -> "Palabra reservada: begin"
				(Matrix _) -> "Palabra reservada: matrix"
				(Row _) -> "Palabra reservada: row"
				(Col _) -> "Palabra reservada: col"
				(Not _) -> "Palabra reservada: not"
				(Div _) -> "Palabra reservada: div escalar"
				(Mod _) -> "Palabra reservada: mod escalar"
				(DivCruz _) -> "Palabra reservada: div cruzado"
				(ModCruz _) -> "Palabra reservada: mod cruzado"
				(Print _) -> "Palabra reservada: print"
				(LeftPar _) -> "Parentesis Izquierdo"
				(RightPar _) -> "Parentesis Derecho"
				(LeftLlave _) -> "Llave Izquierda"
				(RightLlave _) -> "Llave Derecha"
				(LeftCorchete _) -> "Corechete Izquierdo"
				(RightCorchete _) -> "Corchete Derecho"
				(DosPuntos _) -> "Dos Puntos"
				(Coma _) -> "Coma"
				(PuntoComa _) -> "Punto y Coma"
				(And _) -> "And Logico"
				(Or _) -> "Or Logico"
				(Igual _) -> "Comparacion por igualdad"
				(NoIgual _) -> "Comparacion por desigualdad"
				(MenorIgual _) -> "Comparacion menor o igual"
				(MayorIgual _) -> "Comparacion mayor o igual"
				(Menor _) -> "Comparacion menor"
				(Mayor _) -> "Comparacion mayor"
				(Asignar _) -> "Asignacion"
				(PlusCruz _) -> "Operador: Suma cruzada"
				(Plus _) -> "Operador: Suma Escalar"
				(MinusCruz _) -> "Operador: Resta Cruzada"
				(Minus _) -> "Operador: Resta Escalar"
				(MultiCruz _) -> "Operador: Multiplicacion Cruzada"
				(Multi _) -> "Operador: Multiplicacion Escalar"
				(DividirCruz _) -> "Operador: Division Cruzada"
				(Dividir _) -> "Operador: Division Escalar"
				(ModuloCruz _) -> "Operador: Residuo Cruzado"
				(Modulo _) -> "Operador: Residuo Escalar"
				(ComillaSimple _) -> "Comilla simple"
				(NumLit _ _) -> "Literal Numerico"
				(StrLit _ _) -> "String Literal"
				(Ident _ _) -> "Identificador"
				(Error _ _) -> "Caracter inesperado: "




