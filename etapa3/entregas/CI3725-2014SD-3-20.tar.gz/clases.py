# -*- coding: UTF-8 -*-
################################################################################
#        Clases empleadas para la gramática establecida para Trinity
#                                                                   
# Elaborado por 
#               Fabio Castro 10-10132
#               Donato Rolo  10-10640
#                                              
################################################################################

import SymTable

# Clase: Lista
# Descripción: da lugar a una lista genérica de elementos para varios fines.
class Lista:
    def __init__(self, elem):
        self.elem = [elem]

    def set_lista(self):
        return self.elem

    def agregar(self, elem):
        self.elem.append(elem)

    def imprimir(self, sangria):
        prt = ""
        sangria = sangria + "  "
        for i in self.elem:
            prt = prt + sangria + i.imprimir(sangria)
        return prt

    def __str__(self):
        aux = ""
        for i in self.elem:
            aux = "%s%s" %(aux, i)

        return aux

# Clase: Program
# Descripción: permite el reconocimiento del inicio de un programa gracias a la
#              palabra PROGRAM, seguido de la instrucción correspondiente.
class Program:
    def __init__(self, list_fun, lista_inst):
        self.list_fun = list_fun
        self.lista_inst = lista_inst

    def imprimir(self,sangria):
        sangria = sangria + " "
        return "Alcance Program:\n" + sangria + "Hijos:" + self.lista_inst.imprimir(sangria)
    # def imprimir(self,sangria):
    #     return "PROGRAM \n " + self.lista_inst.imprimir(sangria) + " \nEND;"

    def __str__(self):
        return "PROGRAM \n %s" %(self.inst)

    def verificar(self):
      auxlista = self.lista_inst.set_lista()
      if (not(self.list_fun == [])):
        auxlista = auxlista + self.list_fun.set_lista()
      errores = []
      for inst in auxlista:
          errores = errores + inst.verificar(None)

      return  errores      



# Clase: Asignación
# Descripción: permite que el reconocedor identifique las partes de una asignación
#              (variable y valor dado)
class Asignacion:
    def __init__(self, var, valor):
        self.var = var
        self.valor = valor
        self.tabla = None

    def imprimir(self,sangria):
      return str()
    # def imprimir(self, sangria):
    #     prt =  "\n"+ sangria + "ASIGNACION"
    #     sangria = sangria + "  "  
    #     #print str(self.var) + "PRUEBAAA"  
    #     #print str(self.valor)
    #     prt = prt + "\n"+ sangria + "var: " + self.var.identif
    #     if (self.valor != None):
    #         prt = prt + "\n"+ sangria + "valor: " + self.valor.imprimir(sangria)

    #     return prt

    def __str__(self):
        return "\nASIGNACION \n var: %s \n valor: %s" %(self.var, self.valor)

    def verificar(self, symtab):
            self.tabla = symtab
            if (symtab is None):
                symtab = SymTable.SymTable()
            auxsymtab = symtab
            auxsym = symtab.find(self.var.identif)
            symtab = self.tabla
            if (not(auxsym is None)):
                if(auxsym.getModificable()):
                    symtype = auxsym.getTipo()
                    if(symtype=="boolean"):        
                       # print "PNONR" + str(self.valor) + "VARIABLE: " + str(self.var)                
                        errores = self.valor.esBool(self.tabla)
                       # print "SALIO"
                        auxsym.setValor(0)   #Inicializacion momentanea
                        return errores
                    elif(symtype== "number"):
                        errores = self.valor.esInt(self.tabla)
                        auxsym.setValor(0)   #Inicializacion momentanea
                        return errores
                else:
                    return ["ERROR en la linea "+ \
                           str(self.var.linea)+ ", columna " + \
                           str(self.var.columna) + \
                           ": La variable \""+ self.var.identif+ \
                           "\" pertenece a una iteracion y no" + \
                           " puede ser modificada"] + self.valor.esInt(self.tabla)                   
            else:
                    return ["ERROR en la linea "+ \
                           str(self.var.linea)+ ", columna " + \
                           str(self.var.columna) + \
                           ": La variable \""+ self.var.identif+ \
                           "\" no ha sido declarada en nigun bloque" + \
                           " con alcance a esta aparicion"] + self.valor.esValida(auxsymtab)  
              

# Clase: Asignación Matriz
# Descripción: p
class AsignacionMatrix:

    def __init__(self, var, posic_column, posic_row, valor):
        self.var = var
        self.posic_column = posic_column
        self.posic_row = posic_row
        self.valor = 0
        self.tabla = None

    def imprimir(self,sangria):
      return str()
    # def imprimir(self, sangria):
    #     prt =  sangria + "ASIGNACION MATRIZ"
    #     sangria = sangria + "  "  
    #     prt = prt + "\n"+ sangria + "var: " + self.var.imprimir(sangria)
    #     prt = prt + "\n"+ sangria + "valor: " + self.valor.imprimir(sangria)
    #     return prt

    def __str__(self):
        return "\nASIGNACION DE MATRIZ \n var: %s \n valor: %s" %(self.var, self.valor)


    def verificar(self, symtab):
            self.tabla = symtab
            if (symtab is None):
                symtab = SymTable.SymTable()
            auxsymtab = symtab
            auxsym = symtab.find(self.var.identif)
            symtab = self.tabla
            if (not(auxsym is None)):
                if(auxsym.getModificable()):
                    symtype = auxsym.getTipo()
                    if(symtype=="boolean"):                        
                        errores = self.valor.esBool(self.tabla)
                        auxsym.setValor(0)   #Inicializacion momentanea
                        return errores
                    elif(symtype== "number"):
                        errores = self.valor.esInt(self.tabla)
                        auxsym.setValor(0)   #Inicializacion momentanea
                        return errores
                else:
                    return ["ERROR en la linea "+ \
                           str(self.var.linea)+ ", columna " + \
                           str(self.var.columna) + \
                           ": La variable \""+ self.var.identif+ \
                           "\" pertenece a una iteracion y no" + \
                           " puede ser modificada"] + self.valor.esInt(self.tabla)                   
            else:
                    return ["ERROR en la linea "+ \
                           str(self.var.linea)+ ", columna " + \
                           str(self.var.columna) + \
                           ": La variable \""+ self.var.identif+ \
                           "\" no ha sido declarada en nigun bloque" + \
                           " con alcance a esta aparicion"] + self.valor.esValida(auxsymtab)

class AsignacionColRow:
    
    def __init__(self, var, posic_column_row, valor):
        self.var = var
        self.posic_column_row = posic_column_row
        self.valor = 0
        self.tabla = None

    def imprimir(self,sangria):
      return str()
    # def imprimir(self, sangria):
    #     prt = "\n"+ sangria + "ASIGNACION DE FILA O COLUMNA"
    #     sangria = sangria + "  "  
    #     prt = prt + "\n"+ sangria + "variable: " + self.identif.imprimir(sangria)
    #     prt = prt + "\n"+ sangria + " fila o columna:" + self.expresion.imprimir(sangria) 
    #     prt = prt + "\n"+ sangria + "  asignacion: " + self.expresion2.imprimir(sangria)
    #     return prt

    def verificar(self, symtab):
        self.tabla = symtab
        if (symtab is None):
            symtab = SymTable.SymTable()
        auxsymtab = symtab
        auxsym = symtab.find(self.var.identif)
        symtab = self.tabla
        if (not(auxsym is None)):
            if(auxsym.getModificable()):
                symtype = auxsym.getTipo()
                if(symtype=="boolean"):                        
                    errores = self.valor.esBool(self.tabla)
                    auxsym.setValor(0)   #Inicializacion momentanea
                    return errores
                elif(symtype== "number"):
                    errores = self.valor.esInt(self.tabla)
                    auxsym.setValor(0)   #Inicializacion momentanea
                    return errores
            else:
                return ["ERROR en la linea "+ \
                       str(self.var.linea)+ ", columna " + \
                       str(self.var.columna) + \
                       ": La variable \""+ self.var.identif+ \
                       "\" pertenece a una iteracion y no" + \
                       " puede ser modificada"] + self.valor.esInt(self.tabla)                   
        else:
                return ["ERROR en la linea "+ \
                       str(self.var.linea)+ ", columna " + \
                       str(self.var.columna) + \
                       ": La variable \""+ self.var.identif+ \
                       "\" no ha sido declarada en nigun bloque" + \
                       " con alcance a esta aparicion"] + self.valor.esValida(auxsymtab)

# Clase: ExpresionBin
# Descripción: esta clase permite que el reconocedor identifique las expresiones
#              binarias, primero el operador, luego el operando izquierdo y 
#              finalmente el derecho
class ExpresionBin:
    def __init__(self, operador, operand1, operand2, linea, columna):
        self.operador = operador
        self.operand1 = operand1
        self.operand2 = operand2
        self.linea = linea       
        self.columna = columna

    def imprimir(self,sangria):
      return str()
    # def imprimir(self, sangria):
    #     prt = "EXPRESION_BIN"
    #     sangria = sangria + "  "  
    #     prt = prt + "\n"+sangria +"operador: "+self.operador+"\n"+sangria +"operando izq: " 
    #     prt = prt + self.operand1.imprimir(sangria) +"\n"+sangria +"operando der: " +self.operand2.imprimir(sangria)
    #     return prt

    def __str__(self):
        return "EXPRESION_BIN \n operador: %s \n operando izq: %s \n operando der: %s" %(self.operador, self.operand1, self.operand2)  


    def esBool(self, symtab):
        if (self.operador == "AND"):
            expbool = self.operand1.esBool(symtab) + self.operand2.esBool(symtab)      
            if (not (expbool)): 
                return []
            return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "conjuncion"+ \
                  "\" necesita de operandos booleanos para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab)
        elif(self.operador == "OR"):
            expbool = self.operand1.esBool(symtab) + self.operand2.esBool(symtab)      
            if (not (expbool)): 
                return []
            return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "disyuncion"+ \
                  "\" necesita de operandos booleanos para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab)
        elif(self.operador == "IGUAL"):
          #  print "prueba " + str(self.operand1)
          #  print "prueba " + str(self.operand2)
            expbool = self.operand1.esBool(symtab) + self.operand2.esBool(symtab)      
            if (not (expbool)): 
                return []
            expint = self.operand1.esInt(symtab) + self.operand2.esInt(symtab) 
            if (not (expint)): 
                return []     
            return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "equivalencia"+ \
                  "\" necesita de operandos del mismo tipo para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab) 
        elif(self.operador == "DIFERENTE"):
            expbool = self.operand1.esBool(symtab) + self.operand2.esBool(symtab)      
            if (not (expbool)): 
                return []
            expint = self.operand1.esInt(symtab) + self.operand2.esInt(symtab)      
            if (not (expint)): 
                return []     
            return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "desigualdad"+ \
                  "\" necesita de operandos del mismo tipo para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab) 
        elif(self.operador == "MAYOR"): 
            expint = self.operand1.esInt(symtab) + self.operand2.esInt(symtab)      
            if (not (expint)): 
                return []     
            return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "mayor"+ \
                  "\" necesita de operandos del mismo tipo para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab) 
        elif(self.operador == "MENOR"):
            expint = self.operand1.esInt(symtab) + self.operand2.esInt(symtab)
            if (not (expint)): 
                return []     
            return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "menor"+ \
                  "\" necesita de operandos del mismo tipo para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab) 
        elif(self.operador == "MAYORIGUAL"):
            expint = self.operand1.esInt(symtab) + self.operand2.esInt(symtab)
            if (not (expint)): 
                return []     
            return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "mayor o igual"+ \
                  "\" necesita de operandos del mismo tipo para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab) 
        elif(self.operador == "MENORIGUAL"):
            expint = self.operand1.esInt(symtab) + self.operand2.esInt(symtab)
            if (not (expint)): 
                return []     
            return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "menor o igual"+ \
                  "\" necesita de operandos del mismo tipo para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab) 
        

    def esInt(self, symtab):
        if(self.operador == "MAS"):
            expint = self.operand1.esInt(symtab) + self.operand2.esInt(symtab)      
            if (not (expint)): 
                return []
            return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "suma"+ \
                  "\" necesita de operandos enteros para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab)
        elif(self.operador == "MULTIPLICAR"):
            expint = self.operand1.esInt(symtab) + self.operand2.esInt(symtab)      
            if (not (expint)): 
                return []
            return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "multiplicacion"+ \
                  "\" necesita de operandos enteros para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab)
        elif(self.operador == "MENOS"):
            expint = self.operand1.esInt(symtab) + self.operand2.esInt(symtab)      
            if (not (expint)): 
                return []
            return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "resta"+ \
                  "\" necesita de operandos enteros para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab)
        elif(self.operador == "DIVISION"):
            expint = self.operand1.esInt(symtab) + self.operand2.esInt(symtab)      
            if (not (expint)): 
                return []
            return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "division"+ \
                  "\" necesita de operandos enteros para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab)
        elif(self.operador == "MOD"):
            expint = self.operand1.esInt(symtab) + self.operand2.esInt(symtab)      
            if (not (expint)): 
                return []
            return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "division"+ \
                  "\" necesita de operandos enteros para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab)
        elif(self.operador == "RESTO"):
            expint = self.operand1.esInt(symtab) + self.operand2.esInt(symtab)      
            if (not (expint)): 
                return []
            return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "division"+ \
                  "\" necesita de operandos enteros para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab)
        else:
           return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  self.operador.lower()+ \
                  "\" no devuelve una expresion de tipo int"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab) 

    def esMatrix(self, symtab):
        if(self.operador == "MAS"):
            expma = self.operand1.esMatrix(symtab) + self.operand2.esMatrix(symtab)      
            if (not (expma)): 
                return []
            return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "suma"+ \
                  "\" necesita de operandos enteros para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab)
        elif(self.operador == "MULTIPLICAR"):
            expma = self.operand1.esMatrix(symtab) + self.operand2.esMatrix(symtab)      
            if (not (expma)): 
                return []
            return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "suma"+ \
                  "\" necesita de operandos enteros para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab)
        elif(self.operador == "MENOS"):
            expma = self.operand1.esMatrix(symtab) + self.operand2.esMatrix(symtab)      
            if (not (expma)): 
                return []
            return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "suma"+ \
                  "\" necesita de operandos enteros para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab)
        elif(self.operador == "DIVISION"):
            expma = self.operand1.esMatrix(symtab) + self.operand2.esMatrix(symtab)      
            if (not (expma)): 
                return []
            return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "suma"+ \
                  "\" necesita de operandos enteros para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab)
        elif(self.operador == "MOD"):
            expma = self.operand1.esMatrix(symtab) + self.operand2.esMatrix(symtab)      
            if (not (expma)): 
                return []
            return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "suma"+ \
                  "\" necesita de operandos enteros para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab)
        elif(self.operador == "MATRIX_DIVISION"):
            expma = self.operand1.esMatrix(symtab) + self.operand2.esMatrix(symtab)      
            if (not (expma)): 
                return []
            return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "suma"+ \
                  "\" necesita de operandos enteros para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab)
        elif(self.operador == "MAS_MATRIX_NUMBER"):
            expma  = self.operand1.esMatrix(symtab) + self.operand2.esInt(symtab)
            expma2 = self.operand2.esMatrix(symtab) + self.operand1.esInt(symtab)         
            if (not (expma))or(not (expma2)): 
                return []
            return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "suma"+ \
                  "\" necesita de operandos enteros para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab)
        elif(self.operador == "MENOS_MATRIX_NUMBER"):
            expma  = self.operand1.esMatrix(symtab) + self.operand2.esInt(symtab)
            expma2 = self.operand2.esMatrix(symtab) + self.operand1.esInt(symtab)         
            if (not (expma))or(not (expma2)): 
                return []
            return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "suma"+ \
                  "\" necesita de operandos enteros para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab)
        elif(self.operador == "MATRIX_DIVISION"):
            expma  = self.operand1.esMatrix(symtab) + self.operand2.esInt(symtab)
            expma2 = self.operand2.esMatrix(symtab) + self.operand1.esInt(symtab)         
            if (not (expma))or(not (expma2)): 
                return []
            return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "suma"+ \
                  "\" necesita de operandos enteros para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab)
        elif(self.operador == "MENOS_MATRIX_NUMBER"):
            expma  = self.operand1.esMatrix(symtab) + self.operand2.esInt(symtab)
            expma2 = self.operand2.esMatrix(symtab) + self.operand1.esInt(symtab)         
            if (not (expma))or(not (expma2)): 
                return []
            return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "suma"+ \
                  "\" necesita de operandos enteros para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab)
        elif(self.operador == "MATRIX_RESTO"):
            expma  = self.operand1.esMatrix(symtab) + self.operand2.esInt(symtab)
            expma2 = self.operand2.esMatrix(symtab) + self.operand1.esInt(symtab)         
            if (not (expma))or(not (expma2)): 
                return []
            return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "suma"+ \
                  "\" necesita de operandos enteros para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab)
        elif(self.operador == "MATRIX_DIVISION_ENTERA"):
            expma  = self.operand1.esMatrix(symtab) + self.operand2.esInt(symtab)
            expma2 = self.operand2.esMatrix(symtab) + self.operand1.esInt(symtab)         
            if (not (expma))or(not (expma2)): 
                return []
            return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "suma"+ \
                  "\" necesita de operandos enteros para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab)
        elif(self.operador == "MATRIX_RESTO_ENTERO"):
            expma  = self.operand1.esMatrix(symtab) + self.operand2.esInt(symtab)
            expma2 = self.operand2.esMatrix(symtab) + self.operand1.esInt(symtab)         
            if (not (expma))or(not (expma2)): 
                return []
            return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "suma"+ \
                  "\" necesita de operandos enteros para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab)
        elif(self.operador == "MATRIX_DIVISION_ENTERA"):
            expma  = self.operand1.esMatrix(symtab) + self.operand2.esInt(symtab)
            expma2 = self.operand2.esMatrix(symtab) + self.operand1.esInt(symtab)         
            if (not (expma))or(not (expma2)): 
                return []
            return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "suma"+ \
                  "\" necesita de operandos enteros para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab)
        elif(self.operador == "MULTIPLICAR_MATRIX_NUMBER"):
            expma  = self.operand1.esMatrix(symtab) + self.operand2.esInt(symtab)
            expma2 = self.operand2.esMatrix(symtab) + self.operand1.esInt(symtab)         
            if (not (expma))or(not (expma2)): 
                return []
            return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "suma"+ \
                  "\" necesita de operandos enteros para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab)
        else:
           return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  self.operador.lower()+ \
                  "\" no devuelve una expresion de tipo int"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab) 

    def esValida(self, symtab):
        return  self.operand1.esValida(symtab) + self.operand2.esValida(symtab)


# Clase: ExpresionUn
# Descripción: esta clase permite que el reconocedor identifique las expresiones
#              unarias, primero el operador, luego el operando.
class ExpresionUn:
    def __init__(self, operador, operand, linea, columna):
        self.operador = operador
        self.operand = operand
        self.linea = linea       
        self.columna = columna

    def imprimir(self,sangria):
      return str()
    # def imprimir(self, sangria):
    #     prt = "EXPRESION_UN"
    #     sangria = sangria + "  "  
    #     prt = prt + "\n"+sangria + "operador: " + self.operador
    #     prt = prt+"\n"+sangria+"operando: " + self.operand.imprimir(sangria)
    #     return prt

    def __str__(self):
        return "EXPRESION_UN \n operador: %s \n operando %s" %(self.operador, self.operand) 

    def esBool(self, symtab):
        if (self.operador == "NOT"):
            return self.operand.esBool(symtab)
        else:
            return ["ERROR en la linea "+ \
            str(self.linea) + ", columna " + str(self.columna)  + \
            ": El operador unario \""+str(self.operador).lower()+ \
            "\" no es compatible con el tipo bool"] + \
            self.operand.esBool(symtab)


    def esInt(self, symtab):

        if(self.operador == "MENOS"):
            return self.operand.esInt(symtab)
        else:
            return ["ERROR en la linea "+ \
            str(self.linea) + ", columna " + str(self.columna)  + \
            ": El operador unario \""+str(self.operador).lower()+ \
            "\" no es compatible con el tipo int"] +  \
            self.operand.esInt(symtab)

    def esValida(self, symtab):

        return  self.operand.esValida(symtab)

# Clase: Condicional
# Descripción: da lugar a la instrucción de selección tanto simple como con else
class Condicional:
    def __init__(self, condicion, list_inst, list_inst2):
        self.condicion = condicion
        self.list_inst = list_inst
        self.list_inst2 = list_inst2

    def imprimir(self,sangria):
      if not(self.list_inst is None):
          lista=self.list_inst.set_lista()
          tamano = len(lista)
          i=0
          prt = ""
          sangria = sangria + " "
          while (i<tamano):            
            prt = prt + lista[i].imprimir(sangria) 
            if (i != (tamano-1)):
                if not prt:
                  prt = prt + "\n" + sangria
            i = i+1

      if not(self.list_inst2 is None):
          lista=self.list_inst2.set_lista()
          tamano = len(lista)
          i=0
          prt = ""
          sangria = sangria + " "
          while (i<tamano):            
            prt = prt + lista[i].imprimir(sangria) 
            if (i != (tamano-1)):
                if not prt:
                  prt = prt + "\n" + sangria
            i = i+1
      return prt 
    # def imprimir(self, sangria): 
    #     prt = "\n"+ sangria+"CONDICIONAL"
    #     sangria = sangria + "  "  
    #     prt = prt+"\n"+ sangria+"condicion: "+self.condicion.imprimir(sangria)
    #     prt= prt+"\n"+ sangria+"then: "+self.list_inst.imprimir(sangria)
    #     if not(self.list_inst2 is None):
    #         prt = prt + "\n"+ sangria + "else: " + self.list_inst2.imprimir(sangria)
    #     return prt

    def __str__(self):
    
        prt = "\nCONDICIONAL \n condicion: %s \n instruccion: %s" %(self.condicion, self.list_inst)
        
        if not(self.list_inst2 is None):
            prt = "\n%s CONDICIONAL ELSE \n %s" %(prt, self.list_inst2)

        return prt

    def verificar(self, symtab):
        
        self.tabla = symtab
        if (symtab is None):
            symtab = SymTable.SymTable()
        errores = []
        errores = self.condicion.esBool(symtab)
        symtab = self.tabla

        auxlista = self.list_inst.set_lista()
        errores = self.tabla.getErrores()
        for list_inst in auxlista:
            errores = errores + list_inst.verificar(self.tabla)

        if (not(self.list_inst2 is None)):
            auxlista2 = self.list_inst2.set_lista()
            errores = self.tabla.getErrores()
            for list_inst2 in auxlista:
                errores = errores + list_inst2.verificar(self.tabla)
        return errores

            

# def verificar(self, symtab):       
#         auxsymtab = symtab
#         self.tabla.insert(Lista(SymTable.Simbolo(self.var,False)), "int")
#         self.tabla.setpadretabla(symtab)
#         errores = []
#         if (symtab is None):
#             symtab = SymTable.SymTable()
#         errores = errores 
#         # + self.rango.esRange(symtab)
#         symtab = auxsymtab
#         auxlista = self.lista_inst.set_lista()
#         errores = self.tabla.getErrores()
#         for inst in auxlista:
#             errores = errores + inst.verificar(self.tabla)
#         return self.verificarVariables() + errores   

# Clase: Print
# Descripción: permite reconocer qué se imprimirá en pantalla al invocar PRINT
class Print:
    def __init__(self, prt):
        self.prt = prt
        self.tabla =None

    def imprimir(self,sangria):
      return str()
    # def imprimir(self, sangria): 
    #     prt = "\n"+sangria+"PRINT"
    #     sangria = sangria + "  "  
    #     lista=self.prt.set_lista()
    #     for i in lista:
    #         prt = prt +"\n"+sangria+"elemento: "+ i.imprimir(sangria)
    #     return prt
     
    def __str__(self):
        return "\nPRINT %s" %(self.prt)

    def verificar(self, symtab):
        self.tabla = symtab
        if (symtab is None):
            symtab = SymTable.SymTable()
        errores = []
        lista=self.prt.set_lista()
        for i in lista:
            if(not(i.esInt(symtab))):
                pass
            elif(not(i.esMatrix(symtab))):
                pass
            elif(not(i.esBool(symtab))):
                pass
            elif(isinstance(i,String)):
                pass
            else:
                errores =  errores + \
                           ["ERROR en la linea "+ \
                           str(i.linea)+ ", columna " + \
                           str(i.columna) + \
                           ": La expresion es incorrecta y " + \
                           "no se puede imprimir"] + \
                           i.esValida(symtab)
        symtab = self.tabla
        return errores


# Clase: Read
# Descripción: permite reconocer que se le pedirá al usuario la introducción de
#              un valor por consola
class Read:
    def __init__(self, id_):
        self.id = id_
        self.tabla = None

    def imprimir(self,sangria):
      return str()
    # def imprimir(self, sangria): 
    #     prt = "\n"+ sangria+"READ"
    #     sangria = sangria + "  "  
    #     prt = prt +"\n"+ sangria + "variable: "+ self.id.imprimir(sangria)
    #     return prt

    def __str__(self):
        return "\nREAD \n variable: %s " %(self.id)

    def verificar(self, symtab):
     
        self.tabla = symtab
        if (symtab is None):
            symtab = SymTable.SymTable()
        sym = symtab.find(self.id.identif)
        symtab = self.tabla
        if(not (sym is None)):
            if(sym.getModificable()):
                sym.setValor(0)   #Inicializacion momentanea
                return []
            else:
                return ["ERROR en la linea "+ \
                       str(self.id.linea)+ ", columna " + \
                       str(self.id.columna) + \
                       ": La variable \""+ self.id.identif+ \
                       "\" pertenece a una iteracion y no" + \
                       " puede ser modificada"]
        else:
            return ["ERROR en la linea "+ \
            str(self.id.linea)+ ", columna " + \
            str(self.id.columna) + \
            ": La variable \""+ self.id.identif+ \
            "\" no ha sido declarada en nigun bloque" + \
            " con alcance a esta aparicion"] 

# Clase: Bloque
# Descripción: permite reconocer los elementos que pueden incluirse en un bloque
#              (nada, declaraciones, instrucciones o una combinación de ambas)
class Bloque:
    def __init__(self, lista_decl, lista_inst):
      self.tablasimbolos = lista_decl
      self.lista_inst = lista_inst

    def imprimir(self, sangria):
      prt = "\n"+ sangria + "Alcance Bloque:"
      sangria = sangria + " "

      if not(self.tablasimbolos is None):
          prt = prt + self.tablasimbolos.imprimir(sangria)

      if not(self.lista_inst is None):
          lista=self.lista_inst.set_lista()
          tamano = len(lista)
          i=0
          prt = prt + "\n" + sangria + "Hijos: "
          sangria = sangria + " "
          while (i<tamano):            
            prt = prt + lista[i].imprimir(sangria) 
            if (i != (tamano-1)):
                if not prt:
                  prt = prt + "\n" + sangria
            i = i+1
      return prt 

    # def imprimir(self, sangria):
    #     prt = "\n"+ sangria + "BLOQUE"

    #     if not(self.tablasimbolos is None):
    #         prt = prt + self.tablasimbolos.imprimir(sangria + " ")

    #     if not(self.lista_inst is None):
    #         lista=self.lista_inst.set_lista()
    #         tamano = len(lista)
    #         i=0
    #         while (i<tamano):            
    #             prt = prt + lista[i].imprimir(sangria + " " ) 
    #             if (i != (tamano-1)):
    #                 prt = prt + "\n" + sangria + "SEPARADOR"
    #             i = i+1 
    #     return prt


    def __str__(self):

        prt = "\nBLOQUE"

        if not(self.lista_decl is None):
            prt = "\n%s DECLARACIONES %s" %(prt, self.lista_decl)

        if not(self.lista_inst is None):
            prt = "\n%s%s" %(prt, self.lista_inst)

        return prt

    def verificar(self, symtab):
        self.tablasimbolos.setpadretabla(symtab) 
        auxlista = self.lista_inst.set_lista()
        errores= self.tablasimbolos.getErrores()
        for inst in auxlista:
            temporal = inst.verificar(self.tablasimbolos)
            if (temporal is not None):
              errores = errores + temporal
        return self.verificarVariables() + errores

    def verificarVariables(self):

        warnings = []
        for sym in self.tablasimbolos.tabla:
            if(sym.getValor() is None):
                warnings.append("WARNING en la linea "+ \
                          str(sym.nombre.linea)+ ", columna " + \
                          str(sym.nombre.columna) + \
                          ": La variable \""+ sym.nombre.identif+ \
                          "\" no es usada durante la ejecucion del programa")
        return warnings

# Clase: IterDet
# Descripción: permite reconocer que nos encontramos ante una instrucción for.
#              Incluye la variable, el rango en el que vivirá y la instrucción.
class IterDet:
    def __init__(self, var, rango, lista_inst):
        self.var = var
        self.rango = rango
        self.lista_inst = lista_inst
        self.tabla = SymTable.SymTable()

    def imprimir(self,sangria):
      if not(self.lista_inst is None):
          lista=self.lista_inst.set_lista()
          tamano = len(lista)
          i=0
          prt = "\n" + sangria + "Hijos: "
          sangria = sangria + " "
          while (i<tamano):            
            prt = prt + lista[i].imprimir(sangria) 
            if (i != (tamano-1)):
                if not prt:
                  prt = prt + "\n" + sangria
            i = i+1
      return prt 
    # def imprimir(self, sangria):
    #     prt = "\n"+ sangria + "ITERACION_DET"
    #     sangria = sangria + "  "  
    #     prt = prt + "\n"+ sangria + "variable: " + self.var.imprimir(sangria)
    #     if (self.rango != None):
    #         prt = prt + "\n"+ sangria + "rango: " + self.rango.imprimir(sangria) 
        
    #     if not(self.lista_inst is None):
    #         lista=self.lista_inst.set_lista()
    #         tamano = len(lista)
    #         i=0
    #         while (i<tamano):            
    #             prt = prt + lista[i].imprimir(sangria + " " ) 
    #             if (i != (tamano-1)):
    #                 prt = prt + "\n"+ sangria + "instruccion: "+ self.inst.imprimir(sangria)
    #             i = i+1 
    #     return prt

    def __str__(self):
        return "\nINSTRUCCION: ITER_DET \n VARIABLE: %s \n RANGO: %s \n INSTRUCCION: %s" %(self.var, self.rango, self.lista_inst)

    def verificar(self, symtab):
            
            auxsymtab = symtab
            self.tabla.insert(Lista(SymTable.Simbolo(self.var,False)), "number")
            self.tabla.setpadretabla(symtab)
            errores = []
            if (symtab is None):
                symtab = SymTable.SymTable()
            errores = errores 
            # + self.rango.esRange(symtab)
            symtab = auxsymtab

            auxlista = self.lista_inst.set_lista()
            errores = self.tabla.getErrores()
            for inst in auxlista:
                errores = errores + inst.verificar(self.tabla)
            return errores

# Clase: IterIndet
# Descripción: permite reconocer que nos encontramos ante una instrucción while.
#              Incluye la variable, la guardia a revisar y la instrucción.
class IterIndet:
    def __init__(self, guardia, lista_inst):
        self.guardia = guardia
        self.lista_inst = lista_inst
        self.tabla = SymTable.SymTable()

    def imprimir(self,sangria):
      if not(self.lista_inst is None):
          lista=self.lista_inst.set_lista()
          tamano = len(lista)
          i=0
          prt = "\n" + sangria + "Hijos: "
          sangria = sangria + " "
          while (i<tamano):            
            prt = prt + lista[i].imprimir(sangria) 
            if (i != (tamano-1)):
                if not prt:
                  prt = prt + "\n" + sangria
            i = i+1
      return prt 
    # def imprimir(self, sangria):
    #     prt = "\n"+ sangria+"ITERACION_INDET"
    #     sangria = sangria + "  "  
    #     prt = prt + "\n"+ sangria + "condicion: " + self.guardia.imprimir(sangria)
    #     prt = prt + "\n"+ sangria + "instrucción: "+ self.inst.imprimir(sangria)
    #     return prt

    def __str__(self):
        return "\nINSTRUCCION: ITER_INDET \n GUARDIA: %s \n INSTRUCCION: %s" %(self.guardia, self.inst)

    def verificar(self, symtab):
            
            auxsymtab = symtab
            self.tabla.setpadretabla(symtab)
            errores = []
            if (symtab is None):
                symtab = SymTable.SymTable()
            errores = errores 
            # + self.rango.esRange(symtab)
            symtab = auxsymtab

            auxlista = self.lista_inst.set_lista()
            errores = self.tabla.getErrores()
            for inst in auxlista:
                errores = errores + inst.verificar(self.tabla)
            return errores
            # self.tabla = symtab
            # if (symtab is None):
            #     symtab = SymTable.SymTable()
            # errores = []
            # errores = self.guardia.esBool(symtab)
            # symtab = self.tabla

            # errores = errores + self.inst.verificar(self.tabla)
            # # print "IterIndet" + symtab.imprimir(" ")
            # return errores

# # Clase: DeclBloque
# # Descripción: da lugar al reconocimiento de un bloque de declaraciones.
# class DeclBloque:
#     def __init__(self, lista_decl):
#         self.lista_decl = lista_decl

#     def imprimir(self, sangria):
#         prt = "\n"+ sangria +"USE" 
#         if not(self.lista_decl is None):
#             lista=self.lista_decl.get_lista()
#             tamano = len(lista)
#             i=0
#             while (i<tamano):            
#                 prt = prt + lista[i].imprimir(sangria + " " ) 
#                 if (i != (tamano-1)):
#                     prt = prt + "\n" + sangria + "SEPARADOR"
#                 i = i+1 
#         return prt

#     def __str__(self):
#         return "%s" %(self.lista_decl)

# Clase: Decl
# Descripción: permite reconocer las variables que se declaran y su respectivo
#              tipo.
class Decl:
    def __init__(self, lista_id, tipo):
        self.lista_id = lista_id
        self.tipo = tipo

    def imprimir(self,sangria):
      return str()
    # def imprimir(self, sangria):
    #     prt = sangria + "TIPO: %s \n" %(self.lista_id)
    #     prt = prt + sangria + "VARIABLES: %s\n" %(self.tipo)
    #     return prt

    def __str__(self):
        return " TIPO: %s \n VARIABLES: %s\n" %(self.lista_id, self.tipo)


# Clase: Rango
# Descripción: reconoce un rango dado por su cota inferior y su cota superior.
class Rango:
    def __init__(self, cotainf, cotasup):
        self.cotainf = cotainf
        self.cotasup = cotasup

    def __str__(self):
        return "\nRANGO \n inferior: %s \n superior: %s" %(self.cotainf, self.cotasup)

# Clase: Id
# Descripción: permite el reconocimiento de los ID imprimibles en un programa
class Id:
    def __init__(self, identif, linea, columna):
        self.identif = identif 
        self.linea = linea       
        self.columna = columna     

    def imprimir(self,sangria):
      return str()
    # def imprimir(self, sangria):
    #     return self.identif

    def __str__(self):
        return str(self.identif) 

    def esBool(self, symtab):
        sym = symtab.find(self.identif)
        sym.setValor(False)
        if (sym is None):                       
                return ["ERROR en la linea "+ \
                str(self.linea)+ ", columna " + \
                str(self.columna) + \
                ": La variable \""+ self.identif+ \
                "\" no ha sido declarada en nigun bloque" + \
                " con alcance a esta aparicion"] 
        if(sym.getTipo() == "boolean"):
            if(sym.getValor() is None):
                return ["ERROR en la linea "+ \
                str(self.linea)+", columna " + str(self.columna) +\
                 ": La variable \""+str(self.identif) +\
                "\" no ha sido inicializada antes de su aparicion" ]          
            else:
                return []
        else:
            return ["ERROR en la linea "+ \
                   str(self.linea) + ", columna " + \
                   str(self.columna)+ ": La variable \""+ \
                   str(self.identif)+ "\" no coincide con el tipo bool"]

    def esInt(self, symtab):
        sym = symtab.find(self.identif)
        if (sym is None):
                return ["ERROR en la linea "+ \
                str(self.linea)+ ", columna " + \
                str(self.columna) + \
                ": La variable \""+ self.identif+ \
                "\" no ha sido declarada en nigun bloque" + \
                " con alcance a esta aparicion"] 
        if(sym.getTipo() == "number"):
            if(sym.getValor() is None):
                return ["ERROR en la linea "+ \
                str(self.linea)+", columna " + str(self.columna) +\
                 ": La variable \""+str(self.identif) +\
                "\" no ha sido inicializada antes de su aparicion" ]          
            else:
                return []
        else:
            return ["ERROR en la linea "+ \
                   str(self.linea) + ", columna " + \
                   str(self.columna)+ ": La variable \""+ \
                   str(self.identif)+ "\" no coincide con el tipo int"]

    def esMatrix(self, symtab):
        sym = symtab.find(self.identif)
        if (sym is None):
                return ["ERROR en la linea "+ \
                str(self.linea)+ ", columna " + \
                str(self.columna) + \
                ": La variable \""+ self.identif+ \
                "\" no ha sido declarada en nigun bloque" + \
                " con alcance a esta aparicion"] 
        if(sym.getTipo() == "matrix")or(sym.getTipo() == "col")or(sym.getTipo() == "row"):
            if(sym.getValor() is None):
                return ["ERROR en la linea "+ \
                str(self.linea)+", columna " + str(self.columna) +\
                 ": La variable \""+str(self.identif) +\
                "\" no ha sido inicializada antes de su aparicion" ]          
            else:
                return []
        else:
            return ["ERROR en la linea "+ \
                   str(self.linea) + ", columna " + \
                   str(self.columna)+ ": La variable \""+ \
                   str(self.identif)+ "\" no coincide con el tipo rango"]

    def esValida(self, symtab):

        sym = symtab.find(self.identif)
        if (sym is None):
                return ["ERROR en la linea "+ \
                str(self.linea)+ ", columna " + \
                str(self.columna) + \
                ": La variable \""+ self.identif+ \
                "\" no ha sido declarada en nigun bloque" + \
                " con alcance a esta aparicion"] 
        if(sym.getValor() is None):
            return ["ERROR en la linea "+ \
            str(self.linea)+", columna " + str(self.columna) +\
            ": La variable \""+str(self.identif) +\
            "\" no ha sido inicializada antes de su aparicion" ]  
        
        return []



# Clase: Numero
# Descripción: permite el reconocimiento de los numero
class Numero:
    def __init__(self, numero, linea, columna):
        self.numero=numero
        self.linea = linea       
        self.columna = columna 

    def imprimir(self,sangria):
      return str()
    # def imprimir(self, sangria):
    #     return "\n "+ sangria + "elemento: " + "%.2f" %(self.numero)

    def __str__(self):
        return str(self.numero)

    def esBool(self, symtab):
        return ["ERROR en la linea "+ \
               str(self.linea)+", columna " + \
              str(self.columna)+": El numero \""+str(self.numero) + \
               "\" no es de tipo bool"]

    def esInt(self, symtab):
        return []

    def esMatrix(self, symtab):
        return ["ERROR en la linea "+ \
               str(self.linea)+", columna " + \
              str(self.columna)+": El numero \""+str(self.numero) + \
               "\" no es de tipo esMatrix"]

    def esValida(self, symtab):

        return  []

# Clase: String
# Descripción: permite el reconocimiento de las cadenas imprimibles en un programa
class String:
    def __init__(self, valor):
        self.valor = valor
        
    def imprimir(self,sangria):
      return str()
    # def imprimir(self, sangria):
    #     prt = "CADENA "
    #     sangria = sangria + "  "  
    #     prt = prt+"\n"+sangria+"valor: "+self.valor
    #     return prt

    def __str__(self):
        return self.valor

    def esBool(self, symtab):
        return ["ERROR"]

    def esInt(self, symtab):
        return ["ERROR"]

    def esMatrix(self, symtab):
        return ["ERROR"]

    def esValida(self, symtab):

        return  []



# Clase: Boolean
# Descripción: permite el reconocimiento de constantes booleanas que se mandan
#              a imprimir en un programa
class Boolean:
    def __init__(self, valor, linea, columna):
        self.valor=valor
        self.linea = linea       
        self.columna = columna

    def imprimir(self,sangria):
      return str()
    # def imprimir(self, sangria):
    #     prt =  "CONSTANTE_BOOL"
    #     sangria = sangria + "  "  
    #     prt = prt + "\n"+ sangria +"valor: " + str(self.valor)
    #     return prt

    def __str__(self):
        return self.valor

    def esBool(self, symtab):
        return []

    def esInt(self, symtab):
        return ["ERROR en la linea "+ \
               str(self.linea)+", columna " + \
               str(self.columna)+": La expresion booleana \""+ \
                str(self.valor)+"\" no es de tipo int"]

    def esMatrix(self, symtab):
        return ["ERROR en la linea "+ \
               str(self.linea)+", columna " + \
               str(self.columna)+": La expresion booleana \""+ \
                str(self.valor)+"\" no es de tipo Matriz"]

    def esValida(self, symtab):
        return  []

class AccesoMatrix:
    
    def __init__(self, identif,expresion,expresion2):
        self.identif=identif
        self.expresion = expresion
        self.expresion2 = expresion2

    def imprimir(self,sangria):
      return str()
    # def imprimir(self, sangria):
    #     prt = "\n"+ sangria + "ASIGNACION DE FILA O COLUMNA"
    #     sangria = sangria + "  "  
    #     prt = prt + "\n"+ sangria + "variable: " + self.identif.imprimir(sangria)
    #     prt = prt + "\n"+ sangria + " fila:" + self.expresion.imprimir(sangria) 
    #     prt = prt + "\n"+ sangria + " columna: " + self.expresion2.imprimir(sangria) 
    #     return prt

class DeclMatrix:
    
    def __init__(self, identif,expresion,expresion2):
        self.identif=identif
        self.expresion = expresion
        self.expresion2 = expresion2

    def imprimir(self,sangria):
      return str()
    # def imprimir(self, sangria):
    #     prt = "\n"+ sangria + "MATRIX"
    #     sangria = sangria + "  "  
    #     prt = prt + "\n"+ sangria + "fila:" + self.expresion.imprimir(sangria) 
    #     prt = prt + "\n"+ sangria + "columna: " + self.expresion2.imprimir(sangria) 
    #     prt = prt + "\n"+ sangria + "variable: " + self.identif.imprimir(sangria)
    #     return prt

class DeclRowCol:
    
    def __init__(self, identif,expresion):
        self.identif=identif
        self.expresion = expresion
        self.tablasimbolos = None

    def imprimir(self,sangria):
      return str()
    # def imprimir(self, sangria):
    #     prt = "\n"+ sangria + "COL o ROW"
    #     sangria = sangria + "   "  
    #     prt = prt + "\n"+ sangria + " fila o columna:" + self.expresion.imprimir(sangria) 
    #     prt = prt + "\n"+ sangria + "  variable: " + self.identif.imprimir(sangria)
    #     return prt

class Funcion:
    def __init__(self, id_, lista_param, tipo, lista_inst):
        self.id=id_
        self.tablasimbolos = lista_param
        self.tiporetorno = tipo
        self.lista_inst = lista_inst

    def imprimir(self,sangria):
      return str()
    # def immprimir(self, sangria):
    #         return []

    def verificar(self, symtab):
        self.tablasimbolos.setpadretabla(symtab) 
        auxlista = self.lista_inst.set_lista()
        errores= self.tablasimbolos.getErrores()
        for inst in auxlista:
            temporal = inst.verificar(self.tablasimbolos)
            if (temporal is not None):
              errores = errores + temporal
        return self.verificarVariables() + errores