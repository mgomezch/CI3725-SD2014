# -*- coding: UTF-8 -*-

# Clase: Simbolo
# Descripción: Provepe funciones para el manejo de los símbolos que figuran en
#              programas de Trinity
class Simbolo:

# FUNCIONES PARA EL MANEJO DE LOS SÍMBOLOS

    # Inicializa un nuevo símbolo con un nombre dado y posibilidad de modificación
    def __init__(self, nombre,modif):
        self.nombre = nombre
        self.tipo = None
        self.valor = None
        self.fila = 0
        self.columna = 0
        self.modificable = modif
        self.usada = 0

    # Coloca un tipo dado al símbolo en cuestión
    def setTipo(self, tipo):
        self.tipo = tipo

    # Coloca un valor dado a la columna
    def getColumna(self, columna):
        return self.columna

    # Coloca un valor dado a la fila
    def getFila(self, fila):
        return self.fila

    # Coloca un valor dado a la columna
    def setColumna(self, columna):
        self.columna = columna

    # Coloca un valor dado a la fila
    def setFila(self, fila):
        self.fila = fila

    # Coloca un valor dado al símbolo en cuestión
    def setValor(self, valor):
        self.valor = valor
        self.usada = 1

    # Imprime un símbolo con su tipo
    def imprimir(self, sangria):
        return " variable: " + self.nombre.identif + " | tipo: " + self.tipo
        # return "variable: " + str(self.nombre.identif) + " | tipo: " + str(self.tipo) + "  " + str(self.valor)

    # Determina si un símbolo es igual al símbolo en cuestión
    def equals(self, var):
        return (self.nombre.identif == var)

    # Retorna el nombre del símbolo en cuestión
    def getNombre(self):
        return self.nombre.identif

    # Retorna el tipo del símbolo en cuestión
    def getTipo(self):
        return self.tipo

    # Retorna el valor del símbolo en cuestión
    def getValor(self):
        return self.valor

    # Retorna si el símbolo en cuestión se puede modificar o no
    def getModificable(self):
        return self.modificable

# Clase: SymTable
# Descripción: da lugar a una serie de acciones exigidas para manejar la tabla
#              de símbolos. La tabla de símbolos se implementa a través de una
#              lista.
class SymTable:

# FUNCIONES PARA EL MANEJO DE LA TABLA DE SÍMBOLOS:

    # Inicializa una tabla de símbolos con la lista vacía. No se añaden errores
    # hasta el momento y el padre es nulo.
    def __init__(self):
        self.tabla = []
        self.tablapadre = None
        self.errores = []

    # Inserta en la tabla de símbolos una nueva lista de símbolos con su tipo
    # correspondiente
    def insert(self, list_sym, tipo):

        lista_aux = list_sym.set_lista()

        for sym in lista_aux:
           sym.setTipo(tipo)     
        self.tabla = lista_aux

    # Concatena la tabla actual con una tabla auxiliar dada
    def concatenar(self, auxtable):

        self.tabla = self.tabla + auxtable.tabla
        tamano= len(self.tabla)
        i=0
        errores= [] 
        auxlist = []
        while(i<tamano):
            j=0
            while(j<=i):
                if(self.tabla[i].equals(self.tabla[j].getNombre())):
                    if(j<i):
                        self.errores.append("ERROR en la linea "+ \
                        str(self.tabla[i].nombre.linea) + ", columna " + \
                        str(self.tabla[i].nombre.columna)  + \
                        ": La variable \""+str(self.tabla[i].nombre.identif).lower()+ \
                        "\" ya ha sido declarada")
                        break 
                    auxlist.append(self.tabla[i])
                j=j+1
            i=i+1            
        self.tabla = auxlist 
                     
    # Elimina todas las ocurrencias de una variable dada en la tabla de símbolos
    def delete(self, var):

        tamano = len(self.tabla)
        i=0
        while(i<tamano): 
            if (self.tabla[i].equals(var)):
                del self.tabla[i]
                return True 
            i=i+1
        return False 

    # Cambia el valor de una variable dada por uno nuevo.
    def update(self, var, valor):

        tamano = len(self.tabla)
        i=0
        while(i<tamano): 
            if (self.tabla[i].equals(var)):
                self.tabla[i].setValor(valor)
                return True 
            i=i+1
        return False 
        
    # Determina si una variable es miembro de la tabla de símbolos en cuestión
    def isMember(self, var):

        for i in self.tabla:

            if (i.equals(var)):
               return True

        if (not(self.tablapadre is None)):
            return self.tablapadre.find(var)

        return False        

    # Retorna la posición en la tabla de símbolos en la que se encuentra una 
    # variable dada.
    def find(self, var):
        self.imprimir(" ")
        for i in self.tabla:
            if (i.equals(var)):
               return i

        if (not(self.tablapadre is None)):
            return self.tablapadre.find(var)

        return None

    # Coloca como padre de la tabla de símbolos en cuestión a una tabla dada
    def setpadretabla(self, tabla):
        self.tablapadre = tabla

    # Retorna los errores que conciernen a la tabla de símbolos en cuestión
    def getErrores(self):
        return self.errores

    # Imprime en pantalla la tabla de símbolos en cuestión
    def imprimir(self, sangria): 
        prt = "\n" + sangria +"Tabla de Simbolos:"
        for i in self.tabla:
            prt = prt +"\n" + sangria + i.imprimir(sangria)
        return prt
    # def imprimir(self, sangria): 
    #     prt = "\n"+sangria+"TABLA DE SIMBOLOS"
    #     for i in self.tabla:
    #         prt = prt +"\n"+sangria + i.imprimir(sangria)

    #     return prt

