#!/usr/bin/env ruby 
# -*- coding: utf-8 -*-
# David Goudet 08-10479
# Susana Charara 08-10223

class AlcanceFunciones
	def initialize(padre, tipo, nombre)
		@tabla = {}		
		@hijos = []
    	@padre = padre
		@tipo = tipo
		@nombre = nombre
		@nombresParametros = []
		@tiposParametros = Array.new
    	@funciones = {}
    	@funciones[nombre] = tipo # Para recursion    	
    	@accesoFunciones = {} # SOlo para acceder a funciones
    	@accesoFunciones[nombre] = self
  	end
	def agregarTabla(nombre, tipo)
		pertenece = self.buscarTabla(nombre)
		if pertenece.nil?
			@tabla[nombre] = tipo
	    else	    	
	    	raise ErrorVariableYaDefinida::new(nombre)
	    end
	    #puts tablaTo_s
	end
	def naceHijoTabla(hijo)
		@hijos << hijo
	end
	def dameFuncion(nombre)
		if @accesoFunciones.has_key?(nombre) then
			return @accesoFunciones[nombre]
		else
			unless @padre.nil? then
	      		return @padre.dameFuncion(nombre)
	      	else
	      		return nil
	      	end
	    	
	    end
	end
	def buscarFuncion(nombre)
	    if @funciones.has_key?(nombre) then
	    	return @funciones[nombre]
	    else
	      	return nil
	    end
	end
	def buscarTablaLocal(nombre)
	    if @tabla.has_key?(nombre) then
	    	return @tabla[nombre]
	    else
	    	return nil
	    end
	end
	def buscarTabla(nombre)
	    if @tabla.has_key?(nombre) then
	    	return @tabla[nombre]
	    elsif @padre.nil? then
	      	return nil
	    else
	    	#puts "ho"
			return @padre.buscarTabla(nombre)
	    end
	end
	def dameFuncion(nombre)

		if @accesoFunciones.has_key?(nombre) then
			return @accesoFunciones[nombre]
		else
			unless @padre.nil? then
	      		return @padre.dameFuncion(nombre)
	      	else
	      		return nil
	      	end
	    	
	    end
	end
	def agregarParametro(nombre,tipo)
		agregarTabla(nombre, tipo)
		@tiposParametros << tipo
	end
	def buscarTabla(nombre)
	    if @tabla.has_key?(nombre) then
	    	return @tabla[nombre]
	    else
	    	return nil
	    end
	end
	def retornaParametros
		return @nombresParametros,@tiposParametros
	end
 
	def verificaParametros(listaArgsTipos,listaArgsNombres,listaParam)
		if (listaArgsTipos.nil? || listaArgsTipos.length == 0) && (not (listaParam.nil? || listaParam.length == 0))
			raise ErrorNumeroParametros::new(@nombre)
		elsif listaParam.nil? & (not listaArgsTipos.nil?)
			raise ErrorNumeroParametros::new(@nombre)
		elsif (not (listaParam.nil? || listaParam.length == 0)) && (not (listaArgsTipos.nil? || listaArgsTipos.length == 0))
			numArgs = listaArgsTipos.length
			numParam = listaParam.length
			headArgs = listaArgsTipos[0]
			headParam = listaParam[0]
				if headArgs.to_s.eql? headParam.to_s then
					tailArgsTipos = listaArgsTipos[1..numArgs]
					tailArgsNombres = listaArgsNombres[1..numArgs]
					tailParam = listaParam[1..numParam]
					verificaParametros(tailArgsTipos,tailArgsNombres,tailParam)
				else
					raise ErrorTipo::new(listaArgsNombres[0],headArgs,headParam)
				end
			else
		end

	end
	def simbolosTabla
		@string = ""
		@tabla.each do |k,v|
			@string << "\"#{k}\": \"#{v.to_s}\","
		end
		return @string
	end
	def hijosTabla
		@str = ""
		n = @hijos.length
		for i in (0..n-1)
			if i == n-1 then				
				@str << @hijos[i].tablaTo_s
			else
				@str << @hijos[i].tablaTo_s + ","
			end
		end
		return @str
	end

	def tablaTo_s
		
		return "{#{simbolosTabla} \"Hijos\":  [#{hijosTabla}]}"
	end



	def tipo
		return @tipo
	end
	def esFuncion
		return true
	end
end
