#!/usr/bin/env ruby 
# -*- coding: utf-8 -*-
# David Goudet 08-10479
# Susana Charara 08-10223
require_relative 'SymTable'
require_relative 'AlcanceFunciones'
require_relative 'clasesTipos'
require_relative 'erroresContexto'

class AST; end
class Programa < AST 
	def initialize(program)
    	@program = program
    end
    def check()
    	@program.check($tabla)    	
	end	
end

class ProgConFuncion < AST
	def initialize(funciones, instrucciones)		
    	@funciones = funciones
    	@instrucciones = instrucciones
    end
    def check(tabla)
        @funciones.check(tabla)
        unless @instrucciones.nil? then
        	@instrucciones.check(tabla)
        end
    end
end
class ProgSinFuncion < AST
	def initialize(instrucciones)
    	@instrucciones = instrucciones
    end

    def check(tabla)
    	unless @instrucciones.nil? then
        	@instrucciones.check(tabla)
        end
    end
end
class ListaFunciones
	def initialize(primeraFuncion, restoFunciones)
		@primeraFuncion = primeraFuncion
		@restoFunciones = restoFunciones
	end
	def check(tabla)
		@primeraFuncion.check(tabla)
		unless @restoFunciones.nil? then
			@restoFunciones.check(tabla)
		end
	end
end
class FuncionConParametro
	def initialize(nombre, param, rtrn, instrucciones)
		@nombre = nombre
		@param = param
		@rtrn = rtrn
		@instrucciones = instrucciones
	end
	def check(tabla)
		@tipo = @rtrn.check(tabla)		
		a = AlcanceFunciones::new(tabla,@tipo,@nombre.to_s)
		tabla.agregarFuncion(@nombre.to_s,@tipo,a)
		@param.check(a)

		unless @instrucciones.nil? then
			@instrucciones.check(a)
		end
	end
end

class FuncionSinParametro
	def initialize(nombre, rtrn, instrucciones)
		@nombre = nombre
		@rtrn = rtrn
		@instrucciones = instrucciones	
	end
	def check(tabla)
		@tipo = @rtrn.check(tabla)
		a = AlcanceFunciones::new(tabla,@tipo,@nombre.to_s)

		tabla.agregarFuncion(@nombre.to_s,@tipo,a)
		#@param.check(a)
		unless @instrucciones.nil? then
			@instrucciones.check(a)
		end
	end
end
class ParametroFuncion
	def initialize(tipo, parametro)
		@tipo = tipo
		@parametro = parametro
	end
	def check(tabla)
		t = @tipo.check(tabla)
		n = @parametro.to_s
		tabla.agregarParametro(n,t)
	end
end
class ListaParametros
	def initialize(primerParametro, restoParametros)
		@primerParametro = primerParametro
		@restoParametros = restoParametros
	end
	def check(tabla)
		@primerParametro.check(tabla)
		unless @restoParametros.nil? then
			@restoParametros.check(tabla)
		end
	end
end

class Matrix
	def initialize(filas, columnas)
		@filas = filas
		@columnas = columnas
	end
	def check(tabla)
		typeFil = @filas.check(tabla)
		typeCol = @columnas.check(tabla)
		if (typeFil.is_a?(TipoNum) && typeCol.is_a?(TipoNum)) # Se chequea que las dimensiones sean numeros
			f = @filas.to_s.to_f
			c = @columnas.to_s.to_f
			if (f <= 0 || c <= 0 || (f - f.to_i != 0) || (c - c.to_i != 0)) # Se chequea que las dimensiones sean enteros positivos
				raise ErrorDimensionesMatriz::new()
			else
				return TipoMatrix::new(@filas.to_s, @columnas.to_s)
			end
		elsif not typeFil.is_a?(TipoNum)
			raise ErrorTipo::new(@filas, typeFil,TipoNum::new())
		else 
			raise ErrorTipo::new(@columnas, typeCol,TipoNum::new())
		end
	end
	def to_s
		return "matrix"
	end
end
class VectorFila
	def initialize(columnas)
		@columnas = columnas
	end

	def check(tabla)
		typeCol = @columnas.check(tabla)
		if (typeCol.is_a?(TipoNum)) # Se chequea que las dimensiones sean numeros
			c = @columnas.to_s.to_f
			if (c <= 0 ||(c - c.to_i != 0)) # Se chequea que las dimensiones sean enteros positivos
				raise ErrorDimensionesMatriz::new()
			else
				return TipoMatrix::new("1", @columnas.to_s)
			end
		elsif not typeFil.is_a?(TipoNum)
			raise ErrorTipo::new(@columnas, @typeCol,TipoNum::new())
		end
	end
	def tipo
		return "matrix(1,#{@columnas.to_s})"
	end
end
class VectorColumna
	def initialize(filas)
		@filas = filas
	end	
	def check(tabla)
		typeFil = @filas.check(tabla)
		if (typeFil.is_a?(TipoNum)) # Se chequea que las dimensiones sean numeros
			f = @filas.to_s.to_f
			if (f <= 0 ||(f - f.to_i != 0)) # Se chequea que las dimensiones sean enteros positivos
				raise ErrorDimensionesMatriz::new()
			else
				return TipoMatrix::new(@filas.to_s, "1")
			end
		elsif not typeFil.is_a?(TipoNum)
			raise ErrorTipo::new(@filas, @typeFil,TipoNum::new())
		end
	end
	def tipo
		return "matrix(#{@filas.to_s},1)"
	end
end
class LiteralMatricial
	def initialize(valor)
		@valor = valor
	end
	def check(tabla)
		return @valor.check(tabla)
	end

	def to_s
		"LiteralMatricial"
	end
end
class ColumnasLiteralMatricial
	def initialize(primeraColumna, restoColumnas, numeroCol)
		@primeraColumna = primeraColumna
		@restoColumnas = restoColumnas
		@numeroCol = numeroCol
	end
	def check(tabla)
		$nCol = $nCol + 1
		tipo = @primeraColumna.check(tabla)
		unless tipo.is_a?(TipoNum)
			raise ErrorTipo::new(@primeraColumna, tipo,TipoNum::new())
		end
		unless @restoColumnas.nil? then
			tipo = @restoColumnas.check(tabla)
		end
	end
	def to_s
		"#{@primeraColumna.to_s}"
	end

end
class FilasLiteralMatricial
	def initialize(primeraFila,restoFilas)
		@primeraFila = primeraFila
		@restoFilas = restoFilas
		$numeroFilas = 0
		$numeroColumnas = 0
	end
	def check(tabla)
		$nFil = $nCol
		$nCol = 0
		$numeroDeFilas = $numeroDeFilas + 1
		@primeraFila.check(tabla)
		numeroColumnas = $nCol
		unless $nFil == 0 then
			if $nFil != numeroColumnas 
						#$nCol
				raise ErrorLiteralMatricial::new()
			end
		end
		
		unless @restoFilas.nil? then
			@restoFilas.check(tabla)
		else
			t = TipoMatrix::new($numeroDeFilas,$nCol)
			$numeroFilas = $numeroDeFilas
			$numeroColumnas = $nCol
			$nCol = 0
			$nFil = 0
			$numeroDeFilas = 0
			return t
		end

	end
	def to_s
		"#{@primeraColumna.to_s}"
	end
end
class Entero
	def initialize(valor)
		@valor = valor
	end
	def to_s
		"#{@valor.to_s}"
	end
	def check(tabla)
		return TipoNum::new()
	end
	def tipo
		"number"
	end
end
class UsoVariable
	def initialize(valor)
		@valor = valor
	end
	def check(tabla)
		n = @valor.to_s
		existe = tabla.buscarTabla(n)
		if existe.nil?
			raise ErrorVariableNoExiste::new(n)
		else
			return existe
		end
	end
	def to_s
		"#{@valor.to_s}"
	end
end

class Variable
	def initialize(valor)
		@valor = valor
	end
	def to_s
		"#{@valor.to_s}"
	end
end
class Number
	def initialize(valor)
		@valor = valor
	end
	def check(tabla)
		return TipoNum::new()
	end
end
class Boolean
	def initialize(valor)
		@valor = valor
	end
	def check(tabla)
		return TipoBool::new()
	end
end
class MenosUnario
	def initialize(expr)
		@expr = expr
	end
	def check(tabla)
		@tipoActual = @expr.check(tabla)
		unless @tipoActual.is_a?(TipoAritmetico) then
			raise ErrorTipo2::new(@expr, @tipoActual,TipoNum::new(),Matrix::new(0,0))
		end
		return @tipoActual
	end	
	def to_s
		"-#{@expr.to_s}"
	end
end
class Suma 
	def initialize(opIzq, opDer)
		@opIzq = opIzq
		@opDer = opDer
	end
	def check(tabla)
		@tipoIzq = @opIzq.check(tabla)
		@tipoDer = @opDer.check(tabla)
		unless (@tipoIzq.is_a?(TipoAritmetico) && @tipoDer.is_a?(TipoAritmetico)) then
			if not @tipoIzq.is_a?(TipoAritmetico)
				raise ErrorTipo2::new(@opIzq, @tipoIzq, TipoNum::new(), Matrix::new(0,0))
			else
				raise ErrorTipo2::new(@opDer, @tipoDer, TipoNum::new(), Matrix::new(0,0))
			end
		end
		unless @tipoIzq.to_s.eql? @tipoDer.to_s then
			raise ErrorTipo::new(@opDer,@tipoDer,@tipoIzq)
		else
			return @tipoIzq
		end
	end
	def to_s
		"#{@opIzq.to_s} + #{@opDer.to_s}"
	end
end
class Resta  
	def initialize(opIzq, opDer)
		@opIzq = opIzq
		@opDer = opDer
	end
	def check(tabla)
		@tipoIzq = @opIzq.check(tabla)
		@tipoDer = @opDer.check(tabla)
		unless (@tipoIzq.is_a?(TipoAritmetico) && @tipoDer.is_a?(TipoAritmetico)) then
			if not @tipoIzq.is_a?(TipoAritmetico)
				raise ErrorTipo2::new(@opIzq, @tipoIzq, TipoNum::new(), Matrix::new(0,0))
			else
				raise ErrorTipo2::new(@opDer, @tipoDer, TipoNum::new(), Matrix::new(0,0))
			end
		end
		unless @tipoIzq.to_s.eql? @tipoDer.to_s then
			raise ErrorTipo::new(@opDer,@tipoDer,@tipoIzq)
		else
			return @tipoIzq
		end
	end	
	def to_s
		"#{@opIzq.to_s} - #{@opDer.to_s}"
	end
end
class Multiplicacion
	def initialize(opIzq, opDer)
		@opIzq = opIzq
		@opDer = opDer
	end
	def check(tabla)
		@tipoIzq = @opIzq.check(tabla)
		@tipoDer = @opDer.check(tabla)
		unless (@tipoIzq.is_a?(TipoAritmetico)) then
				
				raise ErrorTipo2::new(@opIzq, @tipoIzq, TipoNum::new(), Matrix::new(0,0))
		end
		unless (@tipoDer.is_a?(TipoAritmetico)) then
				raise ErrorTipo2::new(@opDer, @tipoDer, TipoNum::new(), Matrix::new(0,0))
		end
		if @tipoIzq.is_a?(TipoNum) then
			unless @tipoDer.is_a?(TipoNum) then
				raise ErrorTiposDistintos::new(@opIzq, @opDer)
			end
		elsif @tipoIzq.is_a?(TipoMatrix)
			unless @tipoDer.is_a?(TipoMatrix) then
				raise ErrorTiposDistintos::new(@opIzq, @opDer)
			end
			@filasIzq = @tipoIzq.dameFilas
			@filasDer = @tipoDer.dameFilas
			@columnasIzq = @tipoIzq.dameColumnas
			@columnasDer = @tipoIzq.dameColumnas
			if @columnasIzq != @filasDer then

				raise ErrorTipo::new(@opDer, @tipoDer, TipoMatrix::new(@columnasIzq,TipoNum::new()))
			else
				return @tipoIzq
			end
		end
		return @tipoIzq
	end
	def to_s
		"#{@opIzq.to_s} * #{@opDer.to_s}"
	end
end
class Division
	def initialize(opIzq, opDer)
		@opIzq = opIzq
		@opDer = opDer
	end
	def check(tabla)
		@tipoIzq = @opIzq.check(tabla)
		@tipoDer = @opDer.check(tabla)
		unless (@tipoIzq.is_a?(TipoNum) && @tipoDer.is_a?(TipoNum)) then
			if not @tipoIzq.is_a?(TipoNum)
				raise ErrorTipo::new(@opIzq, @tipoIzq, TipoNum::new())
			else
				raise ErrorTipo::new(@opDer, @tipoDer, TipoNum::new())
			end
		else
			return @tipoIzq
		end
	end
end
class Modulo
	def initialize(opIzq, opDer)
		@opIzq = opIzq
		@opDer = opDer
	end
	def check(tabla)
		@tipoIzq = @opIzq.check(tabla)
		@tipoDer = @opDer.check(tabla)
		unless (@tipoIzq.is_a?(TipoNum) && @tipoDer.is_a?(TipoNum)) then
			if not @tipoIzq.is_a?(TipoNum)
				raise ErrorTipo::new(@opIzq, @tipoIzq, TipoNum::new())
			else
				raise ErrorTipo::new(@opDer, @tipoDer, TipoNum::new())
			end
		else
			return @tipoIzq
		end
	end
end
class Div
	def initialize(opIzq, opDer)
		@opIzq = opIzq
		@opDer = opDer
	end
	def check(tabla)
		@tipoIzq = @opIzq.check(tabla)
		@tipoDer = @opDer.check(tabla)
		unless (@tipoIzq.is_a?(TipoNum) && @tipoDer.is_a?(TipoNum)) then
			if not @tipoIzq.is_a?(TipoNum)
				raise ErrorTipo::new(@opIzq, @tipoIzq, TipoNum::new())
			else
				raise ErrorTipo::new(@opDer, @tipoDer, TipoNum::new())
			end
		else
			return @tipoIzq
		end
	end
end
class Mod
	def initialize(opIzq, opDer)
		@opIzq = opIzq
		@opDer = opDer
	end
	def check(tabla)
		@tipoIzq = @opIzq.check(tabla)
		@tipoDer = @opDer.check(tabla)
		unless (@tipoIzq.is_a?(TipoNum) && @tipoDer.is_a?(TipoNum)) then
			if not @tipoIzq.is_a?(TipoNum)
				raise ErrorTipo::new(@opIzq, @tipoIzq, TipoNum::new())
			else
				raise ErrorTipo::new(@opDer, @tipoDer, TipoNum::new())
			end
		else
			return @tipoIzq
		end
	end
end
class Traspuesta
	def initialize(matriz)
		@matriz = matriz
	end
	def check(tabla)
		@tipo = @matriz.check(tabla)
		if @tipo.is_a?(TipoMatrix)
			filas = @tipo.dameFilas
			columnas = @tipo.dameColumnas
			return TipoMatrix::new(columnas,filas)
		else
			raise ErrorTipo::new(@matriz, @tipo, Matrix::new(0,0))
		end
	end
end
class SumaCruz
	def initialize(opIzq, opDer)
		@opIzq = opIzq
		@opDer = opDer
	end
	def check(tabla)
		@tipoIzq = @opIzq.check(tabla)
		@tipoDer = @opDer.check(tabla)
		if @tipoIzq.is_a?(TipoNum)
			if @tipoDer.is_a?(TipoMatrix)
				return @tipoDer
			else
				raise ErrorTipo::new(@opDer, @tipoDer, Matrix::new(0,0))
			end
		elsif @tipoIzq.is_a?(TipoMatrix)
			if @tipoDer.is_a?(TipoNum)
				return @tipoIzq
			else
				raise ErrorTipo::new(@opDer, @tipoDer, TipoNum::new())
			end
		else
			raise ErrorTipoCruz::new(@opIzq,@opDer,@tipoIzq,@tipoDer,TipoNum::new,Matriz::new(0,0))
		end
	end
end
class RestaCruz
	def initialize(opIzq, opDer)
		@opIzq = opIzq
		@opDer = opDer
	end
	def check(tabla)
		@tipoIzq = @opIzq.check(tabla)
		@tipoDer = @opDer.check(tabla)
		if @tipoIzq.is_a?(TipoNum)
			if @tipoDer.is_a?(TipoMatrix)
				return @tipoDer
			else
				raise ErrorTipo::new(@opDer, @tipoDer, Matrix::new(0,0))
			end
		elsif @tipoIzq.is_a?(TipoMatrix)
			if @tipoDer.is_a?(TipoNum)
				return @tipoIzq
			else
				raise ErrorTipo::new(@opDer, @tipoDer, TipoNum::new())
			end
		else
			raise ErrorTipoCruz::new(@opIzq,@opDer,@tipoIzq,@tipoDer,TipoNum::new,Matrix::new(0,0))
		end
	end
end
class MultiplicacionCruz
	def initialize(opIzq, opDer)
		@opIzq = opIzq
		@opDer = opDer
	end
	def check(tabla)
		@tipoIzq = @opIzq.check(tabla)
		@tipoDer = @opDer.check(tabla)
		if @tipoIzq.is_a?(TipoNum)
			if @tipoDer.is_a?(TipoMatrix)
				return @tipoDer
			else
				raise ErrorTipo::new(@opDer, @tipoDer, Matrix::new(0,0))
			end
		elsif @tipoIzq.is_a?(TipoMatrix)
			if @tipoDer.is_a?(TipoNum)
				return @tipoIzq
			else
				raise ErrorTipo::new(@opDer, @tipoDer, TipoNum::new())
			end
		else
			raise ErrorTipoCruz::new(@opIzq,@opDer,@tipoIzq,@tipoDer,TipoNum::new(),Matrix::new(0,0))
		end
	end
end
class DivisionCruz
	def initialize(opIzq, opDer)
		@opIzq = opIzq
		@opDer = opDer
	end
	def check(tabla)
		@tipoIzq = @opIzq.check(tabla)
		@tipoDer = @opDer.check(tabla)
		if @tipoIzq.is_a?(TipoNum)
			if @tipoDer.is_a?(TipoMatrix)
				return @tipoDer
			else
				raise ErrorTipo::new(@opDer, @tipoDer, Matrix::new(0,0))
			end
		elsif @tipoIzq.is_a?(TipoMatrix)
			if @tipoDer.is_a?(TipoNum)
				return @tipoIzq
			else
				raise ErrorTipo::new(@opDer, @tipoDer, TipoNum::new())
			end
		else
			raise ErrorTipoCruz::new(@opIzq,@opDer,@tipoIzq,@tipoDer,TipoNum::new,Matriz::new(0,0))
		end
	end
end
class ModuloCruz
	def initialize(opIzq, opDer)
		@opIzq = opIzq
		@opDer = opDer
	end
	def check(tabla)
		@tipoIzq = @opIzq.check(tabla)
		@tipoDer = @opDer.check(tabla)
		if @tipoIzq.is_a?(TipoNum)
			if @tipoDer.is_a?(TipoMatrix)
				return @tipoDer
			else
				raise ErrorTipo::new(@opDer, @tipoDer, Matrix::new(0,0))
			end
		elsif @tipoIzq.is_a?(TipoMatrix)
			if @tipoDer.is_a?(TipoNum)
				return @tipoIzq
			else
				raise ErrorTipo::new(@opDer, @tipoDer, TipoNum::new())
			end
		else
			raise ErrorTipoCruz::new(@opIzq,@opDer,@tipoIzq,@tipoDer,TipoNum::new,Matriz::new(0,0))
		end
	end
end
class DivCruz
	def initialize(opIzq, opDer)
		@opIzq = opIzq
		@opDer = opDer
	end
	def check(tabla)
		@tipoIzq = @opIzq.check(tabla)
		@tipoDer = @opDer.check(tabla)
		if @tipoIzq.is_a?(TipoNum)
			if @tipoDer.is_a?(TipoMatrix)
				return @tipoDer
			else
				raise ErrorTipo::new(@opDer, @tipoDer, Matrix::new(0,0))
			end
		elsif @tipoIzq.is_a?(TipoMatrix)
			if @tipoDer.is_a?(TipoNum)
				return @tipoIzq
			else
				raise ErrorTipo::new(@opDer, @tipoDer, TipoNum::new())
			end
		else
			raise ErrorTipoCruz::new(@opIzq,@opDer,@tipoIzq,@tipoDer,TipoNum::new,Matriz::new(0,0))
		end
	end
end
class ModCruz
	def initialize(opIzq, opDer)
		@opIzq = opIzq
		@opDer = opDer
	end
	def check(tabla)
		@tipoIzq = @opIzq.check(tabla)
		@tipoDer = @opDer.check(tabla)
		if @tipoIzq.is_a?(TipoNum)
			if @tipoDer.is_a?(TipoMatrix)
				return @tipoDer
			else
				raise ErrorTipo::new(@opDer, @tipoDer, Matrix::new(0,0))
			end
		elsif @tipoIzq.is_a?(TipoMatrix)
			if @tipoDer.is_a?(TipoNum)
				return @tipoIzq
			else
				raise ErrorTipo::new(@opDer, @tipoDer, TipoNum::new())
			end
		else
			raise ErrorTipoCruz::new(@opIzq,@opDer,@tipoIzq,@tipoDer,TipoNum::new,Matriz::new(0,0))
		end
	end
end
class True
	def check(tabla)
		return TipoBool::new()
	end
	def to_s
		"true"
	end
	def tipo
		"boolean"
	end

end
class False
	def check(tabla)
		return TipoBool::new()
	end
	def to_s
		"boolean"
	end
	def tipo
		"boolean"
	end
end
class Not
	def initialize(expr)
		@expr = expr
	end
	def check(tabla)
		tipoActual = @expr.check(tabla)
		unless tipoActual.is_a?(TipoBool) then
			raise ErrorTipo::new(@expr, tipoActual,TipoBool::new())
		end
		return tipoActual
	end
	def to_s
		"not #{@expr.to_s}"
	end

end
class And
	def initialize(opIzq, opDer)
		@opIzq = opIzq
		@opDer = opDer
	end
	def check(tabla)
		@tipoIzq = @opIzq.check(tabla)
		@tipoDer = @opDer.check(tabla)
		unless @tipoIzq.is_a?(TipoBool) then
			raise ErrorTipo::new(@opIzq, @tipoIzq,TipoBool::new())
		end
		unless @tipoDer.is_a?(TipoBool) then
			raise ErrorTipo::new(@opDer, @tipoDer,TipoBool::new())
		end
		return @tipoIzq
	end
end
class Or	
	def initialize(opIzq, opDer)
		@opIzq = opIzq
		@opDer = opDer
	end
	def check(tabla)
		@tipoIzq = @opIzq.check(tabla)
		@tipoDer = @opDer.check(tabla)
		unless @tipoIzq.is_a?(TipoBool) then
			raise ErrorTipo::new(@opIzq, @tipoIzq,TipoBool::new())
		end
		unless @tipoDer.is_a?(TipoBool) then
			raise ErrorTipo::new(@opDer, @tipoDer,TipoBool::new())
		end
		return @tipoIzq
	end
end
class Equivalencia
	def initialize(opIzq, opDer)
		@opIzq = opIzq
		@opDer = opDer
	end
	def check(tabla)
		@tipoIzq = @opIzq.check(tabla)
		@tipoDer = @opDer.check(tabla)
		unless @tipoIzq.to_s.eql?(@tipoDer.to_s) then
			raise ErrorTipo::new(@opDer, @tipoDer,@tipoIzq)
		end
		return TipoBool::new()
	end
end
class Inequivalencia
	def initialize(opIzq, opDer)
		@opIzq = opIzq
		@opDer = opDer
	end
	def check(tabla)
		@tipoIzq = @opIzq.check(tabla)
		@tipoDer = @opDer.check(tabla)
		unless @tipoIzq.to_s.eql? @tipoDer.to_s then
			raise ErrorTipo::new(@opDer, @tipoDer,@tipoIzq)
		end
		return TipoBool::new()
	end
end

class Menor
	def initialize(opIzq, opDer)
		@opIzq = opIzq
		@opDer = opDer
	end
	def check(tabla)
		@tipoIzq = @opIzq.check(tabla)
		@tipoDer = @opDer.check(tabla)
		unless (@tipoIzq.is_a?(TipoNum) && @tipoDer.is_a?(TipoNum)) then
			if not @tipoIzq.is_a?(TipoNum)
				raise ErrorTipo::new(@opIzq, @tipoIzq, TipoNum::new())
			else
				raise ErrorTipo::new(@opDer, @tipoDer, TipoNum::new())
			end
		else
			return TipoBool::new()
		end
	end
end
class MenorOIgual
	def initialize(opIzq, opDer)
		@opIzq = opIzq
		@opDer = opDer
	end
	def check(tabla)
		@tipoIzq = @opIzq.check(tabla)
		@tipoDer = @opDer.check(tabla)
		unless (@tipoIzq.is_a?(TipoNum) && @tipoDer.is_a?(TipoNum)) then
			if not @tipoIzq.is_a?(TipoNum)
				raise ErrorTipo::new(@opIzq, @tipoIzq, TipoNum::new())
			else
				raise ErrorTipo::new(@opDer, @tipoDer, TipoNum::new())
			end
		else
			return TipoBool::new()
		end
	end
end
class Mayor
	def initialize(opIzq, opDer)
		@opIzq = opIzq
		@opDer = opDer
	end
	def check(tabla)
		@tipoIzq = @opIzq.check(tabla)
		@tipoDer = @opDer.check(tabla)
		unless (@tipoIzq.is_a?(TipoNum) && @tipoDer.is_a?(TipoNum)) then
			if not @tipoIzq.is_a?(TipoNum)
				raise ErrorTipo::new(@opIzq, @tipoIzq, TipoNum::new())
			else
				raise ErrorTipo::new(@opDer, @tipoDer, TipoNum::new())
			end
		else
			return TipoBool::new()
		end
	end
end
class MayorOIgual
	def initialize(opIzq, opDer)
		@opIzq = opIzq
		@opDer = opDer
	end
	def check(tabla)
		@tipoIzq = @opIzq.check(tabla)
		@tipoDer = @opDer.check(tabla)
		unless (@tipoIzq.is_a?(TipoNum) && @tipoDer.is_a?(TipoNum)) then
			if not @tipoIzq.is_a?(TipoNum)
				raise ErrorTipo::new(@opIzq, @tipoIzq, TipoNum::new())
			else
				raise ErrorTipo::new(@opDer, @tipoDer, TipoNum::new())
			end
		else
			return TipoBool::new()
		end
	end
end
class Expresion
	def initialize(expresion)
		@expresion = expresion
	end
	def check(tabla)
		@expresion.check(tabla)
	end
end
class ListaExpresiones 
	def initialize(primeraExpresion, restoExpresiones)
		@primeraExpresion = primeraExpresion
		@restoExpresiones = restoExpresiones
	end
	def check(tabla)
		@primeraExpresion.check(tabla)
		unless @restoExpresiones.nil? then
			@restoExpresiones.check(tabla)
		end
	end
end
class Instruccion
	def initialize(instruccion)
		@instruccion = instruccion
	end
end
class ListaInstrucciones
	def initialize(primeraInstruccion, restoInstrucciones)
		@primeraInstruccion = primeraInstruccion
		@restoInstrucciones = restoInstrucciones
	end
	def check(tabla)
		@primeraInstruccion.check(tabla)
		@restoInstrucciones.check(tabla)

	end
end
class NuevaVariable
	def initialize(valor)
		@valor = valor
	end
	def to_s
		"#{@valor.to_s}"
	end
end

class DeclaracionSinInit
	def initialize(tipo, identificador)
		@tipo = tipo
		@identificador = identificador

	end
	def check(tabla)
		t = @tipo.check(tabla)
		n = @identificador.to_s
		tabla.agregarTabla(n,t)

	end
end
class DeclaracionConInit
	def initialize(tipo, identificador, expresion)
		@tipo = tipo
		@identificador = identificador
		@expresion = expresion
	end
	def check(tabla)		
		t = @tipo.check(tabla)
		n = @identificador.to_s
		e = @expresion.check(tabla)
		#puts t.is_a?(TipoNum)		
		#puts e.is_a?(TipoNum)
		unless t.to_s.eql? e.to_s then
			raise ErrorTipo::new(@expresion, e, t)
		end
		tabla.agregarTabla(n,t)
	end
end
class ListaDeclaraciones
	def initialize(primeraDeclaracion, restoDeclaraciones)
		@primeraDeclaracion = primeraDeclaracion
		@restoDeclaraciones = restoDeclaraciones
	end
	def check(tabla)
		@primeraDeclaracion.check(tabla)
		@restoDeclaraciones.check(tabla)
	end
end
class LiteralCadena
	def initialize(valor)
		@valor = valor
	end
	def check(tabla)
		return "string"
	end
end
class ProyeccionMatriz
	def initialize(expr, fila, columna)
		@expr = expr
		@fila = fila
		@columna = columna
	end
	def check(tabla)
		typeExpr = @expr.check(tabla)
		typeFil = @fila.check(tabla)
		typeCol = @columna.check(tabla)
		unless typeExpr.is_a?(TipoMatrix) then
			raise ErrorTipo::new(@expr,typeExpr,Matrix::new(0,0))
		end
		if (typeFil.is_a?(TipoNum) && typeCol.is_a?(TipoNum)) # Se chequea que las dimensiones sean numeros
			f = @filas.to_s.to_f
			c = @columnas.to_s.to_f
			if (f < 0 || c < 0 || (f - f.to_i != 0) || (c - c.to_i != 0)) # Se chequea que las dimensiones sean enteros positivos
				raise ErrorDimensionesMatriz::new()
			else
				return TipoNum::new()
			end
		elsif not typeFil.is_a?(TipoNum)
			raise ErrorTipo::new(@fila, typeFil,TipoNum::new())
		else 
			raise ErrorTipo::new(@columna, typeCol,TipoNum::new())
		end
	end
end
class ProyeccionVector
	def initialize(expr, vector)
		@expr = expr
		@vector = vector
	end
	def check(tabla)

		typeExpr = @expr.check(tabla)
		typeVector = @vector.check(tabla)		
		unless typeExpr.is_a?(TipoMatrix) then
			raise ErrorTipo::new(@expr,typeExpr,Matrix::new(0,0))
		end
		if (typeVector.is_a?(TipoNum)) # Se chequea que las dimensiones sean numeros
			v = @vector.to_s.to_f
			if (v < 0 || (v - v.to_i != 0) ) # Se chequea que las dimensiones sean enteros positivos
				raise ErrorDimensionesMatriz::new()
			else
				return TipoNum::new()
			end
		else 
			raise ErrorTipo::new(@vector,typeVector,TipoNum::new())
		end

	end
end
class Imprime
	def initialize(string)
		@string = string
	end
	def check(tabla)
		@tipo = @string.check(tabla)
		unless @tipo.is_a?(Tipo) or @tipo.eql? "string" then 
			raise ErrorImpresion::new(@tipo)
		end
	end
end
class Lee
	def initialize(identificador)
		@identificador = identificador
	end
	def check(tabla)
		tipoId = @identificador.check(tabla)
		unless (tipoId.is_a?(TipoNum) || tipoId.is_a?(TipoBool)) then
			raise ErrorTipo2::new(@identificador,tipoId,TipoNum::new(),TipoBool::new())
		end
	end
end
class DeclaracionVariableFor
	def initialize(identificador)
		@tipo = TipoNum::new()
		@identificador = identificador
		@expresion = 1
	end
	def check(tabla)
		t = @tipo
		n = @identificador.to_s
		tabla.agregarTabla(n,t)
	end
end

class BloqueUse
	def initialize(declaraciones, instrucciones)
		@declaraciones = declaraciones
		@instrucciones = instrucciones
	end
	def check(tabla)
		a = Alcance::new(tabla)
		tabla.naceHijoTabla(a)
		unless @declaraciones.nil? then
			@declaraciones.check(a)
		end
		unless @instrucciones.nil? then
			@instrucciones.check(a)
		end
	end
end
class Asignacion
	def initialize(ladoIzq, ladoDer)
		@ladoIzq = ladoIzq
		@ladoDer = ladoDer
	end
	def check(tabla)
		tipoIzq = @ladoIzq.check(tabla)
		tipoDer = @ladoDer.check(tabla)
		unless tipoIzq.to_s.eql? tipoDer.to_s then
			raise ErrorTipo::new(@ladoDer, tipoDer, tipoIzq)
		end
	end
end
class AsignacionMatricial
	def initialize(ladoIzq, ladoDer)
		@ladoIzq = ladoIzq
		@ladoDer = ladoDer
	end
	def check(tabla)
		tipoIzq = @ladoIzq.check(tabla)
		tipoDer = @ladoDer.check(tabla)
		unless tipoDer.is_a?(TipoNum) then
			raise ErrorTipo::new(@ladoDer, tipoDer, TipoNum::new())
		end
		unless tipoIzq.to_s.eql? tipoDer.to_s then
			raise ErrorTipo::new(@ladoDer, tipoDer, tipoIzq)
		end
	end
end
class Lectura; end
class IfThen
	def initialize(expresion,instrucciones)
		@expresion = expresion
		@instrucciones = instrucciones
	end
	def check(tabla)
		tipoExpr = @expresion.check(tabla)
		unless tipoExpr.is_a?(TipoBool) then
			raise ErrorTipo::new(@expresion, tipoExpr,TipoBool::new())
		end
		unless @instrucciones.nil? then
			@instrucciones.check(tabla)
		end
	end
end
class IfThenElse
	def initialize(expresionIf,instruccionesIf,instruccionesElse)
		@expresionIf = expresionIf
		@instruccionesIf = instruccionesIf
		@instruccionesElse = instruccionesElse
	end
	def check(tabla)
		tipoExpr = @expresionIf.check(tabla)		
		unless tipoExpr.is_a?(TipoBool) then
			raise ErrorTipo::new(@expresionIf, tipoExpr,TipoBool::new())
		end

		unless @instruccionesIf.nil?
			@instruccionesIf.check(tabla)
		end
		unless @instruccionesElse.nil?
			@instruccionesElse.check(tabla)
		end
	end
end
class IteracionWhile
	def initialize(expresion, instrucciones)
		@expresion = expresion
		@instrucciones = instrucciones
	end
	def check(tabla)
		tipoExpr = @expresion.check(tabla)
		unless tipoExpr.is_a?(TipoBool) then
			raise ErrorTipo::new(@expresion, tipoExpr,TipoBool::new())
		end
		unless @instrucciones.nil? then
			@instrucciones.check(tabla)
		end
	end
end
class IteracionFor
	def initialize(rango, instrucciones)
		@rango = rango
		@instrucciones = instrucciones
	end
	def check(tabla)
		#tipoIndice = @indice.check(tabla)
		tipoRango = @rango.check(tabla)
		#unless tipoIndice.is_a?(TipoNum) then
		#	raise ErrorTipo::new(@indice, tipoIndice,TipoNum::new())
		#end
		unless tipoRango.is_a?(TipoMatrix) then
			raise ErrorTipo::new(@rango, tipoRango,Matrix::new(0,0))
		end
		@instrucciones.check(tabla)
	end
end
class LlamadaFuncionConArgs
	def initialize(nombre, argumentos)
		@nombre = nombre
		@argumentos = argumentos
	end
	def check(tabla)
		@tipoFuncion = tabla.buscarFuncion(@nombre.to_s)
		if @tipoFuncion.nil? then
			raise ErrorFuncionNoExiste::new(@nombre)
		else
			@funcion = tabla.dameFuncion(@nombre.to_s)
			if @funcion.nil? then
				raise ErrorFuncionNoExiste::new(@nombre)
			else
				(@parametros, @tipos) = @funcion.retornaParametros
				@misArgsTipos = Array.new
				@misArgsNombres = Array.new
				@argumentos.dameArgs(@misArgsTipos,@misArgsNombres,tabla)
				@funcion.verificaParametros(@misArgsTipos,@misArgsNombres,@tipos)
				return @tipoFuncion
			end
		end
	end
end
class ListaArgumentos
	def initialize(primerArgumento, restoArgumentos)
		@primerArgumento = primerArgumento
		@restoArgumentos = restoArgumentos
	end
	def dameArgs(listaTipos,listaNombres,tabla)
		@tipoPrimerArg = @primerArgumento.check(tabla)
		listaTipos << @tipoPrimerArg
		listaNombres << @primerArgumento.to_s
		unless @restoArgumentos.nil? then
			@restoArgumentos.dameArgs(listaTipos,listaNombres,tabla)
		end
	end
end

class Argumento
	def initialize(arg)
		@arg = arg
	end
	def dameArgs(listaTipos,listaNombres,tabla)
		listaTipos << @arg.check(tabla)
		listaNombres << @arg.to_s
	end
	def check(tabla)
		return @arg.check(tabla)
	end
	def to_s
		"#{@arg.to_s}"
	end
end
class LlamadaFuncionSinArgs
	def initialize(nombre)
		@nombre = nombre
	end
	def check(tabla)
		
		#puts "Func"
		@tipoFuncion = tabla.buscarFuncion(@nombre.to_s)
		#puts @tipoFuncion.nil?
		if @tipoFuncion.nil? then
			raise ErrorFuncionNoExiste::new(@nombre)
		else
			@funcion = tabla.dameFuncion(@nombre.to_s)

			if @funcion.nil? then
				raise ErrorFuncionNoExiste::new(@nombre)
			else
				(@parametros, @tipos) = @funcion.retornaParametros
				@funcion.verificaParametros(nil,nil,@tipos)
				return @tipoFuncion
			end
		end
	end
end
class InstruccionReturn
	def initialize(expresionReturn)
		@expresionReturn = expresionReturn
	end
	def check(tabla)
		if not tabla.esFuncion
			raise ErrorReturn::new()
		end
		@tipoExpr = @expresionReturn.check(tabla)
		@tipoFuncion = tabla.tipo
		unless @tipoExpr.to_s.eql? @tipoFuncion.to_s then
			raise ErrorTipo::new(@expresionReturn, @tipoExpr, @tipoFuncion)
		end
	end
end

