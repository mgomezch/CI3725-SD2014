#!/usr/bin/env ruby 
# -*- coding: utf-8 -*-
# David Goudet 08-10479
# Susana Charara 08-10223

class Token

  attr_reader :t, :l, :c

  #Definición del token
  def initialize(text,line,col)
    @t = text
    @l = line
    @c = col - text.length
  end

  def to_s
    "#{self.class}"
  end
end
# Se crea una subclase para cada token
# Palabras reservadas
class TkProgram < Token
  def to_s
    "Program"
  end
end
class TkBoolean < Token
end
class TkFalse < Token; end
class TkTrue < Token; end
class TkNumber < Token; end
class TkMatrix < Token; end
class TkRow < Token; end
class TkCol < Token; end
class TkNot < Token; end
class TkDiv < Token; end
class TkMod < Token; end
class TkPrint < Token; end
class TkUse < Token; end
class TkIn < Token; end
class TkEnd < Token; end
class TkSet < Token; end
class TkRead < Token; end
class TkIf < Token; end
class TkThen < Token; end
class TkElse < Token; end
class TkFor < Token; end
class TkDo < Token; end
class TkWhile < Token; end
class TkFunction < Token; end
class TkReturn < Token; end
class TkBegin < Token; end
#Operadores y otros simbolos
class TkTraspuesta < Token; end
class TkComa < Token; end
class TkPuntoYComa < Token; end
class TkParAbre < Token; end
class TkParCierra < Token; end
class TkCorcheteAbre < Token; end
class TkCorcheteCierra < Token; end
class TkLlaveAbre < Token; end
class TkLlaveCierra < Token; end
class TkDosPuntos < Token; end
class TkMenos < Token; end
class TkMas < Token; end
class TkMult < Token; end
class TkDivision < Token; end
class TkModulo < Token; end
class TkPMenosP < Token; end
class TkPMasP < Token; end
class TkPMultP < Token; end
class TkPDivisionP < Token; end
class TkPModuloP < Token; end
class TkPDivP < Token; end
class TkPModP < Token; end
class TkConjuncion < Token; end
class TkDisyuncion < Token; end
class TkMenor < Token; end
class TkMenorIgual < Token; end
class TkMayor < Token; end
class TkMayorIgual < Token; end
class TkIgual < Token; end
class TkIgualIgual < Token; end
class TkDesigual < Token; end
# Subclase para definir literales numericos y guardar su valor
class TkNum < Token
  def to_s
    "#{@t}"
  end
end
# Subclase para definir identificadores y guardar su valor
class TkIdent < Token
  def to_s
    "#{@t}"
  end
end
# Subclase para definir literales de cadena de caracteres y guardar su valor
class TkStr < Token
  def to_s
    "#{@t}"
  end
end
