#!/usr/bin/env ruby 
# -*- coding: utf-8 -*-
# David Goudet 08-10479
# Susana Charara 08-10223
class Tipo; end
class TipoAritmetico < Tipo; end
class TipoNum < TipoAritmetico
	def to_s
		return "number"
	end
end
class TipoBool < Tipo
	def to_s
		return "boolean"
	end
end
class TipoMatrix < TipoAritmetico
	def initialize(f,c)
		@f = f
		@c = c
	end	
	def to_s
		return "matrix(#{@f.to_s},#{@c.to_s})"
	end
	def dameFilas
		return @f
	end
	def dameColumnas
		return @c
	end
end
