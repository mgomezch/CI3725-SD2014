#
# Modulo que une todas las clases que seran usadas en el archivo Parser.py
#

import sys

count = -1

simbolos_binarios = {	
						"+" 	: "Suma",
						"-" 	: "Resta",
						"*" 	: "Multiplicacion",
						"/" 	: "Division exacta",
						"%" 	: "Resto exacto",
						"div"	: "Division entera",
						"mod"	: "Resto entero",
						">" 	: "Mayor",
						">=" 	: "Mayor o igual",
						"<" 	: "Menor",
						"<=" 	: "Menor o igual",
						"==" 	: "Equivalencia",
						"\/=" 	: "Distinto",
						"&" 	: "Conjuncion",
						"|" 	: "Disyuncion",
						".+." 	: "Suma cruzada",
						".-." 	: "Resta cruzada",
						".*." 	: "Multiplicacion cruzada",
						"./." 	: "Division exacta cruzada",
						".%." 	: "Resto exacto cruzado",
						".div."	: "Division entera cruzada",
						".mod."	: "Resto entero cruzado",
					}

#
# Funcion que se encarga de la espaciacion adecuada para la impresion
#
def espaciacion(espacio):
	i = 0
	while (i < 4):
		espacio += " "
		i += 1
	return espacio

#
# Clase Tabla de Simbolos
#
class Tabla_Simbolos:

	def __init__(self,padre):
		self.diccionario = {}
		self.hijos = []
		self.padre = padre
		self.nombre = ""

	def setNombre(self,nombre):
		self.nombre = nombre

	def getNombre(self):
		return self.nombre

	def insertarElem(self,nombreVar, tipo):
		self.diccionario[nombreVar] = tipo

	def enlazarHijo(self,hijo):
		self.hijos.append(hijo)
		

################################################################################
#                     CLASES PARA EL ANALIZADOR SINTACTICO                     #
################################################################################ 

#
# Clase Identificador
#
class Identificador:

	def __init__(self,nombre):		
		self.nombre = nombre
		self.type = "id"

	def imprimir(self,espacio,tablaSimb):
		pass

	def chequear(self,tablaSimb):
		return self.nombre

#
# Clase Tipo
#
class Tipo:

	def __init__(self,valor):
		self.valor =  valor

	def imprimir(self, espacio,tablaSimb):
		pass

	def chequear(self,tablaSimb):
		return self.valor

#
# Clase Literal Numerico
#
class Literal_Numerico:

	def __init__(self,valor):
		self.valor = valor
		self.type = "number"

	def imprimir(self,espacio,tablaSimb):
		pass

	def chequear(self,tablaSimb):
		return self.type

	def retornaValor(self):
		return self.valor

#
# Clase Cadena de Caracteres
#
class Cadena_Caracteres:

	def __init__(self,valor):
		self.valor = valor
		self.type = "caracter"
	
	def imprimir(self,espacio,tablaSimb):
		pass

	def chequear(self,tablaSimb):
		return self.valor	
		
#
# Clase Booleano
#
class Booleano:

	def __init__(self,valor):
		self.valor = valor
		self.type = "boolean"

	def imprimir(self,espacio,tablaSimb):
		pass

	def chequear(self,tablaSimb):
		return self.type

#
# Clase Not
# op e (not)
#
class Expresion_Not:

	def __init__(self,expresion):
		self.expresion = expresion
		self.type = "boolean"

	def imprimir(self,espacio,tablaSimb):
		pass

   	def chequear(self,tablaSimb):
		return self.type

#
# Clase Matrix 
# matrix(n, m)
# row(r) = matrix(r,1)
# col(c) = matrix(1,c)
#
class Matrix:

	def __init__(self,r,c):
		self.r = r
		self.c = c
		self.type = "matrix"		

	def imprimir(self,espacio,tablaSimb):
		pass

	def chequear(self,tablaSimb):
		return (self.type)


#
# Clase Vector
# e[i, j] o e[i]
#
class Vector:	

	def __init__(self,identificador,i,j=None):
		self.identificador = identificador
		self.i = i
		self.j = j
		self.type = "number"

	def imprimir(self,espacio,tablaSimb):
		pass

	def chequear(self,tablaSimb):		
		nombreVariable = self.identificador.chequear(tablaSimb)

		if (tablaSimb.diccionario.has_key(nombreVariable) == True):
			tipoVariable = tablaSimb.diccionario[nombreVariable]
			
			if tipoVariable == "number" or tipoVariable == "boolean":				
				e = " ERROR: La expresion \'%s\' tiene el" % nombreVariable 
				e += " tipo \'%s\', y se " % tipoVariable
				e += "esperaba el tipo matriz, row o column."				
				print e
				exit()
				
			if tipoVariable <> "number" and tipoVariable <> "boolean":	
				self.identificador.chequear(tablaSimb)
								 
				col = tipoVariable[2]
				row = tipoVariable[1]

				i = int(self.i.retornaValor())
				if self.j:
					j = int(self.j.retornaValor())

				if self.j:
					if (i < 0 or j < 0):						
						e = "ERROR: Valores no validos, tienen que ser mayor a cero."
						print e
						exit()
					else:

						if (i >= row or j >= col):							
							e = "ERROR: Valores no validos para la matriz."
							print e
							exit()
				else:
					if (i < 0):
						e = "ERROR: Valor no valido, tiene que ser mayor a cero."
						print e
						exit()
					else:

						# Nos moveremos por las columnas
						if  (row == 1):							
							if (i >= col):								
								e = "ERROR: Valores no validos para la matriz."
								print e
								exit()
						# Nos moveremos por las filas
						elif (col == 1):
							if (i >= row):								
								e = "ERROR: Valores no validos para la matriz."
								print e
								exit()
						else:				
							e = "ERROR: Valores no validos para la matriz."
							print e
							exit()
		else:
			tablaPadre = tablaSimb.padre
			verifica = True
			tipoExp = ""
			
			while (tablaPadre <> None) and verifica:
				# Guardia que revisa si la variable se encuantra en la tabla actual
				if (tablaPadre.diccionario.has_key(nombreVariable) == True):
					tipoVariable = tablaPadre.diccionario[nombreVariable]
			
					if tipoVariable == "number" or tipoVariable == "boolean":						
						e = " ERROR: La expresion \'%s\' tiene el" % nombreVariable 
						e += " tipo \'%s\', y se " % tipoVariable
						e += "esperaba el tipo matriz, row o column."				
						print e
						exit()

					if tipoVariable <> "number" and tipoVariable <> "boolean":	
						self.identificador.chequear(tablaPadre)
						 
						col = tipoVariable[2]
						row = tipoVariable[1]						
						
						i = int(self.i.retornaValor())
						if self.j:
							j = int(self.j.retornaValor())

						if self.j:								
							if (i < 0 or j < 0):								
								e = "ERROR: Valores no validos, tienen que ser mayor a cero."
								print e
								exit()
							else:													
								if (i >= row or j >= col):									
									e = "ERROR: Valores no validos para la matriz."
									print e
									exit()
						else:
							if (i < 0):								
								e = "ERROR: Valor no valido, tiene que ser mayor a cero."
								print e
								exit()
							else:
								# Nos moveremos por las columnas								
								if  (row == 1):							
									if (i >= col):										
										e = "ERROR: Valores no validos para la matriz."
										print e
										exit()
								# Nos moveremos por las filas
								elif (col == 1):
									if (i >= row):										
										e = "ERROR: Valores no validos para la matriz."
										print e
										exit()
								else:									
									e = "ERROR: Valores no validos para la matriz."
									print e
									exit()
					else: 
						break
					verifica = False
				else:
					tablaPadre = tablaPadre.padre
		
			# En caso de revisar todas las tablas
			if tablaPadre == None:
				if (nombreVariable <> "matrix"):				
					print "ERROR: La variable \'%s\' no esta declarada." % nombreVariable
					exit()
				else:
	
					if nombreVariable <> "number" and nombreVariable <> "boolean":	
						self.identificador.chequear(tablaSimb)
						 
						col = self.identificador.getCol()
						row = self.identificador.getRow()

						i = int(self.i.retornaValor())
						if self.j:
							j = int(self.j.retornaValor())

						if self.j:							
							if (i < 0 or j < 0):								
								e = "ERROR: Valores no validos, tienen que ser mayor a cero."
								print e
								exit()
							else:
								if (i >= row or j >= col):							
									e = "ERROR: Valores no validos para la matriz."
									print e
									exit()
						else:
							if (i < 0):								
								e = "ERROR: Valor no valido, tiene que ser mayor a cero."
								print e
								exit()
							else:

								# Nos moveremos por las columnas
								if  (row == 1):							
									if (i >= col):										
										e = "ERROR: Valores no validos para la matriz."
										print e
										exit()
								# Nos moveremos por las filas
								elif (col == 1):
									if (i >= row):										
										e = "ERROR: Valores no validos para la matriz."
										print e
										exit()
								else:									
									e = "ERROR: Valores no validos para la matriz."
									print e
									exit()
		return self.type

#
# Clase Matriz
# {<valores>,<valores>, ...}
# {<valores>:<valores>: ...}
# {<valores>,<valores>:<valores>,<valores>}
# e op (traspuesta) siendo e una matriz, row o column
#
class Matriz:
	
	def __init__(self,valor,t=None):    	
		if (t == "\'"):
			self.t = t
			if ":" in valor and "," in valor:
				self.valor = valor
			elif ":" in valor:
				i = 0
				while (i < len(valor)):
					if valor[i] == ":":
						valor[i] = ","
					i += 1
				self.valor = valor
			elif "," in valor:
				i = 0
				while (i < len(valor)):
					if valor[i] == ",":
						valor[i] = ":"
					i += 1
				self.valor = valor
		else:
			self.valor = valor
			self.t = "."
		self.type = "matrix"
		self.col = 1
		self.row = 1

	def imprimir(self,espacio,tablaSimb):
		pass

	def retornaValor(self):
		return self.valor

	def setValor(self,valor):
		self.valor = valor

	def getCol(self):
		return self.col

	def getRow(self):
		return self.row

	def setCol(self,columna):
		self.col = columna

	def setRow(self,fila):
		self.row = fila

	def separarlista(self):
		lista =[]
		aux = []
		tam = len(self.valor)

		i = 0
		while i < tam:
			if self.valor[i] == ":":
				lista.append(aux)
				aux = []		
			else:
				aux.append(self.valor[i])
			i = i + 1
		lista.append(aux)
		return lista

	def traspuesta(self):
		listanueva = self.separarlista()
		tam = len(listanueva)
		i = 0

		tras = []
		filas = []
		tam_lista = len(listanueva[0])

		i = 0
		while i < tam_lista:

			j = 0
			while j < tam:
				aux = listanueva[j][i]
				filas.append(aux)
				filas.append(",")
				j = j + 1
			filas.pop()
			tras.append(filas)
			filas = []
			i = i + 2 

		tam_tras = len(tras)
		tam_t = len(tras[0])
		k = 0	
		traspuesta = []
		while k < tam_tras:
			l = 0	
			while l < tam_t:
				traspuesta.append(tras[k][l])
				l = l + 1
			traspuesta.append(":")
			k = k + 1
		traspuesta.pop()		
		return traspuesta

	def chequear(self,tablaSimb):
		e = "ERROR: La matriz no tiene las dimensiones correctas."
		# Cuenta el numero de filas y columnas
		if (":" in self.valor and "," in self.valor):
			if self.valor[1] == ":":
				print e
				exit()

			if self.valor[1] == ",":
				c = 1
				r = 1
				i = 3
				aux_c = 0
				while (i < len(self.valor)):
					if (self.valor[i] == ","):
						c += 1
					elif (self.valor[i] == ":"):
						c += 1
						r += 1
						if (aux_c == 0):
							aux_c = c
							c = 0

							if (i + (aux_c + (aux_c - 1))) > len(self.valor):
								print e
								exit()
						else:
							if (aux_c == c):
								c = 0
								if (i + (aux_c + (aux_c - 1))) > len(self.valor):
									print e
									exit()
							else:
								print e
								exit()
					i += 2
				c += 1
				if (aux_c <> c):
					print e
					exit()
				self.setCol(c)
				self.setRow(r)

		# Cuenta el numero de filas
		elif ":" in self.valor:
			i = 0
			contador = 0
			while i < len(self.valor):
				contador = contador + 1
				i = i + 2
			self.setCol(1)
			self.setRow(contador)	

		# Cuenta el numero de columnas
		elif "," in self.valor:		
			i = 0
			contador = 0
			while i < len(self.valor):
				contador = contador + 1
				i = i + 2
			self.setCol(contador)
			self.setRow(1)

		# Obtiene la traspuesta de una matriz
		if (self.t == "\'"):			
			if ":" in self.valor and "," in self.valor:				
				nuevo_valor = self.traspuesta()
				self.setValor(nuevo_valor)				
				row = self.getRow()
				col = self.getCol()		
				self.setRow(col)
				self.setCol(row)		

		return self.type

#
# Clase Declaracion de Variable
# t i
# t i = e (con inicializacion)
#
class Declaracion_Variable:

	def __init__(self,tipo,identificador,expresion=None):		
		self.tipo = tipo
		self.identificador = identificador		
		self.expresion = expresion

	def imprimir(self,espacio,tablaSimb):
	
		msg = "" + self.identificador.chequear(tablaSimb)
		if (isinstance(self.tipo,int) or isinstance(self.tipo,str)):
			print espacio, msg, ": ", self.tipo
		else:
			print espacio, msg, ": ", self.tipo.type


	def chequear(self, tablaSimb):
		nombreVariable = self.identificador.chequear(tablaSimb)
		tipoVariable = self.tipo
		arregloVariable = tipoVariable		

		if tipoVariable <> "number" and tipoVariable <> "boolean":
			tipoVariable = self.tipo.type
			arregloVariable = [self.tipo.type]			

		if (tablaSimb.diccionario.has_key(nombreVariable) == True):			
			e = "ERROR: La variable \"%s\" ya esta declarada."
			print e % nombreVariable
			exit()
		else:
			if tipoVariable <> "number" and tipoVariable <> "boolean":

				if not(isinstance(self.tipo.r, int)):
					num_r = int(self.tipo.r.valor)
					if (isinstance(self.tipo.c, int)): 
						num_c = self.tipo.c
				if not(isinstance(self.tipo.c, int)):
					num_c = int(self.tipo.c.valor)
					if isinstance(self.tipo.r, int):
						num_r = self.tipo.r

				arregloVariable.append(int(num_r))
				arregloVariable.append(int(num_c))

				tablaSimb.insertarElem(nombreVariable,arregloVariable)
			else:
				tablaSimb.insertarElem(nombreVariable,arregloVariable)


		if (self.expresion <> None):
			fun_param_tipo = tipoVariable
			nombreVar = self.expresion.chequear(tablaSimb)
			if self.expresion.type == "exp_bin":				
				if nombreVar <> "number" and nombreVar <> "boolean":
					nombreVar = self.expresion.chequear(tablaSimb)[0]

			if (tablaSimb.diccionario.has_key(nombreVar) == True):
				tipoVar = tablaSimb.diccionario[nombreVar]

				tipoExp = fun_param_tipo	

				if tipoVar <> "number" and tipoVar <> "boolean":
					tipoVar = tablaSimb.diccionario[nombreVar][0]
					fila = tablaSimb.diccionario[nombreVar][1]
					columna = tablaSimb.diccionario[nombreVar][2]
					
					if not(isinstance(self.tipo.r, int)):
						num_r = int(self.tipo.r.valor)
						if (isinstance(self.tipo.c, int)): 
							num_c = self.tipo.c
					if not(isinstance(self.tipo.c, int)):
						num_c = int(self.tipo.c.valor)
						if isinstance(self.tipo.r, int):
							num_r = self.tipo.r

					if fila <> num_r or columna <> num_c:	
						e = "ERROR: La matriz \"%s\" no tiene las dimensiones correctas" 
						print e % nombreVariable
					 	exit()
					
				if (tipoExp <> tipoVar):
					e = "ERROR: Se esperaba que fuese de tipo \"%s\"." 
					print e % tipoExp
					exit()

			#En caso de que tengaque revisar recursivamente las tablas padre
			else:
				tablaPadre = tablaSimb.padre
				verifica = True

				while (tablaPadre <> None) and verifica:

					#Guardia que revisa si la variable se encuantra en la tabla actual
					if (tablaPadre.diccionario.has_key(nombreVar) == True):
						tipoVar = tablaPadre.diccionario[nombreVar]

						tipoExp = fun_param_tipo

						if tipoVar <> "number" and tipoVar <> "boolean":
							tipoVar = tablaPadre.diccionario[nombreVar][0]
							fila = tablaPadre.diccionario[nombreVar][1]
							columna = tablaPadre.diccionario[nombreVar][2]
							
							if not(isinstance(self.tipo.r, int)):
								num_r = int(self.tipo.r.valor)
								if (isinstance(self.tipo.c, int)): 
									num_c = self.tipo.c
							if not(isinstance(self.tipo.c, int)):
								num_c = int(self.tipo.c.valor)
								if isinstance(self.tipo.r, int):
									num_r = self.tipo.r

							if fila <> num_r or columna <> num_c:
								e = "ERROR: La matriz \"%s\" no tiene las dimensiones correctas." 
								print e % nombreVar
							 	exit()
							
						if (tipoExp <> tipoVar):		
							e = "ERROR: Se esperaba que fuese de tipo \"%s\"." 
							print e % tipoExp
							exit()
						verifica = False
					else:
						tablaPadre = tablaPadre.padre
				
				#En caso de revisar todas las tablas
				if tablaPadre == None:					
					tipoVariable1 = nombreVar					

					if tipoVariable1 <> "number" and tipoVariable1 <> "boolean" and tipoVariable1 <> "matrix":
						msg = "ERROR: La variable \"%s\" no esta declarada."
						e = msg % nombreVar
						print e
						exit()
					else:
						if tipoVariable1 <> "number" and tipoVariable1 <> "boolean":

							# Obtengo el tipo de la declaracion
							if not(isinstance(self.tipo.r, int)):
								num_r = int(self.tipo.r.valor)
								if (isinstance(self.tipo.c, int)): 
									num_c = self.tipo.c
							if not(isinstance(self.tipo.c, int)):
								num_c = int(self.tipo.c.valor)
								if isinstance(self.tipo.r, int):
									num_r = self.tipo.r

							ex = self.expresion.chequear(tablaSimb)

							if ex <> "matrix":
								fila = ex[1]
								columna = ex[2]
							else:
								fila = self.expresion.getRow()
								columna = self.expresion.getCol()

							if fila <> num_r or columna <> num_c:					
								e = "ERROR: La matriz \"%s\" no tiene las dimensiones correctas." 
								print e % nombreVariable
							 	exit()

						if (tipoVariable1 <> fun_param_tipo):
							e = "ERROR: Se esperaba que fuese de tipo \"%s\"." 
							print e % fun_param_tipo
							exit()
	
		tablaSimb.insertarElem(nombreVariable,arregloVariable)
		return [nombreVariable,arregloVariable]
		

#
# Clase Asignacion
# set identificador = expresion
#
class Asignacion:

	def __init__(self,identificador,expresion):
		self.identificador = identificador
		self.expresion = expresion

	def imprimir(self,espacio,tablaSimb):
		pass

	def chequear(self,tablaSimb):

		nombreVariable =  self.identificador.chequear(tablaSimb)

		#Guardia que revisa la tabla de simbolos mas cercana		
		if (tablaSimb.diccionario.has_key(nombreVariable) == True):
			tipoVariable = tablaSimb.diccionario[nombreVariable]

			fun_param_tipo = tipoVariable

			nombreVar = self.expresion.chequear(tablaSimb)
			if self.expresion.type == "exp_bin":				
				if nombreVar <> "number" and nombreVar <> "boolean":
					nombreVar = self.expresion.chequear(tablaSimb)[0]

			if (tablaSimb.diccionario.has_key(nombreVar) == True):
				tipoVariable1 = tablaSimb.diccionario[nombreVar]
				ext = tipoVariable1

				tipoExp = fun_param_tipo	
				if tipoVariable1 <> "number" and tipoVariable1 <> "boolean":
					tipoVariable1 = tipoVariable1[0]				

				if tipoVariable1 <> "number" and tipoVariable1 <> "boolean" and tipoVariable1 <> "matrix":									
					msg = "ERROR: La variable \"%s\" no esta declarada6."
					e = msg % nombreVar
					print e
					exit()
				else:
					if tipoVariable1 <> "number" and tipoVariable1 <> "boolean":				
						
						num_r = tipoVariable[1]
						num_c = tipoVariable[2]

						ex = self.expresion.chequear(tablaSimb)

						if ex <> "matrix":
							fila = ext[1]
							columna = ext[2]
						else:
							fila = self.expresion.getRow()
							columna = self.expresion.getCol()
									
						if fila <> num_r or columna <> num_c:											
							e = "ERROR: La matriz \"%s\" no tiene las dimensiones correctas." 
							print e % nombreVariable
						 	exit()
							
						fun_param_tipo = fun_param_tipo[0]

					if (tipoVariable1 <> fun_param_tipo):							
						e = "ERROR: Se esperaba que fuese de tipo \"%s\"." 
						print e % fun_param_tipo
						exit()


			#En caso de que tengaque revisar recursivamente las tablas padre
			else:
				tablaPadre = tablaSimb.padre
				verifica = True

				while (tablaPadre <> None) and verifica:

					#Guardia que revisa si la variable se encuantra en la tabla actual
					if (tablaPadre.diccionario.has_key(nombreVar) == True):
						tipoVar = tablaPadre.diccionario[nombreVar]

						tipoExp = fun_param_tipo

						if tipoVar <> "number" and tipoVar <> "boolean":
							tipoVar = tablaPadre.diccionario[nombreVar][0]
							fila = tablaPadre.diccionario[nombreVar][1]
							columna = tablaPadre.diccionario[nombreVar][2]
							
							if not(isinstance(tipoVariable[1], int)):
								num_r = int(tipoVariable[1])
								if (isinstance(tipoVariable[2], int)): 
									num_c = tipoVariable[2]
							if not(isinstance(tipoVariable[2], int)):
								num_c = int(tipoVariable[2])
								if isinstance(tipoVariable[1], int):
									num_r = tipoVariable[1]

							if fila <> num_r or columna <> num_c:
								e = "ERROR: La matriz \"%s\" no tiene las dimensiones correctas." 
								print e % nombreVar
							 	exit()
							
						if (tipoExp <> tipoVar):		
							e = "ERROR: Se esperaba que fuese de tipo \"%s\"." 
							print e % tipoExp
							exit()
						verifica = False
					else:
						tablaPadre = tablaPadre.padre
				
				#En caso de revisar todas las tablas
				if tablaPadre == None:					
					tipoVariable1 = nombreVar					

					if tipoVariable1 <> "number" and tipoVariable1 <> "boolean" and tipoVariable1 <> "matrix":
						msg = "ERROR: La variable \"%s\" no esta declarada5."
						e = msg % nombreVar
						print e
						exit()
					else:
						if tipoVariable1 <> "number" and tipoVariable1 <> "boolean":						
							
							num_r = tipoVariable[1]
							num_c = tipoVariable[2]							

							ex = self.expresion.chequear(tablaSimb)

							if ex <> "matrix":
								fila = ex[1]
								columna = ex[2]
							else:
								fila = self.expresion.getRow()
								columna = self.expresion.getCol()

							if fila <> num_r or columna <> num_c:					
								e = "ERROR: La matriz \"%s\" no tiene las dimensiones correctas." 
								print e % nombreVariable
							 	exit()
							
							fun_param_tipo = fun_param_tipo[0]

						if (tipoVariable1 <> fun_param_tipo):							
							e = "ERROR: Se esperaba que fuese de tipo \"%s\"." 
							print e % fun_param_tipo
							exit()

		else: # IDENTIFICADOR

			tablaPadre = tablaSimb.padre
			verifica = True
			#Ciclo que revisa recursivamente las tabla padre
			while (tablaPadre <> None and verifica):
				if (tablaPadre.diccionario.has_key(nombreVariable) == True):
					tipoVariable = tablaPadre.diccionario[nombreVariable]
					fun_param_tipo = tipoVariable

					nombreVar = self.expresion.chequear(tablaPadre)

					if self.expresion.type == "exp_bin":				
						if nombreVar <> "number" and nombreVar <> "boolean":
							nombreVar = self.expresion.chequear(tablaSimb)[0]

					if (tablaPadre.diccionario.has_key(nombreVar) == True):
						tipoVariable1 = tablaPadre.diccionario[nombreVar]
						ext = tipoVariable1

						tipoExp = fun_param_tipo	
						if tipoVariable1 <> "number" and tipoVariable1 <> "boolean":
							tipoVariable1 = tipoVariable1[0]				


						if tipoVariable1 <> "number" and tipoVariable1 <> "boolean" and tipoVariable1 <> "matrix":									
							msg = "ERROR: La variable \"%s\" no esta declarada37."
							e = msg % nombreVar
							print e
							exit()
						else:
							if tipoVariable1 <> "number" and tipoVariable1 <> "boolean":				
								
								num_r = tipoVariable[1]
								num_c = tipoVariable[2]

								ex = self.expresion.chequear(tablaPadre)

								if ex <> "matrix":
									fila = ext[1]
									columna = ext[2]
								else:
									fila = self.expresion.getRow()
									columna = self.expresion.getCol()
											
								if fila <> num_r or columna <> num_c:											
									e = "ERROR: La matriz \"%s\" no tiene las dimensiones correctas." 
									print e % nombreVariable
								 	exit()
									
								fun_param_tipo = fun_param_tipo[0]

							if (tipoVariable1 <> fun_param_tipo):							
								e = "ERROR: Se esperaba que fuese de tipo \"%s\"." 
								print e % fun_param_tipo
								exit()

					#En caso de que tengaque revisar recursivamente las tablas padre
					else:
						tablaPadre2 = tablaPadre.padre
						verifica = True

						while (tablaPadre2 <> None) and verifica:

							#Guardia que revisa si la variable se encuantra en la tabla actual
							if (tablaPadre2.diccionario.has_key(nombreVar) == True):
								tipoVar = tablaPadre2.diccionario[nombreVar]

								tipoExp = fun_param_tipo

								if tipoVar <> "number" and tipoVar <> "boolean":
									tipoVar = tablaPadre2.diccionario[nombreVar][0]
									fila = tablaPadre2.diccionario[nombreVar][1]
									columna = tablaPadre2.diccionario[nombreVar][2]
									
									if not(isinstance(tipoVariable[1], int)):
										num_r = int(tipoVariable[1])
										if (isinstance(tipoVariable[2], int)): 
											num_c = tipoVariable[2]
									if not(isinstance(tipoVariable[2], int)):
										num_c = int(tipoVariable[2])
										if isinstance(tipoVariable[1], int):
											num_r = tipoVariable[1]

									if fila <> num_r or columna <> num_c:
										e = "ERROR: La matriz \"%s\" no tiene las dimensiones correctas." 
										print e % nombreVar
									 	exit()
									
								if (tipoExp <> tipoVar):		
									e = "ERROR: Se esperaba que fuese de tipo \"%s\"." 
									print e % tipoExp
									exit()
								verifica = False
							else:
								tablaPadre2 = tablaPadre2.padre
						
						#En caso de revisar todas las tablas
						if tablaPadre2 == None:					
							tipoVariable1 = nombreVar					
							
							if tipoVariable1 <> "number" and tipoVariable1 <> "boolean" and tipoVariable1 <> "matrix":
								msg = "ERROR: La variable \"%s\" no esta declarada3."
								e = msg % nombreVar
								print e
								exit()
							else:
								if tipoVariable1 <> "number" and tipoVariable1 <> "boolean":						
									
									num_r = tipoVariable[1]
									num_c = tipoVariable[2]							

									ex = self.expresion.chequear(tablaPadre)

									if ex <> "matrix":
										fila = ex[1]
										columna = ex[2]
									else:
										fila = self.expresion.getRow()
										columna = self.expresion.getCol()

									if fila <> num_r or columna <> num_c:					
										e = "ERROR: La matriz \"%s\" no tiene las dimensiones correctas." 
										print e % nombreVariable
									 	exit()
									
									fun_param_tipo = fun_param_tipo[0]

								if (tipoVariable1 <> fun_param_tipo):							
									e = "ERROR: Se esperaba que fuese de tipo \"%s\"." 
									print e % fun_param_tipo
									exit()				
					verifica = False
				else:
					tablaPadre = tablaPadre.padre
			
			#En caso de revisar todas las tablas
			if tablaPadre == None:
				msg = "ERROR: La variable \"%s\" no esta declarada2."
				e = msg % nombreVariable
				print e
				exit()
				
#		
# Clase Expresion Binaria
# e1 op e2
#
class Expresion_Binaria:

	def __init__(self,expresion1,operador,expresion2):
		self.expresion1 = expresion1
		self.expresion2 = expresion2
		self.operador  = operador
		self.type = "exp_bin"

	def imprimir(self,espacio,tablaSimb):
		pass

	def chequear_tipos(self,tipoExp1,tipoExp2,extra1,extra2):

		simbolos = ["+","-","*","/","%","div","mod"]
		simbolos_matriz = [".+.",".-.","./.",".%.",".div.",".mod."]
		simbolos_multiplicar = [".*."]
		simbolos_booleanos = [">",">=","<","<=","==","\/=","&","|"]

		e = "ERROR: Incompatibilidad de tipos para realizar la operacion \"%s\"."

		# Se verifica que cumplan los tipos con el operador
		if str(self.operador) in simbolos:
			if (tipoExp1 <> tipoExp2):
				print e % self.operador
				exit()
			if (tipoExp1 == "number"):
				return "number"
			else:
				print e % self.operador
				exit()

		elif str(self.operador) in simbolos_matriz:
			if (tipoExp1 == "number" and tipoExp2 == "matrix"):
				return extra2

			elif (tipoExp1 == "matrix" and tipoExp2 == "number"):
				return extra1

			elif (tipoExp1 == "matrix" and tipoExp2 == "matrix"):
				fil1 = extra1[1]
				col1 = extra1[2]
				fil2 = extra2[1]
				col2 = extra2[2]

				if (fil1 == fil2) and (col1 == col2) :
					return extra1
				else:
					print e % self.operador
					exit()
			else:
				print e % self.operador
				exit()

		elif str(self.operador) in simbolos_multiplicar:
			if (tipoExp1 == "matrix" and tipoExp2 == "matrix"):
				fil1 = extra1[1]
				col1 = extra1[2]
				fil2 = extra2[1]
				col2 = extra2[2]

				if (col1 == fil2):
					return ["matrix",fil1,col2]
				else:
					print e % self.operador
					exit()
			else:
				print e % self.operador
				exit()

		elif str(self.operador) in simbolos_booleanos:
			if (tipoExp1 <> tipoExp2):
				print e % self.operador
				exit()

			if (tipoExp1 == "boolean"):
				return "boolean"
			else:
				print e % self.operador
				exit()

	def chequear(self,tablaSimb):

		nombreVariable1 = self.expresion1.chequear(tablaSimb)
		nombreVariable2 = self.expresion2.chequear(tablaSimb)
		extra1 = []
		extra2 = []

		if (tablaSimb.diccionario.has_key(nombreVariable1) == True):
   			tipoVariable1 = tablaSimb.diccionario[nombreVariable1]
   			if tipoVariable1 <> "number" and tipoVariable1 <> "boolean":
   				tipoVariable1 = tablaSimb.diccionario[nombreVariable1][0]
   				extra2 = tablaSimb.diccionario[nombreVariable2]
   		else:
   			tablaPadre = tablaSimb.padre
			verifica = True
			while (tablaPadre <> None) and verifica:
				if (tablaPadre.diccionario.has_key(nombreVariable1) == True):
					tipoVariable1 = tablaPadre.diccionario[nombreVariable1]
					if tipoVariable1 <> "number" and tipoVariable1 <> "boolean":
   						tipoVariable1 = tablaPadre.diccionario[nombreVariable1][0]
   						extra1 = tablaPadre.diccionario[nombreVariable1]

					verifica = False
				else:
					tablaPadre = tablaPadre.padre
			if tablaPadre == None:
				tipoVariable1 = nombreVariable1
				if tipoVariable1 <> "number" and tipoVariable1 <> "boolean" and tipoVariable1 <> "matrix":
					msg = "ERROR: La variable \"%s\" no esta declarada1."
					e = msg % nombreVariable1
					print e
					exit()

		if (tablaSimb.diccionario.has_key(nombreVariable2) == True):
   			tipoVariable2 = tablaSimb.diccionario[nombreVariable2]
   			if tipoVariable2 <> "number" and tipoVariable2 <> "boolean":
   				tipoVariable2 = tablaSimb.diccionario[nombreVariable2][0]
   				extra2 = tablaSimb.diccionario[nombreVariable2]
   		else:
   			tablaPadre = tablaSimb.padre
			verifica = True
			while (tablaPadre <> None) and verifica:
				if (tablaPadre.diccionario.has_key(nombreVariable2) == True):
					tipoVariable2 = tablaPadre.diccionario[nombreVariable2]
					if tipoVariable2 <> "number" and tipoVariable2 <> "boolean":
   						tipoVariable2 = tablaPadre.diccionario[nombreVariable2][0]
   						extra2 = tablaPadre.diccionario[nombreVariable2]
					verifica = False
				else:
					tablaPadre = tablaPadre.padre
			if tablaPadre == None:
				tipoVariable2 = nombreVariable2
				if tipoVariable2 <> "number" and tipoVariable2 <> "boolean" and tipoVariable2 <> "matrix":
					msg = "ERROR: La variable \"%s\" no esta declarada."
					e = msg % nombreVariable2
					print e
					exit()

		return self.chequear_tipos(tipoVariable1,tipoVariable2,extra1,extra2)

#
# Clase Read
# read e;
#
class Read:

	def __init__(self,identificador):
		self.identificador = identificador
		
	def imprimir(self,espacio,tablaSimb):
		pass

   	def chequear(self,tablaSimb):
   		nombreVariable = self.identificador.chequear(tablaSimb)

   		if (tablaSimb.diccionario.has_key(nombreVariable) == True):
   			tipoVariable = tablaSimb.diccionario[nombreVariable]
   		else:
   			tablaPadre = tablaSimb.padre
			verifica = True
			while (tablaPadre <> None) and verifica:
				if (tablaPadre.diccionario.has_key(nombreVariable) == True):
					verifica = False
				else:
					tablaPadre = tablaPadre.padre
			if tablaPadre == None:
				msg = "ERROR: La variable \"%s\" no se puede"
				msg = msg + " leer pues no esta declarada."
				e = msg % nombreVariable
				print e
				exit()

#
# Clase Print
# print e;
#
class Print:

	def __init__(self,expresion):
		self.expresion = expresion

	def imprimir(self,espacio,tablaSimb):
		pass

	def chequear(self,tablaSimb):
		for i in self.expresion:
			tipoExp = i.chequear(tablaSimb)
			if i.type == "id":
				if (tablaSimb.diccionario.has_key(tipoExp) == True):
					break
				else:
					tablaPadre = tablaSimb.padre
					verifica = True
					while (tablaPadre <> None) and verifica:
						if (tablaPadre.diccionario.has_key(tipoExp) == True):
							verifica = False
						else:
							tablaPadre = tablaPadre.padre
					if tablaPadre == None:
						msg = "ERROR: La variable \"%s\" no se puede"
						msg = msg + " imprimir pues no esta declarada."
						e = msg % tipoExp
						print e
						exit()

#
# Clase If
# if <condicion> then <instruccion1> end;
# if <condicion> then <instruccion1> else <instruccion2> end;
#
class Condicional_If:

	def __init__(self,condicion,instruccion1,instruccion2=None):
		self.condicion = condicion
		self.instruccion1 = instruccion1
		self.instruccion2 = instruccion2		

	def imprimir(self,espacio,tablaSimb):

		for i in self.instruccion1:
			i.imprimir(espaciacion(espacio),tablaSimb)

		if self.instruccion2:
			for i in self.instruccion2:
				i.imprimir(espaciacion(espacio),tablaSimb)


	def chequear(self,tablaSimb):
		if self.condicion.type == "id":
			nombreCond = self.condicion.chequear(tablaSimb)
			if (tablaSimb.diccionario.has_key(nombreCond) == True):
				tipoCond = tablaSimb.diccionario[nombreCond]
				if tipoCond <> "boolean":
					print "ERROR: Se espera que la condicion sea de tipo booleano."
					exit()
			else:
				tablaPadre = tablaSimb.padre
				# Ciclo que revisa recursivamente las tabla padre
				while (tablaPadre <> None):
					# Guardia que revisa si la variable se encuantra en la 
					# tabla actual
					if (tablaPadre.diccionario.has_key(nombreCond) == True):
						tipoCond = tablaPadre.diccionario[nombreCond]
						
						# Guardia que chequea tipos en caso de haber encontrado 
						# la variable
						# Caso en que los tipos no coinciden
						if (tipoCond <> "boolean"):
							print "ERROR: Se espera que la condicion sea de tipo booleano."
							exit()
						#En caso de que los tipos coinciden
						else: 
							break
					else:
						tablaPadre = tablaPadre.padre

				if tablaPadre == None:
					e = "La variable \"%s\" no esta declarada." 
					print e % nombreCond

		elif self.condicion.type == "exp_bin":
			tipoExp = self.condicion.chequear(tablaSimb)
			if tipoExp <> "boolean":
				print "ERROR: Se espera que la condicion sea de tipo booleano."
				exit()

		for i in self.instruccion1:
			i.chequear(tablaSimb)

		if self.instruccion2:
			for i in self.instruccion2:
				i.chequear(tablaSimb)
			
#
# Clase For
# for <identificador> in <vector/matrix> do <instrucciones> end;
#
class Ciclo_For:

	def __init__(self,identificador,vector_matriz,instruccion):
		self.identificador = identificador
		self.vector_matriz = vector_matriz
		self.instruccion = instruccion

	def imprimir(self,espacio,tablaSimb):

		self.identificador.imprimir(espaciacion(espacio),tablaSimb)
		self.vector_matriz.imprimir(espaciacion(espacio),tablaSimb)

		for i in self.instruccion:
			i.imprimir(espaciacion(espacio),tablaSimb)

	def chequear(self,tablaSimb):

		# Verifica el identificador
		nombreVar = self.identificador.chequear(tablaSimb)

   		if (tablaSimb.diccionario.has_key(nombreVar) == True):
   			tipoVar = tablaSimb.diccionario[nombreVar]

			if (tipoVar <> "number"):
				e = "ERROR: El tipo asociado al identificador que se esperaba "
				e += "era de tipo number."
				print e
				exit()
   		else:

   			tablaPadre = tablaSimb.padre
			verifica = True

			while (tablaPadre <> None) and verifica:
				nombreVar =  self.identificador.chequear(tablaPadre)
				if (tablaPadre.diccionario.has_key(nombreVar) == True):

					tipoExp = tablaPadre.diccionario[nombreVar]
				
					if (tipoExp <> "number"):
						e = "ERROR: El tipo asociado al identificador que se "
						e += "esperaba era de tipo number."
						print e
						exit()
					else: 
						break
					verifica = False
				else:
					tablaPadre = tablaPadre.padre

			if tablaPadre == None:	
				e = "ERROR: La variable \"%s\" no esta declarada." 
				print e % nombreVar
				exit()

		# Verificacion de vector_matriz
		nombreVariable = self.vector_matriz.chequear(tablaSimb)

		if (tablaSimb.diccionario.has_key(nombreVariable) == True):
			tipoVariable = tablaSimb.diccionario[nombreVariable]

			if tipoVariable == "number" or tipoVariable == "boolean":
				e = "ERROR: El tipo asociado al identificador que se "
				e += "esperaba era de tipo matriz, row o column."
				print e
				exit()		
		else:
			tablaPadre = tablaSimb.padre
			verifica = True

			while (tablaPadre <> None) and verifica:
				# Guardia que revisa si la variable se encuantra en la tabla actual
				if (tablaPadre.diccionario.has_key(nombreVariable) == True):
					tipoExp = tablaPadre.diccionario[nombreVariable]

					if (tipoExp == "number" or tipoExp == "boolean"):
						e = "ERROR: El tipo asociado al identificador que se "
						e += "esperaba era de tipo matriz, row o column."
						print e
						exit()
					else: 
						break
					verifica = False
				else:
					tablaPadre = tablaPadre.padre
		
			# En caso de revisar todas las tablas
			if tablaPadre == None:
				if (nombreVariable <> "matrix"):				
					e = "ERROR: La variable \"%s\" no esta declarada." 
					print e % nombreVariable
					exit()

		# Verificacion instruccion
		for i in self.instruccion:
			i.chequear(tablaSimb);

#
# Clase While
# while <condicion> do <instrucciones> end;
#
class Ciclo_While:

	def __init__(self,condicion,instruccion):
		self.condicion = condicion
		self.instruccion = instruccion

	def imprimir(self,espacio,tablaSimb):

		self.condicion.imprimir(espaciacion(espacio),tablaSimb)

		for i in self.instruccion:
			i.imprimir(espaciacion(espacio),tablaSimb)

	def chequear(self,tablaSimb):

		if self.condicion.type == "id":
			nombreCond = self.condicion.chequear(tablaSimb)
			if (tablaSimb.diccionario.has_key(nombreCond) == True):
				tipoCond = tablaSimb.diccionario[nombreCond]
				if tipoCond <> "boolean":
					print "ERROR: Se espera que la condicion sea de tipo booleano."
					exit()
			else:
				tablaPadre = tablaSimb.padre
				while (tablaPadre <> None):
					if (tablaPadre.diccionario.has_key(nombreCond) == True):
						tipoCond = tablaPadre.diccionario[nombreCond]
						if (tipoCond <> "boolean"):
							e = "ERROR: Se espera que la condicion sea de tipo booleano."
							print e
							exit()
						else: 
							break
					else:
						tablaPadre = tablaPadre.padre

				if tablaPadre == None:
					e = "ERROR: La variable \"%s\" no esta declarada." 
					print e % nombreCond

		elif self.condicion.type == "exp_bin":
			tipoExp = self.condicion.chequear(tablaSimb)
			if tipoExp <> "boolean":
				print "ERROR: Se espera que la condicion sea de tipo booleano."
				exit()

		for i in self.instruccion:
			i.chequear(tablaSimb)

#
# Clase Funcion
# function <identificador>(<parametros>) return <tipo> 
# begin <instrucciones> return <expresion> end;
#
class Funcion:

	def __init__(self,identificador,parametros,tipo,expresion,instruccion=None):
		self.identificador = identificador
		self.parametros = parametros
		self.tipo = tipo
		self.instruccion = instruccion
		self.expresion = expresion

	def imprimir(self,espacio,tablaSimb):

		nombreFuncion = self.identificador.chequear(tablaSimb)
		print "- Alcance: ", nombreFuncion

		print espacio,"Simbolos:"
		for i in self.parametros:			
	 		i.imprimir(espaciacion(espacio),tablaSimb)

		for i in self.instruccion:
		 	i.imprimir(espaciacion(espacio),tablaSimb)

	def dev_id(self):
		return self.identificador


	def chequear(self, tablaSimb):
		tabNueva = Tabla_Simbolos(tablaSimb)
		tablaSimb.enlazarHijo(tabNueva)
		tabNueva.setNombre(self.identificador.chequear(tablaSimb))
		
		nombreVariable = self.identificador.chequear(tablaSimb)

		# Se verifica que no haya otra funcion con el mismo nombre
		if (tablaSimb.diccionario.has_key(nombreVariable) == True):
			print "ERROR: La funcion \"%s\" ya fue declarada." % nombreVariable
			exit()
		else:
			# Variable que nos guardara en el diccionario el nombre de la funcion
			# y sus parametros
			parametros = ["function"]			

			for i in self.parametros:		
				parametros.append(i.chequear(tabNueva))

			tablaSimb.insertarElem(nombreVariable,parametros)

			if self.instruccion:
				for i in self.instruccion:
					i.chequear(tabNueva)

			# Verificar que la expresion sea del mismo tipo del return			
			exp = self.expresion.chequear(tabNueva)

			num_r = 0
			num_c = 0 
			if (tabNueva.diccionario.has_key(exp) == True):
				tipoExp = tabNueva.diccionario[exp]
			else:
				tablaPadre = tabNueva.padre
				verifica = True
				while (tablaPadre <> None) and verifica:
					if (tablaPadre.diccionario.has_key(exp) == True):
						tipoExp = tablaPadre.diccionario[exp]
						verifica = False
					else:
						tablaPadre = tablaPadre.padre
				if tablaPadre == None:
					if ((exp <> "number") and (exp <> "boolean") and (exp <> "matrix")):				
						e = "ERROR: La variable \"%s\" no esta declarada." 
						print e % exp
						exit()
					if (exp == "matrix"):
						num_c = self.expresion.getCol()
						num_r = self.expresion.getRow()

			if ((exp == "number") and (exp == "boolean")):
				if (self.tipo <> tipoExp):
					print "ERROR: No se retorna el tipo esperado."
					exit()
			elif (exp == "matrix"): 
				if not(isinstance(self.tipo.r, int)):
					r = int(self.tipo.r.valor)
					if (isinstance(self.tipo.c, int)): 
						c = self.tipo.c
				if not(isinstance(self.tipo.c, int)):
					c = int(self.tipo.c.valor)
					if isinstance(self.tipo.r, int):
						r = self.tipo.r

				if ((r <> num_r) or (c <> num_c)):
					e = "ERROR: Las matrices no tienen las mismas dimensiones."
					print e
					exit()

#
# Clase Llamada a Funcion
# <identificador>(<parametros>),
#
class Llamada_Funcion:

	def __init__(self,identificador,parametros):
		self.identificador = identificador
		self.parametros = parametros

	def imprimir(self,espacio,tablaSimb):
		#print espacio,"Llamada a Function:"
		self.identificador.imprimir(espaciacion(espacio),tablaSimb)
		#print espacio,"  Parametros:"
		for i in self.parametros:			
			i.imprimir(espaciacion(espacio),tablaSimb)

	def verificarParametro(self,parametro,tipoVariable,i,tablaSimb):
				
		fun_param = tipoVariable[i]							
		fun_param_tipo = fun_param[1]
						
		nombreVariable = parametro.chequear(tablaSimb)

				
		if (tablaSimb.diccionario.has_key(nombreVariable) == True):
			tipoVariable = tablaSimb.diccionario[nombreVariable]

			tipoExp = fun_param_tipo			

			if tipoVariable <> "number" and tipoVariable <> "boolean":
				tipoVariable = tablaSimb.diccionario[nombreVariable][0]
				fila = tablaSimb.diccionario[nombreVariable][1]
				columna = tablaSimb.diccionario[nombreVariable][2]
			
				num_r = 0
				num_c = 0
				if tipoExp <> "matrix":
					num_r = tipoExp[1]
					num_c = tipoExp[2]
					tipoExp = tipoExp[0]
				else:
					num_r = self.expresion.getRow()
					num_c = self.expresion.getCol()

				if fila <> num_r or columna <> num_c:
					e = "ERROR: La matriz \"%s\" no tiene las dimensiones correctas" 
					print e % nombreVariable
				 	exit()
				
			if (tipoExp <> tipoVariable):
				e = "ERROR: Parametro numero %d, " % i
				e += "se esperaba que fuese de tipo \"%s\"." 
				print e % tipoExp
				exit()

		#En caso de que tengaque revisar recursivamente las tablas padre
		else:
			tablaPadre = tablaSimb.padre
			verifica = True

			while (tablaPadre <> None) and verifica:

				#Guardia que revisa si la variable se encuantra en la tabla actual
				if (tablaPadre.diccionario.has_key(nombreVariable) == True):
					tipoVariable = tablaPadre.diccionario[nombreVariable]

					tipoExp = fun_param_tipo

					if tipoVariable <> "number" and tipoVariable <> "boolean":
						tipoVariable = tablaPadre.diccionario[nombreVariable][0]
						fila = tablaPadre.diccionario[nombreVariable][1]
						columna = tablaPadre.diccionario[nombreVariable][2]
					
						num_r = 0
						num_c = 0
						if tipoExp <> "matrix":
							num_r = tipoExp[1]
							num_c = tipoExp[2]
							tipoExp = tipoExp[0]
						else:
							num_r = self.expresion.getRow()
							num_c = self.expresion.getCol()

						if fila <> num_r or columna <> num_c:
							e = "ERROR: La matriz \"%s\" no tiene las dimensiones correctas." 
							print e % nombreVariable
						 	exit()
						
					if (tipoExp <> tipoVariable):						
						e = "ERROR: Parametro numero %d, " % i
						e += "se esperaba que fuese de tipo \"%s\"." 
						print e % tipoExp
						exit()
					verifica = False
				else:
					tablaPadre = tablaPadre.padre
			
			#En caso de revisar todas las tablas
			if tablaPadre == None:
				tipoVariable1 = nombreVariable
				if tipoVariable1 <> "number" and tipoVariable1 <> "boolean" and tipoVariable1 <> "matrix":
					msg = "ERROR: La variable \"%s\" no esta declarada."
					e = msg % nombreVariable
					print e
					exit()
				else:
					if (tipoVariable1 <> fun_param_tipo):
						e = "ERROR: Parametro numero %d, " % i
						e += "se esperaba que fuese de tipo \"%s\"." 
						print e % fun_param_tipo
						exit()

	def chequear(self,tablaSimb):

		# Se verifica que si existe una funcion con ese nombre
		nombreVariable = self.identificador.chequear(tablaSimb)

		if (tablaSimb.diccionario.has_key(nombreVariable) == True):
   			tipoVariable = tablaSimb.diccionario[nombreVariable]

			if (tipoVariable <> "number") and (tipoVariable <> "boolean") and (tipoVariable <> "matrix"):
				tamano = len(tipoVariable)
			else:
				e = "ERROR: La variable \"%s\" no es una funcion." 
				print e % nombreVariable
				exit()
		
   		else:
   			tablaPadre = tablaSimb.padre
			verifica = True
			while (tablaPadre <> None) and verifica:
				if (tablaPadre.diccionario.has_key(nombreVariable) == True):

					tipoVariable = tablaPadre.diccionario[nombreVariable]

					if (tipoVariable <> "number") and (tipoVariable <> "boolean") and (tipoVariable <> "matrix"):
						tam = len(tipoVariable)
						num_parametros = tam - 1
						tam_parametros = len(self.parametros)

						# Se verifica numero de parametros
						if (num_parametros <> tam_parametros):
							e = "ERROR: La cantidad de parametros que son pasados a " 
							e += "la funcion \"%s\" no es correcta." 
							print e % nombreVariable
							exit()	

						i = 1
						for k in self.parametros:									
							self.verificarParametro(k,tipoVariable,i,tablaSimb)
							i = i + 1

					else:
						e = "ERROR: La variable \"%s\" no es una funcion." 
						print e % nombreVariable
						exit()

					verifica = False
				else:
					tablaPadre = tablaPadre.padre

			if tablaPadre == None:
				print "ERROR: La funcion \"%s\" no existe." % nombreVariable
				exit()

#
# Clase Use In End
# use <declaraciones> in <instrucciones> end;
#
class Use_In_End:

	def __init__(self,declaraciones,instruccion):
		self.declaraciones = declaraciones
		self.instruccion = instruccion

	def imprimir(self,espacio,tablaSimb):

		if tablaSimb.hijos <> []:
			espacio2 = "" + espacio
			print  espacio2, "Hijos:"

			global count
			count = count + 1
			print espacio2, " - Alcance ", count

			print espacio2, "    Simbolos:"


			for i in self.declaraciones:
				i.imprimir(espaciacion(espacio2),tablaSimb)

			for k in self.instruccion:
				k.imprimir(espaciacion(espacio2),tablaSimb)
		else:
			espacio2 = "" + espacio
			print  espacio2, "Hijos: []"


	def chequear(self,tablaSimb):
		
		tabNueva = Tabla_Simbolos(tablaSimb)
		tablaSimb.enlazarHijo(tabNueva)


		for i in self.declaraciones:			
			i.chequear(tabNueva)

		for i in self.instruccion:			
			i.chequear(tabNueva)

#
# Clase Program End
# <funciones> program <bloque> end;
#
class Program_End:

	def __init__(self,bloque,funciones=None):
		self.funciones = funciones
		self.bloque = bloque
		
		tablaSimb = Tabla_Simbolos(None)
		self.chequear(tablaSimb)

		#Imprime el programa
		self.imprimir("",tablaSimb)
		
	def imprimir(self,espacio, tablaSimb):

		if self.funciones:
			for i in self.funciones:
				for k in tablaSimb.hijos:
					nombreTabla = k.getNombre()
					nombreFuncion = i.dev_id().chequear(tablaSimb)
					if nombreTabla == nombreFuncion:
						i.imprimir(espaciacion(espacio),k)
	

		print "- Alcance _main: "
		print espacio, "    Simbolos: [] "
		
		self.bloque.imprimir(espaciacion(espacio),tablaSimb)

	def chequear(self, tablaSimb):
		if self.funciones:
			for i in self.funciones:
				i.chequear(tablaSimb)
		self.bloque.chequear(tablaSimb)

# END Clases.py