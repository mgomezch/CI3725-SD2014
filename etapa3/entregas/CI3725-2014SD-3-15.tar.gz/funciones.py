#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
    Proyecto 2
    Trinity: Modulo con las funciones y clases necesarias para el PARSER.

    Autores:    10-10088 Stefany Botero
                09-10329 Gabriela Gimenez

    Fecha: 12/10/2014
"""

# Notas:
#   - Archivo elaborado en Linux
#   - No hay un MakeFile, el archivo se corre como: ./trinity ejemplo.ty
#   - Trinity termina con 0 si no hay errorres en la gramatica,
#       o con 1 si encontro errores (./trinity ejemplo.ty; echo $?)
#   - En el pdf con la informacion del proyecto 1 no se especifica de cuanto
#       es la longitud de un tab (es decir, cuantos espacios es equivalente)
#       nosotras lo tomamos predeterminado como 4. (1 Tab = 4 spaces)




####################### FUNCIONES ###########################################

# Funcion lematriz: Toma como entrada un string "matriz(f,c)" y retorna
#                   una caja con el tam de la fila y la columna. 
def lematriz(y):
    i = 0
    fila = ''
    col = ''
    tam = len(y)

    while i < tam:
        # Si es un ( empiezo a contar las filas
        if y[i] == '(':
            i = i+1

            # Almacenamos el numero del tam de las filas
            while i < tam:
                fila = fila + y[i]
                i=i+1

                # Aqui terminan las filas, es decir, encontro un ","
                if y[i] == ',':
                    i=i+1

                    # Almacenamos el numero del tam de las columnas
                    while i < tam:
                        if y[i] != ')':
                            col = col + y[i]
                            i=i+1
                        else:
                            i=i+1
        else:
            i = i+1
    f = int(fila)
    c = int(col)
    return [f,c]


# Funcion lerowcol: Toma como entrada un string "row(f)" o #col(c) y retorna
#                   una caja con el tam de la fila o columna. 
def lerowcol(y):
    i = 0
    fila = ''
    tam = len(y)

    while i < tam:
        # Si es un ( empiezo a contar las filas
        if y[i] == '(':
            i = i+1

            # Almacenamos el numero del tam de las filas
            while i < tam:
                fila = fila + y[i]
                i=i+1
                if y[i] == ')':
                    i=i+1

        else:
            i = i+1

    return fila

def imprimelindo(level,x):

    y = x.keys()
    z = x.values()
    
    tam = len(y)

    i = 0

    while i != tam:
        
        if y[i] != None or z[i] != None:
            print ' '*level+y[i],':',z[i]
        
        i = i+1
        
    return ''


def param(x,z,nombre):

    tam = len(z)
    a = 0
    aux = 0
    aux2 = []
    cosa = 0
    aux3 = 0

    while a != (len(x)-1):
        
        if x[a][0] == z[tam-1][0]:
            aux = 1 
            d = a+1
            f = 0
            cosa = a

            while cosa < len(x):
                cosa = cosa + 1
                aux3 = aux3 +1
            
            if d == len(x):
                pass
         
            else:                                   
                while d < len(x) and (x[d][1] != None) and (d-1 < len(x)):
          
                    uno = x[d][0] 
                    dos = z[f][0]
                    por = x[d][0]

                    aux2.append(por)

                    if uno != dos:

                        print ' ERROR: Parámetros incorrectos en la llamada a función "'+nombre+'".\n'
                        exit(1)

                    d = d+1
                    f = f+1

        a = a+1

    if len(aux2) != tam-1:
            print ' ERROR: Parámetros incorrectos en la llamada a función "'+nombre+'".\n'
            exit(1)
            
    if aux == 0:
        print ' ERROR: Parámetros incorrectos en la llamada a función "'+nombre+'".\n'
        exit(1)
    else:
        pass
        