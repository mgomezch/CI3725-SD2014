module Identifier
    ( Identifier
    ) where
    
type Identifier = String

