{-# LANGUAGE LambdaCase #-}

module Expression
    ( Expression(..)
    , Access(..)
    , Binary(..)
    , Unary(..)
    , binaryOperation
    , unaryOperation
    , isComparable
    ) where

import          DataType
import          Identifier
import          Lexeme

import          Data.Sequence (Seq, fromList)
import          Data.Functor ((<$), (<$>))
import          Data.Foldable (concatMap, find)
import          Prelude       hiding (concatMap)

data Expression
    = LitNumber (Lexeme Number)
    | LitBool (Lexeme Bool)
    | LitString (Lexeme String)
    | VariableId (Lexeme Identifier)
    | LitMatrix [Seq (Lexeme Expression)]
    | ProyM (Lexeme Expression) (Lexeme Expression) (Lexeme Expression)
    | ProyRC (Lexeme Expression) (Lexeme Expression)
    | ExpBinary (Lexeme Binary) (Lexeme Expression) (Lexeme Expression)
    | ExpUnary (Lexeme Unary) (Lexeme Expression)
    deriving (Eq, Ord)

instance Show Expression where
    show = \case
        LitNumber vL        -> "Literal numérico: " ++ show (lexInfo vL)
        LitBool vL          -> "Literal booleano: " ++ show (lexInfo vL)
        LitString strL      -> "Literal string: "   ++ show (lexInfo strL)
        VariableId accL     -> "Identificador de variable: " ++ show (lexInfo accL)
        LitMatrix expS      -> "Literal Matricial: { " ++ " }"
        ProyM expL indexlL indexrL -> "Proyección: " ++ show (lexInfo expL) ++ "[" 
                                ++ show (lexInfo indexlL) ++ "," ++ show (lexInfo indexrL) ++ "]"
        ProyRC expL indexL  -> "Proyección: " ++ show (lexInfo expL) ++ "[" ++ show (lexInfo indexL) ++ "]"                
        ExpBinary opL lL rL -> "Operador Binario: " ++ show (lexInfo lL) ++ " " 
                                ++ show (lexInfo opL) ++ " " ++ show (lexInfo rL)
        ExpUnary opL expL   -> "Operador Unario: " ++ show (lexInfo opL) ++ " " 
                                ++ show (lexInfo expL)

---------------------------------------------------------------------

data Access 
    = VariableAccess (Lexeme Identifier)
    | MatrixAccess (Lexeme Identifier) (Lexeme Expression) (Lexeme Expression)
    | RCAccess (Lexeme Identifier) (Lexeme Expression)
    deriving (Eq, Ord)

instance Show Access where
    show = \case
        VariableAccess idnL     -> lexInfo idnL
        MatrixAccess idnL sizeR sizeC -> lexInfo idnL ++ "[" ++ show (lexInfo sizeR) 
                                   ++ "," ++ show (lexInfo sizeC) ++ "]"
        RCAccess idnL expL -> lexInfo idnL ++ "[" ++ show (lexInfo expL) ++ "]"

---------------------------------------------------------------------

data Binary
    = OpSum | OpDiff | OpMul | OpDivEnt | OpModEnt | OpDiv | OpMod
    | OpCruzSum | OpCruzDiff | OpCruzMul | OpCruzDivEnt | OpCruzModEnt
    | OpCruzDiv | OpCruzMod
    | OpEqual | OpUnequal | OpLess | OpLessEq | OpGreat | OpGreatEq
    | OpOr | OpAnd
    deriving (Eq, Ord)

instance Show Binary where
    show = \case
        OpSum        -> "+"
        OpDiff       -> "-"
        OpMul        -> "*"
        OpDivEnt     -> "/"
        OpModEnt     -> "%"
        OpDiv        -> "div"
        OpMod        -> "mod"
        OpCruzSum    -> ".+."
        OpCruzDiff   -> ".-."
        OpCruzMul    -> ".*."
        OpCruzDivEnt -> "./."
        OpCruzModEnt -> ".%."
        OpCruzDiv    -> ".div."
        OpCruzMod    -> ".mod."
        OpEqual      -> "=="
        OpUnequal    -> "/="
        OpLess       -> "<"
        OpLessEq     -> "<="
        OpGreat      -> ">" 
        OpGreatEq    -> ">="
        OpOr         -> "|"
        OpAnd        -> "&"

binaryOperation :: Binary -> (DataType, DataType) -> Maybe DataType
binaryOperation op dts = snd <$> find ((dts==) . fst) (binaryOperator op)

binaryOperator :: Binary -> Seq ((DataType, DataType), DataType)
binaryOperator = fromList . \case
    OpSum        -> arithmetic
    OpDiff       -> arithmetic
    OpMul        -> arithmetic
    OpDivEnt     -> numeric
    OpModEnt     -> numeric
    OpDiv        -> numeric
    OpMod        -> numeric
    OpCruzSum    -> cruzado
    OpCruzDiff   -> cruzado
    OpCruzMul    -> cruzado
    OpCruzDivEnt -> cruzado
    OpCruzModEnt -> cruzado
    OpCruzDiv    -> cruzado
    OpCruzMod    -> cruzado
    OpEqual      -> everythingCompare
    OpUnequal    -> everythingCompare
    OpLess       -> arithmeticCompare
    OpLessEq     -> arithmeticCompare
    OpGreat      -> arithmeticCompare
    OpGreatEq    -> arithmeticCompare
    OpOr         -> boolean
    OpAnd        -> boolean

    where    
        numeric           = [((Number, Number), Number)]
        arithmetic        = numeric ++ matrixArithmetic
        matrixArithmetic  = [((Matrix lexD lexD, Matrix lexD lexD),
                               Matrix lexD lexD),
                             ((Col lexD, Col lexD), Col lexD),
                             ((Row lexD, Row lexD), Row lexD)]
        boolean           = [((Bool, Bool), Bool)]
        arithmeticCompare = [((Number, Number), Bool)]
        cruzado           = cruzadoM1 ++ cruzadoC2 ++ cruzadoC1 ++ cruzadoC2 ++
                            cruzadoR1 ++ cruzadoR2
        cruzadoM1         = [((Matrix lexD lexD, Number), Matrix lexD lexD)] 
        cruzadoM2         = [((Number, Matrix lexD lexD), Matrix lexD lexD)]
        cruzadoC1         = [((Col lexD, Number), Col lexD)]
        cruzadoC2         = [((Number, Col lexD), Col lexD)] 
        cruzadoR1         = [((Number, Row lexD), Row lexD)]
        cruzadoR2         = [((Row lexD, Number), Row lexD)]
        everythingCompare = arithmeticCompare ++ boolean ++ matrixCompare
        matrixCompare     = [((Matrix lexD lexD, Matrix lexD lexD), Bool),
                             ((Col lexD, Col lexD), Bool), ((Row lexD, Row lexD), Bool)]

lexD :: Lexeme Number
lexD = Lex 0.0 defaultPosn
---------------------------------------------------------------------

data Unary 
    = OpNegative
    | OpNot
    | OpTranspose
    deriving (Eq, Ord)

instance Show Unary where
    show = \case
        OpNegative   -> "-"
        OpNot        -> "not"
        OpTranspose  -> "transpose"

unaryOperation :: Unary -> DataType -> Maybe DataType
unaryOperation op dt = snd <$> find ((dt==) . fst) (unaryOperator op)

unaryOperator :: Unary -> Seq (DataType, DataType)
unaryOperator = fromList . \case
    OpNegative  -> [(Number, Number)] ++ matrixes
    OpNot       -> [(Bool, Bool)]
    OpTranspose -> matrixes
    where 
        matrixes = [(Matrix lexD lexD, Matrix lexD lexD),
                   (Row lexD, Row lexD), (Col lexD, Col lexD)]

---------------------------------------------------------------------

isComparable :: Binary -> Bool
isComparable = flip elem [OpEqual,OpUnequal,OpLess,OpLessEq,OpGreat,OpGreatEq]

