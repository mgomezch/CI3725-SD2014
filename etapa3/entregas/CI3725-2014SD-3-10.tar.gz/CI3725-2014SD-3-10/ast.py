# Archivo: AST.py
# Este archivo contiene todas las clases utilizadas para la construccion
# del arbol de sintaxis abstracta.
# Autores: 
#    - Miguel  Saraiva    09-10794
#    - Gabriel Alvarez    09-10029
# Grupo: 10
        
from symTable import *

def getDimensions(type):
    if 'row' in type or 'col' in type:
        aux = type[4:]
        result = ""
        for x in aux:
            if x == ")":
                break
            result += x
        return int(result)
    elif 'matrix' in type:
        aux = type[7:]
        result1 = ""
        i = 0
        for x in aux:
            if x == ",":
                break
            result1 += x
            i += 1
        result2 = ""
        aux = aux[i+1:]
        for x in aux:
            if x == ")":
                break
            result2 += x
        return (int(result1),int(result2))

def getMatrix(type):
    if 'col' in type:
        rows = getDimensions(type)
        matrix = 'matrix(' + str(rows)
        matrix += "," + str(1) + ")"
        return matrix
    elif 'row' in type:
        columns = getDimensions(type)
        matrix = 'matrix(' + str(1)
        matrix += "," + str(columns) + ")"
        return matrix

###############################################################################
#############################        PROGRAM       ############################
###############################################################################

def function_duplicate_error(identifier):        
    message = "ERROR: Duplicate function identifier '" + identifier
    message += "' in functions declaration"
    static_error.append(message)
    
class Program(object):

    def __init__(self,instruction_list,function_list = None):
        self.instruction_list = instruction_list
        self.function_list = function_list
        self.table = SymTable()

    def __str__(self):
        string = "Program:\n"
        print "string = ",string
        if self.function_list:
            for function in self.function_list:
                string += function.string_tree(1)
        for instruction in self.instruction_list:
            string += instruction.string_tree(1)
        return string + "\n"
    
    def check(self):
        nError = True
        if self.function_list:
            for function in self.function_list:
                if self.table.findSymbol(function.identifier.name) is not None:
                    function_duplicate_error(function.identifier.name)
                    nError = False
                else:
                    self.table.insert(function.identifier.name,None)
                if not function.check(self.table):
                    nError = False
        for instruction in self.instruction_list:
            if not instruction.check(self.table):
                nError = False
        return nError
    
    def scope(self):
        string = ""
        if self.function_list:
            for function in self.function_list:
                string += function.scope()
        string += "- Main scope:\n"
        string += "    " + "Symbols:[]\n"
        string += "    " + "Inner Scope:\n"
        for instruction in self.instruction_list:
            string += instruction.scope(2)
        return string
        
        
###############################################################################
#############################       FUNCTIONS      ############################
###############################################################################    
    
class Function(object):
    
    def __init__(self,identifier,type,instruction_list,parameter_list = None):
        self.identifier = identifier
        self.parameter_list = parameter_list
        self.type = type
        self.instruction_list = instruction_list
        self.table = SymTable()
        self.table.isFunction = True

    def string_tree(self,level):
        indent = '    ' * level
        string = indent + "Function:\n" + self.identifier.string_tree(level+1)
        if self.parameter_list:
            for parameter in self.parameter_list:
                string += parameter.string_tree(level+1)
        string += indent + "    " + "Type: " + self.type + "\n"
        for instruction in self.instruction_list:
            string += instruction.string_tree(level+1)
        return string
   
    def check(self,table):
        self.table.outer = table        
        nError = True
        paramId = None
        types = []
        if self.parameter_list:
            for parameter in self.parameter_list:
                types.append(parameter.type)
                if not parameter.check(self.table):
                    nError = False
        table.insert(self.identifier.name,types)
        self.table.insert('return',self.type)
        for instruction in self.instruction_list:
            instr_check = instruction.check(self.table)
            if not instr_check:
                nError = False
        return nError
    
    def scope(self):
        indent = "    "
        string = "- Function '" + self.identifier.name + "' scope:\n"
        string += indent + "Symbols:\n"
        if self.parameter_list:
            string += self.table.toString(2)
        else:
            string = string[0:-1]
            string += "[]\n"
        string += indent + "Inner Scope:\n"
        old = string
        for instruction in self.instruction_list:
            string += instruction.scope(2)
        if old == string:
            string = string[0:-1]
            string += "[]\n"
        return string
        
###############################################################################
#############################       PARAMETERS     ############################
###############################################################################

def param_duplicate_error(paramId):        
    message = "ERROR: Duplicate parameters '" + paramId
    message += "' in function definition"
    static_error.append(message)
    
class Parameter(object):

    def __init__(self,type,identifier):
        self.type = type
        self.identifier = identifier

    def string_tree(self,level):
        indent = '    ' * level
        string = indent + "Parameter:\n" + indent + "    " + "Type: " + self.type + "\n"
        string += self.identifier.string_tree(level+1)
        return string
    
    def check(self,table):
        if table.existsSymbol(self.identifier.name):
            param_duplicate_error(self.identifier)
            return False
        table.insert(self.identifier.name,self.type)
        return True
               
###############################################################################
#############################     INSTRUCTIONS     ############################
###############################################################################
               
class Instruction(object): pass

#############################         BLOCK        ############################

class Block(Instruction):

    def __init__(self,declaration_list,instruction_list):
        self.declaration_list = declaration_list
        self.instruction_list = instruction_list
        self.table = SymTable()

    def string_tree(self,level):
        indent = '    ' * level
        string = indent + "Block:\n"
        string += indent + "    Use:\n"
        for declaration in self.declaration_list:
            string += declaration.string_tree(level+2)
        string += indent + "    In:\n"
        for instruction in self.instruction_list:
            string += instruction.string_tree(level+2)
        return string
    
    def check(self,table):
        self.table.outer = table
        nError = True
        for declaration in self.declaration_list:
            if not declaration.check(self.table):
                nError = False
        for instruction in self.instruction_list:
            if not instruction.check(self.table):
                nError = False
        return nError
    
    def scope(self,level):
        indent = "    "*level
        indent2 = indent + "    " 
        string = indent + "- Block scope:\n"
        string += indent2 + "Symbols:\n"
        string += self.table.toString(level+2)
        string += indent2 + "Inner Scope:\n"
        old = string
        for instruction in self.instruction_list:
            string += instruction.scope(level+2)
        if old == string:
            string = string[0:-1]
            string += "[]\n"
        return string

#############################      EXPRESSION      ############################
    
class Expression_instruction(Instruction):
    
    def __init__(self,expression):
        self.expression = expression

    def string_tree(self,level):
        indent = '    ' * level
        string = indent + "Expression:\n" 
        string += self.expression.string_tree(level+1)
        return string
    
    def check(self,table):
        if self.expression.check(table) is None:
            return False
        return True
    
    def scope(self,level):
        return ""
       
#############################         PRINT        ############################     
                 
class Print(Instruction):

    def __init__(self,argument_list):
        self.argument_list = argument_list

    def string_tree(self,level):
        indent = '    ' * level
        string = indent + "Print:\n" 
        for argument in self.argument_list:
            string += argument.string_tree(level+1)
        return string
    
    def check(self,table):
        nError = True
        for argument in self.argument_list:
            if argument.check(table) is None:
                nError = False
        return nError
    
    def scope(self,level):
        return ""

#############################         READ         ############################

class Read(Instruction):
                 
    def __init__(self,identifier):
        self.identifier = identifier

    def string_tree(self,level):
        indent = '    ' * level
        string = indent + "Read:\n" 
        string += self.identifier.string_tree(level+1)
        return string
    
    def check(self,table):
        ident_check = self.identifier.check(table)
        nError = True
        if ident_check is None:
            nError = False
        else:
            if 'matrix' in ident_check[0] or 'col' in ident_check[0] or 'row' in ident_check[0] :
                message = "ERROR: Unsupported type '" + ident_check[0]
                message += "' for read instruction"
                static_error.append(message)
                nError = False
        return nError
    
    def scope(self,level):
        return ""
      
#############################        ASSIGN        ############################   
        
def assign_error():
    message = "ERROR: The identifier and expression type on"
    message += " the assign instruction must match"
    static_error.append(message)
       
class Assign(Instruction):

    def __init__(self,identifier,expression):
        self.identifier = identifier
        self.expression = expression

    def string_tree(self,level):
        indent = '    ' * level
        string = indent + "Assign:\n"
        string += self.identifier.string_tree(level+1)
        string += self.expression.string_tree(level+1)
        return string
    
    def check(self,table):
        ident_check = self.identifier.check(table)
        nError = True
        if ident_check is None:
            nError = False
        else:
            isMatrix = False
            if 'col' in ident_check[0] or 'row' in ident_check[0]:
                matrix = getMatrix(ident_check[0])
                isMatrix = True
            expr_check = self.expression.check(table)
            if expr_check is None:
                nError = False
            else:
                if isMatrix:
                    if matrix != expr_check[0]:
                        assign_error()
                        nError = False
                else:
                    if ident_check[0] != expr_check[0]:
                        print "ident_check[0]",ident_check[0],"expr_check[0]",expr_check[0]
                        assign_error()
                        nError = False
        return nError
    
    def scope(self,level):
        return ""
                 
#############################     ASSIGN VECTOR    ############################                 

def assign_vector_iden_error():
    message = "ERROR: The identifier type must be row/col for"
    message += " vector assignment"
    static_error.append(message)

def assign_vector_arg_error():
    message = "ERROR: The argument type for vector assignment"
    message += " must be number"
    static_error.append(message)

def assign_vector_arg_isGreater():
    message = "ERROR: Argument for vector assignment can't be greater"
    message += " than the number of cols/rows"
    static_error.append(message)
    
def assign_vector_arg_isFloat():
    message = "ERROR: The argument type for vector assignment"
    message += " can't be float"
    static_error.append(message)
    
def assign_vector_dim_error():
    message = "ERROR: Dimensions of matrix must be equivalent to"
    message += " a row/col for vector assignment"
    static_error.append(message)

def assign_vector_expr_error():
    message = "ERROR: The expression type for vector assignment"
    message += " must be number"
    static_error.append(message)

class Assign_vector(Instruction):

    def __init__(self,identifier,expression_arg,expression):
        self.identifier = identifier
        self.expression_arg = expression_arg
        self.expression = expression

    def string_tree(self,level):
        indent = '    ' * level
        string = indent + "Assign:\n"
        string += self.identifier.string_tree(level+1)
        string += indent + "    Argument:\n" 
        string += self.expression_arg.string_tree(level+2)
        string += self.expression.string_tree(level+1)
        return string
    
    def check(self,table):
        ident_check = self.identifier.check(table)
        nError = True
        if ident_check is None:
            nError = False
        else:
            if 'matrix' not in ident_check[0] and 'col' not in ident_check[0] and 'row' not in ident_check[0]:
                assign_vector_iden_error()
                return False
            if 'col' in ident_check[0] or 'row' in ident_check[0]:
                matrix = getMatrix(ident_check[0])
                dimensions = getDimensions(matrix)
            else:
                dimensions = getDimensions(ident_check[0])
            expr_arg_check = self.expression_arg.check(table)
            if expr_arg_check is None:
                nError = False
            else:   
                if expr_arg_check[0] != 'number':
                    assign_vector_arg_error()
                    nError = False
                isFloat = False
                if expr_arg_check[1] is not None:
                    if '.' in expr_arg_check[1]:
                        isFloat = True
                    #if 1 not in dimensions:
                    #    assign_vector_dim_error()
                    #    nError = False
                    #else:
                        #if dimensions[0] == 1:
                           # if dimensions[1] < expr_arg_check[1]:
                           #     assign_vector_arg_isGreater()
                            #    nError = False
                        #elif dimensions[1] == 1:
                        #    if dimensions[0] < expr_arg_check[1]:
                        #        assign_vector_arg_isGreater()
                        #        nError = False
                if isFloat:
                    assign_vector_arg_isFloat()
                    nError = False
            expr_check = self.expression.check(table)
            if expr_check is None:
                nError = False
            else:
                if expr_check[0] != 'number':
                    assign_vector_expr_error()
                    nError = False
        return nError
    
    def scope(self,level):
        return ""
       
#############################     ASSIGN MATRIX    ############################

def assign_matrix_iden_error():
    message = "ERROR: The identifier type must be matrix for"
    message += " matrix assignment"
    static_error.append(message)

def assign_matrix_arg_error():
    message = "ERROR: The argument types for matrix assignment"
    message += " must be number"
    static_error.append(message)

def assign_matrix_arg_isGreater():
    message = "ERROR: The arguments for matrix assingment can't be"
    message += " greater than the number of columns or rows"
    static_error.append(message)

def assign_matrix_arg_isFloat():
    message = "ERROR: The argument types for matrix assignment"
    message += " can't be float"
    static_error.append(message)
 
def assign_matrix_expr_error():
    message = "ERROR: The expression type for matrix assignment"
    message += " must be number"
    static_error.append(message)
                 
class Assign_matrix(Instruction):

    def __init__(self,identifier,expression_arg1,expression_arg2,expression):
        self.identifier = identifier
        self.expression_arg1 = expression_arg1
        self.expression_arg2 = expression_arg2
        self.expression = expression

    def string_tree(self,level):
        indent = '    ' * level
        string = indent + "Assign:\n" 
        string += self.identifier.string_tree(level+1)
        string += indent + "    Argument 1:\n" 
        string += self.expression_arg1.string_tree(level+2)
        string += indent + "    Argument 2:\n"
        string += self.expression_arg2.string_tree(level+2)
        string += self.expression.string_tree(level+1)
        return string
    
    def check(self,table):
        ident_check = self.identifier.check(table)
        nError = True
        if ident_check is None:
            nError = False
        else:
            isMatrix = False
            if 'col' in ident_check[0] or 'row' in ident_check[0]:
                matrix = getMatrix(ident_check[0])
                isMatrix = True
            if 'matrix' not in ident_check[0] and not isMatrix:
                assign_matrix_iden_error()
                return False
            if isMatrix:
                dimensions = getDimensions(matrix)
            else:
                dimensions = getDimensions(ident_check[0])
            expr_arg1_check = self.expression_arg1.check(table)
            expr_arg2_check = self.expression_arg2.check(table)
            if expr_arg1_check is None or expr_arg2_check is None:
                return None
            else:
                isFloat_1 = False
                isFloat_2 = False
                if expr_arg1_check[0] != 'number' or expr_arg2_check[0] != 'number':
                    assign_matrix_arg_error()
                    nError = False
                if expr_arg1_check[1] is not None and expr_arg2_check[1] is not None:
                    if '.' in expr_arg1_check[1]:
                        isFloat_1 = True
                        arg1 = float(expr_arg1_check[1])
                    else:
                        arg1 = int(expr_arg1_check[1])
                    if '.' in expr_arg2_check[1]:
                        isFloat_2 = True
                        arg1 = float(expr_arg1_check[1])
                    else:
                        arg2 = int(expr_arg2_check[1])
                    #if dimensions[0] < arg1 or dimensions[1] < arg2:
                    #    assign_matrix_arg_isGreater()
                    #    nError = False
                if isFloat_1 or isFloat_2:
                    assign_matrix_arg_isFloat()
                    nError = False
            expr_check = self.expression.check(table)
            if expr_check is None:
                nError = False
            else:
                if expr_check[0] != 'number':
                    assign_matrix_expr_error()
                    nError = False
        return nError
    
    def scope(self,level):
        return ""
 
#############################          IF          ############################
                 
class If(Instruction):
    
    def __init__(self,expression,then_instruction_list,
                 else_instruction_list = None):
        self.expression = expression
        self.then_instruction_list = then_instruction_list
        self.else_instruction_list = else_instruction_list

    def string_tree(self,level):
        indent = '    ' * level
        string = indent + "If:\n"
        string += self.expression.string_tree(level+1)
        string += indent + "    Then:\n"
        for then_instruction in self.then_instruction_list:
            string += then_instruction.string_tree(level+2)
        if self.else_instruction_list:
            string += indent + "    Else:\n"
            for else_instruction in self.else_instruction_list:
                string += else_instruction.string_tree(level+2)
        return string
    
    def check(self,table):
        expr_check = self.expression.check(table)
        nError = True
        if expr_check is None:
            nError = False
        else:
            if expr_check[0] != 'boolean':
                message = "ERROR: If condition must be boolean"
                
                static_error.append(message)
                nError = False
        for instruction in self.then_instruction_list:
            if not instruction.check(table):
                nError = False
        if self.else_instruction_list:
            for instruction in self.else_instruction_list:
                if not instruction.check(table):
                    nError = False
        return nError
    
    def scope(self,level):
        string = ""
        for then_instruction in self.then_instruction_list:
            string += then_instruction.scope(level)
        if self.else_instruction_list:
            for else_instruction in self.else_instruction_list:
                string += else_instruction.scope(level)   
        return string
    
#############################         WHILE        ############################

class While(Instruction):

    def __init__(self,expression,instruction_list):
        self.expression = expression
        self.instruction_list = instruction_list
        
    def string_tree(self,level):
        indent = '    ' * level
        string = indent + "While:\n" 
        string += self.expression.string_tree(level+1)
        string += indent + "    Do:\n"
        for instruction in self.instruction_list:
            string += instruction.string_tree(level+2)
        return string
    
    def check(self,table):
        expr_check = self.expression.check(table)
        nError = True
        if expr_check is None:
            nError = False
        else:
            if expr_check[0] != 'boolean':
                message = "ERROR: While condition must be boolean"
                static_error.append(message)
                nError = False
        for instruction in self.instruction_list:
            if not instruction.check(table):
                nError = False
        return nError
    
    def scope(self,level):
        string = ""
        for instruction in self.instruction_list:
            string += instruction.scope(level)
        return string
       
#############################         FOR          ############################      
        
class For(Instruction):

    def __init__(self,identifier,expression,instruction_list):
        self.identifier = identifier
        self.expression = expression
        self.instruction_list = instruction_list
        self.table = SymTable()
        
    def string_tree(self,level):
        indent = '    ' * level
        string = indent + "For:\n"
        string += self.identifier.string_tree(level+1)
        string += indent + "    In:\n"
        string += self.expression.string_tree(level+2)
        string += indent + "    Do:\n"
        for instruction in self.instruction_list:
            string += instruction.string_tree(level+2)
        return string
    
    def check(self,table):
        self.table.outer = table
        self.table.insert(self.identifier.name,"number")
        nError = True
        expr_check = self.expression.check(table)
        if expr_check is None:
            nError = False
        else:
            if 'matrix' not in expr_check[0] and 'col' not in expr_check[0] and 'row' not in expr_check[0]:
                message = "ERROR: The range of a for loop must be of matrix"
                message += " type"
                static_error.append(message)
                nError = False
        for instruction in self.instruction_list:
            if not instruction.check(self.table):
                nError = False
        return nError

    def scope(self,level):     
        indent = "    "*level
        indent2 = indent + "    " 
        string = indent + "- For scope:\n"
        string += indent2 + "Symbols:\n"
        string += self.table.toString(level+2)
        string += indent2 + "Inner Scope:\n"
        old = string
        for instruction in self.instruction_list:
            string += instruction.scope(level+2)
        if old == string:
            string = string[0:-1]
            string += "[]\n"
        return string         
            
            
#############################        RETURN        ############################    
    
class Return(Instruction):
    
    def __init__(self,expression):
        self.expression = expression
        
    def string_tree(self,level):
        indent = '    ' * level
        string = indent + "Return:\n" + self.expression.string_tree(level+1)
        return string
    
    def check(self,table):
        nError = True
        if not table.findFunction():
            message = "ERROR: Return instruction must be inside a function"
            static_error.append(message)
            return False
        return_type = table.findSymbol('return')
        expr_check = self.expression.check(table)
        isMatrix_return = False
        isMatrix_expr = False
        if "col" in return_type or "row" in return_type:
            matrix_return = getMatrix(return_type)
            isMatrix_return = True
        elif "matrix" in return_type:
            matrix_return = return_type
            isMatrix_return = True
        if expr_check: 
            if "col" in expr_check[0] or "row" in expr_check[0]:
                matrix_expr = getMatrix(expr_check[0])
                isMatrix_expr = True
            elif "matrix" in expr_check[0]:
                matrix_expr = expr_check[0]
                isMatrix_expr = True
            if isMatrix_return and isMatrix_expr:
                if matrix_return != matrix_expr:
                    message = "ERROR: The expression type in the return instruction"
                    message += " must match the function return type"
                    static_error.append(message)
                    nError = False
            else:
                if expr_check[0] != return_type:
                    message = "ERROR: The expression type in the return instruction"
                    message += " must match the function return type"
                    static_error.append(message)
                    nError = False
        else:
            nError = False
        return nError
    
    def scope(self,level):
        return ""
    
###############################################################################
#############################     DECLARATIONS     ############################
###############################################################################        

def declaration_check_matrix(type):
    nError = True
    if '.' in type:
        message = "ERROR: Dimensions in matrix can't be float"
        
        static_error.append(message)
        nError = False
    else:
        dimensions = getDimensions(type)
        if dimensions[0] == 0 or dimensions[1] == 0:
            message = "ERROR: Dimensions in matrix can't be zero"
            static_error.append(message)
            nError = False
    return nError
            
def declaration_check_vector(type):
    nError = True
    if '.' in type:
        message = "ERROR: Dimensions in vector can't be float"
        static_error.append(message)
        nError = False
    else:
        dimension = getDimensions(type)
        if dimension == 0:
            message = "ERROR: Dimensions in vector can't be zero"
            static_error.append(message)
            nError = False
    return nError

def declaration_duplicate_error(identifier):        
    message = "ERROR: Duplicate identifier '" + identifier
    message += "' in block declaration"
    static_error.append(message)

def declaration_type_error(identifier,exp_type):        
    message = "ERROR: The expression type '" + exp_type + "' must match'"
    message += " the identifier '" + identifier + "' type in block declaration"
    static_error.append(message)
    
class Declaration(object):

    def __init__(self,type,identifier,expression = None):
        self.type = type
        self.identifier = identifier
        self.expression = expression
        
    def string_tree(self,level):
        indent = '    ' * level
        string = indent + "Declaration:\n"
        string += indent + "    " + "Type: " + self.type + "\n"
        string += self.identifier.string_tree(level+1)
        if self.expression:
            string += self.expression.string_tree(level+1)
        return string
    
    def check(self,table):
        if 'matrix' in self.type:
            if not declaration_check_matrix(self.type):
                return False
        elif 'col' in self.type or 'row' in self.type:
            if not declaration_check_vector(self.type):
                return False
        if self.expression:
            expr_check = self.expression.check(table)
            if 'col' in self.type:
                columns = getDimensions(self.type)
                if 'matrix' in expr_check[0]:
                    dimensions = getDimensions(expr_check[0])
                    if columns != dimensions[0] or dimensions[1] != 1:
                        declaration_type_error(self.identifier.name,expr_check[0])
                        return False
                else:
                    declaration_type_error(self.identifier.name,expr_check[0])
                    return False
            elif 'row' in self.type:
                rows = getDimensions(self.type)
                if 'matrix' in expr_check[0]:
                    dimensions = getDimensions(expr_check[0])
                    if rows != dimensions[1] or dimensions[0] != 1:
                        declaration_type_error(self.identifier.name,expr_check[0])
                        return False
                else:
                    declaration_type_error(self.identifier.name,expr_check[0])
                    return False
            else:
                if self.type != expr_check[0]:
                    declaration_type_error(self.identifier.name,expr_check[0])
                    return False
        if table.existsSymbol(self.identifier.name):
            declaration_duplicate_error(self.identifier.name)
            return False
        table.insert(self.identifier.name,self.type)
        return True

###############################################################################
#############################      EXPRESSIONS     ############################
###############################################################################
    
class Expression(object): pass

#############################        BINARY        ############################

def binary_type_error(left_type,right_type,operator):
    message = "ERROR: Unsupported operand types '" + left_type[0]
    message += "' and '" + right_type[0] + "' for '" + operator
    message += "' operator"
    static_error.append(message)

def binary_operator_error(operator,type1,type2 = None):
    message = "ERROR: Operator " + operator
    message += " is not defined for type/s '" + type1 + "'"
    if type2 is not None:
        message += " and '" + type2 + "'"
    static_error.append(message)
    
def check_binary_boolean(operator):
    boolean_operators = [
        'AMPERSAND','PIPE',
        'EQUIVALENT','DIFFERENT'
    ]
    if operator in boolean_operators:
        return ('boolean',None)
    binary_operator_error(operator,'boolean')
    return None

def check_binary_number(operator):
    number_operators = [
        'PLUS','MINUS','ASTERISK',
        'DIVIDE','MODULE','SLASH','PERCENT'
    ]
    compare_operators = [
        'LESS','LEQUAL',
        'GREATER','GEQUAL','EQUIVALENT','DIFFERENT'
    ]
    if operator in number_operators:
        return ('number',None)
    elif operator in compare_operators:
        return ('boolean',None)
    binary_operator_error(operator,'number')
    return None

def check_binary_matrix(left,right,operator):
    matrix_operators = ['PLUS','MINUS','ASTERISK']
    matrix_compare_operators = ['EQUIVALENT','DIFFERENT']
    left_dim = getDimensions(left)
    right_dim = getDimensions(right)
    if operator in matrix_operators:
        if operator == 'ASTERISK':
            if left_dim[1] == right_dim[0]:
                result = 'matrix(' + str(left_dim[0])
                result += ',' + str(right_dim[1]) + ')'
                return (result,None)
            else:
                message = "ERROR: For the " + operator
                message += " operator in matrices, the number of"
                message += " columns for left operand must match the"
                message += " number of rows for right operand"
                static_error.append(message)
                return None
        else:
            if left_dim == right_dim:
                result = 'matrix(' + str(left_dim[0])
                result += ',' + str(left_dim[1]) + ')'
                return (result,None)
            else:
                message = "ERROR: For the " + operator
                message += " operator in matrices, left and right"
                message += " operand dimensions must match"
                static_error.append(message)
                return None
    elif operator in matrix_compare_operators:
        print "left",left_dim,"right",right_dim
        if left_dim != right_dim:
            message = "ERROR: For the " + operator
            message += " operator in matrices, left and right"
            message += " operand dimensions must match"
            static_error.append(message)
            return None 
        return ('boolean',None)
    binary_operator_error(operator,'matrix')
    return None

def check_binary_cross(matrix,operator):
    cross_operators = [
        'CPLUS','CMINUS',
        'CASTERISK','CDIVIDE',
        'CMODULE','CSLASH','CPERCENT'
    ]
    if operator in cross_operators:
        return (matrix,None)
    binary_operator_error(operator,'number','matrix')
    return None

class Binary(Expression):

    def __init__(self,operator,left,right):
        self.operator = operator
        self.left = left
        self.right = right
        
    def string_tree(self,level):
        indent = '    ' * level
        string = indent + self.operator + " operator:\n"
        string += self.left.string_tree(level+1)
        string += self.right.string_tree(level+1)
        return string
    
    def check(self,table):
        left_type = self.left.check(table)
        right_type = self.right.check(table)
        if left_type is None or right_type is None:
            return None
        left_isMatrix = False
        right_isMatrix = False
        if 'row' in left_type[0] or 'col' in left_type[0]:
            left_matrix = getMatrix(left_type[0])
            left_isMatrix = True
        if 'row' in right_type[0] or 'col' in right_type[0]:
            right_matrix = getMatrix(right_type[0])
            right_isMatrix = True
        if left_type[0] == 'boolean' and right_type[0] == 'boolean':
            return check_binary_boolean(self.operator)
        elif left_type[0] == 'number' and right_type[0] == 'number':
            return check_binary_number(self.operator) 
        elif 'matrix' in left_type[0] and 'matrix' in right_type[0]:
            return check_binary_matrix(left_type[0],right_type[0],self.operator)
        elif 'matrix' in left_type[0] and right_type[0] == 'number':
            return check_binary_cross(left_type[0],self.operator)
        elif left_type[0] == 'number' and 'matrix' in right_type[0]:
            return check_binary_cross(right_type[0],self.operator)
        elif left_isMatrix and right_isMatrix:
            return check_binary_matrix(left_matrix,right_matrix,self.operator)
        elif left_isMatrix and 'matrix' in right_type[0]:
            return check_binary_matrix(left_matrix,right_type[0],self.operator)
        elif 'matrix' in left_type[0] and right_isMatrix:
            return check_binary_matrix(left_type[0],right_matrix,self.operator)
        elif left_type[0] == 'number' and right_isMatrix:
            return check_binary_cross(right_matrix,self.operator)
        elif left_isMatrix and right_type[0] == 'number':
            return check_binary_cross(left_matrix,self.operator)
        binary_type_error(left_type,right_type,self.operator)
        return None
        
#############################         UNARY        ############################

def Unary_type_error(arg_type,operator):
    message = "ERROR: Unsupported operand type '" + arg_type
    message += "' for '" + operator + "' operator"
    
    static_error.append(message)

class Unary(Expression):

    def __init__(self,operator,expression):
        self.operator = operator
        self.expression = expression
        
    def string_tree(self,level):
        indent = '    ' * level
        string = indent + "Unary " + self.operator + ":\n"
        string += self.expression.string_tree(level+1)
        return string
    
    def check(self,table):
        typeDict = {
            'NOT'       : 'boolean',
            'MINUS'     : 'number'
        }
        expr_check = self.expression.check(table)
        if expr_check is None:
            return None
        if 'row' in expr_check[0] or 'col' in expr_check[0]:
            if self.operator == 'TRANSPOSE':
                matrix = getMatrix(expr_check[0])
                dimensions = getDimensions(matrix)
                result = 'matrix(' + str(dimensions[1]) + ',' 
                result += str(dimensions[0]) + ')'
                return (result,None)
            elif self.operator == 'MINUS':
                matrix = getMatrix(expr_check[0])
                dimensions = getDimensions(matrix)
                result = 'matrix(' + str(dimensions[0]) + ',' 
                result += str(dimensions[1]) + ')'
                return (result,None)
            else:
                Unary_type_error(expr_check[0],self.operator)
                return None
        elif 'matrix' in expr_check[0] and self.operator == 'TRANSPOSE':
            dimensions = getDimensions(expr_check[0])
            result = 'matrix(' + str(dimensions[1]) + ',' 
            result += str(dimensions[0]) + ')'
            return (result,None)
        elif 'matrix' in expr_check[0] and self.operator == 'MINUS':
            return expr_check
        elif 'matrix' in expr_check[0] and self.operator != 'TRANSPOSE':
            Unary_type_error(expr_check[0],self.operator)
            return None
        elif expr_check[0] == typeDict[self.operator]:
            return expr_check
        Unary_type_error(expr_check[0],self.operator)
        return None
    
#############################      PROJECTION      ############################

def projection_argument_negative():
    message = "ERROR: Projection arguments can't be negative."
    static_error.append(message)
    
def projection_argument_error(arg1_type,arg2_type = None):
    message = "ERROR: Unsupported argument type/s '" + arg1_type + "'"
    if arg2_type is not None:
        message += "' and '" + arg2_type + "'"
    message += " for matrix projection"
    static_error.append(message)
    
def projection_dimension_error():
    message = "ERROR: Argument number can't be greater than the dimension of the"
    message += " matrix/vector in the projection"
    static_error.append(message)
    
def projection_check_vector(argument,rows,columns):
    nError = True
    if argument is None:
        return False
    arg_is_float = False
    arg_is_negative = False
    if argument[0] != 'number':
        projection_argument_error(argument[0])
        nError = False
    else:
        if argument[1] is not None:
            if '.' in argument[1]:
                arg_is_float = True
                arg = float(argument[1])
            else:
                arg = int(argument[1])
            if '-' in argument[1]:
                arg_is_negative = True
            #if rows <= arg and columns <= arg:
            #    projection_dimension_error()
            #    nError = False
    if rows != 1 and columns != 1:
        message = "ERROR: Number of arguments in projection must match the dimension of a vector"
        
        static_error.append(message)
        nError = False
    if arg_is_float:
        projection_argument_error('float')
        nError = False
    if arg_is_negative:
        projection_argument_negative()
        nError = False
    return nError

def projection_check_matrix(argument1,argument2,rows,columns):
    nError = True
    if argument1 is None or argument2 is None:
        return False
    arg1_is_float = False
    arg2_is_float = False
    arg1_is_negative = False
    arg2_is_negative = False
    if argument1[0] != 'number' or argument2[0] != 'number':
        projection_argument_error(argument1[0],argument2[0])
        nError = False
    else:
        if argument1[1] is not None:
            if '.' in argument1[1]:
                arg1_is_float = True
                arg1 = float(argument1[1])
            else:
                arg1 = int(argument1[1])
            if '-' in argument1[1]:
                arg1_is_negative = True
           # if rows < arg1:
            #    projection_dimension_error()
             #   nError = False
        if argument2[1] is not None:
            if '.' in argument2[1]:
                arg2_is_float = True
                arg2 = float(argument2[1])
            else:
                arg2 = int(argument2[1])
            if '-' in argument2[1]:
                arg2_is_negative = True
            #if columns < arg2:
            #    projection_dimension_error()
            #    nError = False
    if arg1_is_float or arg2_is_float:
        projection_argument_error('float')
        nError = False
    if arg1_is_negative or arg2_is_negative:
        projection_argument_negative()
        nError = False
    return nError
    
class Projection(Expression):

    def __init__(self,expression,expression_arg1,expression_arg2 = None):
        self.expression = expression
        self.expression_arg1 = expression_arg1
        self.expression_arg2 = expression_arg2
        
    def string_tree(self,level):
        indent = '    ' * level
        string = indent + "Projection:\n"
        string += self.expression.string_tree(level+1)
        string += self.expression_arg1.string_tree(level+1)
        if self.expression_arg2:
            string += self.expression_arg2.string_tree(level+1)
        return string
    
    def check(self,table):
        expr_check = self.expression.check(table)
        if expr_check is None:
            return None
        isMatrix = False
        if 'col' in expr_check[0] or 'row' in expr_check[0]:
            matrix = getMatrix(expr_check[0])
            isMatrix = True
        if not isMatrix and 'matrix' not in expr_check[0]:
            message = "ERROR: Projection can only be done on matrices"
            static_error.append(message)
            return None
        else:
            if isMatrix:
                dimensions = getDimensions(matrix)
            else:
                dimensions = getDimensions(expr_check[0])
        arg1_check = self.expression_arg1.check(table)
        if arg1_check is None:
            return None
        if self.expression_arg2:
            arg2_check = self.expression_arg2.check(table)
            if arg2_check is None:
                return None
            if not projection_check_matrix(arg1_check,arg2_check,dimensions[0],dimensions[1]):
                return None
        else:
            if not projection_check_vector(arg1_check,dimensions[0],dimensions[1]):
                return None
        return ('number',None)
      
#############################         GROUP        ############################       
        
class Group(Expression):

    def __init__(self,expression):
        self.expression = expression
        
    def string_tree(self,level):
        indent = '    ' * level
        string = indent + "Group:\n"
        string += self.expression.string_tree(level+1)
        return string
    
    def check(self,table):
        return self.expression.check(table)

#############################    NUMERIC LITERAL   ############################

class Numeric(Expression):

    def __init__(self,number):
        self.number = number
        
    def string_tree(self,level):
        indent = '    ' * level
        string = indent + "Numeric literal: " + self.number + "\n"
        return string
    
    def check(self,table):
        return ('number',self.number)

#############################    BOOLEAN LITERAL   ############################
        
class Boolean(Expression):

    def __init__(self,bool):
        self.bool = bool
        
    def string_tree(self,level):
        indent = '    ' * level
        string = indent + "Boolean literal: " + self.bool + "\n"
        return string
        
    def check(self,table):
        return ('boolean',self.bool)
        
#############################    STRING LITERAL    ############################       
        
class String(Expression):

    def __init__(self,str):
        self.str = str
        
    def string_tree(self,level):
        indent = '    ' * level
        string = indent + "String literal: " + self.str + "\n"
        return string
        
    def check(self,table):
        return ('string',self.str)
    
#############################    MATRIX LITERAL    ############################

def matrix_dimension_error():
    message = "ERROR: The number of columns"
    message += " for each row must match"
    static_error.append(message)
    
def matrix_type_error(arg_type):
    message = "ERROR: Invalid type '" + arg_type
    message += "' for matrix arguments"
    static_error.append(message)
    
class Matrix(Expression):
    
    def __init__(self,argument_list):
        self.argument_list = argument_list
        
    def string_tree(self,level):
        indent = '    ' * level
        string = indent + "Matrix Literal:\n"
        for argument in self.argument_list:
            if type(argument) is list:
                string += argument[0].string_tree(level+1)
            else:
                string += argument.string_tree(level+1)
        return string
        
    def check(self,table):
        rows = 0
        columns_Old = 0
        columns_New = 0
        for argument in self.argument_list:
            if type(argument) is list:
                arg_check = argument[0].check(table)
                if arg_check[0] != 'number':
                    matrix_type_error(arg_check[0])
                    return None
                if argument[1] == ':':
                    if rows != 0:
                        if columns_New != columns_Old:
                            matrix_dimension_error()
                            return None
                    rows += 1
                    columns_Old = columns_New
                    columns_New = 0
                elif argument[1] == ',':
                    columns_New += 1
            else:
                arg_check = argument.check(table)
                if arg_check[0] != 'number':
                    matrix_type_error(arg_check[0])
                    return None
        if columns_New != columns_Old and rows != 0:
            matrix_dimension_error()
            return None
        else:
            result = 'matrix(' + str(rows+1) + ',' + str(columns_New+1) + ')'
            return (result,None)

#############################     FUNCTION CALL    ############################

def function_error_not_defined(identifier):
    message = "ERROR: Function '" + identifier + "' is not defined"
    static_error.append(message)

def function_error_param(identifier):
    message = "ERROR: number of arguments or argument types must match the function '"
    message += identifier + "' declaration"
    static_error.append(message)
        
class Function_call(Expression):

    def __init__(self,identifier,argument_list = None):
        self.identifier = identifier
        self.argument_list = argument_list
        
    def string_tree(self,level):
        indent = '    ' * level
        string = indent + "Function Call:\n" 
        string += self.identifier.string_tree(level+1)
        if self.argument_list:
            for argument in self.argument_list:
                string += argument.string_tree(level+1)
        return string
    
    def check(self,table):
        result = self.identifier.check(table)
        if result is None:
            function_error_not_defined(self.identifier.name)
            return None
        if self.argument_list:
            types = []
            for argument in self.argument_list:
                arg_check = argument.check(table)
                if arg_check is not None:
                    types.append(arg_check[0])
            if result[0] != types:
                function_error_param(self.identifier.name)
                return None
        return (table.findSymbol('return'),None)
    
###############################################################################
#############################      IDENTIFIER      ############################
###############################################################################        
        
class Identifier(Expression):
    
    def __init__(self,name):
        self.name = name
        
    def string_tree(self,level):
        indent = '    ' * level
        return indent + "Identifier: " + self.name + "\n"
    
    def check(self,table):
        result = table.findSymbol(self.name)
        if result is None:
            message = "ERROR: Identifier '" + self.name + "' is out of scope"
            static_error.append(message)
            return None
        return (result,None)
            
###############################################################################
#############################       ARGUMENTS      ############################
###############################################################################        
        
class Argument(Expression):
    
    def __init__(self,expression,separator = None):
        self.expression = expression
        self.separator = separator
        
    def string_tree(self,level):
        indent = '    ' * level
        string = indent + "Argument:\n" 
        string += self.expression.string_tree(level+1)
        return string
    
    def check(self,table):
        return self.expression.check(table)
    
static_error = []
