# Archivo: lexer.py
# Este archivo contiene la clase lexer y las funciones 
# que permiten lexear el input.
# Autores: 
#   - Miguel  Saraiva   09-10794
#   - Gabriel Alvarez   09-10029
# Grupo: 10

import re
import sys
import token as tokenLib

reSymbols = [ re.compile('\['), re.compile('\]'), re.compile(':'), 
            re.compile(','), re.compile('\('), re.compile('\)'),
            re.compile('{'), re.compile('}'), re.compile('&'), 
            re.compile('\|'), re.compile('=='), re.compile('/='),
            re.compile('<='), re.compile('>='), re.compile('\+'), 
            re.compile('-'), re.compile('\<'), re.compile('\>'),
            re.compile('\*'), re.compile('/'), re.compile('%'),
            re.compile('\''), re.compile('\.\+\.'), re.compile('\.-\.'), 
            re.compile('\.\*\.'), re.compile('\./\.'), re.compile('\.%\.'),
            re.compile('\.div\.'), re.compile('\.mod\.'),
            re.compile(';'), re.compile('=')]
    
class Lexer(object):
    tokenList = []
    column = 1
    line = 1
    nextPop = 0
    
    def input(self,input):
        regex = {
                  'space':re.compile(' '),
                  'tab':re.compile('\t'),
                   'newLine':re.compile('\n'),
                  'word':re.compile('[a-zA-Z][_a-zA-Z0-9]*'),
                 'number':re.compile('[0-9]+(\.[0-9]+)?'),
                 'string':re.compile('"([^"\\\\]|\\\\(n|\\\\|"))*"'),
                  'hashtag':re.compile('#.*\\n'),
                  'carReturn':re.compile('\r')
                  } 
        while input: 
            found = 0    
            k = 0
            for x in regex:
                match = regex[x].match(input)
                if match:
                    found = 1
                    i = createToken(match,x,self.line,self.column,self.tokenList)
                    if (i['column'] == 0):
                        self.column = 1
                    self.line += i['line']
                    self.column += i['column']
                    input = input[i['len']:]
                    break
            if (found == 0):
                i = createSymbol(self.line,self.column,self.tokenList,reSymbols,input)
                input = input[i:]
                self.column += i
# If you want to print the tokens, uncomment the next 2 lines.
#        for x in self.tokenList:
#            x.printToken()
        return self.tokenList

    def token(self):
        if (self.nextPop < len(self.tokenList)):
            self.nextPop += 1
            return self.tokenList[self.nextPop-1]
        else:
            return None

def createSymbol(line, column, tokenList,reSymbols,input):
    found = 0
    for x in reSymbols:
        aux = x.match(input)
        if aux:
            found = 1
            value = aux.group(0)
            tokenLib.symbolizer(line, column, value, tokenList)
            return len(value)
    if (found == 0):
        tokenLib.createError(line, column, input[0], tokenList)
        return 1        

def createToken(match,matchType,line,column,tokenList):
    match = match.group(0)
    ret = {'line':0,'column':0,'len':0}
    if (matchType == 'space'):
        ret['column'] += 1
        ret['len'] = 1
    elif (matchType == 'tab'):
        ret['column'] += 4
        ret['len'] =  1
    elif (matchType == 'newLine'):
        ret['column'] = 0
        ret['line'] +=  1
        ret['len'] =  1
    elif (matchType == 'carReturn'):
        ret['len'] = 1
    elif (matchType == 'hashtag'):
        ret['column'] = 0
        ret['line'] +=  1
        ret['len'] =  len(match)
    elif (matchType == 'word'):
        tokenLib.tokenizer(line,column,match,tokenList)
        ret['column'] += len(match)
        ret['len'] =  len(match)
    elif (matchType == 'number'):
        if ((match[0] == '-') and tokenList and 
            ((isinstance(tokenList[-1],tokenLib.VARNAME))
            or (isinstance(tokenList[-1],tokenLib.NUMBER)))):
                tokenLib.tokenizer(line,column,match[0],tokenList)
                tokenLib.createNumber(line, column+1, match[1:], tokenList)
        else:
            tokenLib.createNumber(line, column, match, tokenList)
        ret['column'] += len(match)
        ret['len'] =  len(match)
    elif (matchType == 'string'):
        tokenLib.createString(line,column,match,tokenList)
        ret['column'] += len(match)
        ret['len'] =  len(match)
    return ret