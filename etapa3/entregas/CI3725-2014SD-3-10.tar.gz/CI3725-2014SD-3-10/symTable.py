# Archivo: symTable
# Este archivo contiene la tabla de simbolos utilizada para el analisis
# de contexto de Trinity.
# Autores: 
#    - Miguel  Saraiva    09-10794
#    - Gabriel Alvarez    09-10029
# Grupo: 10

class SymTable(object):

    def __init__(self):
        self.table = {}
        self.outer = None
        self.isFunction = False
        
    def toString(self,level):
        indent = '    '*level
        string = ""
        for key in self.table.keys():
            if key != "return":
                string += indent + key + ": " 
                string += self.table[key] + "\n"
        return string
    
    def findSymbol(self,key):
        if key in self.table.keys():
            return self.table[key]
        else:
            if self.outer is not None:
                auxRet = self.outer.findSymbol(key)
                if (auxRet == None):
                    return None
                else: 
                    return auxRet
            else:
                return None
    
    def findFunction(self):
        aux = self
        while not aux.isFunction:
            if aux.outer is None:
                return False
            aux = aux.outer
        return True
    
    def existsSymbol(self,key):
        if key in self.table.keys():
            return True
        return False
    
    def insert(self,key,value):
        self.table[key] = value
        