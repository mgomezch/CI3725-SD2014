-- CI 3725 Septiembre-Diciembre 2014
-- Proyecto, Entrega 3
-- Integrantes:
--		Brian Mendoza 07-41206
{-# LANGUAGE DeriveDataTypeable #-}

module AST where

import Tokens
import Data.Data
import Data.Typeable
import Data.Generics

data Expresion
			= Suma Expresion Expresion
			| Resta Expresion Expresion
			| Multiplicacion Expresion Expresion
			| DivisionExacta Expresion Expresion
			| RestoExacto Expresion Expresion
			| DivisionEntera Expresion Expresion
			| RestoEntero Expresion Expresion
			| SumaCruzada Expresion Expresion
			| RestaCruzada Expresion Expresion
			| MultiplicacionCruzada Expresion Expresion
			| DivisionExactaCruzada Expresion Expresion
			| RestoExactoCruzado Expresion Expresion
			| DivisionEnteraCruzada Expresion Expresion
			| RestoEnteroCruzado Expresion Expresion
			| And Expresion Expresion
			| Or Expresion Expresion
			| Igual Expresion Expresion
			| NoIgual Expresion Expresion
			| MenorIgual Expresion Expresion
			| MayorIgual Expresion Expresion
			| Menor Expresion Expresion
			| Mayor Expresion Expresion
            | ProyeccionMatriz Expresion Expresion Expresion
            | ProyeccionVector Expresion Expresion
			| Traspuesta Expresion
            | Negacion Expresion
            | Not Expresion
            | LiteralMatricial [[Expresion]]
            | LlamadaFuncion Token [Expresion]
			| LiteralNumerico Token
			| Identificador Token
			| Falso
			| Verdadero
			deriving (Eq, Show, Data, Typeable)


data Instruccion
			= Asignacion LValue Expresion
			| IfThenElse Expresion [Instruccion] [Instruccion]
            | IfThen Expresion [Instruccion]
			| Read Token
            | Print [Impresion]
            | Use [Declaracion] [Instruccion]
            | While Expresion [Instruccion]
            | For Token Expresion [Instruccion]
            | Return Expresion
            | InstruccionExpresion Expresion
			deriving (Eq, Show, Data, Typeable)

data LValue
            = LValueIdentificador Token
            | LValueVector Token Expresion
            | LValueMatriz Token Expresion Expresion
            deriving (Eq, Show, Data, Typeable)

data Impresion
            = ImprimirExpresion Expresion
            | ImprimirString Token
            deriving (Eq, Show, Data, Typeable)

data Declaracion
            = DeclaracionInicializada Tipo Token Expresion
            | DeclaracionNoInicializada Tipo Token
            deriving (Eq, Show, Data, Typeable)

data Funcion
            = Funcion Token [Parametro] Tipo [Instruccion]
            deriving (Eq, Show, Data, Typeable)

data Parametro
            = Parametro Tipo Token
            deriving(Eq, Show, Data, Typeable)

data Program
            = Program [Funcion] [Instruccion]
            deriving(Eq, Show, Data, Typeable)

data Tipo
			= TipoBoolean
			| TipoNumber
			| TipoMatriz Double Double
			deriving (Eq, Show, Data, Typeable)



