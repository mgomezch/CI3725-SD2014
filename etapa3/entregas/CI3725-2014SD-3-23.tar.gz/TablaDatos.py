'''
	Tabla de Datos
'''
class Tabla:
	def __init__(self,tf):
		self.hijos = []
		self.identificadores = dict()
		self.valores = dict()
		self.padre = None
		# Referencia a la tabla de funciones
		self.tf = tf

	def agregar_hijo(self,h):
		self.hijos.append(h)

	def agregar_padre(self,p):
		self.padre = p
		self.tf = self.padre.tf
		p.agregar_hijo(self)

	def agregar_identificador(self,i,t):
		self.identificadores[i] = t
		self.valores[i] = None

	def asignar_valor(self,i,v):
		self.valores[i] = v

	def buscar_identificador(self,i):
		if i in self.identificadores:
			return self.identificadores[i]
		else:
			if self.padre:
				return self.padre.buscar_identificador(i)
	
	
	def buscar_funcion(self,f):
		return self.tf.buscar_identificador(f)
		
	def verificar_argumentos(self,i,a):
		return self.tf.verificar_argumentos(i,a)
	
	def buscar_valor(self,i):
		if i in self.valores:
			return self.valores[i]
		else:
			if self.padre:
				return self.padre.buscar_valor(i)
		return None

'''
	Tabla de funciones
'''		
class TablaF:
	def __init__(self):
		self.identificadores = dict()
		self.argumentos = dict()

	def agregar_identificador(self,i,t,a):
		self.identificadores[i] = t
		self.argumentos[i] = a

	def buscar_identificador(self,i):
		if i in self.identificadores:
			return self.identificadores[i]
		else:
			return None
	
	def verificar_argumentos(self,i,a):
		if self.argumentos[i]:
			if a:
				if len(a) == len(self.argumentos(i)):
					for i in range(len(a)):
						if not(a[i].__class__.__name__ == self.argumentos[i].__class__.__name__):
							return False
					return True
				return False
			else:
				return False
		else:
			return True
