''' Modulo con las clases necesarias por el Parser
Autores: Jesus Parra
		 Cristian Medina ''' 

from TablaDatos import *
from tokens import *
import sys		 
		 
class identificador:
	def __init__(self,i):
		self.nombre = i;
	def imprimir(self,tb):
		print tb, 'Identificador:\n',tb,' nombre:',self.nombre
	def check(self,ts):
		tipo = ts.buscar_identificador(self.nombre)
		if tipo:
			return tipo
		print 'No ha sido declarado una Variable con el nombre: ',self.nombre
		sys.exit(1)
	 
class Tipo:
	def __init__(self,tipo):
		self.tipo = tipo;
	def imprimir(self,tb):
		print tb, 'Tipo: ',self.tipo
	def check(self,ts):
		#return self.tipo
		if (self.tipo == 'boolean'):
		  return Booleano(False)
		if (self.tipo == 'number'):
		  return Numero(0)	
		
class Tipo_matrix:
	def imprimir(self,tb):
		print tb, 'Tipo: Matrix(',self.fila,',',self.columna,')'
	def __init__(self,f,c):
		self.fila = float(f)
		self.columna = float(c)
	def check(self,ts):
		if self.fila != int(self.fila):
			print ("El numero para la fila en el tipo matriz no es entero")
			sys.exit(1)
		if self.columna != int(self.columna):
			print ("El numero para la columna en el tipo matriz no es entero")
			sys.exit(1)
		if self.columna < 0 or self.fila < 0:
			print 'Los valores de la columna y la fila deben ser positivos'
			sys.exit(1)
		return self

class Proyeccion_matrix:
	def imprimir(self,tb):
		if self.fila:
			print tb, 'Proyeccion Matriz:'
			self.identificador.imprimir(tb+' ')
			print tb, ' columna:'
			self.columna.imprimir(tb+'  ')
			print tb, ' fila:'
			self.fila.imprimir(tb+'  ')
		else:
			print tb, 'Proyeccion Matriz:'
			self.identificador.imprimir(tb+' ')
			print tb,' posicion:'
			self.columna.imprimir(tb+'  ')
	def __init__(self,i,f,c):
		self.identificador = i
		self.columna = c
		self.fila = f
	def check(self,ts):
		# se chequea el literal o identificador
		tv = self.identificador.check(ts)
		if self.columna.__class__.__name__ == 'identificador':
			if not(self.columna.check()):
				print 'No existe el la variable que se asigna a la columna' 
		if self.fila.__class__.__name__ == 'identificador':
			if not(self.fila.check()):
				print 'No existe el la variable que se asigna a la fila' 

		if self.identificador.__class__.__name__ == 'Identificador':
			if not(tv):
				print 'No existe la variable matriz que se quiere usar'
				sys.exit(1)
		else:
			if tv.__class__.__name__ == 'Tipo_matrix':
				return Numero(0)
			else:
				print 'La expresion a proyectar no es una matriz'
				sys.exit(1)
'''
				if not(self.columna.__class__.__name__ == 'identificador' or 
				   self.fila.__class__.__name__ == 'identificador'):
					if tv.__class__.__name__ == 'Tipo_matrix':
						if (tv.columna >= self.columna.valor) and (self.columna.valor > 0):
							if (tv.fila >= self.fila.valor) and (self.fila.valor > 0): 
								#if ts.buscar_valor(self.identificador):
									return Numero(0)
								#else:
								#	print 'La variable no ha sido inicializada'
							else:
								print 'La posicion de la fila esta fuera del rango de la matriz'
								sys.exit(1)
						else:
							print 'El posicion de la columna esta fuera del rango de la matriz'
							sys.exit(1)					
					else:
						print 'La variable no es de tipo matriz'
						sys.exit(1)				
				else:
					return Numero(0)'''		

'''				if (tv.columna >= self.columna.valor) and (self.columna.valor > 0):
					if (tv.fila >= self.fila.valor) and (self.fila.valor > 0): 
							return Numero(0)
					else:
						print 'La posicion de la fila esta fuera del rango de la matriz'
						sys.exit(1)
				else:
					print 'El posicion de la columna esta fuera del rango de la matriz'
					sys.exit(1)'''				

class Asignacion:
	def imprimir(self,tb):
		print tb, 'Asignacion:'
		print tb, ' lado izquierdo:'
		self.identificador.imprimir(tb+'  ') 
		print tb, ' lado derecho:'
		self.expresion.imprimir(tb+'  ')
	def __init__(self,i,e):
		self.identificador = i
		self.expresion = e
	def check(self,ts):
		
		tIden = self.identificador.check(ts)
		tExpr = self.expresion.check(ts)
		if tIden:
			
			if tIden.__class__.__name__ == tExpr.__class__.__name__:
				ts.asignar_valor(self.identificador,0)
				return
			else:
				print 'El tipo de la varibale', self.identificador.nombre,'no coincide con el tipo del valor que se le asigna'
				sys.exit(1)		
		else:
			print 'No existe la variable', self.identificador.nombre
			sys.exit(1)

class OR:
	def imprimir(self,tb):
		print tb, 'Operacion OR:'
		print tb, ' lado izquierdo:'
		self.valorI.imprimir(tb+'  ')
		print tb, ' lado derecho:'
		self.valorR.imprimir(tb+'  ')
	def __init__(self,i,r):
		self.valorI = i
		self.valorR = r
	def check(self,ts):
		tDer = self.valorR.check(ts)
		tIzq = self.valorI.check(ts)
		if tIzq.__class__.__name__ == 'Booleano':
			if tDer.__class__.__name__ == tIzq.__class__.__name__:
				return Booleano(False)
			print 'El lado derecho de la expresion OR no es booleano'
			sys.exit(1)
		else:
			print 'El lado izquierdo de la expresion OR no es booleano'
			sys.exit(1)

class AND:
	def imprimir(self,tb):
		print tb, 'Operacion AND:'
		print tb, ' lado izquierdo:'
		self.valorI.imprimir(tb+'  ')
		print tb, ' lado derecho:'
		self.valorR.imprimir(tb+'  ')
	def __init__(self,i,r):
		self.valorI = i
		self.valorR = r
	def check(self,ts):
		tDer = self.valorR.check(ts)
		tIzq = self.valorI.check(ts)
		if tIzq.__class__.__name__ == 'Booleano':
			if tDer.__class__.__name__ == tIzq.__class__.__name__:
				return Booleano(False)
			print 'El lado derecho de la expresion AND no es booleano'
			sys.exit(1)
		else:
			print 'El lado izquierdo de la expresion AND no es booleano'
			sys.exit(1)



class Igualdad:
	def imprimir(self,tb):
		print tb, 'Operacion Igualdad:'
		print tb, ' lado izquierdo:'
		self.valorI.imprimir(tb+'  ')
		print tb, ' lado derecho:'
		self.valorR.imprimir(tb+'  ')
	def __init__(self,i,r):
		self.valorI = i
		self.valorR = r
	def check(self,ts):
		tDer = self.valorR.check(ts)
		tIzq = self.valorI.check(ts)
		if tDer.__class__.__name__ == tIzq.__class__.__name__:
			return Booleano(False)
		print 'Los valores a comparar en la igualdad deben ser del mismo tipo'
		sys.exit(1)



class Diferencia:
	def imprimir(self,tb):
		print tb, 'Operacion Diferencia:'
		print tb, ' lado izquierdo:'
		self.valorI.imprimir(tb+'  ')
		print tb, ' lado derecho:'
		self.valorR.imprimir(tb+'  ')
	def __init__(self,i,r):
		self.valorI = i
		self.valorR = r
	def check(self,ts):
		tDer = self.valorR.check(ts)
		tIzq = self.valorI.check(ts)
		if tDer.__class__.__name__ == tIzq.__class__.__name__:
			return Booleano(False)
		print 'Los valores a comparar en la diferencia deben ser del mismo tipo'
		sys.exit(1)


class Relacion:
	def imprimir(self,tb):
		print tb, 'Operacion Relacional:'
		print tb, ' Operador:',self.operador
		print tb, ' lado izquierdo:'
		self.valorI.imprimir(tb+'  ')
		print tb, ' lado derecho:'
		self.valorR.imprimir(tb+'  ')
	def __init__(self,i,o,r):
		self.valorI = i
		self.operador = o
		self.valorR = r
	def check(self,ts):
		tDer = self.valorR.check(ts)
		tIzq = self.valorI.check(ts)
		if tIzq.__class__.__name__ == 'Numero':
			if tDer.__class__.__name__ == tIzq.__class__.__name__:
				return Booleano(False)
			print 'El lado derecho de la expresion relacional no es un numero'
			sys.exit(1)
		else:
			print 'El lado izquierdo de la expresion relacional no es un numero'
			sys.exit(1)
	
class Adicion:
	def imprimir(self,tb):
		print tb, 'Operacion Adicion:'
		print tb, ' Operador:',self.operador
		print tb, ' lado izquierdo:'
		self.valorI.imprimir(tb+'  ')
		print tb, ' lado derecho:'
		self.valorR.imprimir(tb+'  ')
	def __init__(self,i,o,r):
		self.valorI = i
		self.operador = o
		self.valorR = r
	def check(self,ts):
		tIzq = self.valorI.check(ts);
		tDer = self.valorR.check(ts);
		if not(tIzq.__class__.__name__ == 'Booleano') and not(tDer.__class__.__name__ == 'Booleano'):		
			if not (tIzq.__class__.__name__ == tDer.__class__.__name__ ):
				if not((self.operador == '.+.') or (self.operador == '.-.')):
				  print 'Los tipos de operandos de la adicion no son iguales'
				  sys.exit(1)
				else:
					if tIzq.__class__.__name__ == 'Tipo_matrix':
						return Tipo_matrix(tIzq.fila, tIzq.columna)		
					else:
						return Tipo_matrix(tDer.fila, tDer.columna)		
			else:
				if   (self.operador == '.+.') or (self.operador == '.-.'):
				  print 'Los tipos de operandos de la adicion  son ambos number o ambos matrix'
				  sys.exit(1)
				else:
					if tIzq.__class__.__name__ == 'Numero':					
						return Numero(0)
					else:
						if tIzq.columna == tDer.columna:
							if tIzq.fila == tIzq.fila:
								return Tipo_matrix(tDer.fila,tDer.columna)
							else:
								print 'El numero de las filas de la matrices no coinciden'
								sys.exit(1)
						else:
							print 'El numero de las columnas de la matrices no coinciden'
							sys.exit(1)			
		else:
			print 'No se pueden sumar valores de tipo booleano'
			sys.exit(1)

class Producto:
	def imprimir(self,tb):
		print tb, 'Operacion Producto:'
		print tb, ' Operador:',self.operador
		print tb, ' lado izquierdo:'
		self.valorI.imprimir(tb+'  ')
		print tb, ' lado derecho:'
		self.valorR.imprimir(tb+'  ')
	def __init__(self,i,o,r):
		self.valorI = i
		self.operador = o
		self.valorR = r
	def check(self,ts):
		tIzq = self.valorI.check(ts);
		tDer = self.valorR.check(ts);
		if not(tIzq.__class__.__name__ == 'Booleano') and not(tDer.__class__.__name__ == 'Booleano'):			
			if not (tIzq.__class__.__name__ == tDer.__class__.__name__ ):
				if not((self.operador == '.*.')
 					or (self.operador == './.') or (self.operador == '.%.') 
				  or (self.operador == '.div.') or (self.operador == '.mod.')):				
					print 'Los tipos de operandos del producto no son iguales'
					sys.exit(1)
				else:
					if tIzq.__class__.__name__ == 'Tipo_matrix':
						return Tipo_matrix(tIzq.fila, tIzq.columna)		
					else:
						return Tipo_matrix(tDer.fila, tDer.columna)					
			else:
				if  ((self.operador == '.*.') or (self.operador == './.') 
				  or (self.operador == '.%.') or (self.operador == '.div.')
				  or (self.operador == '.mod.')):	
					print 'Los tipos de operandos del producto son ambos number o ambos matrix'
					sys.exit(1)
				else:
					if tIzq.__class__.__name__ == 'Numero':					
						return Numero(0)
					else:
						if self.operador == '*':
							if tIzq.columna == tDer.fila:
								if tDer.columna == tIzq.fila:
									return Tipo_matrix(tIzq.fila,tDer.columna)
								else:	
									print 'El numero de las fila de la primera matrix no coincide con las columnas de la segunda matriz'
									sys.exit(1)
							else:
								print 'El numero de las columnas de la primera matricx no coincide con las de filas de la segunda matriz'
								sys.exit(1)	
						else:
							print 'El tipo matriz no soporta ese tipod e operador'
							sys.exit(1)
		else:
			print 'No se pueden realizar esa operacion con tipos booleanos.'
			sys.exit(1)

class Unario:
	def imprimir(self,tb):
		print tb, 'Operacion Unaria:'
		print tb, ' operador:', self.operador
		print tb, ' valor:'
		self.valor.imprimir(tb+'  ')
	def __init__(self,o,v):
		self.operador = o
		self.valor = v
	def check(self,ts):
		tEx = self.valor.check(ts)
		
		if self.operador == 'not':			
			if tEx.__class__.__name__ == 'Booleano':
				return Booleano(False)
			else:
				print 'No puede aplicarse NOT a una expresion que no es booleana'
				sys.exit(1)
		if self.operador == '\'':
			if tEx.__class__.__name__ == 'Tipo_matrix':
				return Tipo_matrix(tEx.fila,tEx.columna)
			else:
				print 'No puede aplicarse \' a una expresion que no es matriz'
				sys.exit(1)
		if self.operador == '-':
			if tEx.__class__.__name__ == 'Numero':
				return Numero(0)
			elif tEx.__class__.__name__ == 'Tipo_matrix':
				return Tipo_matrix(tEx.fila,tEx.columna)
			else:
				print 'No puede aplicarse - a una expresion es booleana'
				sys.exit(1)

class llamadaFuncion:
	def imprimir(self,tb):
		if self.argumentos:
			print tb, 'LlamadaFuncion:'
			self.identificador.imprimir(tb+' ')
			print tb, " Argumentos:"
			self.argumentos.imprimir(tb+'  ')
		else:
			print tb, 'LlamadaFuncion:'
			self.identificador.imprimir(tb+' ')
			print tb, " Argumentos:\n",tb,'  VACIO'
	def __init__(self,i,a):
		self.identificador = i
		self.argumentos = a
	def check(self,ts):
		tFunc = ts.buscar_funcion(self.identificador)
		if tFunc:
			tArg = None
			if self.argumentos:
				tArg = self.argumentos.check(ts)
			if not(ts.verificar_argumentos(tArg)):
				print 'Los argumentos de la llamada a funcion', self.identificador.nombre,'no coinciden'
				sys.exit(1)
			else:
				return tFunc
		else:
			print 'La funcion', self.identificador.imprimir(''),'\nNo existe'
			sys.exit(1)
	

class Numero:
	def imprimir(self,tb):
		print tb, 'Literal Numerico:'
		print tb+' ', self.valor
	def __init__(self,v):
		self.valor = float(v)
	def check(self,ts):
		return Numero(0)

class Booleano:
	def imprimir(self,tb):
		print tb, 'Literal Booleano:'
		print tb+' ', self.valor
	def __init__(self,v):
		self.valor = v
	def check(self,ts):
		return Booleano(False)

class Declaracion_variable:
	def imprimir(self,tb):
		if self.expresion:
			print tb, 'Declaracion de un variable:'
			self.tipo.imprimir(tb+' ')
			self.identificador.imprimir(tb+' ')
			print tb, ' Valor:'
			self.expresion.imprimir(tb+'  ')
		else:
			print tb, 'Declaracion de un variable:'
			self.tipo.imprimir(tb+' ')
			self.identificador.imprimir(tb+' ')
	def __init__(self,t,i,e):
		self.expresion = e
		self.identificador = i
		self.tipo = t
	def check(self,ts):
		if (ts.buscar_identificador(self.identificador.nombre)):
			print "La variable ya fue declarada en el mismo contexto"
			sys.exit(1)
		else:
			if (self.expresion):
				te = self.expresion.check(ts)
				tt = self.tipo.check(ts)
				
				if (isinstance(te,Tipo_matrix)):
					if not ((te.fila == tt.fila) and (te.columna == tt.columna)):
						print 'Las filas o las columnas del tipo no son igualesa la expresion '
						sys.exit(1)
					
				else:
					if not(te.__class__.__name__ == tt.__class__.__name__):
						print "El tipo de la variable y su expresion son diferentes"
						sys.exit(1)
						
				ts.agregar_identificador(self.identificador.nombre,self.tipo.check(ts))
			else:
				ts.agregar_identificador(self.identificador.nombre,self.tipo.check(ts))
	
class Lista_declaracion_variable:
	def imprimir(self,tb):
		self.declaracion1.imprimir(tb)
		self.declaracion2.imprimir(tb)
	def __init__(self,i,r):
		self.declaracion1 = i
		self.declaracion2 = r
	def check(self,ts):
		self.declaracion1.check(ts)
		self.declaracion2.check(ts)
	
class Lista_instruccion:
	def imprimir(self,tb):
		if self.instruccion1:
			self.instruccion1.imprimir(tb)
		self.instruccion2.imprimir(tb)
	def __init__(self,i,r):
		self.instruccion1 = i
		self.instruccion2 = r
	def check(self,ts,tipo):
		
		if ((self.instruccion2.__class__.__name__ == 'Seleccion') or
			(self.instruccion2.__class__.__name__ == 'Impresion') or 
			(self.instruccion2.__class__.__name__ == 'Iteracion_For') or 
			(self.instruccion2.__class__.__name__ == 'Iteracion_While') or
			(self.instruccion2.__class__.__name__ == 'Lectura') or
			(self.instruccion2.__class__.__name__ == 'Bloque_instrucciones') or
			(self.instruccion2.__class__.__name__ == 'Retorna') or
			(self.instruccion2.__class__.__name__ == 'Lista_instruccion')):
						
			t2 = self.instruccion2.check(ts,tipo)
		else:
			t2 = self.instruccion2.check(ts)
			t2 = None

		t1 = None
		
		if self.instruccion1:
			
			if ((self.instruccion1.__class__.__name__ == 'Seleccion') or
				(self.instruccion1.__class__.__name__ == 'Impresion') or 
				(self.instruccion1.__class__.__name__ == 'Iteracion_For') or 
				(self.instruccion1.__class__.__name__ == 'Iteracion_While') or
				(self.instruccion1.__class__.__name__ == 'Lectura') or
				(self.instruccion1.__class__.__name__ == 'Bloque_instrucciones') or
				(self.instruccion1.__class__.__name__ == 'Retorna') or
				(self.instruccion1.__class__.__name__ == 'Lista_instruccion')):
				t1 = self.instruccion1.check(ts,tipo)
			else:
				t1 = self.instruccion1.check(ts)
				t1 = None
		if (tipo):	
			if (t1 and t2):
				if (t1.__class__.__name__ != t2.__class__.__name__):
					print "Tiene varios return de tipos diferentes"
					sys.exit(1)
				else:
					if (t1.__class__.__name__ != tipo.__class__.__name__):
						print t1.__class__.__name__,tipo.__class__.__name__
						print "Tiene un return diferente al tipo de la funcion"
						sys.exit(1)
					else:
		
						return tipo
			elif (t1):
				if (t1.__class__.__name__ != tipo.__class__.__name__):
						print t1.__class__.__name__, tipo.__class__.__name__
						print "Tiene un return diferente al tipo de la funcion"
						sys.exit(1)
				else:
					
					return tipo
			elif (t2):
				if (t2.__class__.__name__ != tipo.__class__.__name__):
						print t2.__class__.__name__, tipo.__class__.__name__
						print "Tiene un return diferente al tipo de la funcion"
						sys.exit(1)
				else:
					
					return tipo
			else:
				return None
		else:
			if (t1 or t2):
				print "La lista de instrucciones tiene un return y no es funcion"
				sys.exit(1)
			
		
class Bloque_instrucciones:
	def imprimir(self,tb):
		if self.lista_variables:
			if self.instrucciones:
				print tb, 'Bloque de Instrucciones:'
				print tb, ' Variables:'
				self.lista_variables.imprimir(tb+'  ')
				print tb, ' Instrucciones:'
				self.instrucciones.imprimir(tb+'  ')
			else: 
				print tb, 'Bloque de Instrucciones:'
				print tb, ' Variables:'
				self.lista_variables.imprimir(tb+'  ')
				print tb, ' Instrucciones:\n',tb,'  VACIO'
		else:
			if self.instrucciones:
				print tb, 'Bloque de Instrucciones:'
				print tb, ' Variables:\n',tb,'  VACIO'
				print tb, ' Instrucciones:'
				self.instrucciones.imprimir(tb+'  ')
			else: 
				print tb, 'Bloque de Instrucciones:'
				print tb, ' Variables:\n',tb,'  VACIO'
				print tb, ' Instrucciones:\n',tb,'  VACIO'

	def __init__(self,i,r):
		self.lista_variables = i
		self.instrucciones = r
	def check(self,ts,tipo):
		t = Tabla(None)
		t.agregar_padre(ts)
		if self.lista_variables:
			self.lista_variables.check(t)
		if self.instrucciones:
			return self.instrucciones.check(t,tipo)
		return None
		
		
class bloque_seleccion:
	def imprimir(self,tb):
		if self.segundo_bloque:
			self.primer_bloque.imprimir(tb+'  ')
			print tb, 'ELSE - Ejecuta:'
			self.segundo_bloque.imprimir(tb+'  ')
		else:
			self.primer_bloque.imprimir(tb+'  ')
			print tb, 'ELSE - Ejecuta:\n',tb,' VACIO'
	def __init__(self,i,r):
		self.primer_bloque = i
		self.segundo_bloque = r
	def check(self,ts,tipo):
		self.primer_bloque.check(ts,tipo)
		if (self.segundo_bloque):
		  self.segundo_bloque.check(ts,tipo)
		
	
class Seleccion:
	def imprimir(self,tb):
		if self.segundo_bloque:
			print tb, 'Seleccion IF:'
			print tb, ' Condicion:'
			self.primer_bloque.imprimir(tb+'  ')
			print tb, ' THEN - Ejecuta:'
			self.segundo_bloque.imprimir(tb+' ')
		else:
			print tb, 'Seleccion IF:'
			print tb, ' Condicion:'
			self.primer_bloque.imprimir(tb+'  ')
			print tb, ' THEN - Ejecuta:\n',tb,'  VACIO'
	def __init__(self,i,r):
		self.primer_bloque = i
		self.segundo_bloque = r
	def check(self,ts,tipo):
		te = self.primer_bloque.check(ts)
		if not(isinstance(te,Booleano)):
			print "La expresion de la seleccion no es booleana"
			sys.exit(1)
		else:
			self.segundo_bloque.check(ts,tipo)

class Iteracion_For:
	def imprimir(self,tb):
		if self.bloque:
			print tb, 'Iteracion FOR:'
			print tb, ' Condicion:'
			self.identificador.imprimir(tb+'  ')
			print tb, ' IN - Matriz:'
			self.matrix.imprimir(tb+'  ')
			print tb, ' DO - Ejecuta:'
			self.bloque.imprimir(tb+'  ')
		else:
			print tb, 'Iteracion FOR:'
			print tb, ' Condicion:'
			self.identificador.imprimir(tb+'  ')
			print tb, ' IN - Matriz:'
			self.matrix.imprimir(tb+'  ')
			print tb, ' DO - Ejecuta:\n', tb, '  VACIO'	
	def __init__(self,i,m,b):
		self.identificador = i
		self.bloque = b
		self.matrix = m
	def check(self,ts,tipo):
		t = Tabla(None)
		t.agregar_padre(ts)
		t.agregar_identificador(self.identificador.nombre,Numero(0))
		tm = self.matrix.check(ts)
		if tm.__class__.__name__ != 'Tipo_matrix':
			print 'No se especifico una matrix como rango para la Itearacion FOR'
			sys.exit(1)
		self.bloque.check(t,tipo)


class Iteracion_While:
	def imprimir(self,tb):
		if self.bloque:
			print tb, 'Iteracion WHILE:'
			print tb, ' Condicion:'
			self.expresion.imprimir(tb+'  ')
			print tb, ' DO - Ejecuta:'
			self.bloque.imprimir(tb+'  ')
		else:
			print tb, 'Iteracion WHILE:'
			print tb, ' Condicion:'
			self.expresion.imprimir(tb+'  ')
			print tb, ' DO - Ejecuta:\n', tb, '  VACIO'	
	def __init__(self,e,b):
		self.expresion = e
		self.bloque = b
	def check(self,ts,tipo):
		te = self.expresion.check(ts)
		if not (isinstance(te,Booleano)):
		  print "La expresion del while no es booleano"
		  sys.exit(1)
		else:
		  self.bloque.check(ts,tipo)

class String:
	def imprimir(self,tb):
		print tb, 'Literal String:'
		print tb+' ', self.valor
	def __init__(self,v):
		self.valor = v
	def check(self,ts):
		return String('')

class Bloque_impresion:
	def imprimir(self,tb):
		if self.imprimir1:
			self.imprimir1.imprimir(tb)
		print tb, 'Imprime:'
		self.imprimir2.imprimir(tb+' ')		
	def __init__(self,i,r):
		self.imprimir1 = i
		self.imprimir2 = r
	def check(self,ts):
		
		if (self.imprimir1):
		  self.imprimir.check(ts)
		self.imprimir2.check(ts)
		
class Impresion:
	def imprimir(self,tb):
		print tb, 'Impresion:'
		self.bloque.imprimir(tb+' ')
	def __init__(self,b):
		self.bloque = b
	def check(self,ts,tipo):
		self.bloque.check(ts)
	
class Lista_argumentos:
	def imprimir(self,tb):
		if self.arg1:
			self.arg1.imprimir(tb)
		print tb, 'Argumento:'
		self.arg2.imprimir(tb+' ')

	def __init__(self,i,r):
		self.arg1 = i
		self.arg2 = r
	def check(self,ts):
		tCheck2 = self.arg2.check(ts)
		l = list()
		l.append(tCheck2)
		if (self.arg1):
			tCheck1 = self.arg1.check(ts)
			l = tCheck1 + l
		return l
	
class Lectura:
	def imprimir(self,tb):
		print tb, 'Lectura:'
		self.identificador.imprimir(tb+' ')
	def __init__(self,i):
		self.identificador = i
	def check(self,ts,tipo):
		self.identificador.check(ts)
		
class Retorna:
	def imprimir(self,tb):
		print tb, 'Retorna:'
		self.expresion.imprimir(tb+' ')
	def __init__(self,e):
		self.expresion = e
	def check(self,ts,tipo):
		return self.expresion.check(ts)
		
class Parametro:
	def imprimir(self,tb):
		print tb, 'Parametro:'
		self.tipo.imprimir(tb+' ')
		self.identificador.imprimir(tb+' ')
	def __init__(self,t,i):
		self.tipo = t
		self.identificador = i
	def check(self,ts):
		if not (ts.buscar_identificador(self.identificador)):
			ts.agregar_identificador(self.identificador.nombre,self.tipo.check(ts))
			ts.asignar_valor(self.identificador,0)
			return self.tipo.check(ts)
		else:
			print "El identificado del parametro ha sido declarado previamente"
			sys.exit(1)
			
class lista_parametros:
	def imprimir(self,tb):
		if self.param1:
			self.param1.imprimir(tb)
		self.param2.imprimir(tb)
	def __init__(self,i,r):
		self.param1 = i
		self.param2 = r
	def check(self,ts):
		tCheck2 = self.param2.check(ts)
		l = list()
		l.append(tCheck2)
		if (self.param1):
			tCheck1 = self.param1.check(ts)
			l = tCheck1 + l
		return l

class Declaracion_funcion:
	def imprimir(self,tb):
		if self.lista_parametros:
			if self.bloque_funcion:
				print tb, 'Declaracion de Funcion:'
				self.identificador.imprimir(tb+' ')
				print tb, ' Lista de Parametros:'
				self.lista_parametros.imprimir(tb+'  ')
				self.tipo.imprimir(tb+' ')
				print tb, ' Bloque de Instrucciones: '
				self.bloque_funcion.imprimir(tb+'  ')
			else:
				print tb, 'Declaracion de Funcion:'
				self.identificador.imprimir(tb+' ')
				print tb, ' Lista de Parametros:'
				self.lista_parametros.imprimir(tb+'  ')
				self.tipo.imprimir(tb+' ')
				print tb, ' Bloque de Instrucciones:\n',tb,'  VACIO'
		else:
			if self.bloque_funcion:
				print tb, 'Declaracion de Funcion:'
				self.identificador.imprimir(tb+' ')
				print tb, ' Lista de Parametros:\n',tb,'  VACIO'
				self.tipo.imprimir(tb+' ')
				print tb, ' Bloque de Instrucciones: '
				self.bloque_funcion.imprimir(tb+'  ')
			else:
				print tb, 'Declaracion de Funcion:'
				self.identificador.imprimir(tb+' ')
				print tb, ' Lista de Parametros:\n',tb,'  VACIO'
				self.tipo.imprimir(tb+' ')
				print tb, ' Bloque de Instrucciones:\n',tb,'  VACIO'

	def __init__(self,i,l,t,b):
		self.identificador = i
		self.lista_parametros = l
		self.tipo = t
		self.bloque_funcion = b
		self.tabla = None
		
	def checkFunc(self,tf):
		
		self.tabla = Tabla(tf)
		
		tArg = None
		if self.lista_parametros:
			tArg = self.lista_parametros.check(self.tabla)
		if not(tf.buscar_identificador(self.identificador)):
			tf.agregar_identificador(self.identificador.nombre,self.tipo.check(tf),tArg)
		else:
			print 'Se declaro dos o mas veces una funcion con el mismo nombre'
			sys.exit(1)

	def check(self,ts):
		tr = self.bloque_funcion.check(self.tabla, self.tipo.check(ts))
		
		if not(self.bloque_funcion.check(self.tabla, self.tipo.check(ts))):
			print 'La funcion no posee una instruccion return'
			sys.exit(1)
	
class lista_funciones:
	def imprimir(self,tb):
		if self.funcion1:
			self.funcion1.imprimir(tb)
		self.funcion2.imprimir(tb)
	def __init__(self,i,r):
		self.funcion1 = i
		self.funcion2 = r
	def check(self,ts):
	  if (self.funcion1):
		  self.funcion1.check(ts);	  
	  self.funcion2.check(ts);
	def checkFunc(self,tf):
	  if (self.funcion1):
		  self.funcion1.checkFunc(tf);	  
	  self.funcion2.checkFunc(tf);
	
class Programa:
	def imprimir(self,tb):
		if self.lista_funciones:
			if self.lista_instrucciones:
				print tb, 'Programa:'
				print tb, ' Lista de Funciones:'
				self.lista_funciones.imprimir(tb+'  ')
				print tb, ' Lista de Instrucciones:'
				self.lista_instrucciones.imprimir(tb+'  ')
			else:
				print tb, 'Programa:'
				print tb, ' Lista de Funciones:'
				self.lista_funciones.imprimir(tb+'  ')
				print tb, ' Lista de Instrucciones:\n',tb,'  VACIO'
		else:
			if self.lista_instrucciones:
				print tb, 'Programa:'
				print tb, ' Lista de Funciones:\n',tb,'  VACIO'
				print tb, ' Lista de Instrucciones:'
				self.lista_instrucciones.imprimir(tb+'  ')
			else:
				print tb, 'Programa:'
				print 	tb, ' Lista de Funciones:\n',tb,'  VACIO'
				print tb, ' Lista de Instrucciones:\n',tb,'  VACIO'
		
	def __init__(self,i,r):
		self.lista_funciones = i
		self.lista_instrucciones = r
	def checkFunc(self,tf):
		if self.lista_funciones:
			self.lista_funciones.checkFunc(tf)
	def check(self,ts):
		if self.lista_funciones:
			self.lista_funciones.check(ts)
		if self.lista_instrucciones:
			if self.lista_instrucciones.__class__.__name__ == 'Lista_instruccion':
				self.lista_instrucciones.check(ts,None)
			else:
				self.lista_instrucciones.check(ts)
class Bloque_fila:
	def imprimir(self,tb):
		if self.columna1:
			self.columna1.imprimir(tb)
		print tb, 'Fila:'
		self.columna2.imprimir(tb+' ')
	def __init__(self,x,y):
		self.columna1 = x
		self.columna2 = y
	def check(self,ts):
		tDer = self.columna2.check(ts)
		l = list()
		l.append(tDer)
		if self.columna1:
			l = self.columna1.check(ts) + l
		return l
		
class Bloque_columna:
	def imprimir(self,tb):
		if self.expresion1:
			self.expresion1.imprimir(tb)
		print tb, 'Columna:'
		self.expresion2.imprimir(tb+' ')
	def __init__(self,x,y):
		self.expresion1 = x
		self.expresion2 = y
	def check(self,ts):
		tDer = self.expresion2.check(ts)
		if not(tDer.__class__.__name__ == 'Numero'):
			print 'Las matrices solo pueden contener Numeros'
			sys.exit(1)
		if self.expresion1:
			return self.expresion1.check(ts) + 1			
		return 1
	
class Literal_matriz:
	def imprimir(self,tb):
		print tb, 'Literal matricial:'
		self.filas.imprimir(tb+' ')
	def __init__(self,f):
		self.filas = f
	def check(self,ts):
		tElem = self.filas.check(ts)
		f = len(tElem)
		nAnt = tElem[0]
		c = nAnt
		for x in tElem:
			if not(x == nAnt):
				print 'El numero de columnas no cuadra por filas, la matriz es imposible.'
				sys.exit(1)
			nAnt = x
		return Tipo_matrix(f,c)

