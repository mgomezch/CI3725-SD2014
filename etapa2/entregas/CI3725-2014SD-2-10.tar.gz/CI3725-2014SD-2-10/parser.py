# Archivo: parser.py
# Este archivo contiene el parser de trinity.
# Autores: 
#	- Miguel  Saraiva	09-10794
#	- Gabriel Alvarez	09-10029
# Grupo: 10

from ast import *
import lexer
from ply import yacc

tokens = ('IF','FALSE','TRUE','BOOLEAN','NUMBER','MATRIX','ROW','COL',
		'NOT','DIVIDE','MODULE','PRINT','USE','IN','END','SET','FOR','READ',
		'THEN','ELSE','DO','WHILE','FUNCTION','RETURN','BEGIN','PROGRAM',
		'LBRACKET','RBRACKET','COLON','COMMA','LPAREN','RPAREN','LBRACE',
		'RBRACE','AMPERSAND','PIPE','EQUIVALENT','DIFFERENT','LESS','GREATER',
		'LEQUAL','GEQUAL','PLUS','MINUS','ASTERISK','SLASH','PERCENT','CPLUS',
		'CMINUS','CASTERISK','CSLASH','CPERCENT','CDIVIDE','SEMICOLON',
		'CMODULE','VARNAME','EQUAL','NUMERIC','STRING','TRANSPOSE')

precedence = (
    ('left','PIPE'),
    ('left','AMPERSAND'),
	('nonassoc','EQUIVALENT','DIFFERENT','LESS', 'GREATER','LEQUAL','GEQUAL'),
    ('left','NOT'),
    ('left','PLUS','MINUS','CPLUS','CMINUS'),
    ('left','ASTERISK','DIVIDE','MODULE','SLASH','PERCENT','CASTERISK','CDIVIDE','CMODULE','CSLASH','CPERCENT'),
    ("right", 'UMINUS'),
    ('left','TRANSPOSE'),
    ('nonassoc','LBRACKET','RBRACKET')
)

###############################################################################
#############################        PROGRAM       ############################
###############################################################################

def p_program(p):
    '''program : PROGRAM instruction_list END SEMICOLON
               | function_list PROGRAM instruction_list END SEMICOLON'''
    if len(p) == 5:
        p[0] = Program(p[2])
    else:
        p[0] = Program(p[3],p[1])

###############################################################################
#############################       FUNCTIONS      ############################
###############################################################################

def p_function_list(p):
    '''function_list : function
                     | function_list function'''
    if len(p) == 2:
        p[0] = [p[1]]
    else:
        p[0] = p[1] + [p[2]]
        
def p_function(p):
    '''function : FUNCTION identifier LPAREN parameter_list RPAREN RETURN type BEGIN instruction_list END SEMICOLON
                | FUNCTION identifier LPAREN RPAREN RETURN type BEGIN instruction_list END SEMICOLON'''
    if len(p) == 12:
        p[0] = Function(p[2],p[7],p[9],p[4])
    elif len(p) == 11:
        p[0] = Function(p[2],p[6],p[8])

###############################################################################
#############################       PARAMETERS     ############################
###############################################################################
    
def p_parameter_list(p):
    '''parameter_list : parameter
                      | parameter_list COMMA parameter'''
    if len(p) == 2:
        p[0] = [p[1]]
    else:
        p[0] = p[1] + [p[3]]
    
def p_parameter(p):
    '''parameter : type identifier'''
    p[0] = Parameter(p[1],p[2])

###############################################################################
#############################     INSTRUCTIONS     ############################
###############################################################################

#############################         BLOCK        ############################         
def p_instruction_block(p):
    '''instruction : USE declaration_list IN instruction_list END SEMICOLON'''
    p[0] = Block(p[2],p[4])
                        
#############################       EXPRESSION     ############################     
def p_instruction_expression(p):
    '''instruction : expression SEMICOLON'''
    p[0] = Expression_instruction(p[1])
            
#############################         PRINT        ############################     
def p_instruction_print(p):
    '''instruction : PRINT argument_list SEMICOLON'''
    p[0] = Print(p[2])
    
#############################         READ         ############################ 
def p_instruction_read(p):
    '''instruction : READ identifier SEMICOLON'''
    p[0] = Read(p[2])
    
#############################         SET          ############################
def p_instruction_assign(p):
    '''instruction : SET identifier EQUAL expression SEMICOLON'''
    p[0] = Assign(p[2],p[4])

def p_instruction_assign_vector(p):
    '''instruction : SET identifier LBRACKET expression RBRACKET EQUAL expression SEMICOLON'''
    p[0] = Assign_vector(p[2],p[4],p[7])

def p_instruction_assign_matrix(p):
    '''instruction : SET identifier LBRACKET expression COMMA expression RBRACKET EQUAL expression SEMICOLON'''
    p[0] = Assign_matrix(p[2],p[4],p[6],p[9])

#############################         IF          ############################
def p_instruction_if(p):
    '''instruction : IF expression THEN instruction_list ELSE instruction_list END SEMICOLON
                   | IF expression THEN instruction_list END SEMICOLON'''
    if len(p) == 9:
        p[0] = If(p[2],p[4],p[6])
    else:
        p[0] = If(p[2],p[4])
        
#############################         WHILE        ############################
def p_instruction_while(p):
    '''instruction : WHILE expression DO instruction_list END SEMICOLON'''
    p[0] = While(p[2],p[4])
    
#############################         FOR          ############################ 
def p_instruction_for(p):
    '''instruction : FOR identifier IN expression DO instruction_list END SEMICOLON'''
    p[0] = For(p[2],p[4],p[6])
    
def p_instruction_return(p):
    '''instruction : RETURN expression SEMICOLON'''
    p[0] = Return(p[2])
    
def p_instruction_list(p):
    '''instruction_list : instruction_list instruction
                        | instruction'''
    if len(p) == 2:
        p[0] = [p[1]]
    else:
        p[0] = p[1] + [p[2]]

###############################################################################
#############################     DECLARATIONS     ############################
############################################################################### 
        
def p_declaration_list(p):
    '''declaration_list : declaration
                        | declaration_list declaration'''
    if len(p) == 2:
        p[0] = [p[1]]
    else:
        p[0] = p[1] + [p[2]]
        
def p_declaration(p):
    '''declaration : type identifier SEMICOLON
                   | type identifier EQUAL expression SEMICOLON'''
    if len(p) == 4:
        p[0] = Declaration(p[1],p[2])
    elif len(p) == 6:
        p[0] = Declaration(p[1],p[2],p[4])

###############################################################################
#############################      EXPRESSIONS     ############################
###############################################################################
        
def p_expression_binary_number(p):
    '''expression : expression PLUS expression
                  | expression MINUS expression
                  | expression ASTERISK expression
                  | expression DIVIDE expression
                  | expression MODULE expression
                  | expression SLASH expression
                  | expression PERCENT expression'''
    operator = {
        '+'  : 'PLUS',
        '-'  : 'MINUS',
        '*'  : 'ASTERISK',
        'div': 'DIVIDE',
        'mod': 'MODULE',
        '/'  : 'SLASH',
        '%'  : 'PERCENT'
    }[p[2]]
    p[0] = Binary(operator,p[1],p[3])

def p_expression_binary_boolean(p):
    '''expression : expression AMPERSAND expression
                  | expression PIPE expression'''
    operator = {
		'&': 'AMPERSAND',
		'|': 'PIPE'
    }[p[2]]
    p[0] = Binary(operator,p[1],p[3])
    
def p_expression_Not(p):
    '''expression : NOT expression'''
    p[0] = Unary('NOT',p[2])

def p_expression_uminus(p):
    '''expression : MINUS expression %prec UMINUS'''
    p[0] = Unary('MINUS',p[2])
    
def p_expression_transpose(p):
    '''expression : expression TRANSPOSE'''
    p[0] = Unary('TRANSPOSE',p[1])    
    
def p_expression_compare(p):
    '''expression : expression LESS expression
                  | expression LEQUAL expression
                  | expression GREATER expression
                  | expression GEQUAL expression
                  | expression EQUIVALENT expression
                  | expression DIFFERENT expression'''
    operator = {
        '<' : 'LESS',
        '<=': 'LEQUAL',
        '>' : 'GREATER',
        '>=': 'GEQUAL',
        '==': 'EQUIVALENT',
        '/=': 'DIFFERENT'
    }[p[2]]
    p[0] = Binary(operator,p[1],p[3])
    
def p_expression_binary_cross(p):
    '''expression : expression CPLUS expression
                  | expression CMINUS expression
                  | expression CASTERISK expression
                  | expression CDIVIDE expression
                  | expression CMODULE expression
                  | expression CSLASH expression
                  | expression CPERCENT expression'''
    operator = {
        '.+.'  : 'CPLUS',
        '.-.'  : 'CMINUS',
        '.*.'  : 'CASTERISK',
        '.div.': 'CDIVIDE',
        '.mod.': 'CMODULE',
        './.'  : 'CSLASH',
        '.%.'  : 'CPERCENT'
    }[p[2]]
    p[0] = Binary(operator,p[1],p[3])             
              
def p_expression_projection(p):
    '''expression : expression LBRACKET expression COMMA expression RBRACKET
                  | expression LBRACKET expression RBRACKET'''
    if len(p) == 7:
        p[0] = Projection(p[1],p[3],p[5])
    else:
        p[0] = Projection(p[1],p[3])
    
def p_expression_group(p):
    '''expression : LPAREN expression RPAREN'''
    p[0] = Group(p[2])

def p_expression_numeric_literal(p):
    '''expression : NUMERIC'''
    p[0] = Numeric(p[1])
    
def p_expression_boolean_literal(p):
    '''expression : FALSE
                  | TRUE'''
    p[0] = Boolean(p[1])
    
def p_expression_string_literal(p):
    '''expression : STRING'''
    p[0] = String(p[1])
    
def p_expression_matrix(p):
    '''expression : LBRACE matrix_argument_list RBRACE'''
    p[0] = Matrix(p[2]) 
                  
def p_expression_identifier(p):
    '''expression : identifier'''
    p[0] = p[1]
                
def p_expression_function(p):
    '''expression : identifier LPAREN argument_list RPAREN
                  | identifier LPAREN RPAREN'''
    if len(p) == 5:
        p[0] = Function_call(p[1],p[3])
    else:
        p[0] = Function_call(p[1])

###############################################################################
#############################      IDENTIFIER      ############################
###############################################################################
    
def p_identifier(p):
    '''identifier : VARNAME'''
    p[0] = Identifier(p[1])

###############################################################################
#############################       ARGUMENTS      ############################
###############################################################################

def p_argument_list(p):
    '''argument_list : argument
                     | argument_list COMMA argument'''
    if len(p) == 2:
        p[0] = [p[1]]
    else:
        p[0] = p[1] + [p[3]]

def p_argument(p):
    '''argument : expression '''
    p[0] = Argument(p[1])

###############################################################################
#############################    MATRIX ARGUMENTS  ############################
###############################################################################

def p_matrix_argument_list(p):
    '''matrix_argument_list : matrix_argument
                            | matrix_argument_list COMMA matrix_argument
                            | matrix_argument_list COLON matrix_argument'''
    if len(p) == 2:
        p[0] = [p[1]]
    else:
        p[0] = p[1] + [p[3]]

def p_matrix_argument(p):
    '''matrix_argument : expression '''
    p[0] = Argument(p[1])
        
###############################################################################
#############################         TYPE         ############################
###############################################################################     
            
def p_type(p):
    '''type : BOOLEAN
            | NUMBER
            | MATRIX LPAREN NUMERIC COMMA NUMERIC RPAREN
            | ROW LPAREN NUMERIC RPAREN
            | COL LPAREN NUMERIC RPAREN'''
    if len(p) == 2:
        p[0] = p[1]
    elif len(p) == 5:
        p[0] = p[1] + p[2] + p[3] + p[4]
    else:
        p[0] = p[1] + p[2] + p[3] + p[4] + p[5] + p[6]
        
def p_error(p):
	if p:
		message = "ERROR: Syntax error at line %d, column %d:"
		message += "Unexpected token '%s'"
		data = (p.lineno,p.lexpos,p.value)
		parser_error.append(message % data)

parser_error = []
        
def parsing(input):
	lex = lexer.Lexer()
	tokenList = lex.input(input)
	parser = yacc.yacc()
	for x in tokenList:
		if x.type == "ERROR":
			return None
	if lex:
		ast = parser.parse(lexer=lex,debug=0)
		if parser_error:
			for error in parser_error:
				print error
			return None
		else:
			return ast
