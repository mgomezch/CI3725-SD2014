# Archivo: token.py
# Este archivo contiene la clase token y las subclases para
# cada lexema.
# Autores: 
#	- Miguel  Saraiva	09-10794
#	- Gabriel Alvarez	09-10029
# Grupo: 

class Token(object):	
	lineno = 1
	lexpos = 1
	value = None
	type = None
	
	def printToken(self):
		if (self.type != "ERROR"):
			print "Encontrado",self.value,"en fila",self.lineno,"columna",
			pass
			print self.lexpos
		else:
			msg_error = "ERROR: Unexpected character '"+self.value+"' at line "
			msg_error += str(self.lineno)+" column "+str(self.lexpos)
			print msg_error
		
class IF(Token):
	def __init__(self): 
		self.value = "if"
		self.type = "IF"

class WHILE(Token):
	def __init__(self):
		self.value = "while"
		self.type = "WHILE"

class FALSE(Token):
	def __init__(self):
		self.value = "false"
		self.type = "FALSE"

class TRUE(Token):
	def __init__(self):
		self.value = "true"
		self.type = "TRUE"

class BOOLEAN(Token):
	def __init__(self):
		self.value = "boolean"
		self.type = "BOOLEAN"

class NUMBER(Token):
	def __init__(self):
		self.value = "number"
		self.type = "NUMBER"

class MATRIX(Token):
	def __init__(self):
		self.value = "matrix"
		self.type = "MATRIX"
		
class ROW(Token):
	def __init__(self):
		self.value = "row"
		self.type = "ROW"

class COL(Token):
	def __init__(self):
		self.value = "col"
		self.type = "COL"

class NOT(Token):
	def __init__(self):
		self.value = "not"
		self.type = "NOT"

class USE(Token):
	def __init__(self):
		self.value = "use"
		self.type = "USE"

class DIVIDE(Token):
	def __init__(self):
		self.value = "div"
		self.type = "DIVIDE"

class MODULE(Token):
	def __init__(self):
		self.value = "mod"
		self.type = "MODULE"

class PRINT(Token):
	def __init__(self):
		self.value = "print"
		self.type = "PRINT"

class IN(Token):
	def __init__(self):
		self.value = "in"
		self.type = "IN"

class END(Token):
	def __init__(self):
		self.value = "end"
		self.type = "END"

class SET(Token):
	def __init__(self):
		self.value = "set"
		self.type = "SET"

class FOR(Token):
	def __init__(self):
		self.value = "for"
		self.type = "FOR"

class READ(Token):
	def __init__(self):
		self.value = "read"
		self.type = "READ"

class THEN(Token):
	def __init__(self):
		self.value = "then"
		self.type = "THEN"

class ELSE(Token):
	def __init__(self):
		self.value = "else"
		self.type = "ELSE"

class DO(Token):
	def __init__(self):
		self.value = "do"
		self.type = "DO"

class FUNCTION(Token):
	def __init__(self):
		self.value = "function"
		self.type = "FUNCTION"

class RETURN(Token):
	def __init__(self):
		self.value = "return"
		self.type = "RETURN"

class BEGIN(Token):
	def __init__(self):
		self.value = "begin"
		self.type = "BEGIN"

class PROGRAM(Token):
	def __init__(self):
		self.value = "program"
		self.type = "PROGRAM"

class LBRACKET(Token):
	def __init__(self):
		self.value = "["
		self.type = "LBRACKET"

class RBRACKET(Token):
	def __init__(self):
		self.value = "]"
		self.type = "RBRACKET"

class COLON(Token):
	def __init__(self):
		self.value = ":"
		self.type = "COLON"

class COMMA(Token):
	def __init__(self):
		self.value = ","
		self.type = 'COMMA'

class LPAREN(Token):
	def __init__(self):
		self.value = "("
		self.type = "LPAREN"

class RPAREN(Token):
	def __init__(self):
		self.value = ")"
		self.type = "RPAREN"

class LBRACE(Token):
	def __init__(self):
		self.value = "{"
		self.type = "LBRACE"
		
class RBRACE(Token):
	def __init__(self):
		self.value = "}"
		self.type = "RBRACE"

class AMPERSAND(Token):
	def __init__(self):
		self.value = "&"
		self.type = "AMPERSAND"

class PIPE(Token):
	def __init__(self):
		self.value = "|"
		self.type = "PIPE"

class EQUIVALENT(Token):
	def __init__(self):
		self.value = "=="
		self.type = "EQUIVALENT"

class DIFFERENT(Token):
	def __init__(self):
		self.value = "/="
		self.type = "DIFFERENT"

class LESS(Token):
	def __init__(self):
		self.value = "<"
		self.type = "LESS"

class GREATER(Token):
	def __init__(self):
		self.value = ">"
		self.type = "GREATER"

class LEQUAL(Token):
	def __init__(self):
		self.value = "<="
		self.type = "LEQUAL"

class GEQUAL(Token):
	def __init__(self):
		self.value = ">="
		self.type = "GEQUAL"

class PLUS(Token):
	def __init__(self):
		self.value = "+"
		self.type = "PLUS"

class MINUS(Token):
	def __init__(self):
		self.value = "-"
		self.type = "MINUS"

class ASTERISK(Token):
	def __init__(self):
		self.value = "*"
		self.type = "ASTERISK"

class SLASH(Token):
	def __init__(self):
		self.value = "/"
		self.type = "SLASH"

class PERCENT(Token):
	def __init__(self):
		self.value = "%"
		self.type = "PERCENT"

class CPLUS(Token):
	def __init__(self):
		self.value = ".+."
		self.type = "CPLUS"

class CMINUS(Token):
	def __init__(self):
		self.value = ".-."
		self.type = "CMINUS"

class CASTERISK(Token):
	def __init__(self):
		self.value = ".*."
		self.type = "CASTERISK"

class CSLASH(Token):
	def __init__(self):
		self.value = "./."
		self.type = "CSLASH"

class CPERCENT(Token):
	def __init__(self):
		self.value = ".%."
		self.type = "CPERCENT"

class CDIVIDE(Token):
	def __init__(self):
		self.value = ".div."
		self.type = "CDIVIDE"

class CMODULE(Token):
	def __init__(self):
		self.value = ".mod."
		self.type = "CMODULE"
		
class SEMICOLON(Token):
	def __init__(self):
		self.value = ";"
		self.type = "SEMICOLON"

class VARNAME(Token):
	def __init__(self,value):
		self.value = value
		self.type = "VARNAME"

class EQUAL(Token):
	def __init__(self):
		self.value = "="
		self.type = "EQUAL"

class NUMERIC(Token):
	def __init__(self,value):
		self.value = value
		self.type = "NUMERIC"

class TRANSPOSE(Token):
	def __init__(self):
		self.value = "'"
		self.type = "TRANSPOSE"
		
class ERROR(Token):
	def __init__(self,value):
		self.value = value
		self.type = "ERROR"
		
class STRING(Token):
	def __init__(self,value):
		self.value = value
		self.type = "STRING"

def createString(line,column,value,tokenList):
	x = STRING(value)
	x.lineno = line
	x.lexpos = column
	tokenList.append(x)

def createNumber(line, column, value, tokenList):
	x = NUMERIC(value)
	x.lineno = line
	x.lexpos = column
	tokenList.append(x)
	
def createError(line, column, value, tokenList):
	x = ERROR(value)
	x.lineno = line
	x.lexpos = column
	tokenList.append(x)

def tokenizer(line, column, value, tokenList):
	if (value == "if"):
		x = IF()
	elif (value =="false"):
		x = FALSE()
	elif (value == "true"):
		x = TRUE()
	elif (value == "boolean"):
		x = BOOLEAN()
	elif (value == "number"):
		x = NUMBER()
	elif (value == "matrix"):
		x = MATRIX()
	elif (value == "row"):
		x = ROW()
	elif (value == "col"):
		x = COL()
	elif (value == "not"):
		x = NOT()
	elif (value == "div"):
		x = DIVIDE()
	elif (value == "mod"):
		x = MODULE()
	elif (value == "print"):
		x = PRINT()
	elif (value == "use"):
		x = USE()
	elif (value == "in"):
		x = IN()
	elif (value == "end"):
		x = END()
	elif (value == "set"):
		x = SET()
	elif (value == "for"):
		x = FOR()
	elif (value == "read"):
		x = READ()
	elif (value == "then"):
		x = THEN()
	elif (value == "else"):
		x = ELSE()
	elif (value == "do"):
		x = DO()
	elif (value == "while"):
		x = WHILE()
	elif (value == "function"):
		x = FUNCTION()
	elif (value == "program"):
		x = PROGRAM()
	elif (value == "return"):
		x = RETURN()
	elif (value == "begin"):
		x = BEGIN()
	else:
		x = VARNAME(value)

	x.lineno = line
	x.lexpos = column
	tokenList.append(x)
	
def symbolizer(line, column, value, tokenList):
	if (value == "["):
		x = LBRACKET()
	elif (value == "]"):
		x = RBRACKET()
	elif (value == ":"):
		x = COLON()
	elif (value == ","):
		x = COMMA()
	elif (value == "("):
		x = LPAREN()
	elif (value == ")"):
		x = RPAREN()
	elif (value == "{"):
		x = LBRACE()
	elif (value == "}"):
		x = RBRACE()
	elif (value == "&"):
		x = AMPERSAND()
	elif (value == "|"):
		x = PIPE()
	elif (value == "=="):
		x = EQUIVALENT()
	elif (value == "/="):
		x = DIFFERENT()
	elif (value == "<="):
		x = LEQUAL()
	elif (value == ">="):
		x = GEQUAL()
	elif (value == "+"):
		x = PLUS()
	elif (value == "-"):
		x = MINUS()
	elif (value == "<"):
		x = LESS()
	elif (value == ">"):
		x = GREATER()
	elif (value == "*"):
		x = ASTERISK()
	elif (value == "/"):
		x = SLASH()
	elif (value == "%"):
		x = PERCENT()
	elif (value == ".+."):
		x = CPLUS()
	elif (value == ".-."):
		x = CMINUS()
	elif (value == ".*."):
		x = CASTERISK()
	elif (value == "./."):
		x = CSLASH()
	elif (value == ".%."):
		x = CPERCENT()
	elif (value == ".div."):
		x = CDIVIDE()
	elif (value == ".mod."):
		x = CMODULE()
	elif (value == ";"):
		x = SEMICOLON()
	elif (value == "="):
		x = EQUAL()
	elif (value == "'"):
		x = TRANSPOSE()
		
	x.lineno = line
	x.lexpos = column
	tokenList.append(x)
