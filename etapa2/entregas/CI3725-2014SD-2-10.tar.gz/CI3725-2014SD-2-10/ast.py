# Archivo: AST.py
# Este archivo contiene todas las clases utilizadas para la construccion
# del arbol de sintaxis abstracta.
# Autores: 
#    - Miguel  Saraiva    09-10794
#    - Gabriel Alvarez    09-10029
# Grupo: 10
        
###############################################################################
#############################        PROGRAM       ############################
###############################################################################

class Program(object):

    def __init__(self,instruction_list,function_list = None):
        self.instruction_list = instruction_list
        self.function_list = function_list

    def __str__(self):
        string = "Program:\n"
        if self.function_list:
            for function in self.function_list:
                string += function.string_tree(1)
        for instruction in self.instruction_list:
            string += instruction.string_tree(1)
        return string + "\n"
        
###############################################################################
#############################       FUNCTIONS      ############################
###############################################################################
        
class Function(object):
    
    def __init__(self,identifier,type,instruction_list,parameter_list = None):
        self.identifier = identifier
        self.parameter_list = parameter_list
        self.type = type
        self.instruction_list = instruction_list

    def string_tree(self,level):
        indent = '    ' * level
        string = indent + "Function:\n" + self.identifier.string_tree(level+1)
        if self.parameter_list:
            for parameter in self.parameter_list:
                string += parameter.string_tree(level+1)
        string += indent + "    " + "Type: " + self.type + "\n"
        for instruction in self.instruction_list:
            string += instruction.string_tree(level+1)
        return string
        
###############################################################################
#############################       PARAMETERS     ############################
###############################################################################

class Parameter(object):

    def __init__(self,type,identifier):
        self.type = type
        self.identifier = identifier

    def string_tree(self,level):
        indent = '    ' * level
        string = indent + "Parameter:\n" + indent + "    " + "Type: " + self.type + "\n"
        string += self.identifier.string_tree(level+1)
        return string       
               
###############################################################################
#############################     INSTRUCTIONS     ############################
###############################################################################
               
class Instruction(object): pass

class Block(Instruction):

    def __init__(self,declaration_list,instruction_list):
        self.declaration_list = declaration_list
        self.instruction_list = instruction_list

    def string_tree(self,level):
        indent = '    ' * level
        string = indent + "Block:\n"
        string += indent + "    Use:\n"
        for declaration in self.declaration_list:
            string += declaration.string_tree(level+2)
        string += indent + "    In:\n"
        for instruction in self.instruction_list:
            string += instruction.string_tree(level+2)
        return string
    
class Expression_instruction(Instruction):
    
    def __init__(self,expression):
        self.expression = expression

    def string_tree(self,level):
        indent = '    ' * level
        string = indent + "Expression:\n" 
        string += self.expression.string_tree(level+1)
        return string
                 
class Print(Instruction):

    def __init__(self,argument_list):
        self.argument_list = argument_list

    def string_tree(self,level):
        indent = '    ' * level
        string = indent + "Print:\n" 
        for argument in self.argument_list:
            string += argument.string_tree(level+1)
        return string

class Read(Instruction):
                 
    def __init__(self,identifier):
        self.identifier = identifier

    def string_tree(self,level):
        indent = '    ' * level
        string = indent + "Read:\n" 
        string += self.identifier.string_tree(level+1)
        return string               
        
class Assign(Instruction):

    def __init__(self,identifier,expression):
        self.identifier = identifier
        self.expression = expression

    def string_tree(self,level):
        indent = '    ' * level
        string = indent + "Assign:\n"
        string += self.identifier.string_tree(level+1)
        string += self.expression.string_tree(level+1)
        return string
                 
class Assign_vector(Instruction):

    def __init__(self,identifier,expression_arg,expression):
        self.identifier = identifier
        self.expression_arg = expression_arg
        self.expression = expression

    def string_tree(self,level):
        indent = '    ' * level
        string = indent + "Assign:\n"
        string += self.identifier.string_tree(level+1)
        string += indent + "    Argument:\n" 
        string += self.expression_arg.string_tree(level+2)
        string += self.expression.string_tree(level+1)
        return string
                 
class Assign_matrix(Instruction):

    def __init__(self,identifier,expression_arg1,expression_arg2,expression):
        self.identifier = identifier
        self.expression_arg1 = expression_arg1
        self.expression_arg2 = expression_arg2
        self.expression = expression

    def string_tree(self,level):
        indent = '    ' * level
        string = indent + "Assign:\n" 
        string += self.identifier.string_tree(level+1)
        string += indent + "    Argument 1:\n" 
        string += self.expression_arg1.string_tree(level+2)
        string += indent + "    Argument 2:\n"
        string += self.expression_arg2.string_tree(level+2)
        string += self.expression.string_tree(level+1)
        return string
                 
class If(Instruction):
    
    def __init__(self,expression,then_instruction_list,
                 else_instruction_list = None):
        self.expression = expression
        self.then_instruction_list = then_instruction_list
        self.else_instruction_list = else_instruction_list

    def string_tree(self,level):
        indent = '    ' * level
        string = indent + "If:\n"
        string += self.expression.string_tree(level+1)
        string += indent + "    Then:\n"
        for then_instruction in self.then_instruction_list:
	        string += then_instruction.string_tree(level+2)
        if self.else_instruction_list:
       		string += indent + "    Else:\n"
	        for else_instruction in self.else_instruction_list:
		        string += else_instruction.string_tree(level+2)
        return string
        
class While(Instruction):

    def __init__(self,expression,instruction_list):
        self.expression = expression
        self.instruction_list = instruction_list
        
    def string_tree(self,level):
        indent = '    ' * level
        string = indent + "While:\n" 
        string += self.expression.string_tree(level+1)
        string += indent + "    Do:\n"
        for instruction in self.instruction_list:
            string += instruction.string_tree(level+2)
        return string
        
class For(Instruction):

    def __init__(self,identifier,expression,instruction_list):
        self.identifier = identifier
        self.expression = expression
        self.instruction_list = instruction_list
        
    def string_tree(self,level):
        indent = '    ' * level
        string = indent + "For:\n"
        string += self.identifier.string_tree(level+1)
        string += indent + "    In:\n"
        string += self.expression.string_tree(level+2)
        string += indent + "    Do:\n"
        for instruction in self.instruction_list:
            string += instruction.string_tree(level+2)
        return string
    
class Return(Instruction):
    
    def __init__(self,expression):
        self.expression = expression
        
    def string_tree(self,level):
        indent = '    ' * level
        string = indent + "Return:\n" + self.expression.string_tree(level+1)
        return string
    
###############################################################################
#############################     DECLARATIONS     ############################
###############################################################################        
    
class Declaration(object):

    def __init__(self,type,identifier,expression = None):
        self.type = type
        self.identifier = identifier
        self.expression = expression
        
    def string_tree(self,level):
        indent = '    ' * level
        string = indent + "Declaration:\n"
        string += indent + "    " + "Type: " + self.type + "\n"
        string += self.identifier.string_tree(level+1)
        if self.expression:
            string += self.expression.string_tree(level+1)
        return string

###############################################################################
#############################      EXPRESSIONS     ############################
###############################################################################
    
class Expression(object): pass

class Binary(Expression):

    def __init__(self,operator,left,right):
        self.operator = operator
        self.left = left
        self.right = right
        
    def string_tree(self,level):
        indent = '    ' * level
        string = indent + self.operator + " operator:\n"
        string += self.left.string_tree(level+1)
        string += self.right.string_tree(level+1)
        return string

class Unary(Expression):

    def __init__(self,operator,expression):
        self.operator = operator
        self.expression = expression
        
    def string_tree(self,level):
        indent = '    ' * level
        string = indent + "Unary " + self.operator + ":\n"
        string += self.expression.string_tree(level+1)
        return string

class Projection(Expression):

    def __init__(self,expression,expression_arg1,expression_arg2 = None):
        self.expression = expression
        self.expression_arg1 = expression_arg1
        self.expression_arg2 = expression_arg2
        
    def string_tree(self,level):
        indent = '    ' * level
        string = indent + "Projection:\n"
        string += self.expression.string_tree(level+1)
        string += self.expression_arg1.string_tree(level+1)
        if self.expression_arg2:
            string += self.expression_arg2.string_tree(level+1)
        return string
        
class Group(Expression):

    def __init__(self,expression):
        self.expression = expression
        
    def string_tree(self,level):
        indent = '    ' * level
        string = indent + "Group:\n"
        string += self.expression.string_tree(level+1)
        return string

class Numeric(Expression):

    def __init__(self,number):
        self.number = number
        
    def string_tree(self,level):
        indent = '    ' * level
        string = indent + "Numeric literal: " + self.number + "\n"
        return string      
        
class Boolean(Expression):

    def __init__(self,bool):
        self.bool = bool
        
    def string_tree(self,level):
        indent = '    ' * level
        string = indent + "Boolean literal: " + self.bool + "\n"
        return string
        
class String(Expression):

    def __init__(self,str):
        self.str = str
        
    def string_tree(self,level):
        indent = '    ' * level
        string = indent + "String literal: " + self.str + "\n"
        return string
        
class Matrix(Expression):
    
    def __init__(self,argument_list):
        self.argument_list = argument_list
        
    def string_tree(self,level):
        indent = '    ' * level
        string = indent + "Matrix Literal:\n"
        for argument in self.argument_list:
            string += argument.string_tree(level+1)
        return string
        
class Function_call(Expression):

    def __init__(self,identifier,argument_list = None):
        self.identifier = identifier
        self.argument_list = argument_list
        
    def string_tree(self,level):
        indent = '    ' * level
        string = indent + "Function Call:\n" 
        string += self.identifier.string_tree(level+1)
        if self.argument_list:
            for argument in self.argument_list:
                string += argument.string_tree(level+1)
        return string

###############################################################################
#############################      IDENTIFIER      ############################
###############################################################################        
        
class Identifier(Expression):
    
    def __init__(self,name):
        self.name = name
        
    def string_tree(self,level):
        indent = '    ' * level
        return indent + "Identifier: " + self.name + "\n"
            
###############################################################################
#############################       ARGUMENTS      ############################
###############################################################################        
        
class Argument(Expression):
    
    def __init__(self,expression):
        self.expression = expression
        
    def string_tree(self,level):
        indent = '    ' * level
        string = indent + "Argument:\n" 
        string += self.expression.string_tree(level+1)
        return string
