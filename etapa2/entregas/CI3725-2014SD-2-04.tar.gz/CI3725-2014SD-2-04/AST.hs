-- CI 3725 Septiembre-Diciembre 2014
-- Proyecto, Entrega 2
-- Integrantes:
--		Brian Mendoza 07-41206

module AST where

data Expresion
			= Suma Expresion Expresion
			| Resta Expresion Expresion
			| Multiplicacion Expresion Expresion
			| DivisionExacta Expresion Expresion
			| RestoExacto Expresion Expresion
			| DivisionEntera Expresion Expresion
			| RestoEntero Expresion Expresion
			| SumaCruzada Expresion Expresion
			| RestaCruzada Expresion Expresion
			| MultiplicacionCruzada Expresion Expresion
			| DivisionExactaCruzada Expresion Expresion
			| RestoExactoCruzado Expresion Expresion
			| DivisionEnteraCruzada Expresion Expresion
			| RestoEnteroCruzado Expresion Expresion
			| And Expresion Expresion
			| Or Expresion Expresion
			| Igual Expresion Expresion
			| NoIgual Expresion Expresion
			| MenorIgual Expresion Expresion
			| MayorIgual Expresion Expresion
			| Menor Expresion Expresion
			| Mayor Expresion Expresion
            | ProyeccionMatriz String Expresion Expresion
            | ProyeccionVector String Expresion
			| Traspuesta Expresion
            | Negacion Expresion
            | Not Expresion
            | LiteralMatricial [[Expresion]]
            | LlamadaFuncion String [Expresion]
			| LiteralNumerico Double
			| Identificador String
			| Falso
			| Verdadero
			deriving (Eq,Show)


data Instruccion
			= Asignacion LValue Expresion
			| IfThenElse Expresion [Instruccion] [Instruccion]
            | IfThen Expresion [Instruccion]
			| Read String
            | Print [Impresion]
            | Use [Declaracion] [Instruccion]
            | While Expresion [Instruccion]
            | For Expresion Expresion [Instruccion]
            | Return Expresion
            | InstruccionExpresion Expresion
			deriving (Eq,Show)

data LValue
            = LValueIdentificador String
            | LValueVector String Expresion
            | LValueMatriz String Expresion Expresion
            deriving (Eq, Show)

data Impresion
            = ImprimirExpresion Expresion
            | ImprimirString String
            deriving (Eq, Show)

data Declaracion
            = DeclaracionInicializada Tipo Expresion Expresion
            | DeclaracionNoInicializada Tipo Expresion
            deriving (Eq, Show)

data Funcion
            = Funcion String [Parametro] Tipo [Instruccion]
            deriving (Eq, Show)

data Parametro
            = Parametro Tipo Expresion
            deriving(Eq, Show)

data Program
            = Program [Funcion] [Instruccion]
            deriving(Eq, Show)

data Tipo
			= TipoBoolean
			| TipoNumber
			| TipoMatriz Double Double
			deriving (Eq,Show)
