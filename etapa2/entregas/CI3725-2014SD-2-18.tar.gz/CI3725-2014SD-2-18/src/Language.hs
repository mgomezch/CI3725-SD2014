module Language where

import Text.Show.Pretty

data  Program = Program [Fun] [Statement]
              deriving(Eq,Show)

data Exp = ExpIdent String
         | ExpString String
         | ExpInt Float
         | ExpFloat Float
         | ExpTrue
         | ExpFalse
         | ExpMat [[Exp]]
         | ExpNot Exp
         | ExpAnd Exp Exp
         | ExpOr Exp Exp
         | ExpEqT Exp Exp 
         | ExpNEqT Exp Exp
         | ExpGrT Exp Exp 
         | ExpLoT Exp Exp 
         | ExpGrEqT Exp Exp 
         | ExpLoEqT Exp Exp 
         | ExpPlus  Exp Exp 
         | ExpMinus Exp Exp
         | ExpUnMinus Exp
         | ExpMult  Exp Exp 
         | ExpExDiv Exp Exp 
         | ExpExMod Exp Exp
         | ExpDiv Exp Exp 
         | ExpMod Exp Exp 
         | ExpTranspose Exp 
         | ExpCPlus Exp Exp 
         | ExpCMinus Exp Exp 
         | ExpCMult Exp Exp 
         | ExpCExDiv Exp Exp 
         | ExpCExMod Exp Exp 
         | ExpCDiv Exp Exp 
         | ExpCMod Exp Exp
         | ExpFun String [Param]
         | ExpComp Exp Float Float
         | ExpOneComp Exp Float
         deriving(Eq,Show)


data Type = Number
          | Matrix Float Float
          | Boolean
          deriving(Eq,Show)

data Statement = Declr Type String
               | Asig String Exp
               | DeclrAsig Type String Exp
               | Return Exp
               | StExp Exp
               | IfElse Exp [Statement] [Statement]
               | If Exp [Statement]
               | While Exp [Statement]
               | For String Exp [Statement]
               | Use [Statement] [Statement]
               | Read Exp
               | Print [Exp]
               deriving(Eq,Show)

data Fun = Function String [Param] Type [Statement]
         deriving(Eq,Show)

data Param = Param Type String
           deriving(Eq,Show)
