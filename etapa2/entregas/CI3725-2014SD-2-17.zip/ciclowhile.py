#MODULO CICLOWHILE

#Modulo que da origen a lo nodos relacionados a las acciones
#que se deben realizar en un metodo iterativo while.

#Atributos:
  
  #expr: contiene la expresion que se debe cumplir para ejecutar
  #las instrucciones del while
  
  #instruccion: contiene la instruccion que se desea ejecutar
  
  #accionelse: representa la lista de instrucciones alternativas en caso 
  #de no cumplir la condicion del if
  
#Elaborado por:
		  #Daniel Pelayo 10-10539
      #Nelson Saturno 09-10797

class ciclowhile:
  
  def __init__(self,expr,instruccion):
    self.expr=expr
    self.instruccion=instruccion
    
  def imprimir(self):
    print "WHILE"
    print
    print "|Inicio del ciclo While:"
    print
    print ("Expresion del While:"),
    self.expr.imprimir()
    
    print "Instruccion del While:"
    self.instruccion.imprimir()
    print 
    print "|Fin del ciclo While."
    print