#MODULO CONDIFTHEN

#Modulo que representa el nodo que da origen a los
#condicionales de la forma IF-THEN que se presentan
#en el programa

#Atributos:
  
  #condicional: Representa la la condicion que se debe cumplirse
  #para caer en la accion del IF
  
  #accion: Representa la  instruccion que se realizara
  #si se cumple la condicion del if
  
  
#Elaborado por:
		  #Daniel Pelayo 10-10539
      #Nelson Saturno 09-10797

import opbin as ob
import asign as asign
import numero as num
import booleano as boole
import identificador as ide

class condifthen:
  def __init__(self,condicional,accion):
    self.condicional=condicional
    self.accion=accion
    
  def imprimir(self):
    print "Condicional IF-THEN:"
    print
    print "//Inicio del condicional IF-THEN:"
    print
    print ("Condicion a cumplirse:"),
    self.condicional.imprimir()
    print ("Accion a realizar:"),
    self.accion.imprimir()
    print 
    print "//Fin del Condicional IF_THEN"
    print
