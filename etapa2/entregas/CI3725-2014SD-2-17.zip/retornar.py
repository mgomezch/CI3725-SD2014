#MODULO retornar

#Modulo que retorna el nodo referente al retorno de una expresion


#Atributos:
  
  #valor: variable a la cual se asigna una expresion

#Integrantes:
    #Daniel Pelayo 10-10539
    #Nelson Saturno 09-10797

import opbin as ob
import asign as asign
import numero as num
import booleano as boole
import identificador as ide


class retornar():
  def __init__(self,valor):
    self.valor=valor
    
  def imprimir(self):
    print "RETORNAR"
    print ("-Valor a retornar:"),
    print self.valor