#MODULO MATRIX

#Modulo que representa el nodo de las matrices
#para las operaciones establecidas en el lenguaje

# Atributos

		# nombre : nombre de la matriz
		# row : numero de filas de la matriz
		# col : numero de columnas de la matriz

# Elaborado por:
		#Daniel Pelayo 10-10539
		#Nelson Saturno 09-10797

import opbin as ob
import asign as asign
import numero as num
import booleano as boole
import identificador as ide

class matrix:
	def __init__(self,nombre,row,col):
		self.nombre = nombre
		self.row = row
		self.col = col

	def imprimir(self):
		print "MATRIX: "
		print self.nombre + "(" + self.row + "," + self.col + ")"