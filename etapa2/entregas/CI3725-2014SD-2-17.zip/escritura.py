#MODULO escritura

#Modulo que representa las acciones de escritura que
#provee el lenguaje: WRITE Y WRITELN

#Atributos:
  
  #p1: lista de valores que seran impresos
  
  #tipo: definde de que manera sera implementado
  #el metodo de escritura: WRITE o WRITELN
  
#Elaborado por:
		  #Daniel Pelayo 10-10539
      #Nelson Saturno 09-10797

import opbin as ob
import asign as asign
import numero as num
import booleano as boole
import identificador as ide


class escritura:
  
  def __init__(self,tipo,p1):
    self.lista=p1
    self.tipo=tipo
    
  def imprimir(self):
    print self.tipo+":"
    print
    print "//Valores impresos: "
    print
    for a in self.lista:
      if isinstance(a,list):
    	for b in a:
    	  b.imprimir()
      if isinstance(a,str):
        print a
      if not ((isinstance(a,str) or isinstance(a,list))):
        a.imprimir()
    print
    print "//Fin de impresion."
    print