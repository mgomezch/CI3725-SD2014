#MODULO BOOLEANO

#Modulo que da origen a lo nodos relacionados con el valor 
#true o false

#Atributos:
  
  #valor: true/false
  
#Elaborado por:
		  #Daniel Pelayo 10-10539
      #Nelson Saturno 09-10797
		  
import opbin as ob
import asign as asign
import numero as num
import booleano as boole
import identificador as ide


class booleano:
  def __init__(self,valor):
    self.value=valor
  def imprimir(self):
    print self.value