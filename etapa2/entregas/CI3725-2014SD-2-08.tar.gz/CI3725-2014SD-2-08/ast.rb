class AST; end
class Programa < AST 
	 def initialize(program)
    	@program = program
    end
end
class ProgConFuncion < AST
	def initialize(funciones, instrucciones)		
    	@funciones = funciones
    	@instrucciones = instrucciones
    end
end
class ProgSinFuncion < AST
	def initialize(instrucciones)
    	@instrucciones = instrucciones
    end
end
class Funciones; end
class FuncionConParametro
	def initialize(nombre, param, rtrn, instrucciones)
		@nombre = nombre
		@param = param
		@rtrn = rtrn
		@intstrucciones = instrucciones
	end
end

class FuncionSinParametro
	def initialize(nombre, rtrn, instrucciones)
		@nombre = nombre
		@rtrn = rtrn
		@intstrucciones = instrucciones
	end
end

class Matriz
	def initialize(filas, columnas)
		@filas = filas
		@columnas = columnas
	end
end
class Fila
	def initialize(filas)
		@filas = filas
	end
end
class Columna
	def initialize(columnas)
		@columnas = columnas
	end
end
class LiteralMatricial
	def initialize(valor)
		@valor = valor
	end
end
class Entero
	def initialize(valor)
		@valor = valor
	end
end
class Variable
	def initialize(valor)
		@valor = valor
	end
end
class ExpresionBinaria
	def initialize(opIzq, opDer)
		@opIzq = opIzq
		@opDer = opDer
	end
end

class MenosUnario < ExpresionBinaria; end
class Suma < ExpresionBinaria; end
class Resta < ExpresionBinaria; end
class Multiplicacion < ExpresionBinaria; end
class Division < ExpresionBinaria; end
class Modulo < ExpresionBinaria; end
class Div < ExpresionBinaria; end
class Mod < ExpresionBinaria; end
class Traspuesta
	def initialize(matriz)
		@matriz = matriz
	end
end
class SumaCruz < ExpresionBinaria; end
class RestaCruz < ExpresionBinaria; end
class MultiplicacionCruz < ExpresionBinaria; end
class DivisionCruz < ExpresionBinaria; end
class ModuloCruz < ExpresionBinaria; end
class DivCruz < ExpresionBinaria; end
class ModCruz < ExpresionBinaria; end
class True; end
class False; end
class Not
	def initialize(expr)
		@expr = expr
	end
end
class And < ExpresionBinaria; end
class Or < ExpresionBinaria; end
class Equivalencia < ExpresionBinaria; end
class Inequivalencia < ExpresionBinaria; end

class Menor< ExpresionBinaria; end
class MenorOIgual < ExpresionBinaria; end
class Mayor< ExpresionBinaria; end
class MayorOIgual < ExpresionBinaria; end
class Instrucciones; end
class Declara ; end
class Imprime; end
class BloqueUse; end
class Asignacion; end
class Lectura; end
class IfThen; end
class IfThenElse; end
class While; end
class For; end
class LlamadaFuncion
	def initialize(nombre, *param)
		@nombre = nombre
		case param
		when 1
			@param = param[0]
		end
end
class ReturnFuncion; end

end
