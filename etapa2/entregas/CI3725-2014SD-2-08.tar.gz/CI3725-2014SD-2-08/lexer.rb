#!/usr/bin/env ruby 
# -*- coding: utf-8 -*-
# David Goudet 08-10479
# Susana Charara 08-10223

##################################################################
#                                                                #
# Este proyecto partio de hacer modificaciones pertinentes al    #
# lexer publicado en:                                            #
# https://github.com/dvdalilue/calculatorRR/blob/master/lexer.rb #
#                                                                #
# Tambien se utilizo el siguiente lexer:                         #
# https://github.com/dvdalilue/Brainiac/blob/master/Lexer.rb     #
#                                                                #
##################################################################


# Clase  basepara definir los token encontrados 
class Token

  attr_reader :t, :l, :c

  #Definición del token
  def initialize(text,line,col)
    @t = text
    @l = line
    @c = col - text.length
  end

  def to_s
    "Tk#{self.class}: Linea #{@l}, columna #{@c} "
  end
end

# Definicion de los tokens
$tok = {
  'Traspuesta'      =>  /\A\'/                        ,
  'Coma'            =>  /\A\,/                        ,       
  'PuntoYComa'      =>  /\A\;/                        ,       
  'ParAbre'         =>  /\A\(/                        ,       
  'ParCierra'       =>  /\A\)/                        ,       
  'CorcheteAbre'    =>  /\A\[/                        ,       
  'CorcheteCierra'  =>  /\A\]/                        ,       
  'LlaveAbre'       =>  /\A\{/                        ,       
  'LlaveCierra'     =>  /\A\}/                        ,       
  'DosPuntos'       =>  /\A\:/                        ,       
  'Menos'           =>  /\A\-/                        ,      
  'Mas'             =>  /\A\+/                        ,      
  'Mult'            =>  /\A\*/                        ,       
  'Division'        =>  /\A\//                        ,       
  'Modulo'          =>  /\A\%/                        ,
  'PMenosP'         =>  /\A\.\-\./                    ,      
  'PMasP'           =>  /\A\.\+\./                    ,      
  'PMultP'          =>  /\A\.\*\./                    ,       
  'PDivisionP'      =>  /\A\.\/\./                    ,       
  'PModuloP'        =>  /\A\.\%\./                    ,
  'PDivP'           =>  /\A\.div\./                   ,
  'PModP'           =>  /\A\.mod\./                   ,
  'Conjuncion'      =>  /\A\&/                        ,       
  'Disyuncion'      =>  /\A\|/                        ,       
  'MenorIgual'      =>  /\A\<\=/                       ,      
  'Menor'           =>  /\A\</                        , 
  'MayorIgual'      =>  /\A\>\=/                       ,       
  'Mayor'           =>  /\A\>/                        ,
  'IgualIgual'      =>  /\A\=\=/                      ,
  'Igual'           =>  /\A\=/                        ,       
  'Desigual'        =>  /\A\/=/                       ,     
  'Ident'           =>  /\A[a-zA-Z]+([a-zA-Z0-9_])*/  ,   
  'Num'             =>  /\A[\d]+(\.[\d]+)?/	      ,
  'Str'             => /\A".*"/                       ,
  #'Str'             => /\A"((\\[n"(\\)])*([^\\"])*)*"/,

}

# Creacion de la tabla de hash que almacena las palabras reservadas del lenguaje
$rw = Hash::new
# Palabras reservadas
reserved_words = %w(program boolean false true number matrix row col not div mod print use in end set read if then else for do while function return begin)

# Clase para definir los errores encontrados
class ErrorLexicografico < Token
  def to_s
    "Error lexico: \"#{t}\" Linea #{@l}, columna #{@c} "
  end
end

# Se almacena cada palabra reservada en la tabla de hash creada
reserved_words.each do |s|
  $rw[s.capitalize] = /\A#{s}\b/
end

# Unión de los tokens y las palabras reservadas
$tokens = $rw.merge($tok)

# Se crea una subclase para cada token
# Palabras reservadas
class TkProgram < Token; end
class TkBoolean < Token; end
class TkFalse < Token; end
class TkTrue < Token; end
class TkNumber < Token; end
class TkMatrix < Token; end
class TkRow < Token; end
class TkCol < Token; end
class TkNot < Token; end
class TkDiv < Token; end
class TkMod < Token; end
class TkPrint < Token; end
class TkUse < Token; end
class TkIn < Token; end
class TkEnd < Token; end
class TkSet < Token; end
class TkRead < Token; end
class TkIf < Token; end
class TkThen < Token; end
class TkElse < Token; end
class TkFor < Token; end
class TkDo < Token; end
class TkWhile < Token; end
class TkFunction < Token; end
class TkReturn < Token; end
class TkBegin < Token; end
#Operadores y otros simbolos
class TkTraspuesta < Token; end
class TkComa < Token; end
class TkPuntoYComa < Token; end
class TkParAbre < Token; end
class TkParCierra < Token; end
class TkCorcheteAbre < Token; end
class TkCorcheteCierra < Token; end
class TkLlaveAbre < Token; end
class TkLlaveCierra < Token; end
class TkDosPuntos < Token; end
class TkMenos < Token; end
class TkMas < Token; end
class TkMult < Token; end
class TkDivision < Token; end
class TkModulo < Token; end
class TkPMenosP < Token; end
class TkPMasP < Token; end
class TkPMultP < Token; end
class TkPDivisionP < Token; end
class TkPModuloP < Token; end
class TkPDivP < Token; end
class TkPModP < Token; end
class TkConjuncion < Token; end
class TkDisyuncion < Token; end
class TkMenor < Token; end
class TkMenorIgual < Token; end
class TkMayor < Token; end
class TkMayorIgual < Token; end
class TkIgual < Token; end
class TkIgualIgual < Token; end
class TkDesigual < Token; end
# Subclase para definir literales numericos y guardar su valor
class TkNum < Token
  def to_s
    "TkDigito(#{@t}): Linea #{@l}, columna #{@c} "
  end
end
# Subclase para definir identificadores y guardar su valor
class TkIdent < Token
  def to_s
    "TkIdent(#{@t}): Linea #{@l}, columna #{@c} "
  end
end
# Subclase para definir literales de cadena de caracteres y guardar su valor
class TkStr < Token
  def to_s
    "TkStr(#{@t}): Linea #{@l}, columna #{@c} "
  end
end

# Clase que analiza la entrada

class Lexer

  attr_accessor :line, :col

  attr_reader :input

  def initialize(input)
    @tokens = []
    @line  = 1
    @col   = 0
    @input = input
  end


#Se analiza cada palabra de la entrada

  def catch
    # Se ignora cualquier espacio en blanco y comentarios
    @input =~ /\A(\s|\n|#.*)*/ 
    self.ignore($&.length)

    return if @input.empty? # Se termino de procesar la entrada

    # En caso de que queden palabras por analizar, se comparan contra los tokens
    $tokens.each do |key, value| 
      @input =~ value
      if $&
	break
      end
      
    end
    newclass = ErrorLexicografico

    # Si se encontro un token, se crea una nueva instancia de esa subclase
    if $&
      phrase = @input[0..($&.length-1)]
      self.ignore($&.length)
      $tokens.each { |k,v|
        if phrase =~ v
          newclass = Object::const_get("Tk#{k}")
          break
        end
      }
    else
      @input =~ /\A(\w|\p{punct})+/ # Se busca una nueva palabra de la entrada
      phrase = $&[0,1]
      self.ignore(1)
    end
    newtoken = newclass.new(phrase,@line,@col)
    @tokens << newtoken

    raise newtoken if newtoken == ErrorLexicografico

    return newtoken
  end

# Se consume la porcion de entrada ya reconocida

  def ignore(length)

    return if length.eql?0

    trh = @input[0..(length-1)]
    
    # Se actualiza el string que falta por analizar
    @input = @input[length..@input.length]

    lineas = (trh + " ").lines.to_a.length.pred

    @line += lineas

    if lineas.eql?0
      @col += length
    else
      @col = (trh + " ").lines.to_a[-1].length
    end
  end

# Se imprimen los tokens y errores encontrados
  def out
    @tokens.each { |t|
      puts t.to_s
    }
  end
end
