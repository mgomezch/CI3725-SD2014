#MODULO bloque2

#Modulo que representa los bloques de instrucciones que NO empiezan con
#una lista de declaraciones

#Atributos:
  
  
  #lins: lista de instrucciones del bloque

#Integrantes:
  #Daniel Pelayo 10-10539
  #Nelson Saturno 09-10797


class bloque:
  
  def __init__(self,lins):
    self.lista=lins
    
  def imprimir(self):
   
    print "Bloque:"
    print
    print "{"
    print
    tamanio = len(self.lista)
    centinela = 0
    for a in self.lista:
      if (centinela != tamanio-1):
	a.imprimir()
	print "SEPARADOR"
      else:
	a.imprimir()
      centinela=centinela+1
    print  
    print "}"
    print