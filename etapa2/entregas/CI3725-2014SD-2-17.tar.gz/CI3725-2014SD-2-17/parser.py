#Parser en donde se incluye la gramatica para el lenguaje Trinity.
#Autores: Daniel Pelayo (10-10539) Nelson Saturno (09-10797)


#Importamos todo lo necesario
    
import yacc
import sys
import opbin as ob
import asign as asign
import numero as num
import booleano as boole
import identificador as ide
import condifthen as condifthen
import lectura as lec
import declaretotal as dt
import declare as decl
import escritura as escr
import condifthenelse as condifthenelse
import bloque as bl
import ciclofor as cfor
import ciclowhile as cwhile
import opunaria as ou
import expresionfuncion as exprfuncion
import bloque2 as bl2
import trinity as lexer

#Importamos la lista de tokens del lexer previamente hecho
tokens=lexer.tokens


#Simbolo inicial de donde comienza la derivacion, la estructura de un
#programa en Trinity es: la palabra reservada program y al menos una
#instruccion. Dicha instruccion puede ser todas las opciones que brinda
#el lenguaje
def p_begin(p):
  '''begin : TokProgram instruccion TokEnd TokPtoComa'''
  p[0]=p[2]

#Para cada produccion se genera un nodo de una clase creada especificamente
#para dicho caso. Cada nodo sera distinto dependiendo de para que se use,por
#ejemplo el nodo de un operador binario tendra: hijo izquierdo,derecho y el
#simbolo del operador y asi variara dependiendo de lo que se quiera almacenar.

#Regla para la produccion de asignaciones. Se crea el nodo que contiene la 
#variable a asignar y el valor que se le asignara
def p_asignacion(p):
  ''' asignacion : TokSet TokID TokEqual expresion'''
  p[0]= asign.asignacion(p[2],p[4])

#Regla para el retorno de variables. Se crea el nodo que contiene el
#valor a retornar
def p_retornar(p):
  ''' retornar : expresion'''
  p[0]= retornar.retornar(p[1])
 
#Se desea "parsear" una lista de identificadores de la forma a,b,c,d...,n.
#Este es el caso base del paso recursivo.
def p_lista_id(p):
  ''' listaIdentificadores : expresion'''
  p[0]=[]
  p[0].append(p[1])
 
#Caso recursivo para el "parseo" de la lista de identificadores.
def p_lista_id_base(p):
  ''' listaIdentificadores : listaIdentificadores TokComa expresion'''
  p[0]=p[1]
  p[0].append(p[3])
  
#Produccion para una declaracion de la forma: declare a,b,c..n as bool.
def p_declaracion(p):
  '''declaracion : tipo listaIdentificadores'''
  p[0]=decl.declare(p[2],p[1])
 
#Una subdeclaracion que no es mas que una declaracion solo que sin la palabra
#reservada declare. Util para cuando se desee "parsear" un bloque de declaraciones
def p_subdeclaracion(p):
  ''' subdeclaracion : tipo listaIdentificadores'''
  p[0]=decl.declare(p[1],p[3])

#Posibilidades para el tipo de dato
def p_tipo(p):
  ''' tipo :  TokNumber
	    | TokBoolean
	    | TokMatrix
      | TokRow
      | TokCol'''
  p[0]=p[1]

#Un bloque completo de declaraciones, como el que puede ir al
#inicio de un bloque de instrucciones. Es de la forma:
#declare a,b,c as <tipo>;w,k as <tipo>.... Declare total no es
#mas que la lista de declaraciones que el bloque contendra
def p_bloque_declaraciones(p):
  ''' bld : TokUse declaretotal TokPtoComa TokIn'''
  p[0]= dt.declaretotal(p[1])
  
#Paso recursivo para ir llenando la lista de declaraciones (
#declaretotal)
def p_listadeDeclaraciones(p):
  ''' declaretotal : declaretotal TokPtoComa subdeclaracion'''
  p[0]=p[1]
  p[0].append(p[3])
  
#Caso base para la lista de declaraciones, simplemente iniciamos la lista
#y adjuntamos el elemento p[1]
def p_listadeDeclraciones_base(p):
  '''declaretotal : declaracion'''
  p[0]=[]
  p[0].append(p[1])
  
#Bloque de instrucciones de la forma: begin lista de instrucciones end.
#Un bloque contiene simplemente una lista de instrucciones contenidas en el
def p_bloque_instrucciones(p):
  ''' bloque : TokBegin listainstruc TokEnd'''
  p[0]= bl.bloque(p[2])

#Similar a p_bloque_instrucciones comentado arriba, solo que este bloque
#posee al inicio un bloque o un conjunto de declaraciones
def p_bloque_instrucciones_condeclare(p):
  ''' bloque : TokBegin bld listainstruc TokEnd'''
  p[0]= bl2.bloque2(p[2],p[3])
 
#Caso base para la creacion de una lista de instrucciones
def p_listainstrucc_base(p):
  ''' listainstruc : instruccion'''
  p[0]=[]
  p[0].append(p[1])
 
#Caso recursivo para la creacion de la lista de instrucciones
def p_listainstrucc_rec(p):
  ''' listainstruc : listainstruc TokPtoComa instruccion'''
  p[0]=p[1]
  p[0].append(p[3])

 
#Gramatica para el ciclo de la forma "FOR", que tiene la forma
#descrita abajo
def p_ciclofor(p):
  ''' ciclofor : TokFor TokID TokIn expresion TokDo instruccion TokEnd'''
  p[0]=cfor.ciclofor(p[2],p[4],p[6])
  
#Gramatica para el ciclo de la forma "WHILE", que tiene la forma
#descrita abajo
def p_ciclowhile(p):
  ''' ciclowhile : TokWhile expresion TokDo instruccion TokEnd'''
  p[0]=cwhile.ciclowhile(p[2],p[4])

#Escritura de datos (print) : Contiene una lista generica de cosas a imprimir
def p_escritura(p):
  ''' escritura : TokPrint listagen TokPtoComa'''
  p[0]=escr.escritura(p[1],p[2])

#Paso recursivo de la lista generica a imprimir con el PRINT
def p_listagen_rec(p):
  ''' listagen : listagen TokComa expresion
      | listagen TokComa TokString'''
  p[0]= p[1]
  p[0].append(p[3])

#Paso base de la lista generica a imprimir con el Print
def p_listagen_base(p):
  ''' listagen : expresion
      | TokString'''
  p[0]=[]
  p[0].append(p[1])
 
#Condicional con else
def p_condicional_if_then_else(p):
    ''' condifthenelse : TokIf expresion TokThen instruccion TokElse instruccion TokEnd TokPtoComa'''
    p[0]= condifthenelse.condifthenelse(p[2],p[4],p[6])
  
    
#Regla para reconocer expresiones de operadores binarios
def p_expresion(p):
  '''expresion :  expresion TokAdd expresion
		| expresion TokAddCru expresion
    | expresion TokMult expresion
    | expresion TokMultCru expresion
		| expresion TokSub expresion
    | expresion TokSubCru expresion
    | expresion TokDiv expresion
    | expresion TokDivCru expresion
    | expresion TokExDiv expresion
		| expresion TokExDivCru expresion
		| expresion TokMod expresion
    | expresion TokModCru expresion
    | expresion TokExMod expresion
    | expresion TokExModCru expresion
		| expresion TokAnd expresion
		| expresion TokOr expresion
		| expresion TokEqual expresion
    | expresion TokEquiv expresion
		| expresion TokNotEqual expresion
		| expresion TokGreater expresion
		| expresion TokLess expresion
		| expresion TokGreaterEqual expresion
		| expresion TokLessEqual expresion
		| expresion TokDosPtos expresion'''
		
  p[0] = ob.opBin(p[1],p[3],p[2])

#Regla para el "parseo" de expresiones unarias (el not booleano y el menos
#unario)
def p_expresionUnaria(p):
  ''' expresion : TokNot expresion
		| TokSub expresion %prec TokUSub'''
  p[0]=ou.opunaria(p[1],p[2])

#Regla para el "parseo" de expresiones representadas por el llamado a funciones
#predefinidas del lenguaje, de esta forma podremos tomar como expresion cosas como:
#a+roti(b), etc...


##  AQUI QUEDAMOS  ###
def p_expresionFuncion(p):
  ''' expresion : TokID TokParI expresion TokParD'''
  p[0]=exprfuncion.expresionfuncion(p[1],p[3])

#Terminal numero para el caso de expresiones
def p_expresion_numero(p):
  '''expresion : TokNumber'''
  p[0] = num.numero(p[1])
 
#Para aprsear expresiones parentizadas
def p_expresion_grupo(p):
  ''' expresion : TokParI expresion TokParD'''
  p[0]=p[2]
 
#Terminal true o false(constantes booleanas)
def p_expresion_bool(p):
  '''expresion : TokTrue
		| TokFalse'''
  p[0] = boole.booleano(p[1])

#Terminal identificador de alguna variable
def p_expresion_id(p):
  '''expresion : TokID'''
  p[0] = ide.identificador(p[1])

#Se Define la gramatica para leer un if de la forma:
#if-then
def p_condicional_if_then(p):
  ''' condifthen : TokIf expresion TokThen instruccion TokEnd TokPtoComa'''
  p[0]=condifthen.condifthen(p[2],p[4])

#Defino lo que es la gramatica de una instruccion, que eventualmente
#pordra ser: un condicional, una asignacion,declaracion,ciclo,etc
def p_instruccion(p):
  '''instruccion :  condifthen
		  | asignacion
		  | read
      | retornar
      | escritura
		  | condifthenelse
      | bloque
      | bld
		  | ciclofor
		  | ciclowhile
      | instruccion instruccion'''
  p[0]=p[1]

#Gramatica para leer los reads o lecturas por teclado
def p_read(p):
  ''' read : TokRead TokID TokPtoComa'''
  p[0]=lec.lectura(p[2])
  
#Que realizar cuando se consiga un error. Si el error se da por un token inesperado
#se especifica cual fue y en donde se encontro. De ser por la ausencia de un token, se
#imprime que existe dicha ausencia.
def p_error(p):
    if (p <> None):
      print "Error de sintaxis, token inesperado :",p.value,
      print "en linea,posicion :"+"("+str(p.lineno)+","+str(lexer.find_column(data2,p))+")"
    else:
      print "Error: Token ausente"
    exit()
 
#Definicion de la precedencia para que la gramatica no sea ambigua
precedence = (
    ('left','TokOr'),
    ('left','TokAnd'),
    ('nonassoc', 'TokNot'),
    ('left','TokEquiv','TokNotEqual'),
    ('nonassoc','TokGreaterEqual','TokLessEqual','TokLess','TokGreater'),
    ('left', 'TokAdd', 'TokSub'),
    ('left', 'TokMult', 'TokExDiv','TokExMod'),  
    ('left','TokDosPtos'),
    ('right', 'TokUSub')
)


# Construccion del parser
# Leemos de archivo lo que queremos parsear, lo procesamos e imprimimos

data = open(sys.argv[1])
data2 = data.read()
parser=yacc.yacc()
p=parser.parse(data2)
p.imprimir()




