#MODULO OPBIN

#Modulo que representa el nodo que da origen a las 
#opeaciones binarias presentes en el programa.

#Atributos:
  
  #izq: operando izquiero de la operacion en cuestion
  
  #der: operando derecho de la operaion en cuestion
  
  #operador: identifica que tipo de operacion binaria se esta realizando
  
#Elaborado por:
		  #Daniel Pelayo 10-10539
      #Nelson Saturno 09-10797



import opbin as ob
import asign as asign
import numero as num
import booleano as boole
import identificador as ide

class opBin():
  def __init__(self,izq,der,operador):
    self.izquierdo=izq
    self.derecho=der
    self.operador=operador
    
  def imprimir(self):
    print "EXPRESION"
    print ("	Operador:"),
    if (self.operador == '+'):
      print "Suma"
    if (self.operador == '.+.'):
      print "Suma Cruzada"
    if (self.operador == '*'):
      print "Multiplicacion"
    if (self.operador == '.*.'):
      print "Multiplicacion Cruzada"
    if (self.operador == '-'):
      print "Resta"
    if (self.operador == '.-.'):
      print "Resta Cruzada"
    if (self.operador == 'div'):
      print "Div"
    if (self.operador == '.div.'):
      print "Div Cruzado"
    if (self.operador == '/'):
      print "Div Exacto"
    if (self.operador == './.'):
      print "Div Exacto Cruzado"
    if (self.operador == 'mod'):
      print "Mod"
    if (self.operador == '.mod.'):
      print "Mod Cruzado"
    if (self.operador == '%'):
      print "Mod Exacto"
    if (self.operador == '.%.'):
      print "Mod Exacto Cruzado"
    if (self.operador == '&'):
      print "And"
    if (self.operador == '|'):
      print "Or"
    if (self.operador == '='):
      print "Igual"
    if (self.operador == '=='):
      print "Equivalente"
    if (self.operador == '/='):
      print "No Igual"
    if (self.operador == '>'):
      print "Mayor que"
    if (self.operador == '<'):
      print "Menor que"
    if (self.operador == '>='):
      print "Mayor Igual que"
    if (self.operador == '<='):
      print "Menor Igual que"
    if (self.operador == ':'):      #NECESARIO???
      print "Dos Puntos"
    
    
    print ("	operando izquierdo:"),
    self.izquierdo.imprimir()
    print ("	operando derecho:"),
    self.derecho.imprimir()