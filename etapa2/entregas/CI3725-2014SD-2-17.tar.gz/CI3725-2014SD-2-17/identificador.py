#MODULO IDENTIFICADOR

#Modulo que representa el nodo que da origen a los 
#tokens de tipo ID en el programa (identificadores de variables)

#Atributos:
  
  #valor: es el valor de la variable en cuestion
  
#Elaborado por:
		  #Daniel Pelayo 10-10539
      #Nelson Saturno 09-10797
		  
import opbin as ob		  
import asign as asign
import numero as num
import booleano as boole
import identificador as ide

class identificador:
  
  def __init__(self,valor):
    self.value=valor
    
  def imprimir(self):
    print ("Variable/Id:"),
    print self.value