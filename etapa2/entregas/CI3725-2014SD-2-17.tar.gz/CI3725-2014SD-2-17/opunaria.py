#MODULO OPUNARIA

#Modulo que representa el nodo que da origen a las 
#expresiones unarias presentes en el programa.

#Atributos:
  
  #operador: Define si es un menos unario (-) o el
  #operador de negacion NOT 
  
  #expresion: expresion a la cual se le aplica el
  #operador.
  
#Elaborado por:
		  #Daniel Pelayo 10-10539
      #Nelson Saturno 09-10797

class opunaria:
  def __init__(self,operador,expresion):
    self.operador=operador
    self.expresion=expresion
    
  def imprimir(self):
     print "EXPRESION"
     print ("	Operador:"),
     
     if (self.operador == 'not'):
       print ("Not")
     else:
       print ("Menos Unario")
       
     print "	Expresion:"
     self.expresion.imprimir()
     
    