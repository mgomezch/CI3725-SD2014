#MODULO ASIGN

#Modulo que retorna el nodo referente a una asignacion
#presentada en un programa

#Atributos:
  
  #final: variable a la cual se asigna un valor
  
  #asignado: expresion asignada a la variable

  #Daniel Pelayo 10-10539
  #Nelson Saturno 09-10797

import opbin as ob
import asign as asign
import numero as num
import booleano as boole
import identificador as ide


class asignacion():
  def __init__(self,final,asignado):
    self.final=final
    self.asignado=asignado
    
  def imprimir(self):
    print "ASIGNACION"
    print ("-Variable a asignar:"),
    print self.final
    print ("-Valor a asignar:"),
    self.asignado.imprimir()