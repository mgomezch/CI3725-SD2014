#MODULO CONDIFTHENELSE

#Modulo que representa el nodo que da origen a los
#condicionales de la forma IF-THEN-ELSE que se presentan
#en el programa

#Atributos:
  
  #condicional: Representa la la condicion que se debe cumplirse
  #para caer en la accion del primer IF
  
  #accion: Representa la instruccion que se realizara
  #si se cumple la condicion del if
  
  #accionelse: Representa la instruccion que se realizara en caso 
  #de no cumplir la condicion del if
  
#Elaborado por:
		  #Daniel Pelayo 10-10539
      #Nelson Saturno 09-10797

import opbin as ob
import asign as asign
import numero as num
import booleano as boole
import identificador as ide

class condifthenelse:
  def __init__(self,condicional,accion,accionelse):
    self.condicional=condicional
    self.accion=accion
    self.accionelse=accionelse
    
  def imprimir(self):
    print "Condicional IF-THEN-ELSE:" 
    print 
    print "//Inicio del COndicional IF-THEN-ELSE"
    print
    print ("Condicion a cumplirse:"),
    self.condicional.imprimir()
    print ("Accion a realizar:"),
    self.accion.imprimir()
    print ("Accion a realizar (else):"),
    self.accionelse.imprimir()
    print
    print "//Fin del condicional IF-THEN-ELSE"
