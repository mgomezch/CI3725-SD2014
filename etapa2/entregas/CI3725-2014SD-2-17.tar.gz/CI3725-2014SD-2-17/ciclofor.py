#MODULO CICLOFOR

#Modulo que da origen a lo nodos relacionados a las acciones
#que se deben realizar en un metodo iterativo for.

#Atributos:
  
  #variable: variable sobe la cual se desea iterar
  
  #rango: rango que abarca la variable iterada
  
  #instruccion: instruccion a ejecutar de manera iterativa hast acabar
  #el for
  
#Elaborado por:
		  #Daniel Pelayo 10-10539
      #Nelson Saturno 09-10797


class ciclofor:
  
  def __init__(self,variable,rango,instruccion):
    self.variable=variable
    self.rango=rango
    self.instruccion=instruccion
    
  def imprimir(self):
    print "FOR:"
    print
    print "|Inicio del For:"
    print
    print ("Variable del For:"),
    print self.variable
    
    print ("Rango del For:"),
    self.rango.imprimir()
    
    print "Instruccion del For:"
    self.instruccion.imprimir()
    print 
    print "|Fin del For."
    print
    