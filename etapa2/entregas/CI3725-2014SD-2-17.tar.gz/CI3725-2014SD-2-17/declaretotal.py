#MODULO DECLARETOTAL

#Representa el nodo que contiene la lista de declaraciones
#presentes en un bloque del programa (Lista de DECLARES)

#Atributos:
  
  #valor: lista inicial de declaraciones presentes en el bloque
  #(primeras declaraciones de un mismo tipo)
  
  
#Elaborado por:
		  #Daniel Pelayo 10-10539
      #Nelson Saturno 09-10797




class declaretotal:
  
  def __init__(self,valor):
    self.lista=valor
    
  def imprimir(self):
    print "declare total:"
    for a in self.lista:
      a.imprimir()
      
  def d_appendeare(self,dt):
    print " appendeare:"
    for c in dt:
      print c
    self.lista.append(dt)
    
  def getlista(self):
    return self.lista
  