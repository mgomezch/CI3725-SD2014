#MODULO NUMERO

#Modulo que representa el nodo de los numeros enteros
#para las operaciones establecidas en el lenguaje.

#Atributos:
  
  #valor: valor del numero
  
#Elaborado por:
		  #Daniel Pelayo 10-10539
      #Nelson Saturno 09-10797
		  
import opbin as ob
import asign as asign
import numero as num
import booleano as boole
import identificador as ide


class numero:
  def __init__(self,valor):
    self.value=valor
  def imprimir(self):
    print self.value