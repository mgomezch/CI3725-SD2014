#MODULO LECTURA

#Modulo que representa el nodo que da origen al
#comando de lectura del valor de una variable por
#consola en el programa

#Atributos:
  
  #leyendo: valor de la variable que se ha leido por consola
  
#Elaborado por:
		  #Daniel Pelayo 10-10539
      #Nelson Saturno 09-10797

import opbin as ob
import asign as asign
import numero as num
import booleano as boole
import identificador as ide


class lectura:
  
  def __init__(self,leyendo):
    self.leyendo=leyendo
    
  def imprimir(self):
    print "READ:"
    print 
    print "|Elemento leido: "
    print
    print ("valor:"),
    if not isinstance(self.leyendo,str):
      self.leyendo.imprimir()
    else:
      print self.leyendo
    print
    print "|Fin lectura."
    print