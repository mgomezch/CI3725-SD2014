#MODULO EXPRESIONFUNCION

#Modulo que alberga los nodos de la funciones predetrminadas
#que presenta el lenguaje: rtoi,length,top y bottom

#Atributos:
  
  #funcion: determina que funcion se va a ejecutar
  
  #expresion: expresion a la cual se le aplicara la
  #funcion.
  
#Elaborado por:
		  #Daniel Pelayo 10-10539
      #Nelson Saturno 09-10797

class expresionfuncion:
  
  def __init__(self,funcion,expresion):
    self.funcion=funcion
    self.expresion=expresion
    
  def imprimir(self):
    print "EXPRESION FUNCIONAL"
    print
    print "|Inicio de la expresion Funcional:"
    print
    print ("Funcion:"),
    print self.funcion
    
    print "Expresion/Parametro de la funcion:"
    self.expresion.imprimir()
    print
    print "|Fin de la expresion Funcional:"
    print