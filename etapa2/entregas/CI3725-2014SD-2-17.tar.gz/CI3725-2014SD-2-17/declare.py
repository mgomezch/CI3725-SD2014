#MODULO DECLARE

#Modulo que representa la lista de variables de un mismo tipo
#que se declaran en un programa (las variables declaradas en un
#DECLARE dado)

#Atributos:
  
  #valor: lista inicial de variables declaradas en algun declare
  
  #tipo: define que tipo de variable se esta declarando.
  
#Elaborado por:
		  ##Daniel Pelayo 10-10539
      #Nelson Saturno 09-10797
		  
class declare:
  
  def __init__(self,valor,tipo):
    self.lista=valor
    self.tipo=tipo
    
  def imprimir(self):
    
    print "declaracion-tipo:"
    
    for b in self.lista:
      b.imprimir() 
    print self.tipo