#MODULO bloque2

#Modulo que representa los bloques de instrucciones que empiezan con
#una lista de declaraciones

#Atributos:
  
  #desc: lista de declaraciones del bloque
  
  #lins: lista de instrucciones del bloque
  
#Elaborado por:
		  #Daniel Pelayo 10-10539
      #Nelson Saturno 09-10797

class bloque2:
  
  def __init__(self,decs,lins):
    self.lista=lins
    self.decs=decs
    
  def imprimir(self):
    print "Bloque:"
    print
    print "{"
    print
    tamanio = len(self.lista)
    centinela = 0
    for a in self.lista:
      if (centinela != tamanio-1):
      	a.imprimir()
      	print "SEPARADOR"
      else:
	      a.imprimir()
      centinela=centinela+1
    print  
    print "}"
    print