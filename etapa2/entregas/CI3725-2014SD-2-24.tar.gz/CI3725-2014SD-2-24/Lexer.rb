#************************************************************************
# Archivo : trinity (lexer)
# 
# Descripcion: Analizador lexicografico  para el lenguaje Trinity.
#              Lee de la entrada un archivo que contiene el programa
#              en trinity para tokenizarlo. Luego de identificado los tokens
#              del programa y en caso de encontrarse, caracteres inesperados
#              que no forman parte del lenguaje ,se imprimen indicando línea 
#              y columna en donde estan ubicados.
#     
# Implementado: Lenguaje Ruby (version 2.1.2)
#  
# Autores: Vanessa Rivas      # carnet 10-10608
#          Reinaldo Verdugo   # carnet 10-10757
# 
#*************************************************************************/




#**************************************************************************
# Nombre: Clase Token  
# Descripcion : Clase que representa a los tokens que se
#               que se identificaran del input recibido
# Atributos: 
# => :t (texto)   : se ecargara de guardar el contenido de un token
# => :l (linea)   : permitira obtener la linea en la que se encuentra
#                   el token al ser creado
# => :c (columna) : permitira obtener la columna en la que se encuentra
#                   el token al ser creado
#*************************************************************************/

class Token
  attr_reader :t, :l, :c

  # Método que inicializa el texto que se está leyendo, el número de línea
  # actual y el número de columna actual.
  def initialize(text,line,col)
    @t = text
    @l = line
    @c = col
  end

  def to_s
    "Linea \"#{@l}\", columna \"#{@c}\": #{self.class}: \"#{@t}\""
  end
end



#**************************************************************************
# Nombre: Clase ErrorLexicográfico
# Descripcion : Clase que hereda de la Clase Token por poseer las mismas 
#               características , ya que ambos son elementos del lexer.
#               Representa a los errores lexicograficos que se identificaran
#               del input recibido. 
#
# Atributos: 
# => :t (texto)   : se ecargara de guardar el contenido de un error
# => :l (linea)   : permitira obtener la linea en la que se encuentra
#                   el error al ser identificado
# => :c (columna) : permitira obtener la columna en la que se encuentra
#                   el error al ser identificado
#*************************************************************************/

class ErrorLexicografico < Token
  def to_s
    "Linea #{@l}, columna #{@c}: Caracter inesperado: #{@t}"
  end
end


#se crea un diccionario que contenga las palabras reservadas del lenguaje
rw = Hash::new
reserved_words = %w(program if do else for not number false true boolean print matrix then begin while read return function end in use row col set div mod) 

# las palabras reservadas las colocamos en mayusculas de manera podamos utilizarlas como claves
# en nuestro diccionario de palabras, colocandoles como valor su correspondiente expresion regular 
reserved_words.each do |word|
  rw[word.capitalize] = /\A#{word}\b/
end

#diccionario de simbolos que pertenecen al lenguaje

tk = {
  'Numero'           => /\A[0-9]+(\.[0-9]+)?/,
  'Id'               => /\A([a-zA-Z][a-z0-9A-Z_]*)/,
  'Mas'              => /\A\+/,
  'Menos'            => /\A-/,
  'Producto'         => /\A\*/,
  'AbreParentesis'   => /\A\(/,
  'CierraParentesis' => /\A\)/,
  'MenorQue'         => /\A</,
  'MayorQue'         => /\A>/,
  'MenorIgual'       => /\A<=/,
  'MayorIgual'       => /\A>=/,
  'AbreCorchete'     => /\A\[/,
  'CierraCorchete'   => /\A\]/,
  'AbreLlave'        => /\A\{/,
  'CierraLlave'      => /\A\}/,
  'Igual'            => /\A\==/,
  'Diferente'        => /\A\/=/,
  'Asignacion'       => /\A\=/,
  'And'              => /\A\&/,
  'Or'               => /\A\|/,
  'MasCruzado'       => /\A\.\+\./,
  'MenosCruzado'     => /\A\.-\./,
  'ProductoCruzado'  => /\A\.\*\./,
  'ModCruzado'       => /\A\.mod\./,
  'DivCruzado'       => /\A\.div\./,
  'RestoCruzado'     => /\A\.%\./,
  'DivRealCruzado'   => /\A\.\/\./,
  'LiteralCaracter'  => /\A"([^\\"]|\\[n\\"])*"/,
  'PuntoYComa'       => /\A;/,
  'Coma'             => /\A,/,
  'RestoEntero'      => /\A%/,
  'DivReal'          => /\A\//,
  'Transpuesta'      => /\A\'/,
  'DosPuntos'        => /\A\:/
}

## Creamos una clase para cada palabra reservada del lenguaje
rw.each do |name, regex|
  clase = Class::new(Token) do 
      def to_s
        "Linea #{@l}, columna #{@c}: Palabra reservada: #{@t}"
      end
  end
  Object::const_set nct = "Tk#{name}", clase
end

#variable global que contiene la combinacion de los tokens de las palabras reservadas 
# junto con los tokens de los simbolos del lenguaje
$tokens = tk.merge(rw)

# Para cada token vamos creando las nuevas subclases para cada token.
  tk.each do |name, regex|
    clase = Class::new(Token) do
      def to_s
        "Linea #{@l}, columna #{@c} : #{self.class.name[2..-1]}: #{@t}"
      end
    end
    Object::const_set nct = "Tk#{name}", clase
  end

# La clase digito se diferencia de las otras al almacenar el dígito encontrado
class TkNumero < Token
  def to_s
    "Linea #{@l}, columna #{@c}: Literal numerico: #{Float(@t)}"
  end
end

# La clase digito se diferencia de las otras al almacenar el identificador  encontrado
class TkId < Token
  def to_s
    "Linea #{@l}, columna #{@c}: Identificador: #{@t}"
  end
end

class TkLiteralCaracter < Token
  def to_s
      "Linea #{@l}, columna #{@c}: String Literal: #{@t}"
  end
end


#********************************************************************************
# Nombre: Clase Lexer 
# Descripcion : Clase que se encargar de tomar la entrada e identificar cada 
#               uno de los elementos contenidos en la misma. Clasificandolos 
#               en tokens, errores lexicograficos o espacios ignorados, 
#               manteniendo la cantidad 
# Atributos: 
# => :line   : permitira llevar la cuenta de las linea en la que se encuentra 
#              el lexer en el programa (la posición hasta donde ha consumido
#              la entrada).
# => :col    : permitira llevar la cuenta de la columa en la que se encuentra 
#              el lexer en el programa (la posición hasta donde ha consumido
#              la entrada).
# => :tokens : Lista que contiene los tokens identificados en el programa
#
# => :errores: Lista que contiene los errores lexicograficos encontrados
#              en el programa
#
# => :input  : variable que contiene la entrada que esta siendo leida
#
#*******************************************************************************/

class Lexer
    attr_accessor :line, :col, :tokens, :errores
    attr_reader :input

    # Metodo para inicializar los valores
    def initialize(input)
        @tokens  = []
        @errores = []
        @line    = 1
        @col     = 1
        @input   = input
    end

    # Metodo que se encarga de ignorar los comentarios 
    def ignore(length)
        return if length.eql? 0

        trh = @input[0 .. (length - 1)]
        @input = @input[length..@input.length]
        lineas = (trh + " ").lines.to_a.length - 1
        @line += lineas

        if lineas.eql? 0
            @col += length
        else
            @col = 1
        end
    end

    # Metodo para leer el siguiente token
    def next_token
        @input =~ /\A(\s|(#.*\n)|\n)*/
        self.ignore($&.length)

        # Si ya no se consiguen mas token, se devuelve nil
        return nil if @input.empty?

        new_class = ErrorLexicografico
        new_text = @input[0].chr

        # Para cada uno de los tokens
        $tokens.each do |k,v|
            if @input =~ v then
                new_class = "Tk#{k}"
                new_class = Object::const_get(new_class)
                new_text = $&
            end
        end

        token = new_class.new(new_text, @line, @col)

        # Si el token es un error lexicografico, se añade a la lista de errores
        if token.is_a? ErrorLexicografico then 
          error = ErrorLexicografico.new(@input[0], @line, @col)
          @errores << error
          self.ignore(1)
          return error

        # Si no es un error y resulta ser un token valido, se añade a la lista
        else
          @tokens.push(token)
          self.ignore(new_text.length)
          return token
        end
    end

    # Método para imprimir los token
    def imprimir
        @tokens.each do |t|
            puts t
        end
    end
end


if ARGV[0] != nil 
    lexer = Lexer.new(File::read(ARGV[0]))
    token = lexer.next_token
    while (token != nil)
        token = lexer.next_token
    end

    # Si no se consiguen errores se devuelve el valor 0
    if lexer.errores.empty? then
        0

    # De conseguir algun error se devuelve 1
    else
        1
    end
end