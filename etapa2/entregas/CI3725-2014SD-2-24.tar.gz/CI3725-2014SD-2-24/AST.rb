##
#************************************************************************
# Archivo : AST.rb 
# 
# Descripcion: Arbol que establece la jerarquía de clases mostrando
#              quienes son los padres, hijos y atributos de cada una.
#     
# Implementado: Lenguaje Ruby (version 2.1.2)
#  
# Autores: Vanessa Rivas      # carnet 10-10608
#          Reinaldo Verdugo   # carnet 10-10757
# 
#*************************************************************************/

require_relative 'ClassFactory'

## Arreglo que muestra la jerarquía de clases con sus respectivos atributos
## y subclases. El árbol se presenta de la forma [nombre,atributos,hijos]


$arbol_ast = [
			['AST', %w[], [
						['Programa',      %w[funciones instrucciones],  []],
						['Funcion',       %w[identificador parametros tipo instrucciones], []],
                  ['Instruccion',   %w[],[
                                       ['IteracionIndeterminada', %w[condicion instruccion],                   []],
                                       ['IteracionDeterminada',   %w[identificador expresion instruccion],     []],
                                       ['CondicionalIf',          %w[condicion instrucciones],                 []],
                                       ['CondicionalIfElse',      %w[condicion instruccionIf instruccionElse], []],
                                       ['EntradaEstandar',        %w[identificador],                           []],
                                       ['SalidaEstandar',         %w[salida],                                  []],
                                       ['Asignacion',             %w[identificador valor],                     []],
                                       ['AsignacionMatricial1D',  %w[identificador posicion valor],            []],
                                       ['AsignacionMatricial2D',  %w[identificador posicion1 posicion2 valor], []],
                                       ['Bloque',                 %w[declaraciones instruccion],               []],
                                       ]],
                  ['Expresion'    , %w[],[
                                       ['True',  [] , []],
                                       ['false', [] , []],
                                       ['Numero', %w[valor], []],
                                       ['identificador',%w[nombre], []],
                                       ['Llamadafuncion', %w[identificador argumentos],   []],
                                       ['ProyeccionComponentes', %w[posicion1 posicion2], []],
                                       ['Negacion', %w[operando],    []],
                                       ['MenosUnario', %w[operando], []],
                                       ['Transpuesta', %w[operando], []],
                                       ['Suma', %w[operandoIzq operandoDer], []],
                                       ['Resta', %w[operandoIzq operandoDer], []],
                                       ['Multiplicacion', %w[operandoIzq operandoDer], []],
                                       ['RestoEntero', %w[operandoIzq operandoDer],    []],
                                       ['DivisionEntera', %w[operandoIzq operandoDer], []],
                                       ['DivisionExacta', %w[operandoIzq operandoDer], []],
                                       ['RestoExacto', %w[operandoIzq operandoDer],    []],
                                       ['MenorOIgualQue', %w[operandoIzq operandoDer], []],
                                       ['MenorQue', %w[operandoIzq operandoDer],       []],
                                       ['MayorOIgualQue', %w[operandoIzq operandoDer], []],
                                       ['MayorQue', %w[operandoIzq operandoDer],       []],
                                       ['And', %w[operandoIzq operandoDer],            []],
                                       ['Or', %w[operandoIzq operandoDer],             []],
                                       ['Desigual', %w[operandoIzq operandoDer],       []],
                                       ['SumaCruzada', %w[operandoIzq operandoDer],    []],
                                       ['MultiplicacionCruzada', %w[operandoIzq operandoDer], []],
                                       ['RestoEnteroCruzado', %w[operandoIzq operandoDer],    []],
                                       ['DivisionEnteraCruzada', %w[operandoIzq operandoDer], []],
                                       ['DivisionExactaCruzada', %w[operandoIzq operandoDer], []],
                                       ['RestoExactoCruzado', %w[operandoIzq operandoDer],    []],
                                       ['Matriz', %w[filas], []],
                                       ]],
                  ['Parametro', %w[tipo identificador], []],
                  ['Declaracion',%w[tipo identificador valor] ,[]],
                  ['Tipo',        %w[],[
                                       ['Numero',   [], []],
                                       ['Booleano', [], []],
                                       ['Matriz', %w[posicion1 posicion2], []],  
                                       ]],
                  ['Impresora', %w[salida],[
                                       ['Expresion', [], []],
                                       ['String',    [], []],
                                       ]],
						]
			]]

## Definimos un método para crear un árbol con sus hijos de manera recursiva
 def create_tree(father,tree)
    tree.each do |arbol|
      nuevaClase = ClassFactory::create_class(father, arbol[0], arbol[1])
      create_tree(nuevaClase, arbol[2])
    end
 end

class AST
   def to_s
      "#{self.class}" + "\n"+ "\t"
   end
end




create_tree(Object,$arbol_ast)
