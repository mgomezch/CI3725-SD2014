#************************************************************************
# Archivo : ClassFactory.rb 
# 
# Descripcion: Arbol que establece la jerarquía de clases mostrando
#              quienes son los padres, hijos y atributos de cada una.
#     
# Implementado: Lenguaje Ruby (version 2.1.2)
#  
# Autores: Vanessa Rivas      # carnet 10-10608
#          Reinaldo Verdugo   # carnet 10-10757
# 
#*************************************************************************/

module ClassFactory

    ## Método para crear clases de manera dinámica
    def ClassFactory::create_class(father, name, attr)
        newClass = Class.new(father) do

            class << self
                attr_accessor :attr
            end

            ## Si el padre no es la clase Objeto, herederán los atributos del padre
            if !father.eql? Object
                @attr = attr + father.attr

            ## Si el padre es la clase Objeto, las clases no tendrán atributos qué
            ## heredar
            else
                @attr = attr
            end

            ## Creamos los getters y setters para cada atributo
            self.attr.each do |att|

                ## Definimos el getter
                define_method att.intern do
                    instance_variable_get("@#{att}")
                end

                ## Definimos el setter
                define_method "#{att}=".intern do |arg|
                    instance_variable_set("@#{att}", arg)
                end
            end
        end

        ## Evaluamoos si la cantidad de atributos que recibe una clase al ser creada
        newClass.class_eval do
            def initialize(*attr)
                raise ArgumentError::new("#{caller(0)[-1]}: Numero de parametros incorrecto a la clase (#{self.class.name}):") unless attr.length == self.class.attr.length
                [self.class.attr, attr].transpose.map { |a,v|
                    instance_variable_set("@#{a}",v)
                }
            end
        end

        ## Asignamos el nombre a la nueva clase

        ## Si el padre es distinto de la clase Object y de 'AST', 
        ## concatenamos el nombre del padre y del hijo
        if (father != Object) && (father.name != 'AST')
           Object::const_set(father.name.match(/[A-Z]\w*$/).to_s + name, newClass)

        ## Si la clase padre es Object o 'AST', no lo concatenamos al principio del nombre
        else
           Object::const_set(name, newClass)
        end

        ## Por ultimo retornamos la nueva clase
        return newClass
    end
end
