
#!/usr/bin/env ruby

require_relative 'gramatica.tab.rb'
require_relative 'Lexer'

def main

    input = File::read(ARGV[0])

    lexer = Lexer::new(input)
 
    while lexer.next_token do; end
    # lexer.out

    lexer = Lexer::new(input)
    begin
        parser = Parser::new.parse(lexer)
    rescue RuntimeError => se
        puts se.to_s
        abort("")
    end
 
    begin
        puts parser.execute
    rescue DynamicError => de
        puts de
    end
end

main

 
