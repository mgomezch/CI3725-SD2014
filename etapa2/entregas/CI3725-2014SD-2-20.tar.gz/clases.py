# -*- coding: iso-8859-15 -*-
################################################################################
#        Clases empleadas para la gramática establecida para Trinity
#                                                                   
# Elaborado por 
#               Fabio Castro 10-10132
#               Donato Rolo  10-10640
#                                              
################################################################################

# Clase: Lista
# Descripción: da lugar a una lista genérica de elementos para varios fines.
class Lista:
    def __init__(self, elem):
        self.elem = [elem]

    def get_lista(self):
        return self.elem

    def agregar(self, elem):
        self.elem.append(elem)

    def imprimir(self, sangria):
        prt = ""
        sangria = sangria + "  "
        for i in self.elem:
            prt = prt + sangria + i.imprimir(sangria)
        return prt

    def __str__(self):
        aux = ""
        for i in self.elem:
            aux = "%s%s" %(aux, i)

        return aux

# Clase: Program
# Descripción: permite el reconocimiento del inicio de un programa gracias a la
#              palabra PROGRAM, seguido de la instrucción correspondiente.
class Program:
    def __init__(self, list_fun, inst):
        self.inst = inst
        self.list_fun = list_fun

    def imprimir(self,sangria):
        return "PROGRAM \n " + self.inst.imprimir(sangria) + "END;"

    def __str__(self):
        return "PROGRAM \n %s" %(self.inst)

# Clase: Asignación
# Descripción: permite que el reconocedor identifique las partes de una asignación
#              (variable y valor dado)
class Asignacion:
    def __init__(self, var, valor):
        self.var = var
        self.valor = valor

    def imprimir(self, sangria):
        prt =  "\n" + sangria + "ASIGNACION"
        sangria = sangria + "  "  
        prt = prt + "\n"+ sangria + "var: " + self.var.imprimir(sangria)
        prt = prt + "\n"+ sangria + "valor: " + self.valor.imprimir(sangria)
        return prt

    def __str__(self):
        return "\nASIGNACION \n var: %s \n valor: %s" %(self.var, self.valor)

# Clase: Asignación Matriz
# Descripción: permite que el reconocedor identifique las partes de una asignación
#              (variable y valor dado) de matricez
class AsignacionMatriz:
    def __init__(self, var, valor1, valor2, valor):
        self.var = var
        self.valor = valor

    def imprimir(self, sangria):
        prt =  "\n"+ sangria + "ASIGNACION"
        sangria = sangria + "  "  
        prt = prt + "\n"+ sangria + "var: " + self.var.imprimir(sangria)
        prt = prt + "\n"+ sangria + "valor: " + self.valor.imprimir(sangria)
        return prt

    def __str__(self):
        return "\nASIGNACION \n var: %s \n valor: %s" %(self.var, self.valor)


# Clase: ExpresionBin
# Descripción: esta clase permite que el reconocedor identifique las expresiones
#              binarias, primero el operador, luego el operando izquierdo y 
#              finalmente el derecho
class ExpresionBin:
    def __init__(self, operador, operand1, operand2):
        self.operador = operador
        self.operand1 = operand1
        self.operand2 = operand2

    def imprimir(self, sangria):
        prt = "EXPRESION_BIN"
        sangria = sangria + "  "  
        prt = prt + "\n"+sangria +"operador: "+self.operador+"\n"+sangria +"operando izq: " 
        prt = prt + self.operand1.imprimir(sangria) +"\n"+sangria +"operando der: " +self.operand2.imprimir(sangria)
        return prt

    def __str__(self):
        return "EXPRESION_BIN \n operador: %s \n operando izq: %s \n operando der: %s" %(self.operador, self.operand1, self.operand2)  

# Clase: ExpresionUn
# Descripción: esta clase permite que el reconocedor identifique las expresiones
#              unarias, primero el operador, luego el operando.
class ExpresionUn:
    def __init__(self, operador, operand):
        self.operador = operador
        self.operand = operand

    def imprimir(self, sangria):
        prt = "EXPRESION_UN"
        sangria = sangria + "  "  
        prt = prt + "\n"+sangria + "operador: " + self.operador
        prt = prt+"\n"+sangria+"operando: " + self.operand.imprimir(sangria)
        return prt

    def __str__(self):
        return "EXPRESION_UN \n operador: %s \n operando %s" %(self.operador, self.operand) 

class Funcion:
    def __init__(self, identificador, lista_parametro, tipo, lista_inst):
        self.identificador = identificador
        self.lista_parametro = lista_parametro
        self.tipo = tipo
        self.lista_inst = lista_inst


    def imprimir(self, sangria):
        return " "
    def __str__(self):
        return " "

# Clase: Condicional
# Descripción: da lugar a la instrucción de selección tanto simple como con else
class Condicional:
    def __init__(self, condicion, inst, inst2):
        self.condicion = condicion
        self.inst = inst
        self.inst2 = inst2

    def imprimir(self, sangria): 
        prt = "\n"+ sangria+"CONDICIONAL"
        sangria = sangria + "  "  
        prt = prt+"\n"+ sangria+"condicion: "+self.condicion.imprimir(sangria)
        prt= prt+"\n"+ sangria+"then: "+self.inst.imprimir(sangria)
        if not(self.inst2 is None):
            prt = prt + "\n"+ sangria + "else: " + self.inst2.imprimir(sangria)
        return prt

    def __str__(self):
    
        prt = "\nCONDICIONAL \n condicion: %s \n instruccion: %s" %(self.condicion, self.inst)
        
        if not(self.inst2 is None):
            prt = "\n%s CONDICIONAL ELSE \n %s" %(prt, self.inst2)

        return prt

# Clase: Print
# Descripción: permite reconocer qué se imprimirá en pantalla al invocar PRINT
class Print:
    def __init__(self, prt):
        self.prt = prt
    def imprimir(self, sangria): 
        prt = "\n"+sangria+"PRINT"
        sangria = sangria + "  "  
        lista=self.prt.get_lista()
        for i in lista:
            prt = prt +"\n"+sangria+"elemento: "+ i.imprimir(sangria)
        return prt
     
    def __str__(self):
        return "\nPRINT %s" %(self.prt)


# Clase: Read
# Descripción: permite reconocer que se le pedirá al usuario la introducción de
#              un valor por consola
class Read:
    def __init__(self, id_):
        self.id = id_

    def imprimir(self, sangria): 
        prt = "\n"+ sangria+"READ"
        sangria = sangria + "  "  
        prt = prt +"\n"+ sangria + "variable: "+ self.id.imprimir(sangria)
        return prt

    def __str__(self):
        return "\nREAD \n variable: %s " %(self.id)

# Clase: Bloque
# Descripción: permite reconocer los elementos que pueden incluirse en un bloque
#              (nada, declaraciones, instrucciones o una combinación de ambas)
class Bloque:
    def __init__(self, lista_decl, lista_inst):
        self.lista_decl = lista_decl
        self.lista_inst = lista_inst

    def imprimir(self, sangria):
        prt = "\n" + sangria +"USE \n" 
        if not(self.lista_decl is None):
            lista2=self.lista_decl.get_lista()
            tamano2 = len(lista2)
            i=0
            while (i<tamano2):            
                prt = prt + lista2[i].imprimir(sangria + " " ) 
                if (i != (tamano2-1)):
                    prt = prt + "\n"
                i = i+1 
        prt = prt + "\n" + sangria + " IN" + "\n"
        if not(self.lista_inst is None):
            lista=self.lista_inst.get_lista()
            tamano = len(lista)
            i=0
            while (i<tamano):            
                prt = prt + lista[i].imprimir(sangria + " " ) 
                if (i != (tamano-1)):
                    prt = prt + "\n"
                i = i+1 
        return prt + "\n"

    def __str__(self):

        prt = "\nBLOQUE"

        if not(self.lista_decl is None):
            prt = "\n%s DECLARACIONES %s" %(prt, self.lista_decl)

        if not(self.lista_inst is None):
            prt = "\n%s%s" %(prt, self.lista_inst)

        return prt

# Clase: IterDet
# Descripción: permite reconocer que nos encontramos ante una instrucción for.
#              Incluye la variable, el rango en el que vivirá y la instrucción.
class IterDet:
    def __init__(self, var, rango, lista_inst):
        self.var = var
        self.rango = rango
        self.lista_inst = lista_inst

    def imprimir(self, sangria):
        prt = "\n"+ sangria + "ITERACION_DET"
        sangria = sangria + "  "  
        prt = prt + "\n"+ sangria + "variable: " + self.var.imprimir(sangria)
        prt = prt + "\n"+ sangria + "rango: " + self.rango.imprimir(sangria) 
        
        if not(self.lista_inst is None):
            lista=self.lista_inst.get_lista()
            tamano = len(lista)
            i=0
            while (i<tamano):            
                prt = prt + lista[i].imprimir(sangria + " " ) 
                if (i != (tamano-1)):
                    prt = prt + "\n"+ sangria + "instruccion: "+ self.inst.imprimir(sangria)
                i = i+1 
        return prt

    def __str__(self):
        return "\nINSTRUCCION: ITER_DET \n VARIABLE: %s \n RANGO: %s \n INSTRUCCION: %s" %(self.var, self.rango, self.inst)

# Clase: IterDet
# Descripción: permite reconocer que nos encontramos ante una instrucción while.
#              Incluye la variable, la guardia a revisar y la instrucción.
class IterIndet:
    def __init__(self, guardia, inst):
        self.guardia = guardia
        self.inst = inst

    def imprimir(self, sangria):
        prt = "\n"+ sangria+"ITERACION_INDET"
        sangria = sangria + "  "  
        prt = prt + "\n"+ sangria + "condicion: " + self.guardia.imprimir(sangria)
        prt = prt + "\n"+ sangria + "instrucción: "+ self.inst.imprimir(sangria)
        return prt

    def __str__(self):
        return "\nINSTRUCCION: ITER_INDET \n GUARDIA: %s \n INSTRUCCION: %s" %(self.guardia, self.inst)

# Clase: DeclBloque
# Descripción: da lugar al reconocimiento de un bloque de declaraciones.
class DeclBloque:
    def __init__(self, lista_decl):
        self.lista_decl = lista_decl

    def imprimir(self, sangria):
        prt = "\n"+ sangria +"USE" 
        if not(self.lista_decl is None):
            lista=self.lista_decl.get_lista()
            tamano = len(lista)
            i=0
            while (i<tamano):            
                prt = prt + lista[i].imprimir(sangria + " " ) 
                if (i != (tamano-1)):
                    prt = prt + "\n" + sangria + "SEPARADOR"
                i = i+1 
        return prt

    def __str__(self):
        return "%s" %(self.lista_decl)

# Clase: Decl
# Descripción: permite reconocer las variables que se declaran y su respectivo
#              tipo.
class Decl:
    def __init__(self, lista_id, tipo):
        self.lista_id = lista_id
        self.tipo = tipo

    def imprimir(self, sangria):
        prt = sangria + "TIPO: %s \n" %(self.lista_id)
        prt = prt + sangria + "VARIABLES: %s\n" %(self.tipo)
        return prt

    def __str__(self):
        return " TIPO: %s \n VARIABLES: %s\n" %(self.lista_id, self.tipo)


# Clase: Rango
# Descripción: reconoce un rango dado por su cota inferior y su cota superior.
class Rango:
    def __init__(self, cotainf, cotasup):
        self.cotainf = cotainf
        self.cotasup = cotasup

    def __str__(self):
        return "\nRANGO \n inferior: %s \n superior: %s" %(self.cotainf, self.cotasup)

# Clase: Id
# Descripción: permite el reconocimiento de los ID imprimibles en un programa
class Id:
    def __init__(self, identif):
        self.identif = identif      

    def imprimir(self, sangria):
        return self.identif

    def __str__(self):
        return str(self.identif) 


# Clase: Numero
# Descripción: permite el reconocimiento de los numero
class Numero:
    def __init__(self, identif):
        self.identif = identif      

    def imprimir(self, sangria):
        return "\n "+ sangria + "elemento: " + "%.2f" %(self.identif)

    def __str__(self):
        return str(self.identif) 

# Clase: String
# Descripción: permite el reconocimiento de las cadenas imprimibles en un programa
class String:
    def __init__(self, valor):
        self.valor = valor
        
    def imprimir(self, sangria):
        prt = "CADENA "
        sangria = sangria + "  "  
        prt = prt+"\n"+sangria+"valor: "+self.valor
        return prt

    def __str__(self):
        return self.valor

# Clase: NumEntero
# Descripción: permite el reconocimiento de las constantes enteras en un programa
class NumEntero:
    def __init__(self, numero):
        self.numero=numero

    def imprimir(self, sangria):
        prt =  "CONSTANTE_ENT"
        sangria = sangria + "  "  
        prt = prt + "\n"+ sangria +"valor: " + str(self.numero)
        return prt
        
    def __str__(self):
        return str(self.numero)

# Clase: Boolean
# Descripción: permite el reconocimiento de constantes booleanas que se mandan
#              a imprimir en un programa
class Boolean:
    def __init__(self, valor):
        self.valor=valor

    def imprimir(self, sangria):
        prt =  "CONSTANTE_BOOL"
        sangria = sangria + "  "  
        prt = prt + "\n"+ sangria +"valor: " + str(self.valor)
        return prt

    def __str__(self):
        return self.valor

# Clase: AccesoMatrix
# Descripción: permite el reconocimiento para el acceso a la matriz
class AccesoMatrix:
    
    def __init__(self, identif,expresion,expresion2):
        self.identif=identif
        self.expresion = expresion
        self.expresion2 = expresion2

    def imprimir(self, sangria):
        prt = "\n"+ sangria + "ASIGNACION DE FILA O COLUMNA"
        sangria = sangria + "  "  
        prt = prt + "\n"+ sangria + "variable: " + self.identif.imprimir(sangria)
        prt = prt + "\n"+ sangria + " fila:" + self.expresion.imprimir(sangria) 
        prt = prt + "\n"+ sangria + " columna: " + self.expresion2.imprimir(sangria) 
        return prt

# Clase: AsignacionMatrix
# Descripción: permite el reconocimiento para la asignacion a la matriz
class AsignacionMatrix:
    
    def __init__(self, identif,expresion,expresion2,expresion3):
        self.identif=identif
        self.expresion = expresion
        self.expresion2 = expresion2
        self.expresion3 = expresion3

    def imprimir(self, sangria):
        prt = "\n"+ sangria + "ASIGNACION DE FILA O COLUMNA"
        sangria = sangria + "  "  
        prt = prt + "\n"+ sangria + "variable: " + self.identif.imprimir(sangria)
        prt = prt + "\n"+ sangria + " fila:" + self.expresion.imprimir(sangria) 
        prt = prt + "\n"+ sangria + " columna: " + self.expresion2.imprimir(sangria) 
        prt = prt + "\n"+ sangria + "  asignacion" + self.expresion3.imprimir(sangria) 
        return prt

# Clase: DeclMatrix
# Descripción: permite el reconocimiento para la declaracion de la matriz
class DeclMatrix:
    
    def __init__(self, identif,expresion,expresion2):
        self.identif=identif
        self.expresion = expresion
        self.expresion2 = expresion2

    def imprimir(self, sangria):
        prt = "\n"+ sangria + "MATRIX"
        sangria = sangria + "  "  
        prt = prt + "\n"+ sangria + "fila:" + self.expresion.imprimir(sangria) 
        prt = prt + "\n"+ sangria + "columna: " + self.expresion2.imprimir(sangria) 
        prt = prt + "\n"+ sangria + "variable: " + self.identif.imprimir(sangria)
        return prt

# Clase: DeclRowCol
# Descripción: permite el reconocimiento para la declaracion de la fila o columna
class DeclRowCol:
    
    def __init__(self, identif,expresion):
        self.identif=identif
        self.expresion = expresion

    def imprimir(self, sangria):
        prt = "\n"+ sangria + "COL o ROW"
        sangria = sangria + "   "  
        prt = prt + "\n"+ sangria + " fila o columna:" + self.expresion.imprimir(sangria) 
        prt = prt + "\n"+ sangria + "  variable: " + self.identif.imprimir(sangria)
        return prt

# Clase: AsignacionColRow
# Descripción: permite el reconocimiento para la asignacion de la fila o columna
class AsignacionColRow:
    
    def __init__(self, identif,expresion,expresion2):
        self.identif=identif
        self.expresion = expresion
        self.expresion2 = expresion2

    def imprimir(self, sangria):
        prt = "\n"+ sangria + "ASIGNACION DE FILA O COLUMNA"
        sangria = sangria + "  "  
        prt = prt + "\n"+ sangria + "variable: " + self.identif.imprimir(sangria)
        prt = prt + "\n"+ sangria + " fila o columna:" + self.expresion.imprimir(sangria) 
        prt = prt + "\n"+ sangria + "  asignacion: " + self.expresion2.imprimir(sangria) 
        return prt