trinity
=======

Lexer y parser del lenguaje trinity

Antes de ejecutar este programa se debe correr el comando make.
Una vez ejecutado make se creara el archivo trinity ejecutable.
El programa se ejecuta de la siguiente manera:
> ./trinity <archivo>.ty
suponiendo que se esta en el directorio donde se ejecuto el make.

Autores:
	Carlo Polisano S. 0910672
	Alejandro Guevara 0910971