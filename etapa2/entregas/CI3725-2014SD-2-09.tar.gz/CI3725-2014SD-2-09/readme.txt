Ci-3725: Traductores e Interpretadores.
Interpretador para el lenguaje Trinity.

Grupo 9.
Autores: 
Alejandro Garbi, 08-10398 y 
Alessandro La Corte 09-10430.

Para compilar, ejecutar los siguientes comandos:
1) cabal configure
2) cabal build

El archivo ejecutable se encontrara en el directorio /dist/build/Trinity...
