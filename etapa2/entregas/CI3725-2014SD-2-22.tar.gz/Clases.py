#!/usr/bin/python

'''
 Traductores e Interpretadores                                                       
 CI-3725  

 Integrantes:   

	 10-10738 Abelardo Jesus Valino Ovalle                                                
	 10-10353 Andres Rafael Hernandez Monterola

 Modulo Clases            
'''

import sys

# Diccionario para guardar operadores y usarlos posteriormente en las 
# clases con mayor facilidad

symbolsDic = {	
						"+" 	: "Plus",
						"<=" 	: "Less equal",
						"==" 	: "Equal",
						".*." 	: "Times Cross",
						"./." 	: "Div Cross",
						".mod."	: "Mod Cross",
						"|" 	: "Or",
						".-." 	: "Minus Cross",
						"/" 	: "Div",
						"%" 	: "Mods",
						"div"	: "Division",
						">" 	: "Greater",
						">=" 	: "Greater equal",
						"mod"	: "Mod",
						"-" 	: "Minus",
						"*" 	: "Times",
						"\/=" 	: "distint",
						"&" 	: "and",
						".%." 	: "mods cross",
						".div."	: "div cross",
						"<" 	: "Less",
						".+." 	: "plus cross",
					} 




# Funcion para impresion de tab
def Identacion(cantidad):
	i=0

	while (i<4):	
		cantidad +=  "  "
		i+=1

	return cantidad;



class Number():
	"""Clase que maneja a los numeros"""

	#Constructor de la clase
	def __init__(self,value,row):
		
		self.value = value
		self.row = row
	
	def getRow(self):
		return set.row

	#Funcion para imprimir
	def printI(self, cantidad):

		print cantidad, "Literal Numerico Valor: ", self.value


class Identificator:
	"""Clase que maneja a los Identificador (ID)"""

	#Constructor de la clase
	def __init__(self,value,row):
		
		self.value = value
		self.row = row
	
	def getRow(self):
		return set.row
	
	#Funcion para imprimir
	def printI(self, cantidad):

		print cantidad, "Nombre: ", str(self.value)

class String:
	"""Clase que maneja a los String"""

	#Constructor de la clase
	def __init__(self,value,row):
		
		self.value = value
		self.row = row

	
	def getRow(self):
		return set.row

	#Funcion para imprimir
	def printI(self, cantidad):

		print cantidad, " String: ", self.value

class Boolean:
	"""Clase que maneja a los Booleanos"""

	# Constructor de la clase
	def __init__(self,value,row):

		self.value = value
		self.row = row
	
	def getRow(self):
		return set.row
		
	#Funcion para imprimir
	def printI(self, cantidad):

		print cantidad, "Boolean: "
		print cantidad, " Valor: ", str(self.value)		


class Matrix:
	"""Clase que maneja a las Matrices "matrix(R,C)" """

	# Constructor de la clase
	def __init__(self,R,C,row):

		self.R = R
		self.C = C
		self.row = row
	
	def getRow(self):
		return set.row
		
	#Funcion para imprimir
	def printI(self, cantidad):

		print cantidad, "Matrix: "
		print cantidad, "  Valor Fila: "
		self.R.printI(Identacion(cantidad)) #imprime la fila
		print cantidad, "  Valor Columna: "
		self.C.printI(Identacion(cantidad)) #imprime la coloumna


class Row:
	"""Clase que maneja a las Filas "row(r)" """

	# Constructor de la clase
	def __init__(self,R,row):

		self.R = R
		self.row = row
	
	def getRow(self):
		return set.row
		
	#Funcion para imprimir
	def printI(self, cantidad):

		print cantidad, "Vector Fila: "
		self.R.printI(cantidad)


class Column:
	"""Clase que maneja a las Columnas "column(c)" """

	# Constructor de la clase
	def __init__(self,C,row):

		self.C = C
		self.row = row
	
	def getRow(self):
		return set.row
		
	#Funcion para imprimir
	def printI(self, cantidad):

		print cantidad, "Vector Columna: "
		print cantidad, " Valor: "
		self.C.printI(Identacion(cantidad))

class RowFormat:
	"""Clase que maneja a los formatos de las Filas 
	"{valor1,valor2,valor3}" """

	# Constructor de la clase
	def __init__(self,row,R = None):

		self.R = R 	#Lista de Filas
		self.row = row
	
	def getRow(self):
		return set.row
		
	#Funcion para imprimir
	def printI(self, cantidad):

		print cantidad, "Fila: "
		
		if self.R:
			for i in self.R:
				print cantidad, " Valor: "
				self.R.printI(Identacion(cantidad))
		else: 
			print cantidad, " Valor: Vacio"


class ColumnFormat:
	"""Clase que maneja a los formatos de las Columnas 
	"{valor1:valor2:valor3}" """

	# Constructor de la clase
	def __init__(self,row,C = None):

		self.C = C 	#Lista de Columnas
		self.row = row
	
	def getRow(self):
		return set.row
		
	#Funcion para imprimir
	def printI(self, cantidad):

		print cantidad, "Columna: "
		
		if self.C:
			for i in self.C:
				print cantidad, " Valor: "
				self.C.printI(Identacion(cantidad))
		else: 
			print cantidad, " Valor: Vacio"


class MatrixFormat:
	"""Clase que maneja a los formatos de las Matrices 
	"{valor1,valor2,valor3:valor4,valor5,valor6}" """

	# Constructor de la clase
	def __init__(self,row,MatrixValue):

		self.MatrixValue = MatrixValue 
		self.row = row
	
	def getRow(self):
		return set.row
		
	#Funcion para imprimir
	def printI(self, cantidad):

		print cantidad, "Matriz: "
		for i in self.MatrixValue:
			print cantidad, " Valor: "
			i.printI(Identacion(cantidad))


class Expre_If_Else:
	"""Clase que maneja a los condicionales IF <condicion> THEN <Intrucciones> END;"""

	#Constructor de la clase
	def __init__(self,row,condition,instruction, instruction2 = None):
		
		self.condition = condition
		self.instruction = instruction
		self.instruction2 = instruction2
		self.row = row
	
	def getRow(self):
		return set.row
	
	#Funcion para imprimir
	def printI(self, cantidad):

		print cantidad, "Expresion IF: "
		print cantidad, " Condicion: "
		self.condition.printI(Identacion(cantidad)) #imprime la condicion

		print cantidad, "Expresion THEN: "
		for j in self.instruction:
			print cantidad, " Instruciones: "
			j.printI(Identacion(cantidad))	#imprime la instruccion

		#imprime siguiente instruccion si la hay
		if self.instruction2 <> None:
			print cantidad, "Expresion ELSE: "
			for k in self.instruction2:
				print cantidad, " Instruciones: "
				k.printI(Identacion(cantidad)) 


class Expre_Set:
	"""Clase que maneja los SET <ID> = expresion """

	# Constructor de la clase
	def __init__(self,identificator,expression,row):

		self.identificator = identificator 	
		self.expression = expression
		self.row = row
	
	def getRow(self):
		return set.row
		
	#Funcion para imprimir
	def printI(self, cantidad):

		print cantidad, "Se Asigna a: "	
		print cantidad, " Identificador: "
		self.identificator.printI(Identacion(cantidad))
		print cantidad, "Expresion: "
		self.expression.printI(Identacion(cantidad))


class Variable_Declaration:
	"""Clase que maneja la declaracion de las variables 

		<type> <variable>;
		<type> <variable> = expression;

	 """

	# Constructor de la clase
	def __init__(self,row,identificator_type,identificator,expression=None):

		self.identificator_type = identificator_type
		self.identificator = identificator 	
		self.expression = expression
		self.row = row
	
	def getRow(self):
		return set.row
		
	#Funcion para imprimir
	def printI(self, cantidad):

		# Impresion de variable y tipo
		print cantidad, "Variable: "

		if (isinstance(self.identificator_type,int) or isinstance(self.identificator_type,str)):
			print cantidad," Tipo:",self.identificator_type
		else:
			self.identificator_type.printI(Identacion(cantidad))	

		#Impresion del identificador
		print cantidad, " Identificador: "
		self.identificator.printI(Identacion(cantidad))
		
		#Impresion de la expresion
		if self.expression:
			print cantidad, " Expresion: "
			self.expression.printI(Identacion(cantidad))


class Expre_Read:
	"""Clase que maneja la lectura por linea de comando

		read <identificator>;
	"""

	#Constructor de la clase
	def __init__(self,identificator,row):
		
		self.identificator = identificator 	
		self.row = row
	
	def getRow(self):
		return set.row
	
	#Funcion para imprimir
	def printI(self, cantidad):

		print cantidad, "Expresion Read: "
		print cantidad, " Identificador: "
		self.identificator.printI(Identacion(cantidad))



class Expre_Vector:
	"""Clase que maneja los return

		e[i,j];
		e[i];
	"""

	#Constructor de la clase
	def __init__(self,row,identificator,fila,columna=None):
		
		self.identificator = identificator
		self.fila = fila
		self.columna = columna 	
		self.row = row
	
	def getRow(self):
		return set.row
	
	#Funcion para imprimir
	def printI(self, cantidad):

		print cantidad, "Vector: "
		print cantidad, " Identificador: " 
		self.identificator.printI(Identacion(cantidad))
		print cantidad, " Numero de fila: "
		self.fila.printI(Identacion(cantidad))
		if self.columna <> None:
			print cantidad, " Numero de columna: " 
			self.columna.printI(Identacion(cantidad))



class Expre_ReturnExpresion:
	"""Clase que maneja los return

		return <expresion>;
	"""

	#Constructor de la clase
	def __init__(self,expresion,row):
		
		self.expresion = expresion 	
		self.row = row
	
	def getRow(self):
		return set.row
	
	#Funcion para imprimir
	def printI(self, cantidad):

		print cantidad, "Return: "
		print cantidad, " Expresion: "
		self.expresion.printI(Identacion(cantidad))


class Inst_PrintExpresion:
	"""Clase que maneja la impresion 

		print <Expresion>
	"""

	#Constructor de la clase
	def __init__(self,row,PrintExpresion):
		
		self.PrintExpresion = PrintExpresion 	
		self.row = row
	
	def getRow(self):
		return set.row
	
	#Funcion para imprimir
	def printI(self, cantidad):

		print cantidad, "Expresion Print: "
		print cantidad, " Expresion: "
		for j in self.PrintExpresion:
			j.printI(Identacion(cantidad))

class Expre_UseIn:
	"""Clase que maneja los Use-In 

		use 
			<VariableDeclaration>
		in
			<Instructions>
		end;

	"""

	#Constructor de la clase
	def __init__(self,row,declarations,instructions):
		
		self.declarations = declarations	#Lista de declaracion
		self.instructions = instructions 	#Lista de instruction
		self.row = row
	
	def getRow(self):
		return set.row
	
	#Funcion para imprimir
	def printI(self, cantidad):

		print cantidad, "Expresion Use: "

		for i in self.declarations:
			print cantidad, " Declaracion: "
			i.printI(Identacion(cantidad))
	
		print cantidad, "Expresion In: "

		for j in self.instructions:
			print cantidad, " Instruccion: "
			j.printI(Identacion(cantidad))


class Expre_While:
	"""Clase que maneja los ciclos del while  

		while <condition> do 
			<Instructions>
		end;

	"""

	#Constructor de la clase
	def __init__(self,row,condition,instructions):
		
		self.condition = condition	#Lista de condiciones
		self.instructions = instructions 	#Lista de instruction
		self.row = row
	
	def getRow(self):
		return set.row
	
	#Funcion para imprimir
	def printI(self, cantidad):

		print cantidad, "Expresion While: "
		print cantidad, " Condicion: "
		self.condition.printI(Identacion(cantidad))

		for j in self.instructions:
			print cantidad, " Instruccion: "
			j.printI(Identacion(cantidad))


class Expre_For:
	"""Clase que maneja los ciclos del while  

		for <identificator> in <expression> do 
			<Instructions>
		end;

	"""

	#Constructor de la clase
	def __init__(self,row,identificator,expression,instructions):
		
		self.identificator = identificator	#Lista de identificadores
		self.instructions = instructions 	#Lista de instruction
		self.expression = expression 		#Lista de expresion 
		self.row = row
	
	def getRow(self):
		return set.row
	
	#Funcion para imprimir
	def printI(self, cantidad):

		print cantidad, "Expresion For: "
		print cantidad, " Identificador: "
		self.identificator.printI(Identacion(cantidad))
		print cantidad, " Expresion: "
		self.expression.printI(Identacion(cantidad))
		for j in self.instructions:
			print cantidad, " Instruccion: "
			j.printI(Identacion(cantidad))

class LlamadoFunction:
	"""Clase que maneja las funciones 

		<identificator>(List<identificator>)

	"""

	#Constructor de la clase
	def __init__(self,row,identificator,ListIdentification=None):
		
		self.identificator = identificator	
		self.ListIdentification = ListIdentification 	#Lista de ListIdentification
		self.row = row
	
	def getRow(self):
		return set.row
	
	#Funcion para imprimir
	def printI(self, cantidad):

		print cantidad, "Funcion: "
		print cantidad, " Identificador: "
		self.identificator.printI(Identacion(cantidad))
		for j in self.ListIdentification:
			print cantidad, " Parametro: "
			j.printI(Identacion(cantidad))

class Function:
	"""Clase que maneja las funciones 

		function <identificator>(<variable_declaration>) return <type>
		begin
			<instructions>
		end;

	"""

	#Constructor de la clase
	def __init__(self,row,identificator,returntype,instructions,variable_declaration=None):
		
		self.identificator = identificator	#Lista de identificadores
		self.variable_declaration = variable_declaration 	#Lista de variable_declaration
		self.returntype = returntype
		self.instructions = instructions 		#Lista de instructions 
		self.row = row
	
	def getRow(self):
		return set.row
	
	#Funcion para imprimir
	def printI(self, cantidad):

		print cantidad, "Funcion: "
		print cantidad, " Identificador: "		
		self.identificator.printI(Identacion(cantidad))
		for j in self.variable_declaration:
			print cantidad, " Parametro: "
			j.printI(Identacion(cantidad))
		print cantidad, " Retornar: "
		if (isinstance(self.returntype,str)):
			print cantidad, self.returntype
		else:
			self.returntype.printI(Identacion(cantidad))

		for i in self.instructions:
			print cantidad, " Instruccion: "

			if (isinstance(i,int) or isinstance(i,str)):
				print cantidad, i
			else:
				i.printI(Identacion(cantidad))


class Instruccion:
	"""Clase que maneja las Instruccion  

		<Instruccion>

	"""

	#Constructor de la clase
	def __init__(self,row,instruccion):
			
		self.instruccion = instruccion 		#Lista de instrucciones
		self.row = row
	
	def getRow(self):
		return set.row
	
	#Funcion para imprimir
	def printI(self, cantidad):

		print cantidad, "Instruccion: "
		for i in self.instruccion:
			print cantidad, " "
			i.printI(Identacion(cantidad))

class Exp_Comments:
	"""Clase que maneja los Comentarios   

		# <Comments>

	"""

	#Constructor de la clase
	def __init__(self,row,comentario):
			
		self.comentario = comentario 		
		self.row = row
	
	def getRow(self):
		return set.row
	
	#Funcion para imprimir
	def printI(self, cantidad):

		print cantidad, "Comentario: ", self.comentario


class Exp_Paren:
	"""Clase que maneja las expresiones binarias 

		(Exp)

	"""

	#Constructor de la clase
	def __init__(self,row,pareni,exp,parend):
		
		self.pareni = pareni	#Lista de expresiones al lado izq del operador
		self.exp = exp 	
		self.parend = parend 		#Lista de expresiones al lado der del operador 
		self.row = row
	
	def getRow(self):
		return set.row
	
	#Funcion para imprimir
	def printI(self, cantidad):

		print cantidad, "Parentesis Izq: "
		print cantidad, " Expresion: "
		self.exp.printI(Identacion(cantidad))
		print cantidad, "Parentesis Der"			


class Exp_Binaria:
	"""Clase que maneja las expresiones binarias 

		Exp op Exp

	"""

	#Constructor de la clase
	def __init__(self,row,leftexpression,operator,rightexpression):
		
		self.leftexpression = leftexpression	#Lista de expresiones al lado izq del operador
		self.operator = operator 	
		self.rightexpression = rightexpression 		#Lista de expresiones al lado der del operador 
		self.row = row
	
	def getRow(self):
		return set.row
	
	#Funcion para imprimir
	def printI(self, cantidad):

		print cantidad, "Operador: ", str(symbolsDic[self.operator])
		print cantidad, " Expresion Izq: "
		self.leftexpression.printI(Identacion(cantidad))
		print cantidad, " Expresion Der: "
		self.rightexpression.printI(Identacion(cantidad))			


class Exp_Unaria:
	"""Clase que maneja las expresiones unarias 

		op Exp
	"""

	#Constructor de la clase
	def __init__(self,row,operator,rightexpression):
		
		self.operator = operator 	
		self.rightexpression = rightexpression 		#Lista de expresiones al lado der del operador 
		self.row = row
	
	def getRow(self):
		return set.row
	
	#Funcion para imprimir
	def printI(self, cantidad):

		print cantidad, "Operador: not "
		self.rightexpression.printI(Identacion(cantidad))	


class Exp_ProgramEnd:
	"""Clase que maneja las expresiones Program y End 

		<FunctionSpecification> 
		program
			<Instructions>
		end;

	"""

	#Constructor de la clase
	def __init__(self,row,instructions,FunctionSpecification=None):
		
		self.FunctionSpecification = FunctionSpecification 	#Lista de FunctionSpecification
		self.instructions = instructions 		#Lista de instructions 
		self.row = row

		self.printI("")
	
	def getRow(self):
		return set.row
	
	#Funcion para imprimir el arbol
	def printI(self, cantidad):

		print cantidad, "TRINITY: "

		if self.FunctionSpecification:
			for j in self.FunctionSpecification:
				j.printI(Identacion(cantidad))

		print cantidad,"Abrir Program:"
		print cantidad,"  Instrucciones:"

		print cantidad, " Program: "
		for i in self.instructions:
			i.printI(Identacion(cantidad))
		print cantidad, "Fin Del Progrma TRINITY"