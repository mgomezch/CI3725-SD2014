import qualified Data.Map as Map
import Lexer (alexScanTokens)
import Parser (parse)
import Token
import System.IO
import System.Environment

-- Function printElements
-- Prints a Token list
printElements :: [Token] -> IO()
printElements [] = return ()
printElements (x:xs) = do print x
                          printElements xs

-- Main Functions
main :: IO()
main =
    do  
        args <- getArgs     -- Get the file from args
        let h = head args

        k <- readFile h
        let x = (alexScanTokens k)  -- Get Tokens
        

        print (parse x)