''' Modulo con las clases necesarias por el Parser
Autores: Jesus Parra
		 Cristian Medina ''' 

		 
class Tipo:
	def imprimir(self):
		print 'Tipo: ',self.tipo

class Tipo_matrix:
	def imprimir(self):
		print 'Tipo: Matrix( ',self.fila,' ',self.columna,' )'
	def __init__(self,f,c):
		self.fila = f
		self.columna = c
		
class Proyeccion_matrix:
	def imprimir(self):
		print 'Proyeccion : ',self.identificador,' columna: ',self.columan, 'fila: ',self.fila
	def __init__(self,i,f,c):
		self.identificador = i
		self.columna = c
		self.fila = f

class Asignacion:
	def imprimir(self):
		print 'Asignacion: ',self.identificador, ' valor: ', self.valor
	def __init__(self,i,e):
		self.identificador = i
		self.valor = e
	
class OR:
	def imprimir(self):
		print 'Operacion OR: lado izquierdo: ',self.I,' lado derecho: ',self.valorR
	def __init__(self,i,r):
		self.valorI = i
		self.valorR = r

class AND:
	def imprimir(self):
		print 'Operacion AND: lado izquierdo: ',self.I,' lado derecho: ',self.valorR
	def __init__(self,i,r):
		self.valorI = i
		self.valorR = r

class Igualdad:
	def imprimir(self):
		print 'Operacion igualdad: lado izquierdo: ',self.I,' lado derecho: ',self.valorR
	def __init__(self,i,r):
		self.valorI = i
		self.valorR = r

class Diferencia:
	def imprimir(self):
		print 'Operacion diferencia: lado izquierdo: ',self.I,' lado derecho: ',self.valorR
	def __init__(self,i,r):
		self.valorI = i
		self.valorR = r

class Relacion:
	def imprimir(self):
		print 'Operacion relacional: lado izquierdo: ',self.I,' lado derecho: ',self.valorR
	def __init__(self,i,o,r):
		self.valorI = i
		self.operador = o
		self.valorR = r
	
class Adicion:
	def imprimir(self):
		print 'Operacion Adicion: lado izquierdo: ',self.I,' lado derecho: ',self.valorR
	def __init__(self,i,r):
		self.valorI = i
		self.operador = o
		self.valorR = r

class Producto:
	def imprimir(self):
		print 'Operacion producto: lado izquierdo: ',self.I,' lado derecho: ',self.valorR
	def __init__(self,i,r):
		self.valorI = i
		self.operador = o
		self.valorR = r
	
class Unario:
	def imprimir(self):
		print 'Operadacion unaria: operador: ',self.operador,' valor: ',self.valor
	def __init__(self,o,v):
		self.operador = o
		self.valor = v
		
class Operador_unario:
	def imprimir(self):
		print 'Operador unario: ',self.operador
	
class expresion_procesada:
	def imprimir(self):
		print 'Expresion procesada: ',self.valor
	def __init__(self,e,v):
		self.expresion = e
		self.valor = v

class Declaracion_variable:
	def imprimir(self):
		print 'Declaracion de un variable: tipo: ',self.tipo,' identificador: ', self.identificador,' valor: ', self.expresion
	def __init__(self,t,i,e):
		self.expresion = e
		self.identificador = i
		self.tipo = t
	
class Lista_declaracion_variable:
	def imprimir(self):
		print 'Lista de declaraciones: ',self.declaraciones
	def __init__(self,i,r):
		self.declaracion1 = i
		self.declaracion2 = r
class Instruccion:
	def imprimir(self):
		print 'Instruccion: ',self.funcion
	
class Lista_instruccion:
	def imprimir(self):
		print 'Lista de instrucciones: ',self.instrucciones
	def __init__(self,i,r):
		self.instruccion1 = i
		self.instruccion2 = r
		
class Bloque_instrucciones:
	def imprimir(self):
		print 'Bloque de instrucciones: variables: ',self.lista_variables,' instrucciones: ',self.instrucciones
	def __init__(self,i,r):
		self.lista_variables = i
		self.instrucciones = r
		
class bloque_seleccion:
	def imprimir(self):
		print 'Bloque de seleccion: primera parte: ',self.primer_bloque,' segunda parte: ',self.segundo_bloque
	def __init__(self,i,r):
		self.primer_bloque = i
		self.segundo_bloque = r
	
class Seleccion:
	def imprimir(self):
		print 'Seleccion: primera parte: ',self.primer_bloque,' segunda parte: ',self.segundo_bloque
	def __init__(self,i,r):
		self.primer_bloque = i
		self.segundo_bloque = r
	
class bloque_iteracion:
	def imprimir(self):
		print 'Bloque de iteracion: instrucciones: ',self.instrucciones

class Iteracion:
	def imprimir(self):
		print 'Iteracion: expresion: ',self.expresion,' bloque: ',self.bloque
	def __init__(self,e,i,b):
		self.expresion = e
		self.identificador = i
		self.bloque = b
		
class Bloque_impresion:
	def imprimir(self):
		print 'Bloque de impresion: expresion: ',self.expresion
	def __init__(self,i,r):
		self.imprimir1 = i
		self.imprimir2 = r
		
class Impresion:
	def imprimir(self):
		print 'Impresion: bloque: ',self.bloque
	
class Lista_argumentos:
	def imprimir(self):
		print 'Lista de argumentos: ',self.lista
	def __init__(self,i,r):
		self.arg1 = i
		self.arg2 = r
	
class Lectura:
	def imprimir(self):
		print 'Lectura: identificador: ',self.identificador
	
class bloque_funcion:
	def imprimir(self):
		print 'Bloque de funciones: instrucciones: ',self.instrucciones
	
class Parametro:
	def imprimir(self):
		print 'Parametro: tipo: ',self.tipo,' identificador: ',self.identificador
	def __init__(self,t,i):
		self.tipo = t
		self.identificador = i
	
class lista_parametros:
	def imprimir(self):
		print 'Lista de parametros: ',self.lista
	def __init__(self,i,r):
		self.param1 = i
		self.param2 = r
	
class Declaracion_funcion:
	def imprimir(self):
		print 'Declaracion de funcion: identificador: ',self.identificador,' lista de parametros: ',self.lista_parametros,' tipo: ',self.tipo,' bloque de la funcion: ',self.bloque_funcion
	def __init__(self,i,l,t,b):
		self.identificador = i
		self.lista_parametros = l
		self.tipo = t
		self.bloque_funcion = b
	
class lista_funciones:
	def imprimir(self):
		print 'Lista de funciones: ',self.lista
	def __init__(self,i,r):
		self.funcion1 = i
		self.funcion2 = r
	
class Programa:
	def imprimir(self):
		print 'Programa: Lista de funciones: ',self.lista_funciones,' lista de instrucciones: ',self.lista_instrucciones
	def __init__(self,i,r):
		self.lista_funciones = i
		self.lista_instrucciones = r
		
class Bloque_fila:
	def imprimir(self):
		print 'Bloque de filas: columnas: ',self.columnas
	def __init__(self,x,y):
		self.columna1 = x
		self.columna2 = y
		
class Bloque_columna:
	def imprimir(self):
		print 'Bloque de columnas: expresiones: ',self.expresion
	def __init__(self,x,y):
		self.expresion1 = x
		self.expresion2 = y
	
class Literal_matriz:
	def imprimir(self):
		print 'Literal matricial: filas: ',self.filas
