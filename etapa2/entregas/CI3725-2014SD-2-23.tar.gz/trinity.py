#!/usr/bin/env python

''' Modulo de Lexer
Este modulo contiene los procedimientos de lectura de archivo,
de creacion de patrones y el constructor de la lista de tokens.
Autores: Jesus Parra
		 Cristian Medina '''

from tokens import *
import re
import sys
from parser import *
'''
	Funcion que le un archivo y devueleve un string con el contenido
	de este.
	Input:
	nombreArchivo: string con el nombre del archivo que contiene
	el codigo en trinity.
	Output:
	listaCaracteres:una lista con los caracteres leidos del archivo.
'''
def lecturaArchivo(nombreArchivo):

	archivo = open(nombreArchivo)
	listaCaracteres = archivo.read()
	archivo.close

	return listaCaracteres

'''
	Metodo que genera una lista con las expresiones regulares correspondientes
	a las palabras del lenguaje trinity, y los asocia con un codigo que los 
	identifica
'''
def constructorPatrones():
	
	'''
		Expresiones Regulares para cada token.

		------- BASE -------
		coma ',' = 0
		punto y coma ';' = 1
		hashtag '#' = 3
		------- BLOQUES -------
		parentesis izquierdo '(' = 4
		parentesis derecho ')' = 5
		corchete izquierdo '[' = 6
		corchete derecho ']' = 7
		llave izquierdo '{' = 8
		llave derecho '}' = 9
		asignacion '==' = 10
		------- OPERADORES BOOLEANOS -------
		conjuncion '|' = 11
		disjuncion '&' = 12
		negacion 'not' = 13
		equivalencia '=' = 14
		mayor '>' = 15
		mayor igual '>=' = 16
		menor '<' = 17
		menor igual '<=' = 18
		diferente '/=' = 62
		------- OPERADORES ARITMETICOS -------
		suma '+' = 19
		resta '-' = 20
		producto '*' = 21
		division '/' = 22
		modulo '%' = 23
		division entera 'div' = 24
		modulo entero 'mod' = 25
		traspuesto ' ' ' = 26
		------- OPERADORES CRUZADOS -------
		suma cruzada '.+.' = 27
		resta cruzada '.-.' = 28
		producto cruzada '.*.' = 29
		division cruzada './.' = 30
		modulo cruzada '.%.' = 31
		division entera cruzada '.div.' = 32
		modulo entero cruzada'.mod.' = 33
		------- PALABRAS RESERVADAS --------
		comienzo codigo 'begin' = 34
		termina bloque 'end' = 35
		seleccion 'if' = 36
		seleccion else 'else' = 37
		seleccion accion 'then' = 38
		iteracion cond 'while' = 39
		iteracion completo 'for' = 40
		iterador 'in' = 41
		iteraacion accion 'do' = 42
		funcion 'function' = 43
		funcion retorno 'return' = 44
		inicio programa 'program' = 45
		impresion 'print' = 46
		lectura 'read' = 47
		declaracion variables 'use' = 48
		asignacion variable 'set' = 49
		------- TIPOS -------
		booleano 'boolean' = 50
		numerico 'numeric' = 51
		matris 'matrix' = 52
		columna 'col' = 53
		fila 'row' = 54   
		------- LITERALES -------
		falso 'false' = 55
		verdadero 'true' = 56
		numerico '[0-9]+(.[0-9]+)?' = 57
		identificadores = 58
		string '"...*"' = 59
		comillas dobles """ = 60
		caracter de salida \" '\"' = 61
		
	'''
	patrones = [
		# Basicos
		(r',', 0),
		(r';', 1),
		(r'#.*', 3),
		# Bloques
		(r'\(', 4),
		(r'\)', 5),
		(r'\[', 6),
		(r'\]', 7),
		(r'{', 8),
		(r'}', 9),
		(r'=(?!=)', 10),
		# Operadores booleanos
		(r'\|', 11),
		(r'&', 12),
		(r'not', 13),
		(r'==', 14),
		(r'>(?!=)', 15),
		(r'>=', 16),
		(r'<(?!=)', 17),
		(r'<=', 18),
		(r'/=',64),
		# Operadores aritmeticos
		(r'\+', 19),
		(r'-', 20),
		(r'\*', 21),
		(r'/(?!=)', 22),
		(r'%', 23),
		(r'div', 24),
		(r'mod', 25),
		(r"'", 26),
		# Operadores cruzados
		(r'\.\+\.', 27),
		(r'\.-\.', 28),
		(r'\.\*\.', 29),
		(r'\./\.', 30),
		(r'\.%\.', 31),
		(r'\.div\.', 32),
		(r'\.mod\.', 33),
		# Palabras reservadas
		(r'begin(?![A-Za-z0-9_])', 34),
		(r'end(?![A-Za-z0-9_])', 35),
		(r'if(?![A-Za-z0-9_])', 36),
		(r'else(?![A-Za-z0-9_])', 37),
		(r'then(?![A-Za-z0-9_])', 38),
		(r'while(?![A-Za-z0-9_])', 39),
		(r'for(?![A-Za-z0-9_])', 40),
		(r'in(?![A-Za-z0-9_])', 41),
		(r'do(?![A-Za-z0-9_])', 42),
		(r'function(?![A-Za-z0-9_])', 43),
		(r'return(?![A-Za-z0-9_])', 44),
		(r'program(?![A-Za-z0-9_])', 45),
		(r'print(?![A-Za-z0-9_])', 46),
		(r'read(?![A-Za-z0-9_])', 47),
		(r'use(?![A-Za-z0-9_])', 48),
		(r'set(?![A-Za-z0-9_])', 49),
		# Tipos
		(r'boolean(?![A-Za-z0-9_])', 50),
		(r'number(?![A-Za-z0-9_])', 51),
		(r'matrix(?![A-Za-z0-9_])', 52),
		(r'col(?![A-Za-z0-9_])', 53),
		(r'row(?![A-Za-z0-9_])', 54),   
		# Literales
		(r'false(?![A-Za-z0-9_])', 55),
		(r'true(?![A-Za-z0-9_])', 56),
		(r'[0-9]+(\.[0-9]+)?', 57),
		# Identificadores
		(r'[A-Za-z][A-Za-z0-9_]*',58),
		# Literal String
		(r'\"(\\\"|[^\"])*([^(\\|\n|\")]|\\\"|\\\\)\"', 59), # LEE CUALQUIER COSA
		(r'"', 60),
		(r'\\', 61),
		(r'(?!(\\))"',62),
		(r':',63)
	]

	return patrones
	
	
'''
	Funcion que a partir de un codigo en string, devuelve
	una lista de tokens que representan al codigo.
	Input: 
	codigo: string con el contenido del codigo a convertir en tokens.
	Output: 
	listaTokens: una lista de tokens encontrados en el codigo.
'''
def aLexicografico(codigo):


	columna = 1
	fila = 1
 
	patrones = constructorPatrones()
	errores = []

	tamCodigo = len(codigo)
	listaTokens = []
	pos = 0
	
	# ciclo que va leyendo el codigo y creando tokens
	while (pos < tamCodigo):
		
		evaluacionER = None

		# Se ignoran los espacios en blanco y los saltos de linea
		if ( (codigo[pos] != ' ') & (codigo[pos] != '\n') ):
			
			# ciclo que va comparando el string con las er de los tokens
			for patron in patrones:
				expresionRegular, idPatron = patron
				erCompilado = re.compile(expresionRegular)
				evaluacionER = erCompilado.match(codigo,pos)
				
				# Se identifica segun el id del patron que tipo de token se crea
				if evaluacionER:
				
					# Se identifica una coma
					if (idPatron == 0):
						newToken = T_Coma(columna,fila,",")
						listaTokens.append(newToken)

					# Se identifica un punto y coma
					elif (idPatron == 1):
						newToken = T_Puntocoma(columna,fila,";")
						listaTokens.append(newToken)
					
					# Se identifica un comentario					
					elif (idPatron == 3):
						newToken = T_Comentario(columna,fila,evaluacionER.group(0))
						listaTokens.append(newToken)
		                            
					# Se identifica un parentesis izquierdo 
					elif (idPatron == 4):
						newToken = T_ParentesisI(columna,fila,"(")			
						listaTokens.append(newToken)
					
					# Se identifica un parentesis derecho 
					elif (idPatron == 5):
						newToken = T_ParentesisR(columna,fila,")")			
						listaTokens.append(newToken)

					# Se identifica un corchete izquierdo 
					elif (idPatron == 6):
						newToken = T_CorcheteI(columna,fila,"[")			
						listaTokens.append(newToken)
					
					# Se identifica un corchete derecho 
					elif (idPatron == 7):
						newToken = T_CorcheteR(columna,fila,"]")			
						listaTokens.append(newToken)
					
					# Se identifica un llave izquierdo 
					elif (idPatron == 8):
						newToken = T_LlaveI(columna,fila,"{")			
						listaTokens.append(newToken)
					
					# Se identifica un llave derecho 
					elif (idPatron == 9):
						newToken = T_LlaveR(columna,fila,"}")			
						listaTokens.append(newToken)
					
					# Se identifica un asignador 
					elif (idPatron == 10):
						newToken = T_Igual(columna,fila,"=")			
						listaTokens.append(newToken)

					# Se identifica un operador booleano |
					elif (idPatron==11):
						newToken = T_oOR(columna,fila,evaluacionER.group(0))
						listaTokens.append(newToken)
					
					# Se identifica el operador &
					elif (idPatron==12):
						newToken=T_oAND(columna,fila,evaluacionER.group(0))
						listaTokens.append(newToken)
					
					# Se identifica el operador not
					elif (idPatron==13):
						newToken=T_oNOT(columna,fila,evaluacionER.group(0))
						listaTokens.append(newToken)
						
					# Se identifica el operador ==
					elif (idPatron==14):
						newToken=T_oIgual(columna,fila,evaluacionER.group(0))
						listaTokens.append(newToken)
						
					# Se identifica el operador >
					elif (idPatron==15):
						newToken=T_oMayor(columna,fila,evaluacionER.group(0))
						listaTokens.append(newToken)
						
					# Se identifica el operador >=
					elif (idPatron==16):
						newToken=T_MayorIgual(columna,fila,evaluacionER.group(0))
						listaTokens.append(newToken)
						
					# Se identifica el operador <
					elif (idPatron==17):
						newToken=T_oMenor(columna,fila,evaluacionER.group(0))
						listaTokens.append(newToken)
						
					# Se identifica el operador <=
					elif (idPatron==18):
						newToken=T_oMenorIgual(columna,fila,evaluacionER.group(0))
						listaTokens.append(newToken)
						
					elif (idPatron==62):
						newToken=T_oDiferente(columna,fila,evaluacionER.group(0))
						listaTokens.append(newToken)
						
					# Se identifica el operador +					
					elif (idPatron==19):
						newToken=T_oMas(columna,fila,evaluacionER.group(0))
						listaTokens.append(newToken)
						
					# Se identifica el operador menos
					elif (idPatron==20):
						newToken=T_oMenos(columna,fila,evaluacionER.group(0))
						listaTokens.append(newToken)
					
					# Se identifica el operador *
					elif (idPatron==21):
						newToken=T_oMultiplicar(columna,fila,evaluacionER.group(0))
						listaTokens.append(newToken)
					
					# Se identifica el operador /
					elif (idPatron==22):
						newToken=T_oDividir(columna,fila,evaluacionER.group(0))
						listaTokens.append(newToken)
						
					# Se identifica el operador %
					elif (idPatron==23):
						newToken=T_oResto(columna,fila,evaluacionER.group(0))
						listaTokens.append(newToken)
						
					# Se identifica el operador div
					elif (idPatron==24):
						newToken=T_oDivisionEntera(columna,fila,evaluacionER.group(0))
						listaTokens.append(newToken)
					
					# Se identifica el operador mod
					elif (idPatron==25):
						newToken=T_oRestoEntero(columna,fila,evaluacionER.group(0))
						listaTokens.append(newToken)
						
					# Se identifica el operador '
					elif (idPatron==26):
						newToken=T_oTranspuesta(columna,fila,evaluacionER.group(0))
						listaTokens.append(newToken)

					# Se identifica un operador .+.					
					elif (idPatron==27):
						newToken=T_oCruzMas(columna,fila,evaluacionER.group(0))
						listaTokens.append(newToken)
					
					# Se identifica el operador .-.
					elif (idPatron==28):
						newToken=T_oCruzMenos(columna,fila,evaluacionER.group(0))
						listaTokens.append(newToken)
					
					# Se identifica el operador .*.
					elif (idPatron==29):
						newToken=T_oCruzMultiplicar(columna,fila,evaluacionER.group(0))
						listaTokens.append(newToken)
					
					# Se identifica el operador ,/.
					elif (idPatron==30):
						newToken=T_oCruzDividir(columna,fila,evaluacionER.group(0))
						listaTokens.append(newToken)
					
					# Se identifica el operador .%.
					elif (idPatron==31):
						newToken=T_oCruzResto(columna,fila,evaluacionER.group(0))
						listaTokens.append(newToken)
						
					# Se identifica el operador .div.
					elif (idPatron==32):
						newToken=T_oCruzDivisionEntera(columna,fila,evaluacionER.group(0))
						listaTokens.append(newToken)
					
					# Se identifica el operador .mod.
					elif (idPatron==33):
						newToken=T_oCruzRestoEntero(columna,fila,evaluacionER.group(0))
						listaTokens.append(newToken)

					# Se identifica la palabra reservada begin						
					elif (idPatron==34):
						newToken=T_RBegin(columna,fila,evaluacionER.group(0))
						listaTokens.append(newToken)
					
					# Se identifica la palabra reservada  end
					elif (idPatron==35):
						newToken=T_REnd(columna,fila,evaluacionER.group(0))
						listaTokens.append(newToken)
						
					# Se identifica la palabra reservada if
					elif (idPatron==36):
						newToken=T_RIf(columna,fila,evaluacionER.group(0))
						listaTokens.append(newToken)
						
					# Se identifica la palabra reservada else
					elif (idPatron==37):
						newToken=T_RElse(columna,fila,evaluacionER.group(0))
						listaTokens.append(newToken)
						
					# Se identifica la palabra reservada then
					elif (idPatron==38):
						newToken=T_RThen(columna,fila,evaluacionER.group(0))
						listaTokens.append(newToken)
					
					# Se identifica la palabra reservada while
					elif (idPatron==39):
						newToken=T_RWhile(columna,fila,evaluacionER.group(0))
						listaTokens.append(newToken)
						
					# Se identifica la palabra reservada for
					elif (idPatron==40):
						newToken=T_RFor(columna,fila,evaluacionER.group(0))
						listaTokens.append(newToken)
					
					# Se identifica la palabra reservada in
					elif (idPatron==41):
						newToken=T_RIn(columna,fila,evaluacionER.group(0))
						listaTokens.append(newToken)
						
					# Se identifica la palabra reservada do
					elif (idPatron==42):
						newToken=T_RDo(columna,fila,evaluacionER.group(0))
						listaTokens.append(newToken)
					
					# Se identifica la palabra reservada function
					elif (idPatron==43):
						newToken=T_RFunction(columna,fila,evaluacionER.group(0))
						listaTokens.append(newToken)
					
					# Se identifica la palabra reservada return
					elif (idPatron==44):
						newToken=T_RReturn(columna,fila,evaluacionER.group(0))
						listaTokens.append(newToken)
					
					# Se identifica la palabra reservada program
					elif (idPatron==45):
						newToken=T_RProgram(columna,fila,evaluacionER.group(0))
						listaTokens.append(newToken)

					# Se identifica la palabra reservada print
					elif (idPatron==46):
						newToken=T_RPrint(columna,fila,evaluacionER.group(0))
						listaTokens.append(newToken)
						
					# Se identifica la palabra reservada read
					elif (idPatron==47):
						newToken=T_RRead(columna,fila,evaluacionER.group(0))
						listaTokens.append(newToken)
						
					# Se identifica la palabra reservada use
					elif (idPatron==48):
						newToken=T_RUse(columna,fila,evaluacionER.group(0))
						listaTokens.append(newToken)
						
					# Se identifica la palabra reservada set
					elif (idPatron==49):
						newToken=T_RSet(columna,fila,evaluacionER.group(0))
						listaTokens.append(newToken)
					
					# Se identifica la palabra reservada boolean
					elif (idPatron==50):
						newToken=T_RBoolean(columna,fila,evaluacionER.group(0))
						listaTokens.append(newToken)
					
					# Se identifica la palabra reservada number
					elif (idPatron==51):
						newToken=T_RNumber(columna,fila,evaluacionER.group(0))
						listaTokens.append(newToken)
						
					# Se identifica la palabra reservada matrix
					elif (idPatron==52):
						newToken=T_RMatrix(columna,fila,evaluacionER.group(0))
						listaTokens.append(newToken)
						
					# Se identifica la palabra reservada col
					elif (idPatron==53):
						newToken=T_RCol(columna,fila,evaluacionER.group(0))
						listaTokens.append(newToken)
						
					# Se identifica la palabra reservada row
					elif (idPatron==54):
						newToken=T_RRow(columna,fila,evaluacionER.group(0))
						listaTokens.append(newToken)
						
					# Se identifica la palabra reservada false
					elif (idPatron==55):
						newToken=T_RFalse(columna,fila,evaluacionER.group(0))
						listaTokens.append(newToken)						
						
					# Se identifica la palabra reservada true
					elif (idPatron==56):
						newToken=T_RTrue(columna,fila,evaluacionER.group(0))
						listaTokens.append(newToken)

					# Se identifica una literal numerico			
					elif (idPatron == 57):
						newToken = T_Number(columna,fila,evaluacionER.group(0))
						listaTokens.append(newToken)

					# Se identifica un identificador				
					elif (idPatron == 58):
						newToken = T_Identificador(columna,fila,evaluacionER.group(0))
						listaTokens.append(newToken)

					# Se identifica un literal String				
					elif (idPatron == 59):
						newToken = T_String(columna,fila,evaluacionER.group(0))
						listaTokens.append(newToken)

					# Se identifica una comilla					
					elif (idPatron == 60):
						newToken = T_PalabraR(columna,fila,evaluacionER.group(0))
						listaTokens.append(newToken)

					# Se identifica caracter de salida \"					
					elif (idPatron == 61):
						newToken = T_Backslash(columna,fila,evaluacionER.group(0)) 
						listaTokens.append(newToken)

					# Se identifica caracter :					
					elif (idPatron == 63):
						newToken = T_Dospuntos(columna,fila,evaluacionER.group(0)) 
						listaTokens.append(newToken)
					break

			# Identificador de errores lexicograficos
			if not(evaluacionER):
				
				newToken = T_Error(columna,fila,codigo[pos])
				listaTokens.append(newToken)
				print "Error Lexicografico: ",codigo[pos]," Linea:",fila,"Columna:",columna
				columna = columna +1
				pos = pos + 1 
				
				
			else:
				columna = columna + (evaluacionER.end(0) - pos) 
				pos = evaluacionER.end(0)

		else:
			if (codigo[pos] == ' '):
				columna = columna + 1
			
			if (codigo[pos] == '\n'):
				columna = 1
				fila = fila + 1
			pos = pos+1
	
	return listaTokens

def obtenerListaToken(archivo):
	codigo = lecturaArchivo(archivo)
	listaTokens = aLexicografico(codigo)
	return listaTokens
		
'''
	****** MAIN ******
'''
if __name__ == "__main__":
	nombreArchivo = sys.argv[1]
	parsear(nombreArchivo)
	