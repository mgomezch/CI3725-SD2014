# -*- coding: utf-8 -*-
''' Modulo de tokens
Este modulo contiene las clases
de tokens reconocidos por el lexer y 
otras funciones relacionadas a los 
tokens.
Autores: Jesus Parra
		 Cristian Medina '''

tokens = ('T_LlaveI','T_LlaveR','T_Coma','T_Comentario','T_Comilla','T_CorcheteI','T_CorcheteR',
			'T_Number','T_ParentesisI','T_ParentesisR','T_Puntocoma','T_RBegin','T_RBoolean','T_RCol',
			'T_RDo','T_RElse','T_REnd','T_RFalse','T_RFor','T_RFunction','T_RIf','T_RIn','T_RMatrix','T_RNumber',
			'T_RPrint','T_RProgram','T_RRead','T_RReturn','T_RRow','T_RSet','T_RThen','T_RTrue','T_RUse',
			'T_RWhile','T_oAND','T_oCruzDividir','T_oCruzDivisionEntera','T_oCruzMas','T_oCruzMenos',
			'T_oCruzMultiplicar','T_oCruzResto','T_oCruzRestoEntero','T_oDiferente','T_oDividir',
			'T_oDivisionEntera','T_oIgual','T_oMas','T_oMayor','T_oMayorIgual','T_oMenor','T_oMenorIgual',
			'T_oMenos','T_oMultiplicar','T_oNOT','T_oOR','T_oResto','T_oRestoEntero','T_oTranspuesta',
			'T_Backslash','T_Dospuntos','T_Identificador','T_Igual','T_String','T_Error')
			
class Token:
	"""Clase abstracta para los tokens """
	
	lineno = 0
	col = 0
	
	def __init__(self,col,linea,value):
		self.col=col
		self.lineno=linea
		self.value=value
		self.type= self.__class__.__name__
		self.lexpos = None
		
	def imprimir(self):
		print 'Linea',self.lineno,', columna',self.col,': ',self.value


class T_LlaveR(Token):
	""" Clase para '}' """
	
class T_LlaveI(Token):
	""" Clase para '{' """
	
class T_Coma(Token):
	""" Clase para ',' """
	
class T_Number(Token):
	""" Clase para los tipo Number """

class T_ParentesisR(Token):
	""" Clase para ')' """
	
class T_ParentesisI(Token):
	""" Clase para '(' """
	
class T_CorcheteR(Token):
	""" Clase para ']' """
	
class T_CorcheteI(Token):
	""" Clase para '[' """
	  
class T_RBegin(Token):
	""" Clase para la palabra reservada 'begin' """

class T_REnd(Token):
	""" Clase para la palabra reservada 'end' """
  
class T_RIf(Token):
	""" Clase para la palabra reservada 'if' """

class T_RElse(Token):
	""" Clase para la palabra reservada 'else' """

class T_RThen(Token):
	""" Clase para la palabra reservada 'then' """

class T_RWhile(Token):
	""" Clase para la palabra reservada 'while' """

class T_RFor(Token):
	""" Clase para la palabra reservada 'for' """

class T_RIn(Token):
	""" Clase para la palabra reservada 'in' """

class T_RDo(Token):
	""" Clase para la palabra reservada 'do' """

class T_RFunction(Token):
	""" Clase para la palabra reservada 'function' """

class T_RReturn(Token):
	""" Clase para la palabra reservada 'return' """
	
class T_RProgram(Token):
	""" Clase para la palabra reservada 'program' """

class T_RPrint(Token):
	""" Clase para la palabra reservada 'print' """

class T_RRead(Token):
	""" Clase para la palabra reservada 'read' """

class T_RUse(Token):
	""" Clase para la palabra reservada 'use' """

class T_RSet(Token):
	""" Clase para la palabra reservada 'set' """

class T_RBoolean(Token):
	""" Clase para la palabra reservada 'boolean' """

class T_RNumber(Token):
	""" Clase para la palabra reservada 'number' """
	
class T_RMatrix(Token):
	""" Clase para la palabra reservada 'matrix' """
	
class T_RCol(Token):
	""" Clase para la palabra reservada 'col' """
	
class T_RRow(Token):
	""" Clase para la palabra reservada 'row' """
	
class T_RFalse(Token):
	""" Clase para la palabra reservada 'false' """
	
class T_RTrue(Token):
	""" Clase para la palabra reservada 'true' """
  
class T_oOR(Token):
	""" Clase para el operador booleano '|' """

class T_oAND(Token):
	""" Clase para el operador booleano '&' """

class T_oNOT(Token):
	""" Clase para el operador booleano 'not' """

class T_oIgual(Token):
	""" Clase para el operador booleano '==' """

class T_oDiferente(Token):
	""" Clase para el operardor booleano '/=' """

class T_oMayor(Token):
	""" Clase para el operador booleano '>' """
  
class T_oMenor(Token):
	""" Clase para el operador booleano '<' """
  
class T_oMayorIgual(Token):
	""" Clase para el operador booleano '>=' """
  
class T_oMenorIgual(Token):
	""" Clase para el operador booleano '<=' """

class T_oMas(Token):
	""" Clase para el operador aritmetico '+' """

class T_oMenos(Token):
	""" Clase para el operador aritmetico '-' """

class T_oMultiplicar(Token):
	""" Clase para el operador aritmetico '*' """
	
class T_oDividir(Token):
	""" Clase para el operador aritmetico '/' """
	
class T_oResto(Token):
	""" Clase para el operador aritmetico '%' """

class T_oDivisionEntera(Token):
	""" Clase para el operador aritmetico 'div' """
	
class T_oRestoEntero(Token):
	""" Clase para el operador aritmetico 'mod' """
	
class T_oTranspuesta(Token):
	""" Clase para el operador aritmetico '\'' """

class T_oCruzMas(Token):
	""" Clase para el operador cruzado '.+.' """
	
class T_oCruzMenos(Token):
	""" Clase para el operador cruzado '.-.' """
	
class T_oCruzMultiplicar(Token):
	""" Clase para el operador cruzado '.*.' """

class T_oCruzDividir(Token):
	""" Clase para el operador cruzado './.' """
  
class T_oCruzResto(Token):
	""" Clase para el operador cruzado '.%.' """
 
class T_oCruzDivisionEntera(Token):
	""" Clase para el operador cruzado '.div.' """

class T_oCruzRestoEntero(Token):
	""" Clase para el operador cruzado '.mod.' """
		
class T_Backslash(Token):
	""" Clase para los '\' """

class T_Dospuntos(Token):
	""" Clase para los : """

class T_Comilla(Token):
	""" Clase para los '"' """
	
class T_Identificador(Token):	
	""" Clase para los identificadores """

class T_Igual(Token):
	""" Clase para '=' """
	
class T_Puntocoma(Token):
	""" Clase para ';' """
	
class T_String(Token):
	""" Clase para cadenas de caracteres """

class T_Comentario(Token):
	""" Clase para los comentarios """

class T_Error(Token):
	""" Clase para errores """