''' Modulo de parser
Autores: Jesus Parra
		 Cristian Medina '''
		 
import sys
from ply import *
from tokens import tokens
from trinity import *
from Clases import *


########## PROGRAMA ##########

def p_inicio(p):
	'inicio : programa'	
	p[0] = p[1]

def p_programa_completo(p):	#
	'programa : lista_funciones T_RProgram lista_instrucciones T_REnd T_Puntocoma'
	p[0] = Programa(p[1], p[3])

def p_programa_sin_instrucciones(p):	#
	'programa : lista_funciones T_RProgram T_REnd T_Puntocoma'
	p[0] = Programa(p[1], None)
	
def p_programa_sin_funciones(p):	#
	'programa : T_RProgram lista_instrucciones T_REnd T_Puntocoma'
	p[0] = Programa(None, p[2])
	
def p_programa_sin_nada(p):	#
	'programa : T_RProgram T_REnd T_Puntocoma'
	p[0] = Programa(None, None)
	
########## TIPO ##########

def p_tipo_Number(p):
	'tipo : T_RNumber'
	p[0] = Tipo(p[1])

def p_tipo_Boolean(p):
	'tipo : T_RBoolean'
	p[0] = Tipo(p[1])
	
def p_tipo_matrix(p):
	'tipo : tipo_matriz'
	p[0] = p[1]
	
########## LITERAL MATRIZ ##########

def p_literal_matriz(p):
	'literal_matriz : T_LlaveI bloque_fila T_LlaveR'
	p[0] = Literal_matriz(p[2])
	
########## BLOQUE FILA ##########

def p_bloque_fila_simple(p):
	'bloque_fila : bloque_columna'
	p[0] = Bloque_fila(None,p[1])

def p_bloque_fila_multiple(p): #
	'bloque_fila : bloque_fila T_Dospuntos bloque_columna'
	p[0] = Bloque_fila(p[1],p[3])
	
########## BLOQUE COLUMNA ##########	

def p_bloque_columna_simple(p):
	'bloque_columna : expresion_adicion'
	p[0] = Bloque_columna(None,p[1])

def p_bloque_columna_multiple(p): #
	'bloque_columna : bloque_columna T_Coma expresion_adicion'
	p[0] = Bloque_columna(p[1],p[3])

########## TIPO MATRIZ ##########	
	
def p_tipo_matriz_completo(p): #
	'tipo_matriz : T_RMatrix T_ParentesisI T_Number T_Coma T_Number T_ParentesisR'
	p[0] = Tipo_matrix(p[3],p[5])
	
def p_tipo_matrix_col(p): #
	'tipo_matriz : T_RCol T_ParentesisI T_Number T_ParentesisR'
	p[0] = Tipo_matrix(p[3], 1)
	
def p_tipo_matrix_row(p): #
	'tipo_matriz : T_RRow T_ParentesisI T_Number T_ParentesisR'
	p[0] = Tipo_matrix(1, p[3])

########## PROYECCION MATRIZ ##########
	
def p_proyeccion_matriz_dos_dimensiones(p): #
	'proyeccion_matriz : expresion_adicion T_CorcheteI expresion_adicion T_Coma expresion_adicion T_CorcheteR %prec proyeccion'
	p[0] = Proyeccion_matrix(p[1], p[3], p[5])

def p_proyeccion_matriz_una_dimensiones(p): #
	'proyeccion_matriz : expresion_adicion T_CorcheteI expresion_adicion T_CorcheteR %prec proyeccion'
	p[0] = Proyeccion_matrix(p[1],p[3],None)

########## PROYECCION MATRIZ ASIGNACION ##########
	
def p_proyeccion_matriz_asignacion_dos_dimensiones(p): #
	'proyeccion_matriz_asignacion : T_Identificador T_CorcheteI expresion_adicion T_Coma expresion_adicion T_CorcheteR %prec proyeccion'
	p[0] = Proyeccion_matrix(identificador(p[1]), p[3], p[5])

def p_proyeccion_matriz_asignacion_una_dimensiones(p): #
	'proyeccion_matriz_asignacion : T_Identificador T_CorcheteI expresion_adicion T_CorcheteR %prec proyeccion'
	p[0] = Proyeccion_matrix(identificador(p[1]),p[3],None)				

########## EXPRESION ASIGNACION ##########

def p_expresion_asignacion_variable(p): #
	'expresion_asignacion : T_RSet T_Identificador T_Igual expresion_OR T_Puntocoma'
	p[0] = Asignacion(identificador(p[2]), p[4])

def p_proyeccion_matriz_proyeccion_matriz(p): #
	'expresion_asignacion : T_RSet proyeccion_matriz_asignacion T_Igual expresion_OR T_Puntocoma'
	p[0] = Asignacion(p[2], p[4])

########## EXPRESION OR ##########

def p_expresion_OR_AND(p):
	'expresion_OR : expresion_AND'
	p[0] = p[1]
	
def p_expresion_OR_op(p): #
	'expresion_OR : expresion_OR T_oOR expresion_AND'
	p[0] = OR(p[1], p[3])
	
########## EXPRESION AND ##########

def p_expresion_AND_Igualdad(p):
	'expresion_AND : expresion_Igualdad'
	p[0] = p[1]
	
def p_expresion_AND_op(p): #
	'expresion_AND : expresion_AND T_oAND expresion_Igualdad'
	p[0] = AND(p[1], p[3])

########## EXPRESION IGUALDAD ##########

def p_expresion_Igualdad_relacional(p):
	'expresion_Igualdad : expresion_relacional'
	p[0] = p[1]
	
def p_expresion_igualdad_Igual(p): #
	'expresion_Igualdad : expresion_Igualdad T_oIgual expresion_Igualdad'
	p[0] = Igualdad(p[1], p[3])
	
def p_expresion_igualdad_Diferente(p): #
	'expresion_Igualdad : expresion_Igualdad T_oDiferente expresion_Igualdad'
	p[0] = Diferencia(p[1], p[3])
		
########## EXPRESION RELACIONAL ##########

def p_expresion_relacional_adicion(p):
	'expresion_relacional : expresion_adicion'
	p[0] = p[1]
	
def p_expresion_relacional_Menor(p): #
	'expresion_relacional : expresion_relacional T_oMenor expresion_relacional'
	p[0] = Relacion(p[1], p[2], p[3])

def p_expresion_relacional_Mayor(p): #
	'expresion_relacional : expresion_relacional T_oMayor expresion_relacional'
	p[0] = Relacion(p[1], p[2], p[3])
	
def p_expresion_relacional_MenorIgual(p): #
	'expresion_relacional : expresion_relacional T_oMenorIgual expresion_relacional'
	p[0] = Relacion(p[1], p[2], p[3])

def p_expresion_relacional_MayorIgual(p): #
	'expresion_relacional : expresion_relacional T_oMayorIgual expresion_relacional'
	p[0] = Relacion(p[1], p[2], p[3])

########## EXPRESION ADICION ##########
	
def p_expresion_adicion_Mas(p): # 
	'expresion_adicion : expresion_adicion T_oMas expresion_producto'
	p[0] = Adicion(p[1], p[2], p[3])

def p_expresion_adicion_Menos(p): # 
	'expresion_adicion : expresion_adicion T_oMenos expresion_producto'
	p[0] = Adicion(p[1], p[2], p[3])

def p_expresion_adicion_CruzMas(p): # 
	'expresion_adicion : expresion_adicion T_oCruzMas expresion_producto'
	p[0] = Adicion(p[1], p[2], p[3])

def p_expresion_adicion_CruzMenos(p): # 
	'expresion_adicion : expresion_adicion T_oCruzMenos expresion_producto'
	p[0] = Adicion(p[1], p[2], p[3])

def p_expresion_adicion_producto(p): 
	'expresion_adicion : expresion_producto'
	p[0] = p[1]


########## EXPRESION PRODUCTO ##########
	
def p_expresion_producto_Multiplicar(p): # 
	'expresion_producto : expresion_producto T_oMultiplicar expresion_unario'
	p[0] = Producto(p[1], p[2], p[3])

def p_expresion_producto_Dividir(p): # 
	'expresion_producto : expresion_producto T_oDividir expresion_unario'
	p[0] = Producto(p[1], p[2], p[3])

def p_expresion_producto_Resto(p): # 
	'expresion_producto : expresion_producto T_oResto expresion_unario'
	p[0] = Producto(p[1], p[2], p[3])

def p_expresion_producto_DivisionEntera(p): # 
	'expresion_producto : expresion_producto T_oDivisionEntera expresion_unario'
	p[0] = Producto(p[1], p[2], p[3])

def p_expresion_producto_RestoEntero(p): # 
	'expresion_producto : expresion_producto T_oRestoEntero expresion_unario'
	p[0] = Producto(p[1], p[2], p[3])
	
def p_expresion_producto_CruzMultiplicar(p): # 
	'expresion_producto : expresion_producto T_oCruzMultiplicar expresion_unario'
	p[0] = Producto(p[1], p[2], p[3])

def p_expresion_producto_CruzDividir(p): # 
	'expresion_producto : expresion_producto T_oCruzDividir expresion_unario'
	p[0] = Producto(p[1], p[2], p[3])

def p_expresion_producto_CruzResto(p): # 
	'expresion_producto : expresion_producto T_oCruzResto expresion_unario'
	p[0] = Producto(p[1], p[2], p[3])

def p_expresion_producto_CruzDivisionEntera(p): # 
	'expresion_producto : expresion_producto T_oCruzDivisionEntera expresion_unario'
	p[0] = Producto(p[1], p[2], p[3])

def p_expresion_producto_CruzRestoEntero(p): # 
	'expresion_producto : expresion_producto T_oCruzRestoEntero expresion_unario'
	p[0] = Producto(p[1], p[2], p[3])

def p_expresion_producto_unario(p):
	'expresion_producto : expresion_unario'
	p[0] = p[1]


########## EXPRESION UNARIO ##########

def p_expresion_unario_procesado(p):
	'expresion_unario : expresion_procesada'
	p[0] = p[1]

def p_expresion_unario_minus(p):
	'expresion_unario : T_oMenos expresion_adicion %prec uminus'
	p[0] = Unario(p[1], p[2])

def p_expresion_unario_transpuesta(p):
	'expresion_unario : expresion_adicion T_oTranspuesta'
	p[0] = Unario(p[2], p[1])

def p_expresion_unario_op(p): #
	'expresion_unario : T_oNOT expresion_OR'
	p[0] = Unario(p[1], p[2])

########## OPERADOR UNARIO ##########	
'''
def p_operador_unario(p):
	operador_unario : 
					    		
	p[0] = p[1]
'''
########## EXPRESION PROCESADA ##########	

def p_expresion_procesado_primitiva(p):
	'expresion_procesada : expresion_primitiva'
	p[0] = p[1]

def p_expresion_procesado_parentesis(p):
	'expresion_procesada : T_ParentesisI expresion_OR T_ParentesisR'
	p[0] = p[2] 
	
	
########## EXPRESION PRIMITIVA ##########	

def p_expresion_primitiva_identificador(p):
	'expresion_primitiva : T_Identificador'
	p[0] = identificador(p[1])

def p_expresion_primitiva_funcion(p): #
	'expresion_primitiva : T_Identificador T_ParentesisI lista_argumentos T_ParentesisR'
	p[0] = llamadaFuncion(identificador(p[1]), p[3])
	
def p_expresion_primitiva_funcion_sin_argumentos(p):
	'expresion_primitiva : T_Identificador T_ParentesisI T_ParentesisR'
	p[0] = llamadaFuncion(identificador(p[1]),None)

def p_expresion_primitiva_valor(p):
	'expresion_primitiva : valor'
	p[0] = p[1]

########## VALOR ##########
def p_literalNum(p):
	'literalNumerico : T_Number'
	p[0] = Numero(p[1])

def p_literalBool(p):
	'''literalBooleano : T_RTrue
		     		   | T_RFalse'''
	p[0] = Booleano(p[1])

def p_valor(p):
	'''valor : literalNumerico
		     | literalBooleano
		     | literal_matriz
		     | proyeccion_matriz'''
	p[0] = p[1]
	
########## DECLARACION VARIABLE ##########

def p_declaracion_variable(p): #
	'declaracion_variable : tipo T_Identificador T_Puntocoma'
	p[0] = Declaracion_variable(p[1], identificador(p[2]), None)

def p_declaracion_variable_init(p): #
	'declaracion_variable : tipo T_Identificador T_Igual expresion_OR T_Puntocoma'
	p[0] = Declaracion_variable(p[1], identificador(p[2]), p[4])

########## LISTA DECLARACION VARIABLE ##########

def p_lista_declaracion_variable(p):
	'lista_declaracion_variables : declaracion_variable'
	p[0] = p[1]

def p_lista_declaracion_variable_varias(p): #
	'lista_declaracion_variables : lista_declaracion_variables declaracion_variable'
	p[0] = Lista_declaracion_variable(p[1], p[2])

########## INSTRUCCION ##########

def p_instruccion(p):
	'''instruccion : seleccion
		           | impresion
				   | iteracion
		           | lectura
				   | bloque_instrucciones
		           | expresion_asignacion
				   | retorno
				   | expresion_OR T_Puntocoma'''
	p[0] = p[1]
	
########## LISTA INSTRUCCIONES ##########

def p_lista_instrucciones(p):
	'lista_instrucciones : instruccion'
	p[0] = Lista_instruccion(None, p[1])

def p_lista_instrucciones_varias(p): #
	'lista_instrucciones : lista_instrucciones instruccion'
	p[0] = Lista_instruccion(p[1], p[2])

########## BLOQUE INSTRUCCIONES ##########

def p_bloque_instrucciones(p): #
	'bloque_instrucciones : T_RUse lista_declaracion_variables T_RIn lista_instrucciones T_REnd T_Puntocoma'
	p[0] = Bloque_instrucciones(p[2], p[4])

def p_bloque_instruccionesVacioVar(p): #
	'bloque_instrucciones : T_RUse T_RIn lista_instrucciones T_REnd T_Puntocoma'
	p[0] = Bloque_instrucciones(None, p[3])

def p_bloque_instruccionesVacioIns(p): #
	'bloque_instrucciones : T_RUse lista_declaracion_variables T_RIn T_REnd T_Puntocoma'
	p[0] = Bloque_instrucciones(p[2], None)

def p_bloque_instruccionesVacioTodo(p): #
	'bloque_instrucciones : T_RUse T_RIn T_REnd T_Puntocoma'
	p[0] = Bloque_instrucciones(None, None)

########## RETURN ##########

def p_retorno(p):
	'retorno : T_RReturn expresion_OR T_Puntocoma'
	p[0] = Retorna(p[2])

########## BLOQUE SELECCION ##########

def p_bloque_seleccion_nada(p):
	'bloque_seleccion : T_REnd T_Puntocoma'
	p[0] = None
	
def p_bloque_seleccion_simple(p):
	'bloque_seleccion : lista_instrucciones T_REnd T_Puntocoma'
	p[0] = p[1]

def p_bloque_seleccion_else(p): #
	'bloque_seleccion : lista_instrucciones T_RElse lista_instrucciones T_REnd T_Puntocoma'
	p[0] = bloque_seleccion(p[1], p[3])

def p_bloque_seleccion_else_nada(p): #
	'bloque_seleccion : lista_instrucciones T_RElse T_REnd T_Puntocoma'
	p[0] = bloque_seleccion(p[1], None)
	
def p_bloque_seleccion_nada_absolutamente(p):
	'bloque_seleccion :  T_RElse T_REnd T_Puntocoma'
	p[0] = bloque_seleccion(None, None)
	
def p_bloque_seleccion_nada_primero(p):
	'bloque_seleccion : T_RElse lista_instrucciones T_REnd T_Puntocoma'
	p[0] = bloque_seleccion(None, p[2])

########## SELECCION ##########

def p_seleccion(p): #
	'seleccion : T_RIf expresion_OR T_RThen bloque_seleccion'
	p[0] = Seleccion(p[2], p[4])
	
########## BLOQUE ITERACION ##########

def p_bloque_iteracion(p):
	'bloque_iteracion : lista_instrucciones T_REnd T_Puntocoma'
	p[0] = p[1]

def p_bloque_iteracion_nada(p):
	'bloque_iteracion : T_REnd T_Puntocoma'
	p[0] = None
########## ITERACION ##########

def p_iteracion_while(p): #
	'iteracion : T_RWhile expresion_OR T_RDo bloque_iteracion'
	p[0] = Iteracion_While(p[2], p[4])
	
def p_iteracion_for(p): #
	'iteracion : T_RFor T_Identificador T_RIn expresion_adicion T_RDo bloque_iteracion'
	p[0] = Iteracion_For(identificador(p[2]), p[4], p[6])

########## BLOQUE IMPRESION ##########

def p_bloque_impresion_string(p):
	'bloque_impresion : T_String'
		
	p[0] = Bloque_impresion(None, String(p[1]))
	
def p_bloque_impresion_expresion(p):	
	'bloque_impresion : expresion_OR'
	p[0] = Bloque_impresion(None, p[1])

	
def p_bloque_impresion_varios_expresion(p): #
	'bloque_impresion : bloque_impresion T_Coma expresion_OR'
	p[0] = Bloque_impresion(p[1], p[3])
	
def p_bloque_impresion_varios_string(p): #
	'bloque_impresion : bloque_impresion T_Coma T_String'
	p[0] = Bloque_impresion(p[1], String(p[3]))

########## IMPRESION ##########

def p_impresion(p):
	'impresion : T_RPrint bloque_impresion T_Puntocoma'
	p[0] = Impresion(p[2])

########## LISTA ARGUMENTOS ##########

def p_lista_argumentos_simple(p):
	'lista_argumentos : expresion_OR'
	p[0] = Lista_argumentos(None,p[1])
	
def p_lista_argumentos_multiple(p): #
	'lista_argumentos : lista_argumentos T_Coma expresion_OR'
	p[0] = Lista_argumentos(p[1], p[3])

########## LECTURA ##########

def p_lectura(p):
	'lectura : T_RRead T_Identificador T_Puntocoma'
	p[0] = Lectura(identificador(p[2]))
	
########## BLOQUE FUNCION ##########

def p_bloque_funcion(p): 
	'bloque_funcion : T_RBegin lista_instrucciones T_REnd T_Puntocoma'
	p[0] = p[2]
	
def p_bloque_funcion_nada(p): 
	'bloque_funcion : T_RBegin T_REnd T_Puntocoma'
	p[0] = None	
########## PARAMETRO ##########

def p_parametro(p): #
	'parametro : tipo T_Identificador'
	p[0] = Parametro(p[1], identificador(p[2]))
	
########## LISTA PARAMETRO ##########

def p_lista_parametro_simple(p): 
	'lista_parametros : parametro'
	p[0] = lista_parametros(None,p[1])

def p_lista_parametro_multiple(p): #
	'lista_parametros : lista_parametros T_Coma parametro'
	p[0] = lista_parametros(p[1], p[3])

########## DECLARACION FUNCION ##########

def p_declaracion_funcion(p): # 
	'declaracion_funcion : T_RFunction T_Identificador T_ParentesisI lista_parametros T_ParentesisR T_RReturn tipo bloque_funcion'
	p[0] = Declaracion_funcion(identificador(p[2]), p[4], p[7], p[8])

def p_declaracion_funcion_sin_paramtros(p): #
	'declaracion_funcion : T_RFunction T_Identificador T_ParentesisI T_ParentesisR T_RReturn tipo bloque_funcion'
	p[0] = Declaracion_funcion(identificador(p[2]), None, p[6], p[7])

########## LISTA FUNCIONES ##########

def p_lista_funciones_simple(p):
	'lista_funciones : declaracion_funcion'
	p[0] = lista_funciones(None,p[1])

def p_lista_funciones_multiple(p): #
	'lista_funciones : lista_funciones declaracion_funcion'
	p[0] = lista_funciones(p[1], p[2])
	
########## ERROR ##########

def p_error(p):
	if not (p):
		print "Error de sintaxis: se alcanzo el final del archivo inesperadamente"
		sys.exit(1)
	else:
		print "Error de sintaxis:",p.value,". Linea:",p.lineno,"Columna:",p.col
		sys.exit(1)


########## PARSER ##########
class Lexer:
	def __init__(self,lista):
		self.lista=lista
	def token(self):
		if self.lista:
			return self.lista.pop(0)
		
precedence = (         
        ('left', 'T_oOR'),
        ('left', 'T_oAND'),
        ('nonassoc', 'T_oIgual', 'T_oDiferente','T_oMayor','T_oMenor','T_oMayorIgual','T_oMenorIgual'),
        ('right', 'T_oNOT'),
        ('left','T_oMas','T_oMenos','T_oCruzMas','T_oCruzMenos'),
        ('left','T_oMultiplicar','T_oDividir','T_oResto','T_oDivisionEntera','T_oRestoEntero','T_oCruzDividir','T_oCruzDivisionEntera','T_oCruzResto','T_oCruzMultiplicar','T_oCruzRestoEntero'),
		('right', 'uminus'),
        ('left','proyeccion','T_oTranspuesta'),

    )
	
def parsear(archivo):
	lista_token = obtenerListaToken(archivo)
	if (lista_token):
		if not 'T_Error' in lista_token:
			#print lista_token			
			parser = yacc.yacc()
			#result = parser.parse(debug=True,lexer= Lexer(lista_token))
			result = parser.parse(lexer= Lexer(lista_token))
			#tb = ''
			if result:
			#	result.imprimir(tb)
				checkear(result)
		else:
			sys.exit(1)		
	else:
		print 'No hay tokens, el archivo esta vacio'
		sys.exit(1)

def checkear(arbol):
	tf = TablaF()
	arbol.checkFunc(tf)
	ts = Tabla(tf)
	arbol.check(ts)
	arbol.ejecutar(ts)
	sys.exit(0)
