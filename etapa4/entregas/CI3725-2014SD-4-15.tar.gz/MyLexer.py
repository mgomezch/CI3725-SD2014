#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
    Proyecto 1
    Trinity: Modulo con las funciones y clases necesarias para el LEXER.

    Autores:    10-10088 Stefany Botero
                09-10329 Gabriela Gimenez

    Fecha: 26/09/2014
"""

# Notas:
#   - Archivo elaborado en Linux
#   - No hay un MakeFile, el archivo se corre como: ./trinity ejemplo.ty
#   - Trinity termina con 0 si encontro todos los lexemas en el archivos,
#       o con 1 si encontro errores (./trinity ejemplo.ty; echo $?)
#   - En el pdf con la informacion del proyecto 1 no se especifica de cuanto
#       es la longitud de un tab (es decir, cuantos espacios es equivalente)
#       nosotras lo tomamos predeterminado como 4. (1 Tab = 4 spaces)


# LIBRERIAS

import re                       # Libreria para expresiones regulares
import sys                      # Libreria para lectura de argumentos
import lex                      # Libreria para el lexer
import yacc                     # Libreria para el parser




################################### LEXER #########################################


#CLASE PADRE

#Token: Clase que definira cada tipo de lexema del lenguaje Trinity
class Token:

    def __init__(self, line, col, code):
        self.lineno = line      # Numero de la fila donde se encuentra
        self.col    = col       # Numero de la columna donde comienza
        self.value  = code      # Palabra o simbolo leido
        self.type   = self.__class__.__name__    # Nombre de la clase
        self.lexpos = None


#CLASES HIJAS

# Palabras Reservadas

# Token PROGRAM: Palabra reservada "program"
class TkProgram(Token): 
    reg = r"program\b"       

# Token USE: Palabra reservada "use"
class TkUse(Token):    
    reg = r"use\b"

# Token IN: Palabra reservada "in"
class TkIn(Token):   
    reg = r"in\b"     

# Token END: Palabra reservada "end"
class TkEnd(Token):  
    reg = r"end\b" 
    
# Token Boolean: Palabra reservada "boolean"
class TkBoolean(Token):     
    reg = r"boolean\b"   

# Token NUMBER: Palabra reservada "number"
class TkNumber(Token):   
    reg = r"number\b"         
        
# Token IF: Palabra reservada "if"
class TkIf(Token): 
    reg = r"if\b"

# Token THEN: Palabra reservada "then"
class TkThen(Token):  
    reg = r"then\b"

# Token ELSE: Palabra reservada "else"
class TkElse(Token):    
    reg = r"else\b"

# Token FOR: Palabra reservada "for"
class TkFor(Token):      
    reg = r"for\b"

# Token DO: Palabra reservada "do"
class TkDo(Token):     
    reg = r"do\b"   

# Token WHILE: Palabra reservada "while"
class TkWhile(Token):   
    reg = r"while\b"
        
# Token FUNCTION: Palabra reservada "function"
class TkFunction(Token):  
    reg    = r"function\b"

# Token RETURN: Palabra reservada "return"
class TkReturn(Token):   
    reg    = r"return\b"

# Token BEGIN: Palabra reservada "begin"
class TkBegin(Token):  
    reg    = r"begin\b"

# Token PRINT: Palabra reservada "print"
class TkPrint(Token):    
    reg    = r"print\b" 
        
# Token READ: Palabra reservada "read"
class TkRead(Token):  
    reg    = r"read\b" 

# Token TRUE: Palabra reservada "true"
class TkTrue(Token):  
    reg    = r"true\b"
        
# Token FALSE: Palabra reservada "false"
class TkFalse(Token):        
    reg    = r"false\b" 
        
# Token NOT: Palabra reservada "not"
class TkNot(Token):          
    reg    = r"not\b" 

# Token ROW: Palabra reservada "row"
class TkRow(Token):          
    reg    = r"row\b"
        
# Token COL: Palabra reservada "col"
class TkCol(Token):          
    reg    = r"col\b"

# Token MATRIX: Palabra reservada "matrix"
class TkMatrix(Token):        
    reg    = r"matrix\b"         

# Token SET: Palabra reservada "set"
class TkSet(Token):          
    reg    = r"set\b" 
        
# Token DIV: Palabra reservada "div"
class TkDiv(Token):          
    reg    = r"div\b"
                      
# Token MOD: Palabra reservada "mod"
class TkMod(Token):        
    reg    = r"mod\b" 


# Simbolos Reservados

# Token NUMERAL: Simbolo que representa #
class TkNumeral(Token):          
    reg    = r"#.*"

# Token PUNTO Y COMA: Simbolo que representa ;
class TkPuntoYComa(Token):   
    reg    = r";"      

# Token COMA: Simbolo que representa ,
class TkComa(Token):  
    reg    = r","      

# Token STRING: Representacion de un String
class TkComillas(Token):
    reg    = r"\"((\\\"|\\\\|\\n|[^\"\\])*([^(\\|\n|\")]|\\\"|\\\\|\\n)*)\""

# Token DOS PUNTOS: Simbolo que representa :
class TkDosPuntos(Token): 
    reg    = r":"

# Token ABRE LLAVES: Simbolo que representa {
class TkALlaves(Token):         
    reg    = r"\{"   

# Token CIERRA LLAVES: Simbolo que representa }
class TkCLlaves(Token):   
    reg    = r"\}" 
      
# Token ABRE PARENTESIS: Simbolo que representa (
class TkAParentesis(Token):            
    reg    = r"\("       

# Token CIERRA PARENTESIS: Simbolo que representa )
class TkCParentesis(Token):    
    reg    = r"\)"
        
# Token ABRE CORCHETES: Simbolo que representa [
class TkACorchetes(Token):   
    reg    = r"\["
        
# Token CIERRA CORCHETES: Simbolo que representa ]
class TkCCorchetes(Token):   
    reg    = r"\]"
        
# Token OPERADOR CRUZADO +: Simbolo que representa .+.
class TkOCSuma(Token):   
    reg    = r"\.\+\."
        
# Token OPERADOR CRUZADO -: Simbolo que representa .-.
class TkOCResta(Token):   
    reg    = r"\.-\."
        
# Token OPERADOR CRUZADO *: Simbolo que representa .*.
class TkOCMult(Token):   
    reg    = r"\.\*\."
        
# Token OPERADOR CRUZADO /: Simbolo que representa ./.
class TkOCDivisionE(Token):  
    reg    = r"\./\."      
        
# Token OPERADOR CRUZADO %: Simbolo que representa .%.
class TkOCRestoE(Token):      
    reg    = r"\.%\."    
        
# Token OPERADOR CRUZADO div: Simbolo que representa .div.
class TkOCDiv(Token):   
    reg    = r"\.div\."     
        
# Token OPERADOR CRUZADO mod: Simbolo que representa .mod.
class TkOCMod(Token):   
    reg    = r"\.mod\."           

# Token CONJUNCION: Simbolo que representa &
class TkConjuncion(Token): 
    reg    = r"&"
        
# Token DISYUNCION: Simbolo que representa |
class TkDisyuncion(Token):   
    reg    = r"\|"

# Token SUMA: Simbolo que representa +
class TkSuma(Token):     
    reg    = r"\+"

# Token RESTA: Simbolo que representa -
class TkResta(Token):     
    reg    = r"-"     

# Token MULTIPLICACION: Simbolo que representa *
class TkMult(Token):  
    reg    = r"\*"  
        
# Token RESTO EXACTO: Simbolo que representa %
class TkRestoE(Token):     
    reg    = r"%"
        
# Token EQUIVALENCIA: Simbolo que representa ==
class TkEquivalencia(Token):  
    reg    = r"=="  
        
# Token INEQUIVALENCIA: Simbolo que representa /=
class TkInequivalencia(Token):   
    reg    = r"/="     
        
# Token CONJUNCION: Simbolo que representa &
class TkConjuncion(Token): 
    reg    = r"&"
        
# Token MENOR IGUAL: Simbolo que representa <=
class TkMenorIgual(Token):  
    reg    = r"<="      

# Token MAYOR IGUAL: Simbolo que representa >=
class TkMayorIgual(Token):   
    reg    = r">="     
        
# Token ASIGNACION: Simbolo que representa =
class TkAsignacion(Token):      
    reg    = r"="   
        
# Token DIVISION EXACTA: Simbolo que representa /
class TkDivisionE(Token):        
    reg    = r"/" 
        
# Token MENOR: Simbolo que representa <
class TkMenor(Token):    
    reg    = r"<"    
        
# Token MAYOR: Simbolo que representa >
class TkMayor(Token):   
    reg    = r">" 
        
# Token COMILLA SIMPLE: Simbolo que representa '
class TkComillaSimple(Token):   
    reg    = r"'"  



# Identificadores y numeros

# Token NUMEROS: Representacion de los numeros 
class TkNumeros(Token):    
    reg    = r"[0-9]+\.[0-9]+|[0-9]+"    

# Token IDENTIFICADOR: Palabra que corresponde con un identificador
class TkIdentificador(Token):   
    reg    = r"[a-zA-Z][_a-zA-Z0-9]*"      
		


# FUNCIONES


# FUNCION LECTURA:  Se encarga de la lectura del archivo y devolver toda la 
#                   informacion de ese archivo en un string

def LecturaArchivo(Entrada):

    # Si encuentra el archivo a leer
    try:
        Fichero = open(Entrada,"r")
        Programa = Fichero.read()
        Fichero.close()

        return Programa

    # Si no encuentra el archivo a leer
    except IOError:
        print(" ")
        print("> Archivo de lectura no encontrado.")
        print(" ")
        exit(1)
	

# MAIN

lectura = sys.argv[1]

# Se lee el nombre del archivo introducido y se lee la informacion

Programa = LecturaArchivo(lectura)

# Lista con todos los elementos leidos y su posicion original (fila, columna)
ListaPalabras = []
ListaParser = []

# ListaPalabras va a contener informacion sobre lo leido:
#   Posicion 0: Puede tomar valores de "v" o "i" (valido o invalido)
#   Posicion 1: Contenido textual de lo leido
#   Posicion 2: Fila de donde se encuentra lo que se leyo
#   Posicion 3: Columna donde comienza lo que se leyo
#   Posicion 4: Puede tomar valores de "n", "i", "s", "none", "l" o "e" 
#               (numero, identificador, string, no es lexema, lexema, espacio/tab/enter)



# Ciclo que va comparando con las expresiones regulares y guardando cada
# elemento leido en la lista

TamPrograma = len(Programa)             # Longitud del string del "Programa"
f = 1                                   # Numero de la fila
c = 1                                   # Numero de la columna

while (TamPrograma != 0):

    Lexema = True                       # Variable para ver si es lexema

    # Verificacion ESPACIO
    if (ord(Programa[0]) == 32):
        ListaPalabras.append(["v","_Espacio_",f,c,"e"])
        Programa = Programa[1:]
        c = (c+1)

    # Verificacion ENTER   
    elif (ord(Programa[0]) == 10):
        ListaPalabras.append(["v","_Enter_",f,c,"e"])
        Programa = Programa[1:]
        f = (f+1)
        c = 1

    # Verificacion TAB
    elif (ord(Programa[0]) == 9):
        ListaPalabras.append(["v","_Tab_",f,c,"e"])
        c = (c+4)
        Programa = Programa[1:]

    else:

        i = f
        j = c


        # Verificacion PROGRAM
        if (re.match(TkProgram.reg,Programa)):
            HaceMatch = re.match(TkProgram.reg,Programa)
            c = (c+7)
            Ins = TkProgram(i,j,HaceMatch.group(0))

        # Verificacion USE
        elif (re.match(TkUse.reg,Programa)):
            HaceMatch = re.match(TkUse.reg,Programa)
            c = (c+3)
            Ins = TkUse(i,j,HaceMatch.group(0))

        # Verificacion IN
        elif (re.match(TkIn.reg,Programa)):
            HaceMatch = re.match(TkIn.reg,Programa)
            c = (c+2)
            Ins = TkIn(i,j,HaceMatch.group(0))

        # Verificacion END
        elif (re.match(TkEnd.reg,Programa)):
            HaceMatch = re.match(TkEnd.reg,Programa)
            c = (c+3)
            Ins = TkEnd(i,j,HaceMatch.group(0))

        # Verificacion BOOLEAN
        elif (re.match(TkBoolean.reg,Programa)):
            HaceMatch = re.match(TkBoolean.reg,Programa)
            c = (c+7)
            Ins = TkBoolean(i,j,HaceMatch.group(0))
            
        # Verificacion NUMBER
        elif (re.match(TkNumber.reg,Programa)):
            HaceMatch = re.match(TkNumber.reg,Programa)
            c = (c+6)
            Ins = TkNumber(i,j,HaceMatch.group(0))
            
        # Verificacion IF
        elif (re.match(TkIf.reg,Programa)):
            HaceMatch = re.match(TkIf.reg,Programa)
            c = (c+2)
            Ins = TkIf(i,j,HaceMatch.group(0))

        # Verificacion THEN
        elif (re.match(TkThen.reg,Programa)):
            HaceMatch = re.match(TkThen.reg,Programa)
            c = (c+4)
            Ins = TkThen(i,j,HaceMatch.group(0))

        # Verificacion ELSE
        elif (re.match(TkElse.reg,Programa)):
            HaceMatch = re.match(TkElse.reg,Programa)
            c = (c+4)
            Ins = TkElse(i,j,HaceMatch.group(0))

        # Verificacion FOR
        elif (re.match(TkFor.reg,Programa)):
            HaceMatch = re.match(TkFor.reg,Programa)
            c = (c+3)
            Ins = TkFor(i,j,HaceMatch.group(0))
            

        # Verificacion DO
        elif (re.match(TkDo.reg,Programa)):
            HaceMatch = re.match(TkDo.reg,Programa)
            c = (c+2)
            Ins = TkDo(i,j,HaceMatch.group(0))

        # Verificacion WHILE
        elif (re.match(TkWhile.reg,Programa)):
            HaceMatch = re.match(TkWhile.reg,Programa)
            c = (c+5)
            Ins = TkWhile(i,j,HaceMatch.group(0))

        # Verificacion FUNCTION
        elif (re.match(TkFunction.reg,Programa)):
            HaceMatch = re.match(TkFunction.reg,Programa)
            c = (c+8)
            Ins = TkFunction(i,j,HaceMatch.group(0))

        # Verificacion RETURN
        elif (re.match(TkReturn.reg,Programa)):
            HaceMatch = re.match(TkReturn.reg,Programa)
            c = (c+6)
            Ins = TkReturn(i,j,HaceMatch.group(0))

        # Verificacion BEGIN
        elif (re.match(TkBegin.reg,Programa)):
            HaceMatch = re.match(TkBegin.reg,Programa)
            c = (c+5)
            Ins = TkBegin(i,j,HaceMatch.group(0))

        # Verificacion PRINT
        elif (re.match(TkPrint.reg,Programa)):
            HaceMatch = re.match(TkPrint.reg,Programa)
            c = (c+5)
            Ins = TkPrint(i,j,HaceMatch.group(0))

        # Verificacion READ
        elif (re.match(TkRead.reg,Programa)):
            HaceMatch = re.match(TkRead.reg,Programa)
            c = (c+4)
            Ins = TkRead(i,j,HaceMatch.group(0))

        # Verificacion TRUE
        elif (re.match(TkTrue.reg,Programa)):
            HaceMatch = re.match(TkTrue.reg,Programa)
            c = (c+4)
            Ins = TkTrue(i,j,HaceMatch.group(0))

        # Verificacion FALSE
        elif (re.match(TkFalse.reg,Programa)):
            HaceMatch = re.match(TkFalse.reg,Programa)
            c = (c+5)
            Ins = TkFalse(i,j,HaceMatch.group(0))

        # Verificacion NOT
        elif (re.match(TkNot.reg,Programa)):
            HaceMatch = re.match(TkNot.reg,Programa)
            c = (c+3)
            Ins = TkNot(i,j,HaceMatch.group(0))

        # Verificacion ROW
        elif (re.match(TkRow.reg,Programa)):
            HaceMatch = re.match(TkRow.reg,Programa)
            c = (c+3)
            Ins = TkRow(i,j,HaceMatch.group(0))

        # Verificacion COL
        elif (re.match(TkCol.reg,Programa)):
            HaceMatch = re.match(TkCol.reg,Programa)
            c = (c+3)
            Ins = TkCol(i,j,HaceMatch.group(0))

        # Verificacion MATRIX
        elif (re.match(TkMatrix.reg,Programa)):
            HaceMatch = re.match(TkMatrix.reg,Programa)
            c = (c+6)
            Ins = TkMatrix(i,j,HaceMatch.group(0))

        # Verificacion SET
        elif (re.match(TkSet.reg,Programa)):
            HaceMatch = re.match(TkSet.reg,Programa)
            c = (c+3)
            Ins = TkSet(i,j,HaceMatch.group(0))

        # Verificacion DIV
        elif (re.match(TkDiv.reg,Programa)):
            HaceMatch = re.match(TkDiv.reg,Programa)
            c = (c+3)
            Ins = TkDiv(i,j,HaceMatch.group(0))

        # Verificacion MOD
        elif (re.match(TkMod.reg,Programa)):
            HaceMatch = re.match(TkMod.reg,Programa)
            c = (c+3)
            Ins = TkMod(i,j,HaceMatch.group(0))

        # Verificacion #
        elif (re.match(TkNumeral.reg,Programa)):
            HaceMatch = re.match(TkNumeral.reg,Programa)
            TamMatch = HaceMatch.span()[1]
            c = (c+TamMatch)  
            Ins = TkNumeral(i,j,HaceMatch.group(0))
            Lexema = False
            Ins = TkNumeros(i,j,HaceMatch.group(0))
            ListaPalabras.append(["v",Ins.value,Ins.lineno,Ins.col,"n"])
            Programa = Programa.lstrip(HaceMatch.group(0))                                            

        # Verificacion ;
        elif (re.match(TkPuntoYComa.reg,Programa)):
            HaceMatch = re.match(TkPuntoYComa.reg,Programa)
            c = (c+1)
            Ins = TkPuntoYComa(i,j,HaceMatch.group(0))

        # Verificacion ,
        elif (re.match(TkComa.reg,Programa)):
            HaceMatch = re.match(TkComa.reg,Programa)
            c = (c+1)
            Ins = TkComa(i,j,HaceMatch.group(0))

        # Verificacion String
        elif (re.match(TkComillas.reg,Programa)):
            HaceMatch = re.match(TkComillas.reg,Programa)
            TamMatch = HaceMatch.span()[1]
            c = (c+TamMatch)
            Lexema = False
            Ins = TkComillas(i,j,HaceMatch.group(0))
            ListaPalabras.append(["v",Ins.value,Ins.lineno,Ins.col,"s"])
            ListaParser.append(Ins)
            quitar = len(Ins.value)
            Programa = Programa[quitar:]

        # Verificacion :
        elif (re.match(TkDosPuntos.reg,Programa)):
            HaceMatch = re.match(TkDosPuntos.reg,Programa)
            c = (c+1) 
            Ins = TkDosPuntos(i,j,HaceMatch.group(0))

        # Verificacion {
        elif (re.match(TkALlaves.reg,Programa)):
            HaceMatch = re.match(TkALlaves.reg,Programa)
            c = (c+1)  
            Ins = TkALlaves(i,j,HaceMatch.group(0))

        # Verificacion }
        elif (re.match(TkCLlaves.reg,Programa)):
            HaceMatch = re.match(TkCLlaves.reg,Programa)
            c = (c+1)
            Ins = TkCLlaves(i,j,HaceMatch.group(0))

        # Verificacion (
        elif (re.match(TkAParentesis.reg,Programa)):
            HaceMatch = re.match(TkAParentesis.reg,Programa)
            c = (c+1) 
            Ins = TkAParentesis(i,j,HaceMatch.group(0))

        # Verificacion )
        elif (re.match(TkCParentesis.reg,Programa)):
            HaceMatch = re.match(TkCParentesis.reg,Programa)
            c = (c+1) 
            Ins = TkCParentesis(i,j,HaceMatch.group(0))

        # Verificacion [
        elif (re.match(TkACorchetes.reg,Programa)):
            HaceMatch = re.match(TkACorchetes.reg,Programa)
            c = (c+1) 
            Ins = TkACorchetes(i,j,HaceMatch.group(0))

        # Verificacion ]
        elif (re.match(TkCCorchetes.reg,Programa)):
            HaceMatch = re.match(TkCCorchetes.reg,Programa)
            c = (c+1)
            Ins = TkCCorchetes(i,j,HaceMatch.group(0))

        # Verificacion .+.
        elif (re.match(TkOCSuma.reg,Programa)):
            HaceMatch = re.match(TkOCSuma.reg,Programa)
            c = (c+3)
            Ins = TkOCSuma(i,j,HaceMatch.group(0))

        # Verificacion .-.
        elif (re.match(TkOCResta.reg,Programa)):
            HaceMatch = re.match(TkOCResta.reg,Programa)
            c = (c+3)
            Ins = TkOCResta(i,j,HaceMatch.group(0))

        # Verificacion .*.
        elif (re.match(TkOCMult.reg,Programa)):
            HaceMatch = re.match(TkOCMult.reg,Programa)
            c = (c+3) 
            Ins = TkOCMult(i,j,HaceMatch.group(0))

        # Verificacion ./.
        elif (re.match(TkOCDivisionE.reg,Programa)):
            HaceMatch = re.match(TkOCDivisionE.reg,Programa)
            c = (c+3) 
            Ins = TkOCDivisionE(i,j,HaceMatch.group(0))

        # Verificacion .%.
        elif (re.match(TkOCRestoE.reg,Programa)):
            HaceMatch = re.match(TkOCRestoE.reg,Programa)
            c = (c+3)
            Ins = TkOCRestoE(i,j,HaceMatch.group(0))

        # Verificacion .div.
        elif (re.match(TkOCDiv.reg,Programa)):
            HaceMatch = re.match(TkOCDiv.reg,Programa)
            c = (c+5)
            Ins = TkOCDiv(i,j,HaceMatch.group(0))

        # Verificacion .mod.
        elif (re.match(TkOCMod.reg,Programa)):
            HaceMatch = re.match(TkOCMod.reg,Programa)
            c = (c+5)
            Ins = TkOCMod(i,j,HaceMatch.group(0))

        # Verificacion &
        elif (re.match(TkConjuncion.reg,Programa)):
            HaceMatch = re.match(TkConjuncion.reg,Programa)
            c = (c+1)
            Ins = TkConjuncion(i,j,HaceMatch.group(0))

        # Verificacion |
        elif (re.match(TkDisyuncion.reg,Programa)):
            HaceMatch = re.match(TkDisyuncion.reg,Programa)
            c = (c+1)
            Ins = TkDisyuncion(i,j,HaceMatch.group(0))

        # Verificacion +
        elif (re.match(TkSuma.reg,Programa)):
            HaceMatch = re.match(TkSuma.reg,Programa)
            c = (c+1)
            Ins = TkSuma(i,j,HaceMatch.group(0))

        # Verificacion -
        elif (re.match(TkResta.reg,Programa)):
            HaceMatch = re.match(TkResta.reg,Programa)
            c = (c+1)
            Ins = TkResta(i,j,HaceMatch.group(0))

        # Verificacion *
        elif (re.match(TkMult.reg,Programa)):
            HaceMatch = re.match(TkMult.reg,Programa)
            c = (c+1)
            Ins = TkMult(i,j,HaceMatch.group(0))

        # Verificacion %
        elif (re.match(TkRestoE.reg,Programa)):
            HaceMatch = re.match(TkRestoE.reg,Programa)
            c = (c+1)
            Ins = TkRestoE(i,j,HaceMatch.group(0))

        # Verificacion ==
        elif (re.match(TkEquivalencia.reg,Programa)):
            HaceMatch = re.match(TkEquivalencia.reg,Programa)
            c = (c+2)
            Ins = TkEquivalencia(i,j,HaceMatch.group(0))

        # Verificacion /=
        elif (re.match(TkInequivalencia.reg,Programa)):
            HaceMatch = re.match(TkInequivalencia.reg,Programa)
            c = (c+2)
            Ins = TkInequivalencia(i,j,HaceMatch.group(0))

        # Verificacion <=
        elif (re.match(TkMenorIgual.reg,Programa)):
            HaceMatch = re.match(TkMenorIgual.reg,Programa)
            c = (c+2)
            Ins = TkMenorIgual(i,j,HaceMatch.group(0))

        # Verificacion >=
        elif (re.match(TkMayorIgual.reg,Programa)):
            HaceMatch = re.match(TkMayorIgual.reg,Programa)
            c = (c+2)
            Ins = TkMayorIgual(i,j,HaceMatch.group(0))

        # Verificacion =
        elif (re.match(TkAsignacion.reg,Programa)):
            HaceMatch = re.match(TkAsignacion.reg,Programa)
            c = (c+1)
            Ins = TkAsignacion(i,j,HaceMatch.group(0))

        # Verificacion /
        elif (re.match(TkDivisionE.reg,Programa)):
            HaceMatch = re.match(TkDivisionE.reg,Programa)
            c = (c+1)
            Ins = TkDivisionE(i,j,HaceMatch.group(0))

        # Verificacion <
        elif (re.match(TkMenor.reg,Programa)):
            HaceMatch = re.match(TkMenor.reg,Programa)
            c = (c+1)
            Ins = TkMenor(i,j,HaceMatch.group(0))

        # Verificacion >
        elif (re.match(TkMayor.reg,Programa)):
            HaceMatch = re.match(TkMayor.reg,Programa)
            c = (c+1)
            Ins = TkMayor(i,j,HaceMatch.group(0))

        # Verificacion '
        elif (re.match(TkComillaSimple.reg,Programa)):
            HaceMatch = re.match(TkComillaSimple.reg,Programa)
            c = (c+1)
            Ins = TkComillaSimple(i,j,HaceMatch.group(0))

        # Verificacion NUMEROS
        elif (re.match(TkNumeros.reg,Programa)):
            HaceMatch = re.match(TkNumeros.reg,Programa)
            TamMatch = HaceMatch.span()[1]
            c = (c+TamMatch)
            Lexema = False
            Ins = TkNumeros(i,j,HaceMatch.group(0))
            ListaPalabras.append(["v",Ins.value,Ins.lineno,Ins.col,"n"])
            ListaParser.append(Ins)
            Programa = Programa.lstrip(HaceMatch.group(0))

        # Verificacion IDENTIFICADORES
        elif (re.match(TkIdentificador.reg,Programa)):
            HaceMatch = re.match(TkIdentificador.reg,Programa)
            TamMatch = HaceMatch.span()[1]
            c = (c+TamMatch)
            Lexema = False
            Ins = TkIdentificador(i,j,HaceMatch.group(0))
            ListaPalabras.append(["v",Ins.value,Ins.lineno,Ins.col,"i"])
            ListaParser.append(Ins)
            Programa = Programa.lstrip(HaceMatch.group(0))

        # NO ES LEXEMA DE TRINITY    
        else:
            Lexema = False
            CharInvalido = Programa[0]

            # Se agrega la caracter invalido a la lista
            ListaPalabras.append(["i",CharInvalido,f,c,"none"])
            Programa = Programa[1:]
            c = (c+1)


        # Se agrega el Lexema a la lista cuando no es ni numero ni identificador
        if Lexema:

            ListaPalabras.append(["v",Ins.value,Ins.lineno,Ins.col,"l"])
            ListaParser.append(Ins)
            
            if len(HaceMatch.group(0)) > 1:
                Programa = Programa.lstrip(HaceMatch.group(0))
            else:
                Programa = Programa[1:]
                         

    TamPrograma = len(Programa)


# Impresion de los resultados obtenidos

Aux = ListaPalabras                         # Lista con los elementos
Error = 0                                   # Variable si existen errores             
for i in Aux:
    Verif = i[0]

    # Si el lexema es valido
    if (Verif == "v"):
        Blank = i[1]

        # Se ignoran los espacios en blanco, enter y tabs
        if not ((Blank == "_Espacio_")|(Blank == "_Enter_")|(Blank == "_Tab_")):
            Comment = Blank[0]

            # Si es un comentario en el programa
            if (Comment == "#"):
                pass

            # Si es un lexema
            else:
                TipoLex = i[4]

                # Si es un numero
                if (TipoLex == "n"):
                    pass

                # Si es un identificador
                elif (TipoLex == "i"):
                    pass

                # Si es un string
                elif (TipoLex == "s"):
                   pass

                # Si es un lexema (simbolo o palabra reservada)
                else: 
                   pass

    # Si el lexema es invalido, es decir, hay un error
    else:
        Error = 1
        
        print " "
        print "Error LEXER "
        print "> Lexema invalido:  ", i[1]
        print "    Fila:           ", i[2]
        print "    Columna:        ", i[3]
        print " "

# Si todos los lexemas son correctos
if (Error == 0):
    pass
    
# Si hay al menos un error (lexema no encontrado)
else:
    exit(1)

