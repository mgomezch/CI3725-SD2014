################################################################################
#                            DECLARACION DE VARIABLE                           #
#                            <tipo> <identificador>                            #
#                     <tipo> <identificador> = <expresion>                     #
################################################################################

import sys
import Literal_Numerico
import Booleano
import Matriz
import Matrix
import Identificador
import Llamada_Funcion
import Expresion_Binaria
from Program_End import *

class Declaracion_Variable:

	def __init__(self,tipo,identificador,expresion=None):		
		self.tipo = tipo
		self.identificador = identificador		
		self.expresion = expresion

	def imprimir(self,espacio,tablaSimb):
		msg = "" + self.identificador.chequear(tablaSimb)
		if (isinstance(self.tipo,int) or isinstance(self.tipo,str)):
			print espacio, msg, ": ", self.tipo
		else:
			print espacio, msg, ": ", self.tipo.type

	def chequear(self, tablaSimb):
		nombreVariable = self.identificador.chequear(tablaSimb)
		tipoVariable = self.tipo
		arregloVariable = tipoVariable		

		if tipoVariable <> "number" and tipoVariable <> "boolean":			
			tipoVariable = self.tipo.type
			arregloVariable = [self.tipo.type]
			self.tipo.chequear(tablaSimb)

		if (tablaSimb.diccionario.has_key(nombreVariable) == True):			
			e = "ERROR-DEC: La variable \'%s\' ya esta declarada."
			print e % nombreVariable
			sys.exit(1)
		else:
			if tipoVariable <> "number" and tipoVariable <> "boolean":

				if not(isinstance(self.tipo.r, int)):
					num_r = int(self.tipo.r.valor)
					if (isinstance(self.tipo.c, int)): 
						num_c = self.tipo.c
				if not(isinstance(self.tipo.c, int)):
					num_c = int(self.tipo.c.valor)
					if isinstance(self.tipo.r, int):
						num_r = self.tipo.r

				arregloVariable.append(int(num_r))
				arregloVariable.append(int(num_c))

				tablaSimb.insertarElem(nombreVariable,arregloVariable)
			else:
				tablaSimb.insertarElem(nombreVariable,arregloVariable)

		if (self.expresion <> None):
			fun_param_tipo = tipoVariable
			nombreVar = self.expresion.chequear(tablaSimb)
			if self.expresion.type == "exp_bin" or self.expresion.type == "llamada_func":				
				if nombreVar <> "number" and nombreVar <> "boolean":
					nombreVar = self.expresion.chequear(tablaSimb)[0]

			if (tablaSimb.diccionario.has_key(nombreVar) == True):
				tipoVar = tablaSimb.diccionario[nombreVar]

				tipoExp = fun_param_tipo	

				if tipoVar <> "number" and tipoVar <> "boolean":
					tipoVar = tablaSimb.diccionario[nombreVar][0]
					fila = tablaSimb.diccionario[nombreVar][1]
					columna = tablaSimb.diccionario[nombreVar][2]
					
					if not(isinstance(self.tipo.r, int)):
						num_r = int(self.tipo.r.valor)
						if (isinstance(self.tipo.c, int)): 
							num_c = self.tipo.c
					if not(isinstance(self.tipo.c, int)):
						num_c = int(self.tipo.c.valor)
						if isinstance(self.tipo.r, int):
							num_r = self.tipo.r

					if fila <> num_r or columna <> num_c:	
						e = "ERROR-DEC: La matriz \'%s\' no tiene las dimensiones correctas." 
						print e % nombreVariable
					 	sys.exit(1)
					
				if (tipoExp <> tipoVar):
					e = "ERROR-DEC: La expresion tiene el" 
					e += " tipo \'%s\' y se " % tipoVar
					e += "esperaba el tipo \'%s\'."	
					print e % tipoExp
					sys.exit(1)

			#En caso de que tengaque revisar recursivamente las tablas padre
			else:
				tablaPadre = tablaSimb.padre
				verifica = True

				while (tablaPadre <> None) and verifica:

					#Guardia que revisa si la variable se encuantra en la tabla actual
					if (tablaPadre.diccionario.has_key(nombreVar) == True):
						tipoVar = tablaPadre.diccionario[nombreVar]

						tipoExp = fun_param_tipo

						if tipoVar <> "number" and tipoVar <> "boolean":
							tipoVar = tablaPadre.diccionario[nombreVar][0]
							fila = tablaPadre.diccionario[nombreVar][1]
							columna = tablaPadre.diccionario[nombreVar][2]
							
							if not(isinstance(self.tipo.r, int)):
								num_r = int(self.tipo.r.valor)
								if (isinstance(self.tipo.c, int)): 
									num_c = self.tipo.c
							if not(isinstance(self.tipo.c, int)):
								num_c = int(self.tipo.c.valor)
								if isinstance(self.tipo.r, int):
									num_r = self.tipo.r

							if fila <> num_r or columna <> num_c:
								e = "ERROR-DEC: La matriz \'%s\' no tiene las dimensiones correctas." 
								print e % nombreVar
							 	sys.exit(1)
							
						if (tipoExp <> tipoVar):		
							e = "ERROR-DEC: La expresion tiene el" 
							e += " tipo \'%s\' y se " % tipoVar
							e += "esperaba el tipo \'%s\'."	
							print e % tipoExp
							sys.exit(1) 
							print e % tipoExp
							sys.exit(1)
						verifica = False
					else:
						tablaPadre = tablaPadre.padre
				
				#En caso de revisar todas las tablas
				if tablaPadre == None:					
					tipoVariable1 = nombreVar					

					if tipoVariable1 <> "number" and tipoVariable1 <> "boolean" and tipoVariable1 <> "matrix":
						msg = "ERROR-DEC: La variable \'%s\' no esta declarada."
						e = msg % nombreVar
						print e
						sys.exit(1)
					else:
						if tipoVariable1 <> "number" and tipoVariable1 <> "boolean":

							# Obtengo el tipo de la declaracion
							if not(isinstance(self.tipo.r, int)):
								num_r = int(self.tipo.r.valor)
								if (isinstance(self.tipo.c, int)): 
									num_c = self.tipo.c
							if not(isinstance(self.tipo.c, int)):
								num_c = int(self.tipo.c.valor)
								if isinstance(self.tipo.r, int):
									num_r = self.tipo.r

							ex = self.expresion.chequear(tablaSimb)

							if ex <> "matrix":
								fila = ex[1]
								columna = ex[2]
							else:
								fila = self.expresion.getRow()
								columna = self.expresion.getCol()

							if fila <> num_r or columna <> num_c:					
								e = "ERROR-DEC: La matriz no tiene las dimensiones correctas." 
								print e
							 	sys.exit(1)

						if (tipoVariable1 <> fun_param_tipo):
							e = "ERROR-DEC: La expresion tiene el" 
							e += " tipo \'%s\' y se " % tipoVariable1
							e += "esperaba el tipo \'%s\'."	
							print e % fun_param_tipo
							sys.exit(1)
	
		tablaSimb.insertarElem(nombreVariable,arregloVariable)
		return [nombreVariable,arregloVariable]

	def inicializarMatriz(self,fila, columna):

		if not(isinstance(fila,int)):
			fila = fila.retornaValor()

		
		if not(isinstance(columna,int)):
			columna = columna.retornaValor()

		nuevaMatriz = []
		if fila <> 1 and columna <> 1:
			i = 0
			while i < fila:
				j = 0
				nuevo = []
				while j < columna:
					nuevo.append(0)         
					j = j + 1
				nuevaMatriz.append(nuevo)
				i = i + 1
			return nuevaMatriz
		 
		elif columna == 1:
			i = 0
			while i < fila:
				nuevo = []
				nuevo.append(0)
				nuevaMatriz.append(nuevo)
				i = i + 1
			return nuevaMatriz
	 
		elif fila == 1:
			i = 0
			nuevo = []
			while i < columna:
				nuevo.append(0)
				i = i + 1      
			nuevaMatriz.append(nuevo)
			return nuevaMatriz
	 
		elif fila == 1 and columna == 1:
			return [[0]]

	def ejecutar(self,tabla,dicc_Aux):
		dicc_Actual = {}

		maximo = len(tabla) - 1

		if self.expresion <> None:

			if isinstance(self.expresion,Identificador.Identificador):

				if maximo >= 0:
					dicc_Actual = tabla[maximo]
					verifica = True
					while (maximo >= 0 and verifica):
						if dicc_Actual.has_key(self.expresion.ejecutar(tabla,dicc_Aux)) == True:
							valor1 = dicc_Actual[self.expresion.ejecutar(tabla,dicc_Aux)]
							dicc_Aux[self.identificador.ejecutar(tabla,dicc_Aux)] = valor1
							verifica = False
						maximo = maximo - 1
						dicc_Actual = tabla[maximo]

			elif isinstance(self.expresion,Llamada_Funcion.Llamada_Funcion):

				valor1 = self.expresion.ejecutar(tabla,dicc_Aux)
				dicc_Aux[self.identificador.ejecutar(tabla,dicc_Aux)] = valor1
					
			else:
				if (self.tipo == "number"):
					dicc_Aux[self.identificador.ejecutar(tabla,dicc_Aux)] = 0
				elif (self.tipo == "boolean"):
					dicc_Aux[self.identificador.ejecutar(tabla,dicc_Aux)] = "false"
				
				else:
					inicM = self.inicializarMatriz(self.tipo.r,self.tipo.c)
					dicc_Aux[self.identificador.ejecutar(tabla,dicc_Aux)] = inicM

				valor = self.expresion.ejecutar(tabla,dicc_Aux)
				valor_id = self.identificador.ejecutar(tabla,dicc_Aux)
				dicc_Aux[valor_id] = valor

		else:
			
			if (self.tipo == "number"):
				dicc_Aux[self.identificador.ejecutar(tabla,dicc_Aux)] = 0
			elif (self.tipo == "boolean"):
				dicc_Aux[self.identificador.ejecutar(tabla,dicc_Aux)] = "false"
			
			else:
				inicM = self.inicializarMatriz(self.tipo.r,self.tipo.c)
				dicc_Aux[self.identificador.ejecutar(tabla,dicc_Aux)] = inicM

		return dicc_Aux

				
# END Declaracion_Variable.py
