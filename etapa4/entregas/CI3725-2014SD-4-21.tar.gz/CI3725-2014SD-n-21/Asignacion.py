################################################################################
#                                 ASIGNACION                                   #
#                      set <identificador> = <expresion>                       #
################################################################################

import Vector
import sys
from Program_End import *
import Expresion_Negativo
import Matriz_Traspuesta
import Literal_Numerico
import Identificador

class Asignacion:

	def __init__(self,identificador,expresion):
		self.identificador = identificador
		self.expresion = expresion

	def imprimir(self,espacio,tablaSimb):
		pass

	def chequearExpresion(self,tipo_id,tablaSimb):
		
		nombreVar = self.expresion.chequear(tablaSimb)

		if self.expresion.type == "exp_bin" or self.expresion.type == "llamada_func":
			if nombreVar <> "number" and nombreVar <> "boolean":
				nombreVar = self.expresion.chequear(tablaSimb)[0]
		
		if (tablaSimb.diccionario.has_key(nombreVar) == True):
			tipo_exp = tablaSimb.diccionario[nombreVar]
	
			tipo_exp_extra = tipo_exp
			if tipo_exp <> "number" and tipo_exp <> "boolean":
				tipo_exp_extra = tipo_exp[0]

			if tipo_exp_extra <> "number" and tipo_exp_extra <> "boolean" and tipo_exp_extra <> "matrix":									
				msg = "ERROR-ASIG: La variable \'%s\' no esta declarada."
				e = msg % nombreVar
				print e
				sys.exit(1)
			else:
				tipo_id_extra = tipo_id
				if tipo_id <> "number" and tipo_id <> "boolean":
					tipo_id_extra = tipo_id[0]

				if (tipo_exp_extra <> tipo_id_extra):
					e = "ERROR-ASIG: La expresion \'%s\' tiene el" % nombreVar 
					e += " tipo \'%s\', y se " % tipo_exp_extra
					e += "esperaba el tipo \'%s\'." % tipo_id_extra				
					print e
					sys.exit(1)

				if tipo_exp <> "number" and tipo_exp <> "boolean":

					num_r = tipo_exp[1]
					num_c = tipo_exp[2]

					fila = tipo_id[1]
					columna = tipo_id[2]
								
					if fila <> num_r or columna <> num_c:											
						e = "ERROR-ASIG: La matriz no tiene las dimensiones correctas." 
						print e
					 	sys.exit(1)
		else:
			tablaPadre = tablaSimb.padre
			verifica = True
			while (tablaPadre <> None) and verifica:
				if (tablaPadre.diccionario.has_key(nombreVar) == True):
					tipo_exp = tablaPadre.diccionario[nombreVar]

					tipo_exp_extra = tipo_exp
					if tipo_exp <> "number" and tipo_exp <> "boolean":
						tipo_exp_extra = tipo_exp[0]

					if tipo_exp_extra <> "number" and tipo_exp_extra <> "boolean" and tipo_exp_extra <> "matrix":									
						msg = "ERROR-ASIG: La variable \'%s\' no esta declarada."
						e = msg % nombreVar
						print e
						sys.exit(1)
					else:
						tipo_id_extra = tipo_id
						if tipo_id <> "number" and tipo_id <> "boolean":
							tipo_id_extra = tipo_id[0]

						if (tipo_exp_extra <> tipo_id_extra):
							e = "ERROR-ASIG: La expresion \'%s\' tiene el" % nombreVar 
							e += " tipo \'%s\', y se " % tipo_exp_extra
							e += "esperaba el tipo \'%s\'." % tipo_id_extra				
							print e
							sys.exit(1)

						if tipo_exp <> "number" and tipo_exp <> "boolean":

							num_r = tipo_exp[1]
							num_c = tipo_exp[2]

							fila = tipo_id[1]
							columna = tipo_id[2]
										
							if fila <> num_r or columna <> num_c:											
								e = "ERROR-ASIG: La matriz no tiene las dimensiones correctas." 
								print e
							 	sys.exit(1)

					verifica = False

				else:

					tablaPadre = tablaPadre.padre
				
			if tablaPadre == None:

				if nombreVar <> "number" and nombreVar <> "boolean" and nombreVar <> "matrix":					
					if isinstance(self.expresion,Expresion_Negativo.Expresion_Negativo):
						self.expresion.chequear(tablaSimb)
					elif isinstance(self.expresion,Matriz_Traspuesta.Matriz_Traspuesta):
						self.expresion.chequear(tablaSimb)
					else:						
						msg = "ERROR-ASIG: La variable \'%s\' no esta declarada."
						e = msg % nombreVar
						print e
						sys.exit(1)
				
				else:					
					tipo_exp = self.expresion.chequear(tablaSimb)

					tipo_exp_extra = tipo_exp
					if self.expresion.type == "exp_bin" or self.expresion.type == "llamada_func":
						if tipo_exp <> "number" and tipo_exp <> "boolean":
							tipo_exp_extra = tipo_exp[0]


					tipo_id_extra = tipo_id
					if tipo_id <> "number" and tipo_id <> "boolean":
						tipo_id_extra = tipo_id[0]


					if (tipo_exp_extra <> tipo_id_extra):							
						e = "ERROR-ASIG: La expresion tiene el"
						e += " tipo \'%s\', y se " % tipo_exp_extra
						e += "esperaba el tipo \'%s\'." % tipo_id_extra				
						print e
						sys.exit(1)

					if nombreVar <> "number" and nombreVar <> "boolean":					
						num_r = 0
						num_c = 0
						if tipo_exp <> "matrix":
							num_r = tipo_exp[1]
							num_c = tipo_exp[2]

						else:
							num_r = self.expresion.getRow()
							num_c = self.expresion.getCol()


						fila = tipo_id[1]
						columna = tipo_id[2]
						if fila <> num_r or columna <> num_c:					
							e = "ERROR-ASIG: La matriz no tiene las dimensiones correctas." 
							print e
						 	sys.exit(1)


	def chequear(self,tablaSimb):
		
		nombreVariable =  self.identificador.chequear(tablaSimb)
		
		if (tablaSimb.diccionario.has_key(nombreVariable) == True):
			tipoVariable = tablaSimb.diccionario[nombreVariable]			
			self.chequearExpresion(tipoVariable,tablaSimb)
		else:
			tablaPadre = tablaSimb.padre
			verifica = True
			while (tablaPadre <> None and verifica):
				if (tablaPadre.diccionario.has_key(nombreVariable) == True):
					tipoVariable = tablaPadre.diccionario[nombreVariable]
					self.chequearExpresion(tipoVariable,tablaPadre)
					verifica = False
				else:
					tablaPadre = tablaPadre.padre
			if tablaPadre == None:
				if isinstance(self.identificador,Vector.Vector) <> True:
					msg = "ERROR-ASIG: La variable \'%s\' no esta declarada."
					e = msg % nombreVariable
					print e
					sys.exit(1)
				elif isinstance(self.identificador,Vector.Vector) == True:
					if self.expresion.type == "exp_bin" or self.expresion.type == "llamada_func":
						tipoVariable = self.expresion.chequear(tablaSimb)	
						if tipoVariable <> "number":
							e = "ERROR-ASIG: Se esperaba que fuese "
							e += "de tipo \'number\'." 
							print e
						sys.exit(1)
					elif self.expresion.type == "boolean" or self.expresion.type == "matrix":
						e = "ERROR-ASIG: Se esperaba que fuese "
						e += "de tipo \'number\'." 
						print e
					else:
						self.chequearExpresion("number",tablaSimb)

	def ejecutar(self,tabla,dicc_Aux):
		if isinstance(self.identificador,Vector.Vector):

			matriz = dicc_Aux[self.identificador.identificador.ejecutar(tabla,dicc_Aux)]

			if isinstance(self.identificador.i,Literal_Numerico.Literal_Numerico):
				i = self.identificador.i.retornaValor()
			elif isinstance(self.identificador.i,Identificador.Identificador):
				maximo = len(tabla) - 1
				dicc_Actual = tabla[maximo]
				nombreVariable = self.identificador.i.nombre
				while (maximo >= 0):				
					if dicc_Actual.has_key(nombreVariable) == True:					
						i = dicc_Actual[nombreVariable]
						break
					maximo = maximo - 1
					dicc_Actual = tabla[maximo]
			else:
				i = self.identificador.i.ejecutar(tabla,dicc_Aux)


			row = len(matriz)
			col = len(matriz[0])

			
			if self.identificador.j:
				if isinstance(self.identificador.j,Literal_Numerico.Literal_Numerico):
					j = self.identificador.j.retornaValor()
				elif isinstance(self.identificador.j,Identificador.Identificador):
					maximo = len(tabla) - 1
					dicc_Actual = tabla[maximo]
					nombreVariable = self.identificador.j.nombre
					while (maximo >= 0):				
						if dicc_Actual.has_key(nombreVariable) == True:					
							j = dicc_Actual[nombreVariable]
							break
						maximo = maximo - 1
						dicc_Actual = tabla[maximo]
				else:
					j = self.identificador.j.ejecutar(tabla,dicc_Aux)

	
				if (i <= 0 or j <= 0):								
					e = "ERROR-ASIG: Valores no validos, e[i,j] i y j "
					e += "tienen que ser mayor a cero."
					print e
					sys.exit(1)
				else:													
					if (i > row or j > col):									
						e = "ERROR-ASIG: e[i,j] Valores no validos para la matriz."
						print e
						sys.exit(1)
				j = j - 1
			else:
				if (i <= 0):								
					e = "ERROR-ASIG: Valor no valido, e[i] i "
					e += "tiene que ser mayor a cero."
					sys.exit(1)
				else:
					# Nos moveremos por las columnas								
					if  (row == 1):							
						if (i > col):										
							e = "ERROR-ASIG: e[i] Valor no valido para la matriz."
							print e
							sys.exit(1)
					# Nos moveremos por las filas
					elif (col == 1):
						if (i > row):										
							e = "ERROR-ASIG: e[i] Valor no valido para la matriz."
							print e
							sys.exit(1)
					else:									
						e = "ERROR-ASIG: e[i] Valor no valido para la matriz."
						print e
						sys.exit(1)
				
			i = i - 1			

			if self.identificador.j:
				matriz[i][j] = self.expresion.ejecutar(tabla,dicc_Aux)
			else:				
				matriz[0][i] = self.expresion.ejecutar(tabla,dicc_Aux)
								
		else:	
			if isinstance(self.expresion,Identificador.Identificador):
				maximo = len(tabla) - 1
				dicc_Aux = tabla[maximo]
				nombreVariable = self.expresion.nombre
				print nombreVariable
				while (maximo >= 0):				
					if dicc_Aux.has_key(nombreVariable) == True:				
						dicc_Aux[self.identificador.ejecutar(tabla,dicc_Aux)] = dicc_Aux[nombreVariable]
						break
					maximo = maximo - 1
					dicc_Aux = tabla[maximo]
			else:

				dicc_Aux[self.identificador.ejecutar(tabla,dicc_Aux)] = self.expresion.ejecutar(tabla,dicc_Aux)


		return dicc_Aux
						
# END Asignacion.py
