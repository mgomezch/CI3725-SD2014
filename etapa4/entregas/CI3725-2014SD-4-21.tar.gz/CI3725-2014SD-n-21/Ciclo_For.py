################################################################################
#                                     FOR                                      #
#        for <identificador> in <vector/matrix> do <instrucciones> end;        #
################################################################################

import sys
import Identificador
from Program_End import *
import Return

class Ciclo_For:

	def __init__(self,identificador,vector_matriz,instruccion=None):
		self.identificador = identificador
		self.vector_matriz = vector_matriz
		self.instruccion = instruccion

	def imprimir(self,espacio,tablaSimb):

		self.identificador.imprimir(espaciacion(espacio),tablaSimb)
		self.vector_matriz.imprimir(espaciacion(espacio),tablaSimb)

		for i in self.instruccion:
			i.imprimir(espaciacion(espacio),tablaSimb)

	def chequear(self,tablaSimb):

		flag = False

		# Verifica el identificador
		nombreVar = self.identificador.chequear(tablaSimb)

   		if (tablaSimb.diccionario.has_key(nombreVar) == True):
   			tipoVar = tablaSimb.diccionario[nombreVar]
			if (tipoVar <> "number"):
				e = "ERROR-FOR: El tipo asociado al identificador "
				e += "\'%s\'" % self.identificador.nombre
				e += " que se esperaba era de tipo \'number\'."
				print e
				sys.exit(1)
   		else:
   			tablaPadre = tablaSimb.padre
			verifica = True
			while (tablaPadre <> None) and verifica:
				nombreVar =  self.identificador.chequear(tablaPadre)
				if (tablaPadre.diccionario.has_key(nombreVar) == True):
					tipoExp = tablaPadre.diccionario[nombreVar]
					if (tipoExp <> "number"):
						e = "ERROR-FOR: El tipo asociado al identificador "
						e += "\'%s\'" % self.identificador.nombre
						e += " que se esperaba era de tipo \'number\'."
						print e
						sys.exit(1)
					else:
						break
					verifica = False
				else:
					tablaPadre = tablaPadre.padre

			if tablaPadre == None:
				flag = True

		# Verificacion de vector_matriz
		nombreVariable = self.vector_matriz.chequear(tablaSimb)
		
		if self.vector_matriz.type == "exp_bin":
			if nombreVariable <> "number" and nombreVariable <> "boolean":
				nombreVariable = nombreVariable[0]

		if (tablaSimb.diccionario.has_key(nombreVariable) == True):
			tipoVariable = tablaSimb.diccionario[nombreVariable]

			if tipoVariable == "number" or tipoVariable == "boolean":
				e = "ERROR-FOR: El tipo asociado al identificador que se "
				e += "esperaba era de tipo \'matriz\', \'row\' o \'column\'."
				print e
				sys.exit(1)		
		else:
			tablaPadre = tablaSimb.padre
			verifica = True

			while (tablaPadre <> None) and verifica:
				if (tablaPadre.diccionario.has_key(nombreVariable) == True):
					tipoVariable = tablaPadre.diccionario[nombreVariable]					

					if (tipoVariable == "number" or tipoVariable == "boolean"):
						e = "ERROR-FOR: El tipo asociado al identificador que se "
						e += "esperaba era de tipo \'matriz\', \'row\' o \'column\'."
						print e
						sys.exit(1)
					else: 
						break
					verifica = False
				else:
					tablaPadre = tablaPadre.padre		
			if tablaPadre == None:
				if (nombreVariable <> "matrix"):				
					e = "ERROR-FOR: La variable \'%s\' no esta declarada." 
					print e % nombreVariable
					sys.exit(1)

		if flag == True:
			tablaSimb.insertarElem(nombreVar,"number")

		# Verificacion instruccion
		if self.instruccion:
			for i in self.instruccion:
				if i <> None: 
					i.chequear(tablaSimb);


	def ejecutar(self,tabla,dicc):

		maximo = len(tabla) - 1

		if isinstance(self.identificador,Identificador.Identificador):
			dicc_Actual = tabla[maximo]
			nombreVariable = self.identificador.nombre
			flag = True
			while (maximo >= 0):				
				if dicc_Actual.has_key(nombreVariable) == True:					
					extra = dicc_Actual[nombreVariable]
					flag = False
					break
				maximo = maximo - 1
				dicc_Actual = tabla[maximo]

			# Caso que no este declarado
			if flag == True:
				maximo = len(tabla) - 1
				dicc_Actual = tabla[maximo]
				dicc_Actual[self.identificador.ejecutar(tabla,dicc)] = 0

		maximo = len(tabla) - 1

		if isinstance(self.vector_matriz,Identificador.Identificador):
			dicc_Actual = tabla[maximo]
			nombreVariable = self.vector_matriz.nombre
			while (maximo >= 0):				
				if dicc_Actual.has_key(nombreVariable) == True:					
					matriz = dicc_Actual[nombreVariable]
					break
				maximo = maximo - 1
				dicc_Actual = tabla[maximo]
		else:
			matriz = self.vector_matriz.ejecutar(tabla,dicc)

		maximo = len(tabla) - 1
		dicc_Actual = tabla[maximo]

		nombreVar = self.identificador.ejecutar(tabla,dicc)
		k = 0
		while k < len(matriz):
			for nombre in matriz[k]:
				dicc_Actual[nombreVar] = nombre

			 	if self.instruccion:
					for i in self.instruccion:
						if i <> None: 
							if isinstance(i,Return.Return):									
								return i.ejecutar(tabla,dicc)
							else:
								i.ejecutar(tabla,dicc)
			 				
			k = k + 1


# END Ciclo_For.py 
