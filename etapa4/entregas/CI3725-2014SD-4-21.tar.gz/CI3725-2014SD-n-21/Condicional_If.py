################################################################################
#                                      IF                                      #
#                    if <condicion> then <instruccion1> end;                   #
#                 if <condicion> then <instruccion1> else end;                 #
#          if <condicion> then <instruccion1> else <instruccion2> end;         #
################################################################################

import sys
import Return

class Condicional_If:

	def __init__(self,condicion,instruccion1,instruccion2=None):
		self.condicion = condicion
		self.instruccion1 = instruccion1
		self.instruccion2 = instruccion2		

	def imprimir(self,espacio,tablaSimb):
		for i in self.instruccion1:
			i.imprimir(espaciacion(espacio),tablaSimb)

		if self.instruccion2:
			for i in self.instruccion2:
				i.imprimir(espaciacion(espacio),tablaSimb)


	def chequear(self,tablaSimb):
		f = "ERROR-IF: Se esperaba que la condicion fuese de tipo \'boolean\'."
		if self.condicion.type == "id":
			nombreCond = self.condicion.chequear(tablaSimb)
			if (tablaSimb.diccionario.has_key(nombreCond) == True):
				tipoCond = tablaSimb.diccionario[nombreCond]
				if tipoCond <> "boolean":
					print f
					sys.exit(1)
			else:
				tablaPadre = tablaSimb.padre
				while (tablaPadre <> None):
					if (tablaPadre.diccionario.has_key(nombreCond) == True):
						tipoCond = tablaPadre.diccionario[nombreCond]
						if (tipoCond <> "boolean"):
							print f
							sys.exit(1)
						else: 
							break
					else:
						tablaPadre = tablaPadre.padre

				if tablaPadre == None:
					e = "ERROR-IF: La variable \'%s\' no esta declarada." 
					print e % nombreCond
					sys.exit(1)
					
		elif self.condicion.type == "exp_bin":
			tipoExp = self.condicion.chequear(tablaSimb)
			if tipoExp <> "boolean":
				print f
				sys.exit(1)
		else:
			tipoExp = self.condicion.chequear(tablaSimb)
			if tipoExp <> "boolean":
				print f
				sys.exit(1)

		if self.instruccion1 <> "VACIO":
			for i in self.instruccion1:
				if i <> None:
					i.chequear(tablaSimb)

		if self.instruccion2:
			for i in self.instruccion2:
				if i <> None:
					i.chequear(tablaSimb)

	def ejecutar(self,tabla,dicc):
		condicion = self.condicion.ejecutar(tabla,dicc)

		if condicion == "true":
			if self.instruccion1 <> "VACIO":
			 	for i in self.instruccion1:
			 		if i <> None:
			 			i.ejecutar(tabla,dicc)
		else:
			if self.instruccion2:
				if self.instruccion2:
				 	for i in self.instruccion2:
				 		if i <> None:
							if isinstance(i,Return.Return):									
								return i.ejecutar(tabla,dicc)
							else:
								i.ejecutar(tabla,dicc)


# END Condicional_If.py
