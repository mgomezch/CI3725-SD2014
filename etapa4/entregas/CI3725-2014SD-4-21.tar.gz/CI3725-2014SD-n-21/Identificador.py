################################################################################
#                                IDENTIFICADOR                                 #
################################################################################

class Identificador:

	def __init__(self,nombre):		
		self.nombre = nombre
		self.type = "id"

	def imprimir(self,espacio,tablaSimb):
		pass

	def chequear(self,tablaSimb):
		return self.nombre

	def ejecutar(self,tabla,dicc):
		return self.nombre

# END Identificador.py
