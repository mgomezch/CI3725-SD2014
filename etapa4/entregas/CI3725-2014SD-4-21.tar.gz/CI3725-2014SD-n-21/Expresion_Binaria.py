################################################################################
#                               EXPRESION BINARIA                              #
#                         <expresion1> op <expresion2>                         #
################################################################################

import Expresion_Negativo
import Booleano
import sys
import Identificador
import Matriz
import Literal_Numerico
from Program_End import *


class Expresion_Binaria:

	def __init__(self,expresion1,operador,expresion2):
		self.expresion1 = expresion1
		self.expresion2 = expresion2
		self.operador  = operador
		self.type = "exp_bin"

	def imprimir(self,espacio,tablaSimb):
		pass

	def chequear_tipos(self,tipoExp1,tipoExp2,extra1,extra2):

		simbolos = ["+","-","*","/","%","div","mod"]
		simbolos_matriz = [".+.",".*.",".-.","./.",".%.",".div.",".mod."]
		simbolos_booleanos = ["&","|"]
		simbolos_rango = [">",">=","<","<="]
		simbolos_comparacion = ["==","/="]

		e = "ERROR-EXP-BIN: Incompatibilidad de tipos para realizar la operacion \'%s\'."
		f = "ERROR-EXP-BIN: No se puede realizar la operacion \'%s\'."

		# Se verifica que cumplan los tipos con el operador
		if str(self.operador) in simbolos:

			if (tipoExp1 <> tipoExp2):
				print e % self.operador
				sys.exit(1)

			# NUMBER
			if (tipoExp1 == "number"):
				return "number"

			# MATRIZ
			elif tipoExp1 == "matrix":
				fil1 = extra1[1]
				col1 = extra1[2]
				fil2 = extra2[1]
				col2 = extra2[2]

				if  self.operador == "*":					
					if (col1 == fil2):
						return ["matrix",fil1,col2]
					else:
						print f % self.operador
						sys.exit(1)
				elif self.operador == "/" or self.operador == "%" or self.operador == "div" or self.operador == "mod": 
					print f % self.operador
					sys.exit(1)
				else:
					if (fil1 == fil2) and (col1 == col2):
						return ["matrix",fil1,col1]
					else:
						print f % self.operador
						sys.exit(1)
			else:
				print e % self.operador
				sys.exit(1)

		elif str(self.operador) in simbolos_matriz:			
			if (tipoExp1 == "number" and tipoExp2 == "matrix"):
				return extra2

			elif (tipoExp1 == "matrix" and tipoExp2 == "number"):
				return extra1

		elif str(self.operador) in simbolos_rango:
			if (tipoExp1 <> tipoExp2):
				print e % self.operador
				sys.exit(1)

			if (tipoExp1 == "number"):
				return "boolean"
			else:
				print e % self.operador
				sys.exit(1)	

		elif str(self.operador) in simbolos_comparacion:
			if (tipoExp1 <> tipoExp2):
				print e % self.operador
				sys.exit(1)
			elif tipoExp1 == "matrix":
				fil1 = extra1[1]
				col1 = extra1[2]
				fil2 = extra2[1]
				col2 = extra2[2]	

				if (fil1 == fil2) and (col1 == col2):
					return "boolean"
				else:
					print f % self.operador
					sys.exit(1)

			return "boolean"		

		elif str(self.operador) in simbolos_booleanos:
			if (tipoExp1 <> tipoExp2):
				print e % self.operador
				sys.exit(1)

			if (tipoExp1 == "boolean"):
				return "boolean"
			else:
				print e % self.operador
				sys.exit(1)

	def chequear(self,tablaSimb):

		nombreVariable1 = self.expresion1.chequear(tablaSimb)
		nombreVariable2 = self.expresion2.chequear(tablaSimb)

		extra1 = []
		extra2 = []

		
		if self.expresion1.type == "exp_bin":
			if nombreVariable1 <> "number" and nombreVariable1 <> "boolean":
				nombreVariable1 = self.expresion1.chequear(tablaSimb)[0]
		elif self.expresion1.type == "llamada_func":
			if nombreVariable1 <> "number" and nombreVariable1 <> "boolean":
				nombreVariable1 = self.expresion1.chequear(tablaSimb)[0]
		elif self.expresion1.type == "id" or nombreVariable1 == "matrix":
			nombreVariable1 = nombreVariable1
		elif nombreVariable1 <> "number" and nombreVariable1 <> "boolean":
			nombreVariable1 = self.expresion1.chequear(tablaSimb)[0]

		if self.expresion2.type == "exp_bin":
			if nombreVariable2 <> "number" and nombreVariable2 <> "boolean":
				nombreVariable2 = self.expresion2.chequear(tablaSimb)[0]
		elif self.expresion2.type == "llamada_func":
			if nombreVariable2 <> "number" and nombreVariable2 <> "boolean":
				nombreVariable2 = self.expresion2.chequear(tablaSimb)[0]
		elif self.expresion2.type == "id" or nombreVariable2 == "matrix":
			nombreVariable2 = nombreVariable2
		elif nombreVariable2 <> "number" and nombreVariable2 <> "boolean":
			nombreVariable2 = self.expresion2.chequear(tablaSimb)[0]
		
		# VERIFICAR EXPRESION 1
		if (tablaSimb.diccionario.has_key(nombreVariable1) == True):

   			tipoVariable1 = tablaSimb.diccionario[nombreVariable1]
   			if tipoVariable1 <> "number" and tipoVariable1 <> "boolean":
   				tipoVariable1 = tablaSimb.diccionario[nombreVariable1][0]   				
   				extra1 = tablaSimb.diccionario[nombreVariable1]
   		else:
   			tablaPadre = tablaSimb.padre
			verifica = True			
			while (tablaPadre <> None) and verifica:
				if (tablaPadre.diccionario.has_key(nombreVariable1) == True):
					tipoVariable1 = tablaPadre.diccionario[nombreVariable1]
					if tipoVariable1 <> "number" and tipoVariable1 <> "boolean":
   						tipoVariable1 = tablaPadre.diccionario[nombreVariable1][0]
   						extra1 = tablaPadre.diccionario[nombreVariable1]
					verifica = False
				else:
					tablaPadre = tablaPadre.padre
			if tablaPadre == None:
				tipoVariable1 = nombreVariable1

				if tipoVariable1 == "matrix":
					if self.expresion1.type == "exp_bin" or self.expresion1.type == "llamada_func":
						if tipoVariable1 <> "number" and tipoVariable1 <> "boolean":
							tipoVariable1 = self.expresion1.chequear(tablaSimb)
						r = tipoVariable1[1]
		   				c = tipoVariable1[2]		   				
		   				extra1.append(tipoVariable1[0])
						extra1.append(r)
						extra1.append(c)
						tipoVariable1 = tipoVariable1[0]
					else:
						r = 0
						c = 0
						if isinstance(self.expresion1,Expresion_Negativo.Expresion_Negativo):
							lista = self.expresion1.chequear(tablaSimb)
							r = lista[1]
							c = lista[2]
						else:
			   				r = self.expresion1.getRow()
			   				c = self.expresion1.getCol()
		   				extra1.append(nombreVariable1)
						extra1.append(r)
						extra1.append(c)

				elif tipoVariable1 <> "number" and tipoVariable1 <> "boolean" and tipoVariable1 <> "matrix":
					msg = "ERROR-EXP-BIN: La variable \'%s\' no esta declarada."
					e = msg % nombreVariable1
					print e
					sys.exit(1)

		# VERIFICAR EXPRESION 2
		if (tablaSimb.diccionario.has_key(nombreVariable2) == True):
   			tipoVariable2 = tablaSimb.diccionario[nombreVariable2]
   			if tipoVariable2 <> "number" and tipoVariable2 <> "boolean":
   				tipoVariable2 = tablaSimb.diccionario[nombreVariable2][0]
   				extra2 = tablaSimb.diccionario[nombreVariable2]
   		else:
   			tablaPadre = tablaSimb.padre
			verifica = True
			while (tablaPadre <> None) and verifica:
				if (tablaPadre.diccionario.has_key(nombreVariable2) == True):
					tipoVariable2 = tablaPadre.diccionario[nombreVariable2]
					if tipoVariable2 <> "number" and tipoVariable2 <> "boolean":
   						tipoVariable2 = tablaPadre.diccionario[nombreVariable2][0]
   						extra2 = tablaPadre.diccionario[nombreVariable2]

					verifica = False
				else:
					tablaPadre = tablaPadre.padre
			if tablaPadre == None:
				tipoVariable2 = nombreVariable2
				if tipoVariable2 == "matrix":
					if self.expresion2.type == "exp_bin" or self.expresion2.type == "llamada_func":
						if tipoVariable2 <> "number" and tipoVariable2 <> "boolean":
							tipoVariable2 = self.expresion2.chequear(tablaSimb)
						r = tipoVariable2[1]
		   				c = tipoVariable2[2]		   				
		   				extra2.append(tipoVariable2[0])
						extra2.append(r)
						extra2.append(c)
						tipoVariable2 = tipoVariable2[0]
					else:						
						r = 0
						c = 0

						if isinstance(self.expresion2,Expresion_Negativo.Expresion_Negativo):
							lista = self.expresion2.chequear(tablaSimb)
							r = lista[1]
							c = lista[2]

						else:
			   				r = self.expresion2.getRow()
			   				c = self.expresion2.getCol()

			   			extra2.append(nombreVariable2)
						extra2.append(r)
						extra2.append(c)

				if tipoVariable2 <> "number" and tipoVariable2 <> "boolean" and tipoVariable2 <> "matrix":
					msg = "ERROR-EXP-BIN: La variable \'%s\' no esta declarada."
					e = msg % nombreVariable2
					print e
					sys.exit(1)

		return self.chequear_tipos(tipoVariable1,tipoVariable2,extra1,extra2)

	def ejecutar(self,tabla,dicc):
		
		maximo = len(tabla) - 1

		if isinstance(self.expresion1,Identificador.Identificador):

			dicc_Actual = tabla[maximo]
			while (maximo >= 0):
				if dicc_Actual.has_key(self.expresion1.ejecutar(tabla,dicc)) == True:
					valor1 = dicc_Actual[self.expresion1.ejecutar(tabla,dicc)]
					break
				maximo = maximo - 1
				dicc_Actual = tabla[maximo]
		else:
			valor1 = self.expresion1.ejecutar(tabla,dicc)


		maximo = len(tabla) - 1

		if isinstance(self.expresion2,Identificador.Identificador):
			dicc_Actual = tabla[maximo]
			nombreVariable2 = self.expresion2.nombre
			while (maximo >= 0):				
				if dicc_Actual.has_key(nombreVariable2) == True:
					
					extra = dicc_Actual[nombreVariable2]
					valor2 = extra
					break
				maximo = maximo - 1
				dicc_Actual = tabla[maximo]
		else:
			valor2 = self.expresion2.ejecutar(tabla,dicc)

		return self.operar(valor1,valor2)


	def operar(self,valor1,valor2):


		if str(self.operador) == "+":
			if isinstance(valor1,str) and valor1 <> "true" and valor1 <> "false":
				valor1 = int(valor1)
			if isinstance(valor2,str) and valor2 <> "true" and valor2 <> "false":
				valor2 = int(valor2)
			if isinstance(valor1,int):
				valor = valor1 + valor2
			else:
				valor = [[valor1[i][j]+valor2[i][j] for j in range(len(valor1))] for i in range(len(valor2))]
			return valor

		elif str(self.operador) == "-":
			if isinstance(valor1,str) and valor1 <> "true" and valor1 <> "false":
				valor1 = int(valor1)
			if isinstance(valor2,str) and valor2 <> "true" and valor2 <> "false":
				valor2 = int(valor2)
			if isinstance(valor1,int):
				valor = valor1 - valor2
			else:
				valor = [[valor1[i][j]-valor2[i][j] for j in range(len(valor1))] for i in range(len(valor2))]
			return valor

		elif str(self.operador) == "*":
			if isinstance(valor1,str) and valor1 <> "true" and valor1 <> "false":
				valor1 = int(valor1)
			if isinstance(valor2,str) and valor2 <> "true" and valor2 <> "false":
				valor2 = int(valor2)
			if isinstance(valor1,int):
				valor = valor1 * valor2
			else:
				return [[sum(a*b for a,b in zip(X_row,Y_col)) for Y_col in zip(*valor2)] for X_row in valor1]
			return valor

		elif str(self.operador) == "/":
			if isinstance(valor1,str) and valor1 <> "true" and valor1 <> "false":
				valor1 = int(valor1)
			if isinstance(valor2,str) and valor2 <> "true" and valor2 <> "false":
				valor2 = int(valor2)
			if valor2 == 0:
				e = "ERROR-EXP-BIN: No se puede dividir entre cero."
				print e
				sys.exit(1)
			if isinstance(valor1,int):
				valor = valor1 / valor2
			else:
				valor = [[valor1[i][j]/valor2[i][j] for j in range(len(valor1))] for i in range(len(valor2))]
			return valor

		elif str(self.operador) == "%":
			if isinstance(valor1,str) and valor1 <> "true" and valor1 <> "false":
				valor1 = int(valor1)
			if isinstance(valor2,str) and valor2 <> "true" and valor2 <> "false":
				valor2 = int(valor2)
			if valor2 == 0:
				e = "ERROR-EXP-BIN: No se puede dividir entre cero."
				print e
				sys.exit(1)
			if isinstance(valor1,int):
				valor = valor1 % valor2
			else:
				valor = [[valor1[i][j]%valor2[i][j] for j in range(len(valor1))] for i in range(len(valor2))]
			return valor

		elif str(self.operador) == "div":
			if isinstance(valor1,str) and valor1 <> "true" and valor1 <> "false":
				valor1 = int(valor1)
			if isinstance(valor2,str) and valor2 <> "true" and valor2 <> "false":
				valor2 = int(valor2)
			if valor2 == 0:
				e = "ERROR-EXP-BIN: No se puede dividir entre cero."
				print e
				sys.exit(1)
			if isinstance(valor1,int):
				valor = valor1 // valor2
			else:
				valor = [[valor1[i][j]//valor2[i][j] for j in range(len(valor1))] for i in range(len(valor2))]
			return valor

		elif str(self.operador) == "mod":
			if isinstance(valor1,str) and valor1 <> "true" and valor1 <> "false":
				valor1 = int(valor1)
			if isinstance(valor2,str) and valor2 <> "true" and valor2 <> "false":
				valor2 = int(valor2)
			if valor2 == 0:
				e = "ERROR-EXP-BIN: No se puede dividir entre cero."
				print e
				sys.exit(1)
			if isinstance(valor1,int):
				valor = valor1 % valor2
			else:
				valor = [[valor1[i][j]%valor2[i][j] for j in range(len(valor1))] for i in range(len(valor2))]
			return valor



		if str(self.operador) == "&":
			if valor1 == "true" and valor2 == "true":
			 	return "true"
			else: 
			 	return "false"

		elif str(self.operador) == "|":
			if valor1 == "true" or valor2 == "true":
			 	return "true"
			else: 
			 	return "false"



		if str(self.operador) == ">": 
			valor1 = int(valor1)
			valor2 = int(valor2)
			if valor1 > valor2:
				return "true"
			else:
				return "false"

		if str(self.operador) == ">=":
			valor1 = int(valor1)
			valor2 = int(valor2)
			if valor1 >= valor2:
				return "true"
			else:
				return "false"

		if str(self.operador) == "<":
			valor1 = int(valor1)
			valor2 = int(valor2)
			if valor1 < valor2:
				return "true"
			else:
				return "false"

		if str(self.operador) == "<=":
			valor1 = int(valor1)
			valor2 = int(valor2)
			if valor1 <= valor2:
				return "true"
			else:
				return "false"

		if str(self.operador) == "==":
			print valor1, valor2, "aqui"
			if not(isinstance(self.expresion1, Booleano.Booleano)) and valor1 <> "true" and valor1 <>"false":
				if not(isinstance(self.expresion1,Matriz.Matriz)) and not(isinstance(self.expresion1,Expresion_Binaria)):
					valor1 = int(valor1)
			if not(isinstance(self.expresion2, Booleano.Booleano)) and valor2 <> "true" and valor2 <>"false":
				if not(isinstance(self.expresion2,Matriz.Matriz)) and not(isinstance(self.expresion2,Expresion_Binaria)):
					valor2 = int(valor2)
			if valor1 == valor2:
				return "true"
			else:
				return "false"

		if str(self.operador) == "/=": 
			if not(isinstance(self.expresion1, Booleano.Booleano)) and valor1 <> "true" and valor1 <>"false":
				if not(isinstance(self.expresion1,Matriz.Matriz)) and not(isinstance(self.expresion1,Expresion_Binaria)):
					valor1 = int(valor1)
			if not(isinstance(self.expresion2, Booleano.Booleano)) and valor2 <> "true" and valor2 <>"false":
				if not(isinstance(self.expresion2,Matriz.Matriz)) and not(isinstance(self.expresion2,Expresion_Binaria)):
					valor2 = int(valor2)
			if valor1 <> valor2:
				return "true"
			else:
				return "false"

################################################				
		
		if isinstance(valor1, int) and not(isinstance(valor2,int)):
			temp = valor1
			valor1 = valor2
			valor2 = temp
		
		if str(self.operador) == ".+.":
			return [[a[X_row] + valor2 for X_row in range(len(valor1[0]))] for a in valor1]

		if str(self.operador) == ".*.":
			return [[a[X_row]*valor2 for X_row in range(len(valor1[0]))] for a in valor1]

		if str(self.operador) == ".-.":
			return [[a[X_row]-valor2 for X_row in range(len(valor1[0]))] for a in valor1]

		if str(self.operador) == "./.":
			if valor2 == 0:
				e = "ERROR-EXP-BIN: No se puede dividir entre cero."
				print e
				sys.exit(1)
			return [[a[X_row]/valor2 for X_row in range(len(valor1[0]))] for a in valor1]

		if str(self.operador) == ".%.":
			if valor2 == 0:
				e = "ERROR-EXP-BIN: No se puede dividir entre cero."
				print e
				sys.exit(1)
			return [[a[X_row]/valor2 for X_row in range(len(valor1[0]))] for a in valor1]

		if str(self.operador) == ".div.":
			if valor2 == 0:
				e = "ERROR-EXP-BIN: No se puede dividir entre cero."
				print e
				sys.exit(1)
			return [[a[X_row]//valor2 for X_row in range(len(valor1[0]))] for a in valor1]

		if str(self.operador) == ".mod.":
			if valor2 == 0:
				e = "ERROR-EXP-BIN: No se puede dividir entre cero."
				print e
				sys.exit(1)
			return [[a[X_row]%valor2 for X_row in range(len(valor1[0]))] for a in valor1]

#############################################

# END Expresion_Binaria.py
		