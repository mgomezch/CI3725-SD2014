################################################################################
#                               LLAMADA A FUNCION                              #
#                        <identificador>(<parametros>)                         #
################################################################################

import sys
from Program_End import *
import Identificador
import Literal_Numerico
import Booleano
import Matriz
import Asignacion
import Return

class Llamada_Funcion:

	def __init__(self,identificador,parametros=None):
		self.identificador = identificador
		self.parametros = parametros
		self.type = "llamada_func"

	def imprimir(self,espacio,tablaSimb):
		self.identificador.imprimir(espaciacion(espacio),tablaSimb)
		if self.parametros:
			for i in self.parametros:			
				i.imprimir(espaciacion(espacio),tablaSimb)


	def verificarParametro(self,parametro,tipoVariable,i,tablaSimb):
		fun_param = tipoVariable[i]							
		fun_param_tipo = fun_param[1]
						
		nombreVariable = parametro.chequear(tablaSimb)
				
		if parametro.type == "exp_bin":
			if nombreVariable <> "number" and nombreVariable <> "boolean":
				nombreVariable = nombreVariable[0]

		if (tablaSimb.diccionario.has_key(nombreVariable) == True):
			tipoVariable = tablaSimb.diccionario[nombreVariable]

			tipoExp = fun_param_tipo			

			if tipoVariable <> "number" and tipoVariable <> "boolean":
				tipoVariable = tablaSimb.diccionario[nombreVariable][0]
				fila = tablaSimb.diccionario[nombreVariable][1]
				columna = tablaSimb.diccionario[nombreVariable][2]
			
				num_r = 0
				num_c = 0
				if tipoExp <> "matrix":
					num_r = tipoExp[1]
					num_c = tipoExp[2]
					tipoExp = tipoExp[0]
				else:
					num_r = self.expresion.getRow()
					num_c = self.expresion.getCol()

				if fila <> num_r or columna <> num_c:
					e = "ERROR-LLAM: La matriz no tiene las dimensiones correctas." 
					print e
				 	sys.exit(1)

				
			if (tipoExp <> tipoVariable):
				j = i -1
				e = "ERROR-LLAM: Parametro numero %d, " % j
				e += "se esperaba que fuese de tipo \'%s\'." 
				print e % tipoExp
				sys.exit(1)

		#En caso de que tenga que revisar recursivamente las tablas padre
		else:
			tablaPadre = tablaSimb.padre
			verifica = True

			while (tablaPadre <> None) and verifica:

				#Guardia que revisa si la variable se encuantra en la tabla actual
				if (tablaPadre.diccionario.has_key(nombreVariable) == True):
					tipoVariable = tablaPadre.diccionario[nombreVariable]

					tipoExp = fun_param_tipo

					if tipoVariable <> "number" and tipoVariable <> "boolean":
						tipoVariable = tablaPadre.diccionario[nombreVariable][0]
						fila = tablaPadre.diccionario[nombreVariable][1]
						columna = tablaPadre.diccionario[nombreVariable][2]
					
						num_r = 0
						num_c = 0
						if tipoExp <> "matrix":
							num_r = tipoExp[1]
							num_c = tipoExp[2]
							tipoExp = tipoExp[0]
						else:
							num_r = self.expresion.getRow()
							num_c = self.expresion.getCol()

						if fila <> num_r or columna <> num_c:
							e = "ERROR-LLAM: La matriz no tiene las dimensiones correctas." 
							print e
						 	sys.exit(1)
						
					if (tipoExp <> tipoVariable):
						j = i -1					
						e = "ERROR-LLAM: Parametro numero %d, " % j
						e += "se esperaba que fuese de tipo \'%s\'." 
						print e % tipoExp
						sys.exit(1)
					verifica = False
				else:
					tablaPadre = tablaPadre.padre
			
			#En caso de revisar todas las tablas
			if tablaPadre == None:
				tipoVariable1 = nombreVariable
				if tipoVariable1 <> "number" and tipoVariable1 <> "boolean" and tipoVariable1 <> "matrix":
					msg = "ERROR-LLAM: La variable \'%s\' no esta declarada."
					e = msg % nombreVariable
					print e
					sys.exit(1)
				else:

					tipoExp = fun_param_tipo

					if tipoVariable1 <> "number" and tipoVariable1 <> "boolean":
						fila = 0
						columna = 0

						if parametro.type == "exp_bin":
							nombreVar = parametro.chequear(tablaSimb)
							fila = nombreVar[1]
							columna = nombreVar[2]
						else:
							fila = parametro.getRow()
							columna = parametro.getCol()

						num_r = 0
						num_c = 0
						if tipoExp <> "matrix":
							num_r = tipoExp[1]
							num_c = tipoExp[2]
							tipoExp = tipoExp[0]
						else:
							num_r = self.expresion.getRow()
							num_c = self.expresion.getCol()

						if fila <> num_r or columna <> num_c:
							e = "ERROR-LLAM: La matriz no tiene las dimensiones correctas." 
							print e
						 	sys.exit(1)

					if (tipoVariable1 <> tipoExp):
						j = i -1
						e = "ERROR-LLAM: Parametro numero %d, " % j
						e += "se esperaba que fuese de tipo \'%s\'." 
						print e % fun_param_tipo
						sys.exit(1)

	def chequear(self,tablaSimb):

		nombreVariable = self.identificador.chequear(tablaSimb)

		tablaPadre = tablaSimb
		flag = False
		verifica = True

		tipoVariable = []

		while (tablaPadre <> None and verifica):
			if (tablaPadre.diccionario.has_key(nombreVariable) == True):
				tipoCond = tablaPadre.diccionario[nombreVariable]
				if tipoCond[0] == "function":					
					tipoVariable = tablaPadre.diccionario[nombreVariable]

					if (tipoVariable <> "number") and (tipoVariable <> "boolean") and (tipoVariable <> "matrix"):
						tam = len(tipoVariable)
						num_parametros = tam - 2
						tam_parametros = 0
						if self.parametros:
							tam_parametros = len(self.parametros)

						# Se verifica numero de parametros
						if (num_parametros <> tam_parametros):
							e = "ERROR-LLAM: La cantidad de parametros que son pasados a " 
							e += "la funcion \'%s\' no es correcta." 
							print e % nombreVariable
							sys.exit(1)	

						i = 2
						if self.parametros:
							for k in self.parametros:									
								self.verificarParametro(k,tipoVariable,i,tablaSimb)
								i = i + 1
					flag = True
					verifica = False
				else:
					tablaPadre = tablaPadre.padre
			else:
				tablaPadre = tablaPadre.padre

		if tablaPadre == None:
			print "ERROR-LLAM: La funcion \'%s\' no existe." % nombreVariable
			sys.exit(1)

		if flag == False:
			e = "ERROR-LLAM: La variable \'%s\' no es una funcion."
			print e % nombreVariable

		return tipoVariable[1]

	def ejecutar(self,tabla,dicc):

		#self.identificador = identificador
		maximo = len(Tabla_Funciones) - 1

		dicc_Actual = {}
		if isinstance(self.identificador,Identificador.Identificador):
			dicc_Actual = Tabla_Funciones[maximo]
			nombreVariable = self.identificador.nombre
			while (maximo >= 0):				
				if dicc_Actual.has_key(nombreVariable) == True:					
				
					if dicc_Actual.has_key("parametros") == True:
						parametros = dicc_Actual["parametros"]
						j = 0
						for i in parametros:
							i.ejecutar(Tabla_Funciones,dicc)
							if isinstance(self.parametros[j],Literal_Numerico.Literal_Numerico):
								dicc_Actual[i.identificador.nombre] = self.parametros[j].retornaValor()
							elif isinstance(self.parametros[j],Booleano.Booleano):
								dicc_Actual[i.identificador.nombre] = self.parametros[j].retornaValor()
							elif isinstance(self.parametros[j],Matriz.Matriz):
								matriz = self.parametros[j].ejecutar(Tabla_Funciones,dicc)
								dicc_Actual[i.identificador.nombre] = matriz
							j = j + 1 
						
						instrucciones = dicc_Actual[self.identificador.nombre]
						for k in instrucciones:
							if isinstance(k,Asignacion.Asignacion):								
								k.ejecutar(Tabla_Funciones,dicc_Actual)
							else:
								if isinstance(k,Return.Return):									
									return k.ejecutar(Tabla_Funciones,dicc)
								else:
									k.ejecutar(Tabla_Funciones,dicc)
					else:
						instrucciones = dicc_Actual[self.identificador.nombre]
						for k in instrucciones:
							if isinstance(k,Asignacion.Asignacion):								
								k.ejecutar(Tabla_Funciones,dicc_Actual)
							else:
								if isinstance(k,Return.Return):
									return k.ejecutar(Tabla_Funciones,dicc)
								else:
									k.ejecutar(Tabla_Funciones,dicc)
					break
				maximo = maximo - 1
				dicc_Actual = Tabla_Funciones[maximo]

# END Llamada_Funcion.py
