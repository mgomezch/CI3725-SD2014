################################################################################
#                                     TIPO                                     #
################################################################################

class Tipo:

	def __init__(self,valor):
		self.valor = valor

	def imprimir(self,espacio,tablaSimb):
		pass

	def chequear(self,tablaSimb):
		return self.valor

# END Tipo.py
