################################################################################
#                                    RETURN                                    #
#                              return <expresion>                              #
################################################################################

import sys
import Booleano
import Literal_Numerico
import Identificador
import Matriz
import Llamada_Funcion
import Expresion_Binaria

class Return:

	def __init__(self,expresion):
		self.expresion = expresion
		self.type = ""

	def setType(self,tipo):
		self.type = tipo

	def imprimir(self,espacio,tablaSimb):
		pass

	def verificarReturn(self,return_funcion,tablaSimb):

		ret = self.expresion

		if ret.type == "id":
			nombreCond = ret.chequear(tablaSimb)
			if (tablaSimb.diccionario.has_key(nombreCond) == True):
				tipoCond = tablaSimb.diccionario[nombreCond]

				if tipoCond == "number" or tipoCond == "boolean":
					
					if return_funcion <> tipoCond:
						e = "ERROR-RET: No se retorna el tipo esperado "
						e +=  "\'%s\'." % return_funcion
						print e
						sys.exit(1)
				else:
					if return_funcion <> "number" or return_funcion <> "boolean":
						r = tipoCond[1]
						c = tipoCond[2]
						num_r = return_funcion[1]
						num_c = return_funcion[2]

						if ((r <> num_r) or (c <> num_c)):
							e = "ERROR-RET: No se retorna el tipo esperado "
							e +=  "\'%s\'." % return_funcion
							e += " Las matrices no tienen las mismas dimensiones."
							print e
							sys.exit(1)
					else:
						e = "ERROR-RET: No se retorna el tipo esperado "
						e +=  "\'%s\'." % return_funcion
						print e
						sys.exit(1)
			else:
				tablaPadre = tablaSimb.padre
				verifica = False
				while (tablaPadre <> None and verifica):
					if (tablaPadre.diccionario.has_key(nombreCond) == True):
						tipoCond = tablaPadre.diccionario[nombreCond]

						if tipoCond == "number" or tipoCond == "boolean":
							
							if return_funcion <> tipoCond:
								e = "ERROR-RET: No se retorna el tipo esperado "
								e +=  "\'%s\'." % return_funcion
								print e
								sys.exit(1)
						else:
							if return_funcion <> "number" or return_funcion <> "boolean":
								r = tipoCond[1]
								c = tipoCond[2]
								num_r = return_funcion[1]
								num_c = return_funcion[2]

								if ((r <> num_r) or (c <> num_c)):
									e = "ERROR-RET: No se retorna el tipo esperado "
									e +=  "\'%s\'." % return_funcion
									e += " Las matrices no tienen las mismas dimensiones."
									print e
									sys.exit(1)
							else:
								e = "ERROR-RET: No se retorna el tipo esperado "
								e +=  "\'%s\'." % return_funcion
								print e
								sys.exit(1)	
						verifica = True				
					else:
						tablaPadre = tablaPadre.padre

				if tablaPadre == None:			
					if ret.type == "id":
						e = "ERROR-RET: La variable \'%s\' no esta declarada." 
						print e % nombreCond

					elif ret.type == "exp_bin":
						tipo_exp_bin = ret.chequear(tablaSimb)

						if tipo_exp_bin == "number" or tipo_exp_bin == "boolean":
							if return_funcion <> tipo_exp_bin:
								e = "ERROR-RET: No se retorna el tipo esperado "
								e +=  "\'%s\'." % return_funcion
								print e
								sys.exit(1)
						else:
							if return_funcion <> "number" or return_funcion <> "boolean":
								r = tipo_exp_bin[1]
								c = tipo_exp_bin[2]
								num_r = return_funcion[1]
								num_c = return_funcion[2]

								if ((r <> num_r) or (c <> num_c)):
									e = "ERROR-RET: No se retorna el tipo esperado "
									e +=  "\'%s\'." % return_funcion
									e += " Las matrices no tienen las mismas dimensiones."
									print e
									sys.exit(1)
							else:
								e = "ERROR-RET: No se retorna el tipo esperado "
								e +=  "\'%s\'." % return_funcion
								print e
								sys.exit(1)

					elif ret.type == "number" or ret.type == "boolean":
						
						if return_funcion <> ret.type:
							e = "ERROR-RET: No se retorna el tipo esperado "
							e +=  "\'%s\'." % return_funcion
							print e
							sys.exit(1)

					elif ret.type == "matrix":

						if return_funcion <> "number" or return_funcion <> "boolean":
							r = ret[1]
							c = ret[2]
							num_r = return_funcion[1]
							num_c = return_funcion[2]

							if ((r <> num_r) or (c <> num_c)):
								e = "ERROR-RET: No se retorna el tipo esperado "
								e +=  "\'%s\'." % return_funcion
								e += " Las matrices no tienen las mismas dimensiones."
								print e
								sys.exit(1)
						else:
							e = "ERROR-RET: No se retorna el tipo esperado "
							e +=  "\'%s\'." % return_funcion
							print e
							sys.exit(1)
		else:
			if ret.type == "number" or ret.type == "boolean":
				if return_funcion <> ret.type:
					e = "ERROR-RET: No se retorna el tipo esperado: "
					e +=  "\'%s\'." % return_funcion
					print e
					sys.exit(1)

			elif ret.type == "exp_bin":
				tipo_exp_bin = self.expresion.chequear(tablaSimb)

				if tipo_exp_bin == "number" or tipo_exp_bin == "boolean":
					if return_funcion <> tipo_exp_bin:
						e = "ERROR-RET: No se retorna el tipo esperado "
						e +=  "\'%s\'." % return_funcion
						print e
						sys.exit(1)
				else:
					if return_funcion <> "number" or return_funcion <> "boolean":
						r = tipo_exp_bin[1]
						c = tipo_exp_bin[2]
						num_r = return_funcion[1]
						num_c = return_funcion[2]

						if ((r <> num_r) or (c <> num_c)):
							e = "ERROR-RET: No se retorna el tipo esperado "
							e +=  "\'%s\'." % return_funcion
							e += " Las matrices no tienen las mismas dimensiones."
							print e
							sys.exit(1)
					else:
						e = "ERROR-RET: No se retorna el tipo esperado "
						e +=  "\'%s\'." % return_funcion
						print e
						sys.exit(1)

			elif ret.type == "matrix":
				tipo_exp_bin = self.expresion.chequear(tablaSimb)
				if return_funcion <> "number" and return_funcion <> "boolean":
					if return_funcion[0] <> tipo_exp_bin:
						e = "ERROR-RET: No se retorna el tipo esperado: "
						e +=  "\'%s\'." % return_funcion
						print e
						sys.exit(1)

					num_r = return_funcion[1]
					num_c = return_funcion[2]
					r = self.expresion.getRow()
					c = self.expresion.getCol()

					if ((r <> num_r) or (c <> num_c)):
						e = "ERROR-RET: No se retorna el tipo esperado "
						e +=  "\'%s\'." % return_funcion
						e += " Las matrices no tienen las mismas dimensiones."
						print e
						sys.exit(1)
				else:
					e = "ERROR-RET: No se retorna el tipo esperado: "
					e +=  "\'%s\'." % return_funcion
					print e
					sys.exit(1)

		self.setType(return_funcion)


	def chequear(self,tablaSimb):

		# Verifica si el return esta dentro de una funcion
		tablaPadre = tablaSimb.padre		
		k = 0
		if tablaPadre.padre == None:
			for l in tablaSimb.diccionario:
				tipoCond = tablaSimb.diccionario[l]
						
				if tipoCond[0] == "function":
					k = k + 1
		else:
			verifica = True
			while (tablaPadre <> None and verifica):
				if tablaPadre.padre == None:
					verifica = False
				else:
					for i in tablaPadre.diccionario:
						tipoCond = tablaPadre.diccionario[i]
						
						if tipoCond[0] == "function":
							k = k + 1
				tablaPadre = tablaPadre.padre

		if (k == 0):
			e = "ERROR-RET: No puedes usar \'return\'"
			e += " porque no estas en una funcion."
			print e
			sys.exit(1)


		# Verifica si el return esta dentro de una funcion
		tipo_funcion = []
		tablaPadre = tablaSimb.padre		
		k = 0
		if tablaPadre.padre == None:
			for i in tablaSimb.diccionario:
				tipoCond = tablaSimb.diccionario[i]
						
				if tipoCond[0] == "function":
					tipo_funcion = tipoCond[1]
		else:
			verifica = True
			while (tablaPadre <> None and verifica):
				if tablaPadre.padre == None:
					verifica = False
				else:
					for i in tablaPadre.diccionario:
						tipoCond = tablaPadre.diccionario[i]
						
						if tipoCond[0] == "function":
							tipo_funcion = tipoCond[1]
				tablaPadre = tablaPadre.padre

		return_funcion = tipo_funcion
		
		self.verificarReturn(return_funcion,tablaSimb)

	def ejecutar(self,tabla,dicc):

		maximo = len(tabla) - 1


		if isinstance(self.expresion,Identificador.Identificador):
			dicc_Actual = tabla[maximo]
			nombreVariable = self.expresion.nombre
			while (maximo >= 0):				
				if dicc_Actual.has_key(nombreVariable) == True:					
					return dicc_Actual[nombreVariable]
				maximo = maximo - 1
				dicc_Actual = tabla[maximo]

		elif isinstance(self.expresion,Literal_Numerico.Literal_Numerico):
			return self.expresion.retornaValor()

		elif isinstance(self.expresion,Booleano.Booleano):
			return self.expresion.retornaValor()
		
		elif isinstance(self.expresion,Matriz.Matriz):
			return self.expresion.ejecutar(tabla,dicc)

		elif isinstance(self.expresion,Llamada_Funcion.Llamada_Funcion):
			return self.expresion.ejecutar(tabla,dicc)

		elif isinstance(self.expresion,Expresion_Binaria.Expresion_Binaria):
			return self.expresion.ejecutar(tabla,dicc)

			
# END Return.py	
