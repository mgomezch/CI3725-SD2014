################################################################################
#                                    MATRIZ                                    #
#                        col {<valores>,<valores>, ...}                        #
#                        row {<valores>:<valores>: ...}                        #
#               matrix {<valores>,<valores>:<valores>,<valores>}               #
################################################################################

import sys
import Expresion_Binaria
import Identificador
from Program_End import *

class Matriz:
	
	def __init__(self,valor):       
		self.valor = valor
		self.type = "matrix"
		self.col = 1
		self.row = 1

	def retornaValor(self):
		return self.valor

	def setValor(self,valor):
		self.valor = valor

	def getCol(self):
		return self.col

	def getRow(self):
		return self.row

	def setCol(self,columna):
		self.col = columna

	def setRow(self,fila):
		self.row = fila

	def verificarArg(self,i,tablaSimb):
		nombreVariable = i.chequear(tablaSimb)

		if (tablaSimb.diccionario.has_key(nombreVariable) == True):
			tipoVariable = tablaSimb.diccionario[nombreVariable]
			if tipoVariable <> "number":
				e = "ERROR-MAT: Se esperaba que \'%s\'" % nombreVariable
				e += " fuese del tipo number."              
				print e
				sys.exit(1)
		else:
			tablaPadre = tablaSimb.padre
			verifica = True
			while (tablaPadre <> None) and verifica:
				if (tablaPadre.diccionario.has_key(nombreVariable) == True):
					tipoVariable = tablaPadre.diccionario[nombreVariable]
					if tipoVariable <> "number":
						e = "ERROR-MAT: Se esperaba que \'%s\'" % nombreVariable
						e += " fuese del tipo \'number\'."              
						print e
						sys.exit(1)
					else:
						verifica = False
				else:
					tablaPadre = tablaPadre.padre

			if tablaPadre == None:          
				if (nombreVariable <> "number" and nombreVariable <> "boolean"):
					e = "ERROR-MAT: La variable \'%s\' no esta declarada."
					print e % nombreVariable
					sys.exit(1)
				elif nombreVariable == "number":
					e = "" 
				else:       
					e = "ERROR-MAT: La expresion tiene el" 
					e += " tipo \'%s\' y se " % nombreVariable 
					e += "esperaba el tipo \'number\'."             
					print e
					sys.exit(1)

	def imprimir(self,espacio,tablaSimb):
		pass

	def chequear(self,tablaSimb):
		e = "ERROR-MAT: La matriz no esta bien formada, dimensiones incorrectas."
		
		# Cuenta el numero de filas y columnas
		if (":" in self.valor and "," in self.valor):
			if self.valor[1] == ":":
				print e
				sys.exit(1)

			if self.valor[1] == ",":
				c = 1
				r = 1
				i = 3
				aux_c = 0
				while (i < len(self.valor)):
					if (self.valor[i] == ","):
						c += 1
					elif (self.valor[i] == ":"):
						c += 1
						r += 1
						if (aux_c == 0):
							aux_c = c
							c = 0

							if (i + (aux_c + (aux_c - 1))) > len(self.valor):
								print e
								sys.exit(1)
						else:
							if (aux_c == c):
								c = 0
								if (i + (aux_c + (aux_c - 1))) > len(self.valor):
									print e
									sys.exit(1)
							else:
								print e
								sys.exit(1)
					i += 2
				c += 1
				if (aux_c <> c):
					print e
					sys.exit(1)
				self.setCol(c)
				self.setRow(r)

		# Cuenta el numero de filas
		elif ":" in self.valor:
			i = 0
			contador = 0
			while i < len(self.valor):
				contador = contador + 1
				i = i + 2
			self.setCol(1)
			self.setRow(contador)   

		# Cuenta el numero de columnas
		elif "," in self.valor:     
			i = 0
			contador = 0
			while i < len(self.valor):
				contador = contador + 1
				i = i + 2
			self.setCol(contador)
			self.setRow(1)

		# Verifico que todos los argumentos sean number
		i = 0
		while i < len(self.valor):
			self.verificarArg(self.valor[i],tablaSimb)
			i = i + 2

		return self.type

	def verificarIdentificador(self,ident,tabla):
		maximo = len(tabla) - 1

		if isinstance(ident,Identificador.Identificador):
			dicc_Actual = tabla[maximo]
			nombreVariable = ident.nombre
			while (maximo >= 0):				
				if dicc_Actual.has_key(nombreVariable) == True:					
					return dicc_Actual[nombreVariable]
					break
				maximo = maximo - 1
				dicc_Actual = tabla[maximo]


	def ejecutar(self,tabla,dicc):

		nuevaMatriz = []

		if (":" in self.valor and "," in self.valor):
			i = 0
			j = 1
			nuevo = []

			while i < len(self.valor):

				if self.valor[j] == ",":
					if isinstance(self.valor[i],Expresion_Binaria.Expresion_Binaria):
						value = self.valor[i].ejecutar(tabla,dicc)
					elif isinstance(self.valor[i],Identificador.Identificador):
						value = self.verificarIdentificador(self.valor[i],tabla)
					else:
						try:
							value = int(self.valor[i].retornaValor())
						except ValueError:
							value = float(self.valor[i].retornaValor())	
					nuevo.append(value)
					if (j + 1) >= (len(self.valor) - 1):
						nuevaMatriz.append(nuevo)
				elif self.valor[j] == ":":
					nuevaMatriz.append(nuevo)
					if isinstance(self.valor[i],Expresion_Binaria.Expresion_Binaria):
						value = self.valor[i].ejecutar(tabla,dicc)
					elif isinstance(self.valor[i],Identificador.Identificador):
						value = self.verificarIdentificador(self.valor[i],tabla)
					else:
						try:
							value = int(self.valor[i].retornaValor())
						except ValueError:
							value = float(self.valor[i].retornaValor())	
					nuevo = [value]
				if (j + 1) < len(self.valor):
					j = i + 1
				else:
					nuevaMatriz.append(nuevo)

				i = i + 2

		# Cuenta el numero de filas
		elif ":" in self.valor:
			i = 0
			while i < len(self.valor):
				nuevo = []
				
				if isinstance(self.valor[i],Expresion_Binaria.Expresion_Binaria):
					value = self.valor[i].ejecutar(tabla,dicc)
				elif isinstance(self.valor[i],Identificador.Identificador):
						value = self.verificarIdentificador(self.valor[i],tabla)
				else:
					try:
						value = int(self.valor[i].retornaValor())
					except ValueError:
						value = float(self.valor[i].retornaValor())

				nuevo.append(value)
				nuevaMatriz.append(nuevo)
				i = i + 2

		# Cuenta el numero de columnas
		elif "," in self.valor:
			i = 0
			nuevo = []
			while i < len(self.valor):
				if isinstance(self.valor[i],Expresion_Binaria.Expresion_Binaria):
					value = self.valor[i].ejecutar(tabla,dicc)
					nuevo.append(value)
				elif isinstance(self.valor[i],Identificador.Identificador):					
					value = self.verificarIdentificador(self.valor[i],tabla)
					nuevo.append(value)
				else:
					try:
						value = int(self.valor[i].retornaValor())
					except ValueError:
						value = float(self.valor[i].retornaValor())
					nuevo.append(value)
				i = i + 2

			nuevaMatriz.append(nuevo)
		else:
			nuevo = []
			i = 0
			if isinstance(self.valor[i],Expresion_Binaria.Expresion_Binaria):
				value = self.valor[i].ejecutar(tabla,dicc)
				nuevo.append(value)
			elif isinstance(self.valor[i],Identificador.Identificador):
				value = self.verificarIdentificador(self.valor[i],tabla)
				nuevo.append(value)
			else:
				try:
					value = int(self.valor[i].retornaValor())
				except ValueError:
					value = float(self.valor[i].retornaValor())
				nuevo.append(value)

			nuevaMatriz.append(nuevo)
		return nuevaMatriz

	def inicializarMatriz(self,fila,columna):
		 
		nuevaMatriz = []
		if fila <> 1 and columna <> 1:
			i = 0
			while i < fila:
				j = 0
				nuevo = []
				while j < columna:
					nuevo.append(0)         
					j = j + 1
				nuevaMatriz.append(nuevo)
				i = i + 1
			return nuevaMatriz
		 
		elif columna == 1:
			i = 0
			while i < fila:
				nuevo = []
				nuevo.append(0)
				nuevaMatriz.append(nuevo)
				i = i + 1
			return nuevaMatriz
	 
		elif fila == 1:
			i = 0
			nuevo = []
			while i < columna:
				nuevo.append(0)
				i = i + 1      
			nuevaMatriz.append(nuevo)
			return nuevaMatriz
	 
		elif fila == 1 and columna == 1:
			return [[0]]

# END Matriz.py
