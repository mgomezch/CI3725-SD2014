################################################################################
#                             CADENA DE CARACTERES                             #
################################################################################

class Cadena_Caracteres:

	def __init__(self,valor):
		self.valor = valor
		self.type = "caracter"
	
	def imprimir(self,espacio,tablaSimb):
		pass

	def chequear(self,tablaSimb):
		return self.valor	

	def retornaValor(self):
		return self.valor	

# END Cadena_Caracteres.py
