################################################################################
#                                    MATRIX                                    #
#                                 matrix(r, c)                                 #
#                             row(r) = matrix(r,1)                             #
#                             col(c) = matrix(1,c)                             #
################################################################################

import sys
import Literal_Numerico

class Matrix:

	def __init__(self,r,c):
		self.r = r
		self.c = c
		self.type = "matrix"		

	def imprimir(self,espacio,tablaSimb):
		pass

	def chequear(self,tablaSimb):
		e = "ERROR-MATRIX: Los valores tienen que ser mayores que cero."
		f = "ERROR-MATRIX: Los valores tienen que ser enteros."

		if isinstance(self.r,Literal_Numerico.Literal_Numerico):
			if self.r.retornaValor() <= 0:
				print e
				sys.exit(1)
		else:
			if self.r <= 0:
				print e
				sys.exit(1)

		if isinstance(self.c,Literal_Numerico.Literal_Numerico):
			if self.c.retornaValor() <= 0:
				print e
				sys.exit(1)
		else:
			if self.c <= 0:
				print e
				sys.exit(1)

		if isinstance(self.r,Literal_Numerico.Literal_Numerico):
			if not(isinstance(self.r.retornaValor(), int)):
				print f
				sys.exit(1)

		if isinstance(self.c,Literal_Numerico.Literal_Numerico):
			if not(isinstance(self.c.retornaValor(), int)):
				print f
				sys.exit(1)

		return self.type

# END Matrix.py
