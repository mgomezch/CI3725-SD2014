################################################################################
#                                     PRINT                                    #
#                               print <expresion>                              #
################################################################################

import sys
import Cadena_Caracteres
import Matriz
import Literal_Numerico
import Booleano
import Identificador
import Expresion_Binaria
import Vector
from Program_End import *

class Print:

	def __init__(self,expresion):
		self.expresion = expresion

	def imprimir(self,espacio,tablaSimb):
		pass

	def chequear(self,tablaSimb):
		for i in self.expresion:
			tipoExp = i.chequear(tablaSimb)

			if i.type == "id":
				if (tablaSimb.diccionario.has_key(tipoExp) == True):
					break
				else:
					tablaPadre = tablaSimb.padre
					verifica = True
					while (tablaPadre <> None) and verifica:
						if (tablaPadre.diccionario.has_key(tipoExp) == True):
							verifica = False
						else:
							tablaPadre = tablaPadre.padre
					if tablaPadre == None:
						e = "ERROR-PRINT: La variable \'%s\' no esta declarada."
						print e % tipoExp
						sys.exit(1)

	def ejecutar(self,tabla,dicc):

		maximo = len(tabla) - 1

		for i in self.expresion:
			
			if isinstance(i,Cadena_Caracteres.Cadena_Caracteres):							

				if i.retornaValor().find('\\n') == -1:
					print i.retornaValor(),
				else:
					j = i.retornaValor().replace('\\n', '\n')
					print j,

			elif isinstance(i,Vector.Vector):
				valor1 = i.ejecutar(tabla,dicc)

				if isinstance(valor1,int):
					print valor1,
				
				elif isinstance(valor1,float):
					print valor1,
			
			elif isinstance(i,Literal_Numerico.Literal_Numerico):
				print i.retornaValor(),

			elif isinstance(i,Expresion_Binaria.Expresion_Binaria):
				valor1 = i.ejecutar(tabla,dicc)
				if isinstance(valor1,int):
					print valor1,
				
				elif isinstance(valor1,float):
					print valor1,

				elif valor1 == "true" or valor1 == "false":
					print valor1,

				else:
					X = valor1
					k = 0
					while  k < len(X):
						j = 0
						print "|",
						while j < len(X[k]):
							print X[k][j], "",
							j = j + 1
						k = k + 1
						print "|"
						
			elif isinstance(i,Matriz.Matriz):
				X = i.ejecutar(tabla,dicc)
				k = 0
				while  k < len(X):
					j = 0
					print "|",
					while j < len(X[k]):
						print X[k][j], "",
						j = j + 1
					k = k + 1
					print "|"
					
			elif isinstance(i,Booleano.Booleano):
				print i.retornaValor(),
			
			elif isinstance(i,Identificador.Identificador):
				
				dicc_Actual = tabla[maximo]
				while (maximo >= 0):
					if dicc_Actual.has_key(i.ejecutar(tabla,dicc)) == True:	
						valor1 = dicc_Actual[i.ejecutar(tabla,dicc)]
						break
					maximo = maximo - 1
					dicc_Actual = tabla[maximo]

				if isinstance(valor1,int):
					print valor1,
				
				elif isinstance(valor1,float):
					print valor1,

				elif isinstance(valor1,str):
					print valor1,					

				elif valor1 == "true" or valor1 == "false":
					print valor1,

				else:
					X = valor1
					k = 0
					while  k < len(X):
						j = 0
						print "|",
						while j < len(X[k]):
							print X[k][j], "",
							j = j + 1
						k = k + 1
						print "|"


# END Print.py
