################################################################################
#                                 EXPRESION NOT                                #
#                                not <expresion>                               #
################################################################################

import sys

class Expresion_Not:

	def __init__(self,expresion):
		self.expresion = expresion
		self.type = "boolean"

	def imprimir(self,espacio,tablaSimb):
		pass

   	def chequear(self,tablaSimb):
   		nombreVariable = self.expresion.chequear(tablaSimb)

		if self.expresion.type == "exp_bin" or self.expresion.type == "llamada_func":
			tipoVariable = self.expresion.chequear(tablaSimb)
			if tipoVariable == "boolean":
	   			return self.type
			else:
				e = "ERROR-TRAS: Se esperaba que fuese "
				e += "de tipo \'boolean\'." 
				print e
				sys.exit(1)
		else:
			if (tablaSimb.diccionario.has_key(nombreVariable) == True):
	   			tipoVariable = tablaSimb.diccionario[nombreVariable]
	   			if tipoVariable <> "boolean":
	   				e = "ERROR-NOT: Se esperaba que \'%s\'" % nombreVariable
					e += " fuese del tipo \'boolean\'."				
					print e
					sys.exit(1)
	   			else:
					return self.type
	   		else:
	   			tablaPadre = tablaSimb.padre
				verifica = True
				while (tablaPadre <> None) and verifica:
					if (tablaPadre.diccionario.has_key(nombreVariable) == True):
						tipoVariable = tablaPadre.diccionario[nombreVariable]
			   			if tipoVariable <> "boolean":
			   				e = "ERROR-NOT: Se esperaba que \'%s\'" % nombreVariable
							e += " fuese del tipo \'boolean\'."				
							print e
							sys.exit(1)
			   			else:
							return self.type
							verifica = False
					else:
						tablaPadre = tablaPadre.padre

				if tablaPadre == None:
					if (nombreVariable <> "number" and nombreVariable <> "boolean"):
						e = "ERROR-NOT: La variable \'%s\' no esta declarada."
						print e % nombreVariable
						sys.exit(1)
					elif nombreVariable == "boolean":
						return self.type
					else:	
						e = "ERROR-NOT: La expresion tiene el" 
						e += " tipo \'%s\' y se " % nombreVariable 
						e += "esperaba el tipo \'boolean\'."				
						print e
						sys.exit(1)

	def ejecutar(self,tabla,dicc):
		if self.expresion.ejecutar(tabla,dicc) == "true":
			return "false"
		else:
			return "true"

# END Expresion_Not.py
