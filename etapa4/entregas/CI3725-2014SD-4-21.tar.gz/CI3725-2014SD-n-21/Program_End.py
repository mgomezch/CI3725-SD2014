################################################################################
#                              CLASS PROGRAM END                               #
#                      <funciones> program <bloque> end;                       #
################################################################################

import Tabla_Simbolos

Tabla_Valores = []
Tabla_Funciones = []

class Program_End:

	def __init__(self,bloque,funciones=None):
		self.funciones = funciones
		self.bloque = bloque
		
		tablaSimb = Tabla_Simbolos.Tabla_Simbolos(None)
		self.chequear(tablaSimb)

		# Imprime el programa
		# self.imprimir("",tablaSimb)

		self.ejecutar(Tabla_Valores,{})
		
	def imprimir(self,espacio,tablaSimb):
		if self.funciones:
			for i in self.funciones:
				for k in tablaSimb.hijos:
					nombreTabla = k.getNombre()
					nombreFuncion = i.dev_id().chequear(tablaSimb)
					if nombreTabla == nombreFuncion:
						i.imprimir(espaciacion(espacio),k)
		print "- Alcance _main: "
		print espacio, "    Simbolos: []"
		
		self.bloque.imprimir(espaciacion(espacio),tablaSimb)

	def chequear(self,tablaSimb):
		if self.funciones:			
			for i in self.funciones:
				i.chequear(tablaSimb)

		if self.bloque <> [None]:
			if self.bloque <> "VACIO":
				for i in self.bloque:
					i.chequear(tablaSimb)

	def ejecutar(self,tabla,dicc):

		if self.funciones:			
			for i in self.funciones:
				i.ejecutar(Tabla_Funciones,dicc)

		
		if self.bloque <> [None]:
			if self.bloque <> "VACIO":
				for i in self.bloque:
					i.ejecutar(Tabla_Valores,dicc)


		#print Tabla_Funciones


# END Program_End.py
