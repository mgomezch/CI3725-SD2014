################################################################################
#                              CLASS USE IN END                                #
#                 use <declaraciones> in <instrucciones> end;                  #
################################################################################

import Tabla_Simbolos
from Program_End import *
import Return

class Use_In_End:

	def __init__(self,declaraciones,instruccion=None):
		self.declaraciones = declaraciones
		self.instruccion = instruccion

	def imprimir(self,espacio,tablaSimb):

		if tablaSimb.hijos <> []:
			espacio2 = "" + espacio
			print  espacio2, "Hijos:"

			global count
			count = count + 1
			print espacio2, " - Alcance ", count

			print espacio2, "    Simbolos:"


			for i in self.declaraciones:
				i.imprimir(espaciacion(espacio2),tablaSimb)

			for k in self.instruccion:
				k.imprimir(espaciacion(espacio2),tablaSimb)
		else:
			espacio2 = "" + espacio
			print  espacio2, "Hijos: []"


	def chequear(self,tablaSimb):
		
		tabNueva = Tabla_Simbolos.Tabla_Simbolos(tablaSimb)
		tablaSimb.enlazarHijo(tabNueva)


		if self.declaraciones <> "VACIO":
			for i in self.declaraciones:			
				i.chequear(tabNueva)

		if self.instruccion:			
			for i in self.instruccion:
				if i <> None:							
					i.chequear(tabNueva)

	def ejecutar(self,tabla,dicc_Aux):
 		dicc_Aux = {}

		tabla.append(dicc_Aux)

		if self.declaraciones <> "VACIO":

			for i in self.declaraciones:			
				prueba1 = i.ejecutar(tabla,dicc_Aux)
		
		if self.instruccion:	
			for i in self.instruccion:
				if i <> None:							
					if isinstance(i,Return.Return):									
						return i.ejecutar(tabla,dicc_Aux)
					else:
						i.ejecutar(tabla,dicc_Aux)

		tabla.remove(dicc_Aux)


# END Use_In_End.py
