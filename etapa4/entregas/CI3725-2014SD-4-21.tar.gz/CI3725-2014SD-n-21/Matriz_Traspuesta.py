################################################################################
#                              MATRIZ TRASPUESTA                               #
#                            <matriz, row o column>'                           #
################################################################################

import sys
import Matriz
import Identificador
import Llamada_Funcion
import Expresion_Binaria
import Expresion_Negativo
from Program_End import *

class Matriz_Traspuesta:
	
	def __init__(self,valor):		
		self.col = 1
		self.row = 1
		self.type = "matrix"

		if isinstance(valor,Matriz.Matriz):	
		 	self.identificador = "no_id"
		else:
		 	self.identificador = "id"
		 
		self.valor = valor
		
	def imprimir(self,espacio,tablaSimb):
		pass
		
	def retornaValor(self):
		return self.valor

	def setValor(self,valor):
		self.valor = valor

	def getCol(self):
		return self.col

	def getRow(self):
		return self.row

	def setCol(self,columna):
		self.col = columna

	def setRow(self,fila):
		self.row = fila

	def separarlista(self,valor):
		lista =[]
		aux = []
		tam = len(valor)

		i = 0
		while i < tam:
			if valor[i] == ":":
				lista.append(aux)
				aux = []		
			else:
				aux.append(valor[i])
			i = i + 1
		lista.append(aux)

		return lista

	def traspuesta(self,valor):
		if ":" in valor and "," in valor:
			listanueva = self.separarlista(valor)
			tam = len(listanueva)
			i = 0

			tras = []
			filas = []
			tam_lista = len(listanueva[0])

			i = 0
			while i < tam_lista:
				j = 0
				while j < tam:
					aux = listanueva[j][i]
					filas.append(aux)
					filas.append(",")
					j = j + 1
				filas.pop()
				tras.append(filas)
				filas = []
				i = i + 2 
			tam_tras = len(tras)
			tam_t = len(tras[0])
			k = 0	
			traspuesta = []
			while k < tam_tras:
				l = 0	
				while l < tam_t:
					traspuesta.append(tras[k][l])
					l = l + 1
				traspuesta.append(":")
				k = k + 1
			traspuesta.pop()

			return traspuesta

		elif ":" in valor:
			i = 0
			while (i < len(valor)):
				if valor[i] == ":":
					valor[i] = ","
				i += 1
			return valor
		
		elif "," in valor:
			i = 0
			while (i < len(valor)):
				if valor[i] == ",":
					valor[i] = ":"
				i += 1
			return valor
		else:
			return valor
				
	def verificarArg(self,i,tablaSimb):
		nombreVariable = i.chequear(tablaSimb)

		if (tablaSimb.diccionario.has_key(nombreVariable) == True):
   			tipoVariable = tablaSimb.diccionario[nombreVariable]
   			if tipoVariable <> "number":
   				e = "ERROR-TRAS: Se esperaba que \'%s\'" % nombreVariable
				e += " fuese del tipo number."				
				print e
				sys.exit(1)
   		else:
   			tablaPadre = tablaSimb.padre
			verifica = True
			while (tablaPadre <> None) and verifica:
				if (tablaPadre.diccionario.has_key(nombreVariable) == True):
					tipoVariable = tablaPadre.diccionario[nombreVariable]
		   			if tipoVariable <> "number":
		   				e = "ERROR-TRAS: Se esperaba que \'%s\'" % nombreVariable
						e += " fuese del tipo number."				
						print e
						sys.exit(1)
		   			else:
						verifica = False
				else:
					tablaPadre = tablaPadre.padre

			if tablaPadre == None:	   		
				if (nombreVariable <> "number" and nombreVariable <> "boolean"):
					e = "ERROR-TRAS: La variable \'%s\' no esta declarada."
					print e % nombreVariable
					sys.exit(1)
				elif nombreVariable == "number":
					e = ""
				else:		
					e = "ERROR-TRAS: La expresion tiene el" 
					e += " tipo \'%s\' y se " % nombreVariable 
					e += "esperaba el tipo number."				
					print e
					sys.exit(1)


	def verificarMatriz(self,tablaSimb):
		e = "ERROR-TRAS: La matriz no esta bien formada, dimensiones incorrectas."

		# Cuenta el numero de filas y columnas
		if (":" in self.valor and "," in self.valor):
			if self.valor[1] == ":":
				print e
				sys.exit(1)

			if self.valor[1] == ",":
				c = 1
				r = 1
				i = 3
				aux_c = 0
				while (i < len(self.valor)):
					if (self.valor[i] == ","):
						c += 1
					elif (self.valor[i] == ":"):
						c += 1
						r += 1
						if (aux_c == 0):
							aux_c = c
							c = 0

							if (i + (aux_c + (aux_c - 1))) > len(self.valor):
								print e
								sys.exit(1)
						else:
							if (aux_c == c):
								c = 0
								if (i + (aux_c + (aux_c - 1))) > len(self.valor):
									print e
									sys.exit(1)
							else:
								print e
								sys.exit(1)
					i += 2
				c += 1
				if (aux_c <> c):
					print e
					sys.exit(1)

				self.setCol(c)
				self.setRow(r)
				
		# Cuenta el numero de filas
		elif ":" in self.valor:
			i = 0
			contador = 0
			while i < len(self.valor):
				contador = contador + 1
				i = i + 2
			self.setCol(1)
			self.setRow(contador)	

		# Cuenta el numero de columnas
		elif "," in self.valor:		
			i = 0
			contador = 0
			while i < len(self.valor):
				contador = contador + 1
				i = i + 2
			self.setCol(contador)
			self.setRow(1)

		# Verifico que todos los argumentos sean number
		i = 0
		while i < len(self.valor):
			self.verificarArg(self.valor[i],tablaSimb)
			i = i + 2


	def chequear(self,tablaSimb):
		
		if isinstance(self.valor,Expresion_Binaria.Expresion_Binaria):
			tipoVariable = self.valor.chequear(tablaSimb)	
			if tipoVariable <> "boolean" and tipoVariable <> "number":				
				self.setRow(tipoVariable[2])
				self.setCol(tipoVariable[1])
	   			return self.type
			else:
				e = "ERROR-TRAS: Se esperaba que fuese "
				e += "de tipo \'matriz\', \'row\' o \'column\'." 
				print e
				sys.exit(1)
		elif isinstance(self.valor,Llamada_Funcion.Llamada_Funcion):
			tipoVariable = self.valor.chequear(tablaSimb)

			if tipoVariable <> "boolean" and tipoVariable <> "number":
				self.setRow(tipoVariable[2])
				self.setCol(tipoVariable[1])
	   			return self.type
			else:
				e = "ERROR-TRAS: Se esperaba que fuese "
				e += "de tipo \'matriz\', \'row\' o \'column\'." 
				print e
				sys.exit(1)
		else:
			if self.identificador == "no_id":
				if isinstance(self.valor,Matriz_Traspuesta):
					self.valor.chequear(tablaSimb)					
				elif isinstance(self.valor,Matriz.Matriz):
					tras = self.traspuesta(self.valor.retornaValor())
					self.setValor(tras)
					self.verificarMatriz(tablaSimb)
				return self.type

			elif self.identificador == "id":
				nombreVariable = self.valor.chequear(tablaSimb)

				if isinstance(self.valor,Expresion_Negativo.Expresion_Negativo):
					nombreVariable = self.valor.chequear(tablaSimb)[0]

	   			if (tablaSimb.diccionario.has_key(nombreVariable) == True):

	   				tipoVariable = tablaSimb.diccionario[nombreVariable]   				
	   				if tipoVariable <> "boolean" and tipoVariable <> "number":
						self.setRow(tipoVariable[2])
						self.setCol(tipoVariable[1])
	   					return self.type
	   				else:
	   					e = "ERROR-TRAS: Se esperaba que el identificador \'%s\' fuese "
	   					e += "de tipo \'matriz\', \'row\' o \'column\'." 
						print e % self.valor.nombre
						sys.exit(1)
	   			else:
	   				tablaPadre = tablaSimb.padre
					verifica = True
					while (tablaPadre <> None) and verifica:
						if (tablaPadre.diccionario.has_key(nombreVariable) == True):
							tipoVariable = tablaPadre.diccionario[nombreVariable]   				
			   				if tipoVariable <> "boolean" and tipoVariable <> "number":
			   					self.setRow(tipoVariable[2])
								self.setCol(tipoVariable[1])
			   					return self.type
			   				else:
			   					e = "ERROR-TRAS: Se esperaba que el identificador \'%s\' fuese "
			   					e += "de tipo \'matriz\', \'row\' o \'column\'." 
								print e % self.valor.nombre
								sys.exit(1)
							verifica = False
						else:
							tablaPadre = tablaPadre.padre
					if tablaPadre == None:

	
						if isinstance(self.valor,Matriz_Traspuesta):
							self.valor.chequear(tablaSimb)
						else:
							if isinstance(self.valor,Identificador.Identificador):
								msg = "ERROR-TRAS: La variable \'%s\' no esta declarada."
								e = msg % self.valor.nombre
								print e
								sys.exit(1)
							else:
								e = "ERROR-TRAS: Se esperaba que fuese "
			   					e += "de tipo \'matriz\', \'row\' o \'column\'." 
								print e
								sys.exit(1)
	
	
	def verificarIdentificador(self,ident,tabla):
		maximo = len(tabla) - 1
		if isinstance(ident,Identificador.Identificador):
			dicc_Actual = tabla[maximo]
			nombreVariable = ident.nombre
			while (maximo >= 0):				
				if dicc_Actual.has_key(nombreVariable) == True:					
					return dicc_Actual[nombreVariable]
					break
				maximo = maximo - 1
				dicc_Actual = tabla[maximo]


	def matrizPython(self,dicc,tabla):
		nuevaMatriz = []

		if (":" in self.valor and "," in self.valor):
			i = 0
			j = 1
			nuevo = []

			while i < len(self.valor):

				if self.valor[j] == ",":
					if isinstance(self.valor[i],Expresion_Binaria.Expresion_Binaria):
						value = self.valor[i].ejecutar(dicc)
					elif isinstance(self.valor[i],Identificador.Identificador):
						value = self.verificarIdentificador(self.valor[i],tabla)
					else:
						try:
							value = int(self.valor[i].retornaValor())
						except ValueError:
							value = float(self.valor[i].retornaValor())	
					nuevo.append(value)
					if (j + 1) >= (len(self.valor) - 1):
						nuevaMatriz.append(nuevo)
				elif self.valor[j] == ":":
					nuevaMatriz.append(nuevo)
					if isinstance(self.valor[i],Expresion_Binaria.Expresion_Binaria):
						value = self.valor[i].ejecutar(dicc)
					elif isinstance(self.valor[i],Identificador.Identificador):
						value = self.verificarIdentificador(self.valor[i],tabla)
					else:
						try:
							value = int(self.valor[i].retornaValor())
						except ValueError:
							value = float(self.valor[i].retornaValor())	
					nuevo = [value]
				if (j + 1) < len(self.valor):
					j = i + 1
				else:
					nuevaMatriz.append(nuevo)

				i = i + 2

		# Cuenta el numero de filas
		elif ":" in self.valor:
			i = 0
			while i < len(self.valor):
				nuevo = []
				
				if isinstance(self.valor[i],Expresion_Binaria.Expresion_Binaria):
					value = self.valor[i].ejecutar(dicc)
				elif isinstance(self.valor[i],Identificador.Identificador):
						value = self.verificarIdentificador(self.valor[i],tabla)
				else:
					try:
						value = int(self.valor[i].retornaValor())
					except ValueError:
						value = float(self.valor[i].retornaValor())

				nuevo.append(value)
				nuevaMatriz.append(nuevo)
				i = i + 2

		# Cuenta el numero de columnas
		elif "," in self.valor:
			i = 0
			nuevo = []
			while i < len(self.valor):
				if isinstance(self.valor[i],Expresion_Binaria.Expresion_Binaria):
					value = self.valor[i].ejecutar(dicc)
					nuevo.append(value)
				elif isinstance(self.valor[i],Identificador.Identificador):
					value = self.verificarIdentificador(self.valor[i],tabla)
					nuevo.append(value)
				else:
					try:
						value = int(self.valor[i].retornaValor())
					except ValueError:
						value = float(self.valor[i].retornaValor())
					nuevo.append(value)
				i = i + 2

			nuevaMatriz.append(nuevo)

		return nuevaMatriz


	def traspose(self,matriz):
		return [list(x) for x in zip(*matriz)]

	def ejecutar(self,tabla,dicc):
		
		maximo = len(tabla) - 1
		if isinstance(self.valor,Identificador.Identificador):
			dicc_Actual = tabla[maximo]
			nombreVariable = self.valor.nombre
			while (maximo >= 0):				
				if dicc_Actual.has_key(nombreVariable) == True:					
					matriz = dicc_Actual[nombreVariable]					
					row = len(matriz)
					col = len(matriz[0])
					self.setCol(row)
					self.setRow(col)
					matriz = self.traspose(matriz)
					break
				maximo = maximo - 1
				dicc_Actual = tabla[maximo]
		elif isinstance(self.valor,Expresion_Binaria.Expresion_Binaria):
			matriz = self.valor.ejecutar(tabla,dicc)				
			row = len(matriz)
			col = len(matriz[0])
			self.setCol(row)
			self.setRow(col)
			matriz = self.traspose(matriz)
		elif isinstance(self.valor,Matriz_Traspuesta):
			matriz = self.valor.ejecutar(tabla,dicc)
			row = len(matriz)
			col = len(matriz[0])
			self.setCol(row)
			self.setRow(col)
			matriz = self.traspose(matriz)
		else:
			matriz = self.matrizPython(dicc,tabla)

		return matriz
# END Matriz_Traspuesta.py 
