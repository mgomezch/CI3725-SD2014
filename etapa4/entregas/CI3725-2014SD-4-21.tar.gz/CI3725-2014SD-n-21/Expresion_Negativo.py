################################################################################
#                                   NEGATIVO                                   #
#                               menos <expresion>                              #
################################################################################

import Matriz
import Matriz_Traspuesta
import sys
import Identificador
import Expresion_Binaria
import Vector
from Program_End import *

class Expresion_Negativo:

	def __init__(self,expresion):
		self.expresion = expresion
		self.type = ""

	def setType(self,tipo):
		self.type = tipo;

	def retornaValor(self):
		return self.expresion

	def imprimir(self,espacio,tablaSimb):
		pass

   	def chequear(self,tablaSimb):

   		nombreVariable = self.expresion.chequear(tablaSimb)
 
   		if isinstance(self.expresion,Expresion_Negativo):
			self.expresion.chequear(tablaSimb)
			return self.type

		if (tablaSimb.diccionario.has_key(nombreVariable) == True):
   			tipoVariable = tablaSimb.diccionario[nombreVariable]

   			if tipoVariable == "boolean":
   				e = "ERROR-NEG: Incompatibilidad con la negatividad."				
				print e
				sys.exit(1)
   			else:
   				self.setType(tipoVariable)
				return tipoVariable	
   		else:
   			tablaPadre = tablaSimb.padre
			verifica = True
			while (tablaPadre <> None) and verifica:
				if (tablaPadre.diccionario.has_key(nombreVariable) == True):
					tipoVariable = tablaPadre.diccionario[nombreVariable]
					if tipoVariable == "boolean":	
						print "ERROR-NEG: Incompatibilidad con la negatividad."
						sys.exit(1)
		 			else:
						verifica = False
						self.setType(tipoVariable)
						return tipoVariable					
				else:
					tablaPadre = tablaPadre.padre

			if tablaPadre == None:

	   			if nombreVariable == "boolean":			
					print "ERROR-NEG: Incompatibilidad con la negatividad."
					sys.exit(1)
				elif nombreVariable <> "number" and nombreVariable <> "boolean" and nombreVariable <> "matrix":
					e = "ERROR-NEG: La variable \'%s\' no esta declarada."
					print e % nombreVariable
					sys.exit(1)
				else:	
					if isinstance(self.expresion,Matriz.Matriz):
						r = self.expresion.getRow()
			   			c = self.expresion.getCol()
						tipo_exp = []
			   			tipo_exp.append(nombreVariable)
						tipo_exp.append(r)
						tipo_exp.append(c)
						self.setType(tipo_exp)
						return tipo_exp
					elif isinstance(self.expresion,Matriz_Traspuesta.Matriz_Traspuesta):
						r = self.expresion.getRow()
			   			c = self.expresion.getCol()
						tipo_exp = []
			   			tipo_exp.append(nombreVariable)
						tipo_exp.append(r)
						tipo_exp.append(c)
						self.setType(tipo_exp)
						return tipo_exp
					else:
						tipo_exp = nombreVariable
						self.setType(tipo_exp)
						return tipo_exp
	
	def ejecutar(self,tabla,dicc):
		
		maximo = len(tabla) - 1
		if isinstance(self.expresion,Identificador.Identificador):
			dicc_Actual = tabla[maximo]
			nombreVariable = self.expresion.nombre
			while (maximo >= 0):				
				if dicc_Actual.has_key(nombreVariable) == True:					
					valor = dicc_Actual[nombreVariable]
					break
				maximo = maximo - 1
				dicc_Actual = tabla[maximo]

			if isinstance(self.expresion,Expresion_Negativo):
				valor = self.expresion.ejecutar(tabla,dicc)

			return (-1)*valor

		elif isinstance(self.expresion,Expresion_Binaria.Expresion_Binaria):
			valor = self.expresion.ejecutar(tabla,dicc)

			if isinstance(self.expresion,Expresion_Negativo):
				valor = self.expresion.ejecutar(tabla,dicc)
			return (-1)*valor

		elif isinstance(self.expresion,Vector.Vector):
			valor = self.expresion.ejecutar(tabla,dicc)

			if isinstance(self.expresion,Expresion_Negativo):
				valor = self.expresion.ejecutar(tabla,dicc)				
			return (-1)*valor
		else:
			if isinstance(self.expresion,Expresion_Negativo):
				valor = self.expresion.ejecutar(tabla,dicc)
				return (-1)*valor				
			else:
				return (-1)*self.expresion.retornaValor()
				
# END Expresion_Negativo.py
		