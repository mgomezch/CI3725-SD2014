################################################################################
#                                     WHILE                                    #
#                  while <condicion> do <instrucciones> end;                   #
################################################################################

import sys
import Return

class Ciclo_While:

	def __init__(self,condicion,instruccion=None):
		self.condicion = condicion
		self.instruccion = instruccion

	def imprimir(self,espacio,tablaSimb):

		self.condicion.imprimir(espaciacion(espacio),tablaSimb)

		for i in self.instruccion:
			i.imprimir(espaciacion(espacio),tablaSimb)

	def chequear(self,tablaSimb):
		f = "ERROR-WHILE: Se esperaba que la condicion fuese de tipo \'boolean\'."

		if self.condicion.type == "id":
			nombreCond = self.condicion.chequear(tablaSimb)
			if (tablaSimb.diccionario.has_key(nombreCond) == True):
				tipoCond = tablaSimb.diccionario[nombreCond]
				if tipoCond <> "boolean":
					print f
					sys.exit(1)
			else:
				tablaPadre = tablaSimb.padre
				while (tablaPadre <> None):
					if (tablaPadre.diccionario.has_key(nombreCond) == True):
						tipoCond = tablaPadre.diccionario[nombreCond]
						if (tipoCond <> "boolean"):
							e = f
							print e
							sys.exit(1)
						else: 
							break
					else:
						tablaPadre = tablaPadre.padre

				if tablaPadre == None:
					e = "ERROR-WHILE: La variable \'%s\' no esta declarada." 
					print e % nombreCond
					sys.exit(1)

		elif self.condicion.type == "exp_bin":
			tipoExp = self.condicion.chequear(tablaSimb)
			if tipoExp <> "boolean":
				print f
				sys.exit(1)
		else:
			tipoExp = self.condicion.chequear(tablaSimb)
			if tipoExp <> "boolean":
				print f
				sys.exit(1)

		if self.instruccion:
			for i in self.instruccion:
				if i <> None:
					i.chequear(tablaSimb)

	def ejecutar(self,tabla,dicc):
		
		while self.condicion.ejecutar(tabla,dicc) == "true":
			if self.instruccion:
				for i in self.instruccion:
					if i <> None:
						if isinstance(i,Return.Return):									
							return i.ejecutar(tabla,dicc)
						else:
							i.ejecutar(tabla,dicc)


# END Ciclo_While.py
