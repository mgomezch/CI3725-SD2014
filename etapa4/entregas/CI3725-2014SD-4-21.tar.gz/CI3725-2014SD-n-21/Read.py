################################################################################
#                                     READ                                     #
#                                read <expresion>                              #
################################################################################

import sys
import Identificador
from Program_End import *

class Read:

	def __init__(self,identificador):
		self.identificador = identificador
		
	def imprimir(self,espacio,tablaSimb):
		pass

   	def chequear(self,tablaSimb):
   		nombreVariable = self.identificador.chequear(tablaSimb)

   		if (tablaSimb.diccionario.has_key(nombreVariable) == True):
   			tipoVariable = tablaSimb.diccionario[nombreVariable]

   			if tipoVariable <> "number" and tipoVariable <> "boolean":
   				e = "ERROR-READ: La variable \'%s\' no es de tipo "
   				e += "'number' o 'boolean'."
				print e % nombreVariable
				sys.exit(1)
   		else:
   			tablaPadre = tablaSimb.padre
			verifica = True
			while (tablaPadre <> None) and verifica:
				if (tablaPadre.diccionario.has_key(nombreVariable) == True):
					tipoVariable = tablaPadre.diccionario[nombreVariable]
		   			if tipoVariable <> "number" and tipoVariable <> "boolean":
		   				e = "ERROR-READ: La variable \'%s\' no es de tipo "
		   				e += "'number' o 'boolean."
						print e % nombreVariable
						sys.exit(1)
					verifica = False
				else:
					tablaPadre = tablaPadre.padre
			if tablaPadre == None:
				e = "ERROR-READ: La variable \'%s\' no esta declarada."
				print e % nombreVariable
				sys.exit(1)

	def ejecutar(self,tabla,dicc):

		nombre = raw_input()
		tipo = ""
		if nombre <> "true" and nombre <> "false":
			try:
				value = int(nombre)
				tipo = "number"			
			except ValueError:
				try:
					value = float(nombre)
					tipo = "number"
				except ValueError:
					print "ERROR-READ: El valor introducido debe ser de tipo \'boolean\' o de tipo \'number\'."
					sys.exit(1)
		else:
			tipo = "boolean"

		maximo = len(tabla) - 1

		if isinstance(self.identificador,Identificador.Identificador):
			dicc_Actual = tabla[maximo]
			while (maximo >= 0):
				if dicc_Actual.has_key(self.identificador.ejecutar(tabla,dicc)) == True:
					var = dicc_Actual[self.identificador.ejecutar(tabla,dicc)]
					tipo_var = ""
					if var == "true" or var == "false":
						tipo_var = "boolean"
					else:
						tipo_var = "number"			

					if tipo <> tipo_var:
						e = "ERROR-READ: Los valores no poseen el mismo tipo, "
						e+= "se esperaba el tipo \'%s\'." % tipo_var
						print e
						sys.exit(1)
					else:
						dicc_Actual[self.identificador.ejecutar(tabla,dicc)] = nombre

					break
				maximo = maximo - 1
				dicc_Actual = tabla[maximo]
		
# END Read.py
