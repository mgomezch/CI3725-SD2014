################################################################################
#                               LITERAL NUMERICO                               #
################################################################################

class Literal_Numerico:

	def __init__(self,valor):
		self.valor = valor
		self.type = "number"

	def retornaValor(self):
		return self.valor

	def imprimir(self,espacio,tablaSimb):
		pass

	def chequear(self,tablaSimb):
		return self.type

	def ejecutar(self,tabla,dicc):
		return self.valor

# END Literal_Numerico.py
