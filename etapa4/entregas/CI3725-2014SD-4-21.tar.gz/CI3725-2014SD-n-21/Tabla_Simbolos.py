################################################################################
#                              TABLA DE SIMBOLOS                               #
################################################################################ 

class Tabla_Simbolos:

	def __init__(self,padre):
		self.diccionario = {}
		self.hijos = []
		self.padre = padre
		self.nombre = ""

	def setNombre(self,nombre):
		self.nombre = nombre

	def getNombre(self):
		return self.nombre

	def insertarElem(self,nombreVar, tipo):
		self.diccionario[nombreVar] = tipo

	def enlazarHijo(self,hijo):
		self.hijos.append(hijo)

# END Tabla_Simbolos.py
