################################################################################
#                     CLASES PARA EL ANALIZADOR SINTACTICO                     #
################################################################################
import sys

count = -1 # Contador de alcance

#
# Funcion que se encarga de la espaciacion adecuada para la impresion
#
def espaciacion(espacio):
	i = 0
	while (i < 4):
		espacio += " "
		i += 1
	return espacio


# END Clases.py
