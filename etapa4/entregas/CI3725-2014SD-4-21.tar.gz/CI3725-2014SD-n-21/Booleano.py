################################################################################
#                                   BOOLEANO                                   #
################################################################################

class Booleano:

	def __init__(self,valor):
		self.valor = valor
		self.type = "boolean"

	def imprimir(self,espacio,tablaSimb):
		pass

	def chequear(self,tablaSimb):
		return self.type

	def ejecutar(self,tabla,dicc):
		return self.valor

	def retornaValor(self):
		return self.valor


# END Booleano.py
