################################################################################
#                                    FUNCION                                   #
#             function <identificador>(<parametros>) return <tipo>             #
#                begin <instrucciones> [return <expresion>] end;               #
################################################################################

import Tabla_Simbolos
from Program_End import *
import sys
import Return

class Funcion:

	def __init__(self,identificador,parametros,tipo,instruccion=None):
		self.identificador = identificador
		self.parametros = parametros
		self.tipo = tipo
		self.instruccion = instruccion

	def imprimir(self,espacio,tablaSimb):
		nombreFuncion = self.identificador.chequear(tablaSimb)
		print "- Alcance: ", nombreFuncion

		print espacio,"Simbolos:"
		for i in self.parametros:			
	 		i.imprimir(espaciacion(espacio),tablaSimb)

		for i in self.instruccion:
		 	i.imprimir(espaciacion(espacio),tablaSimb)

	def dev_id(self):
		return self.identificador

	def chequear(self,tablaSimb):
		tabNueva = Tabla_Simbolos.Tabla_Simbolos(tablaSimb)
		tablaSimb.enlazarHijo(tabNueva)
		tabNueva.setNombre(self.identificador.chequear(tablaSimb))
		
		nombreVariable = self.identificador.chequear(tablaSimb)

		# Se verifica que no haya otra funcion con el mismo nombre
		if (tablaSimb.diccionario.has_key(nombreVariable) == True):
			e = "ERROR-FUNC: La funcion \'%s\' ya fue declarada." 
			print e % nombreVariable
			sys.exit(1)
		else:
			# Variable que nos guardara en el diccionario el nombre de la funcion
			# y sus parametros
			parametros = ["function"]			

			if (self.tipo <> "number") and (self.tipo <> "boolean") and (self.tipo <> "matrix"):
				tipo_r = []

				tipo_return = self.tipo.chequear(tabNueva)
				if not(isinstance(self.tipo.r, int)):
					tipo_fila = int(self.tipo.r.valor)
					if (isinstance(self.tipo.c, int)): 
						tipo_columna = self.tipo.c
				if not(isinstance(self.tipo.c, int)):
					tipo_columna = int(self.tipo.c.valor)
					if isinstance(self.tipo.r, int):
						tipo_fila = self.tipo.r
				tipo_r.append(tipo_return)
				tipo_r.append(tipo_fila)
				tipo_r.append(tipo_columna)
				parametros.append(tipo_r)
			else:
				tipo_return = self.tipo
				parametros.append(tipo_return)

			if self.parametros <> "VACIO":
				for i in self.parametros:		
					parametros.append(i.chequear(tabNueva))

			tablaSimb.insertarElem(nombreVariable,parametros)
			tabNueva.insertarElem(nombreVariable,parametros)

			if self.instruccion:
				for i in self.instruccion:
					i.chequear(tabNueva)

	def ejecutar(self,tabla,dicc):

		nombre_funcion = self.identificador.nombre
		dicc_Aux = {}

		#tabla.append(dicc_Aux)

		dicc_Aux[nombre_funcion] = self.instruccion

		if self.parametros <> "VACIO":
			dicc_Aux["parametros"] = self.parametros

		tabla.append(dicc_Aux)
		
# END Funcion.py		
