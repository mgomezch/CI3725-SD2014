################################################################################
#                                    VECTOR                                    #
#                      <expresion>[i,j] o <expresion>[i]                       #
################################################################################

import sys
from Program_End import *
import Identificador
import Literal_Numerico

class Vector:

	def __init__(self,identificador,i,j=None):
		self.identificador = identificador
		self.i = i
		self.j = j
		self.type = "number"

	def imprimir(self,espacio,tablaSimb):
		pass

	def verificar(self,i,tablaSimb):

		nombreVariable = i.chequear(tablaSimb)

		if (tablaSimb.diccionario.has_key(nombreVariable) == True):
   			tipoVariable = tablaSimb.diccionario[nombreVariable]
   			if tipoVariable <> "number":
   				e = "ERROR-VEC: Se esperaba que \'%s\'" % nombreVariable
				e += " fuese del tipo \'number\'."				
				print e
				sys.exit(1)
   			else:
				return self.type
   		else:
   			tablaPadre = tablaSimb.padre
			verifica = True
			while (tablaPadre <> None) and verifica:
				if (tablaPadre.diccionario.has_key(nombreVariable) == True):
					tipoVariable = tablaPadre.diccionario[nombreVariable]
		   			if tipoVariable <> "number":
		   				e = "ERROR-VEC: Se esperaba que \'%s\'" % nombreVariable
						e += " fuese del tipo \'number\'."				
						print e
						sys.exit(1)
		   			else:
		   				verifica = False
						return self.type						
				else:
					tablaPadre = tablaPadre.padre

			if tablaPadre == None:				
		   		if (nombreVariable <> "number"):	
		   			if nombreVariable <> "boolean":
						print "ERROR-VEC: La variable \'%s\' no esta declarada." % nombreVariable
						sys.exit(1)
		   			else:	
						e = "ERROR-VEC: La expresion tiene el" 
						e += " tipo \'%s\' y se " % nombreVariable 
						e += "esperaba el tipo \'number\'."				
						print e
						sys.exit(1)
				else:
					return self.type


	def verificarVector(self,row,col,tablaSimb):

		if self.j:
			if self.j.type == "matrix" or self.j.type == "boolean":
				e = "ERROR-VEC: Se esperaba que j fuese "
				e += "de tipo \'number\'." 
				print e
				sys.exit(1)

		if self.i.type == "matrix" or self.i.type == "boolean":
			e = "ERROR-VEC: Se esperaba que i fuese "
			e += "de tipo \'number\'." 
			print e
			sys.exit(1)

		if self.i.type == "id":
			tipo_i = self.verificar(self.i,tablaSimb)

			if self.j:
				if self.j.type == "id":
					self.verificar(self.j,tablaSimb)
				elif self.j.type == "exp_bin":
					tipo_bin_j = self.j.chequear(tablaSimb)

					if tipo_bin_j == "number":
						return "number"
					else:
						e = " ERROR-VEC: La expresion tiene el"
						e += " tipo \'%s\', y se " % tipo_bin_j
						e += "esperaba el tipo \'number\'."				
						print e
						sys.exit(1)
				else:
					j = int(self.j.retornaValor())

					if self.j:							
						if (j <= 0):								
							e = "ERROR-VEC: Valores no validos, e[i,j] i y j "
							e += "tienen que ser mayor a cero."
							print e
							sys.exit(1)
						else:
							if (j > col):							
								e = "ERROR-VEC: e[i,j] Valores no validos para la matriz."
								print e
								sys.exit(1)
			return "number"

		elif self.i.type == "exp_bin":
			tipo_bin_i = self.i.chequear(tablaSimb)

			if tipo_bin_i == "number":				
				if self.j:
					if self.j.type == "id":
						self.verificar(self.j,tablaSimb)
					elif self.j.type == "exp_bin":
						tipo_bin_j = self.j.chequear(tablaSimb)

						if tipo_bin_j == "number":
							return "number"
						else:
							e = " ERROR-VEC: La expresion tiene el"
							e += " tipo \'%s\', y se " % tipo_bin_j
							e += "esperaba el tipo \'number\'."				
							print e
							sys.exit(1)
					else:
						j = int(self.j.retornaValor())

						if self.j:							
							if (j <= 0):								
								e = "ERROR-VEC: Valores no validos, e[i,j] i y j "
								e += "tienen que ser mayor a cero."
								print e
								sys.exit(1)
							else:
								if (j > col):							
									e = "ERROR-VEC: e[i,j] Valores no validos para la matriz."
									print e
									sys.exit(1)			
			else:
				e = " ERROR-VEC: La expresion tiene el"
				e += " tipo \'%s\', y se " % tipo_bin_i
				e += "esperaba el tipo \'number\'."				
				print e
				sys.exit(1)

			return "number"

		else: # i no es exp_bin

			if self.j:
				if self.j.type == "id":
					self.verificar(self.j,tablaSimb)
					i = int(self.i.retornaValor())
					if (i <= 0):								
						e = "ERROR-VEC: Valor no valido, e[i,j] i y j "
						e += "tienen que ser mayor a cero."
						sys.exit(1)
					else:													
						if (i > row):									
							e = "ERROR-VEC: e[i,j] Valores no validos para la matriz."
							print e
							sys.exit(1)

				elif self.j.type == "exp_bin":
					tipo_bin_j = self.j.chequear(tablaSimb)

					i = int(self.i.retornaValor())
					if (i <= 0):								
						e = "ERROR-VEC: Valor no valido, e[i,j] i y j "
						e += "tienen que ser mayor a cero."
						sys.exit(1)
					else:													
						if (i > row):									
							e = "ERROR-VEC: e[i,j] Valor no valido para la matriz."
							print e
							sys.exit(1)

					if tipo_bin_j == "number":
						return "number"
					else:
						e = " ERROR-VEC: La expresion tiene el"
						e += " tipo \'%s\', y se " % tipo_bin_j
						e += "esperaba el tipo \'number\'."				
						print e
						sys.exit(1)
				else:
					if not(isinstance(self.i,Vector)):
						i = int(self.i.retornaValor())
						
						if self.j:
							if isinstance(self.j,Vector):
								self.j.chequear(tablaSimb)	
							else:								
								j = int(self.j.retornaValor())					
								if (i <= 0 or j <= 0):								
									e = "ERROR-VEC: Valores no validos, e[i,j] i y j "
									e += "tienen que ser mayor a cero."
									print e
									sys.exit(1)
								else:													
									if (i > row or j > col):									
										e = "ERROR-VEC: e[i,j] Valores no validos para la matriz."
										print e
										sys.exit(1)
						else:
							if (i <= 0):								
								e = "ERROR-VEC: Valor no valido, e[i] i "
								e += "tiene que ser mayor a cero."
								sys.exit(1)
							else:
								# Nos moveremos por las columnas								
								if  (row == 1):							
									if (i > col):										
										e = "ERROR-VEC: e[i] Valor no valido para la matriz."
										print e
										sys.exit(1)
								# Nos moveremos por las filas
								elif (col == 1):
									if (i > row):										
										e = "ERROR-VEC: e[i] Valor no valido para la matriz."
										print e
										sys.exit(1)
								else:									
									e = "ERROR-VEC: e[i] Valor no valido para la matriz."
									print e
									sys.exit(1)
					else:
						self.i.chequear(tablaSimb)
			else:
				if not(isinstance(self.i,Vector)):
					i = int(self.i.retornaValor())
					if (i <= 0):								
						e = "ERROR-VEC: Valor no valido, e[i] i "
						e += "tiene que ser mayor a cero."
						sys.exit(1)
					else:													
						if  (row == 1):							
							if (i > col):										
								e = "ERROR-VEC: e[i] Valor no valido para la matriz."
								print e
								sys.exit(1)
						elif (col == 1):
							if (i > row):										
								e = "ERROR-VEC: e[i] Valor no valido para la matriz."
								print e
								sys.exit(1)
						else:									
							e = "ERROR-VEC: e[i] Valor no valido para la matriz."
							print e
							sys.exit(1)
				else:
					self.i.chequear(tablaSimb)
		return "number"

	def chequear(self,tablaSimb):
		
		nombreVariable = self.identificador.chequear(tablaSimb)
		if self.identificador.type == "exp_bin" or self.identificador.type == "llamada_func":
			tipoVariable = self.identificador.chequear(tablaSimb)
			if tipoVariable == "boolean" or tipoVariable == "number":
				e = "ERROR-VEC: Se esperaba que fuese "
				e += "de tipo \'matriz\', \'row\' o \'column\'." 
				print e
				sys.exit(1)
			elif tipoVariable <> "number" and tipoVariable <> "boolean":	
				self.identificador.chequear(tablaSimb)

				row = tipoVariable[1]			 
				col = tipoVariable[2]				
				self.verificarVector(row,col,tablaSimb)
				
		elif (tablaSimb.diccionario.has_key(nombreVariable) == True):
			tipoVariable = tablaSimb.diccionario[nombreVariable]			

			if tipoVariable == "number" or tipoVariable == "boolean":				
				e = "ERROR-VEC: La expresion \'%s\' tiene el" % nombreVariable 
				e += " tipo \'%s\', y se " % tipoVariable
				e += "esperaba el tipo matriz, row o column."				
				print e
				sys.exit(1)
			elif tipoVariable <> "number" and tipoVariable <> "boolean":	
				self.identificador.chequear(tablaSimb)

				row = tipoVariable[1]			 
				col = tipoVariable[2]				
				self.verificarVector(row,col,tablaSimb)
		else:
			tablaPadre = tablaSimb.padre
			verifica = True
			tipoExp = ""
			
			while (tablaPadre <> None) and verifica:
				# Guardia que revisa si la variable se encuantra en la tabla actual
				if (tablaPadre.diccionario.has_key(nombreVariable) == True):
					tipoVariable = tablaPadre.diccionario[nombreVariable]
			
					if tipoVariable == "number" or tipoVariable == "boolean":						
						e = " ERROR-VEC: La expresion \'%s\' tiene el" % nombreVariable 
						e += " tipo \'%s\', y se " % tipoVariable
						e += "esperaba el tipo \'matriz\', \'row\' o \'column\'."				
						print e
						sys.exit(1)

					if tipoVariable <> "number" and tipoVariable <> "boolean":	
						self.identificador.chequear(tablaSimb)						 
						col = tipoVariable[2]
						row = tipoVariable[1]						
						self.verificarVector(row,col,tablaSimb)
					else: 
						break
					verifica = False				
				else:				
					tablaPadre = tablaPadre.padre
		
			# En caso de revisar todas las tablas
			if tablaPadre == None:				
				if (nombreVariable <> "matrix"):
					if nombreVariable == "number" or nombreVariable == "boolean":
						e = "ERROR-FOR: El tipo que se "
						e += "esperaba era \'matriz\', \'row\' o \'column\'."
						print e
						sys.exit(1)
					else:
						print "ERROR-VEC: La variable \'%s\' no esta declarada." % nombreVariable
						sys.exit(1)
				else:	
					if nombreVariable <> "number" and nombreVariable <> "boolean":	
						self.identificador.chequear(tablaSimb)						 
						col = self.identificador.getCol()
						row = self.identificador.getRow()
						self.verificarVector(row,col,tablaSimb)	
					
		return self.type

	def ejecutar(self,tabla,dicc):
		
		maximo = len(tabla) - 1

		if isinstance(self.identificador,Identificador.Identificador):
			dicc_Actual = tabla[maximo]
			nombreVariable = self.identificador.nombre
			while (maximo >= 0):				
				if dicc_Actual.has_key(nombreVariable) == True:					
					valor = dicc_Actual[nombreVariable]
					break
				maximo = maximo - 1
				dicc_Actual = tabla[maximo]
		else:
			valor = self.identificador.ejecutar(tabla,dicc)

		#self.i = i
		maximo = len(tabla) - 1
		if isinstance(self.i,Identificador.Identificador):
			dicc_Actual = tabla[maximo]
			nombreVariable = self.i.nombre
			while (maximo >= 0):				
				if dicc_Actual.has_key(nombreVariable) == True:					
					valorI = dicc_Actual[nombreVariable]
					break
				maximo = maximo - 1
				dicc_Actual = tabla[maximo]
		else:
			valorI = self.i.ejecutar(tabla,dicc)

		#self.j = j
		if self.j:
			maximo = len(tabla) - 1
			if isinstance(self.j,Identificador.Identificador):
				dicc_Actual = tabla[maximo]
				nombreVariable = self.j.nombre
				while (maximo >= 0):				
					if dicc_Actual.has_key(nombreVariable) == True:					
						valorJ = dicc_Actual[nombreVariable]
						break
					maximo = maximo - 1
					dicc_Actual = tabla[maximo]
			else:
				valorJ = self.j.ejecutar(tabla,dicc)

		i = valorI
		row = len(valor)
		col = len(valor[0])
		
		if self.j:	

			j = valorJ				
			if (i <= 0 or j <= 0):								
				e = "ERROR-VEC: Valores no validos, e[i,j] i y j "
				e += "tienen que ser mayor a cero."
				print e
				sys.exit(1)
			else:										
				if (i > row or j > col):									
					e = "ERROR-VEC: e[i,j] Valores no validos para la matriz."
					print e
					sys.exit(1)
		else:
			if (i <= 0):								
				e = "ERROR-VEC: Valor no valido, e[i] i "
				e += "tiene que ser mayor a cero."
				sys.exit(1)
			else:
				# Nos moveremos por las columnas								
				if  (row == 1):							
					if (i > col):										
						e = "ERROR-VEC: e[i] Valor no valido para la matriz."
						print e
						sys.exit(1)
				# Nos moveremos por las filas
				elif (col == 1):
					if (i > row):										
						e = "ERROR-VEC: e[i] Valor no valido para la matriz."
						print e
						sys.exit(1)
				else:									
					e = "ERROR-VEC: e[i] Valor no valido para la matriz."
					print e
					sys.exit(1)

		if self.j:
			resp = valor[valorI-1][valorJ-1]
			return resp
		else:
			resp =  valor[0][valorI-1]
			return resp


# END Vector.py
