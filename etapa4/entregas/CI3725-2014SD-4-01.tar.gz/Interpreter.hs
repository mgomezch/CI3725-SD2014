-- Interpreter.hs

module Interpreter ()
    where

import Data.Maybe
import AST
import SymTable
import System.IO

            
-- This section includes the arithmetic expressions     
-- add, subtract, multiply, divide

addExpresion::SymValue -> SymValue -> SymValue
addExpresion (Numero n1) (Numero n2) = Numero (n1 + n2)

subExpression::SymValue -> SymValue -> SymValue
subExpression (Numero n1) (Numero n2) = Numero (n1 - n2)

multExpression::SymValue -> SymValue -> SymValue
multExpression (Numero n1) (Numero n2) = Numero (n1 * n2)

divExpression::SymValue -> SymValue -> SymValue
divExpression (Numero n1) (Numero n2) = Numero (div n1 n2)

modExpression::SymValue -> SymValue -> SymValue
modExpression (Numero n1) (Numero n2) = Numero (mod n1 n2)

minorExpression::SymValue -> SymValue -> SymValue
minorExpression (Numero n1) (Numero n2) = Booleano (n1 < n2)

minoreqExpression::SymValue -> SymValue -> SymValue
minoreqExpression (Numero n1) (Numero n2) = Booleano (n1 <= n2)

majorExpression::SymValue -> SymValue -> SymValue
majorExpression (Numero n1) (Numero n2) = Booleano (n1 > n2)

majoreqExpression::SymValue -> SymValue -> SymValue
majoreqExpression (Numero n1) (Numero n2) = Booleano (n1 >= n2)

minusExpression::SymValue -> SymValue
minusExpression (Numero n) = Numero (-n)

   
-- This section includes the boolean expressions     
-- and, or, equal, non-equal, not

andExpression::SymValue -> SymValue -> SymValue
andExpression (Booleano b1) (Booleano b2) = Booleano (b1 && b2)

orExpression::SymValue -> SymValue -> SymValue
orExpression (Booleano b1) (Booleano b2) = Booleano (b1 || b2)

eqExpression ::SymValue -> SymValue -> SymValue
eqExpression (Numero t1) (Numero t2) = Booleano (t1 == t2)
eqExpression (Booleano t1) (Booleano t2) = Booleano (t1 == t2)

noneqExpression ::SymValue -> SymValue -> SymValue
noneqExpression (Tipo t1) (Tipo t2) = Tipo (t1 /= t2)

notExpression::SymValue -> SymValue
notExpression (Booleano b) = Booleano (not b)

