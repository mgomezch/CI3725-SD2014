
module AST where

import Token

-- Data types definiton 

-- Program Type Definition
-- and use of show for I/O

data Program = Program [Declare] [Instruction]
              deriving (Eq)

instance Show Program where
  show t = case t of
   Program _ i -> "Program\n" ++ (unlines (map show i))

-- Declare Type Definition
-- Variable declarations in Trinity
data Declare = Declare [Token] Tipo                 
                 deriving (Eq, Show)

-- Definition for types in Trinity
data Tipo = TNumber                    
          | TBoolean
          | TMatrix
          | TRow
          | TCol
          deriving (Eq, Show)

-- Expression Type: Definition of
-- the available expressions in Trinity
data Exp = BinaryExpression Exp Oper Exp
         | PrefixExpression Oper Exp
         | PostfixExpression Exp Oper
         | ParenthesisExpression Exp
         | IdentExpression Token
         | NumeroExpression Numero
         | TrueExpression
         | FalseExpression
         deriving (Eq)

-- Use of Show for I/O
instance Show Exp where
  show t = case t of
   BinaryExpression e o f -> "BinaryExpression" ++ "\n  Operation: " ++ show o ++ "\n  Left Operator: " ++ show e ++ "\n Right Operator: " ++ show f
   PrefixExpression o e -> "PrefixExpression " ++ show o ++ " " ++ show e
   PostfixExpression e o -> "PostfixExpression " ++ show e ++ " " ++ show o
   ParenthesisExpression e -> "ParenthesisExpression " ++ show e
   IdentExpression t -> "IdentExpression " ++ show t
   NumeroExpression n -> "NumeroExpression " ++ show n
   TrueExpression -> "TrueExpression"
   FalseExpression -> "FalseExpression"

-- Instruction Type: Definition of
-- the available instructions in Trinity

data Instruction = AssignmentInstruction Token Exp
                 | ConditionalInstruction Exp [Instruction]
                 | ConditionalInstructionElse Exp [Instruction] [Instruction]
                 | UndRepeatInstruction Exp [Instruction]
                 | BaseDetRepeatInstruction Exp Exp [Instruction]
                 | DetRepeatInstruction Token Exp Exp [Instruction]
                 | ScopeInstruction [Declare] [Instruction]
                 | ReadInstruction Token
                 | PrintInstruction Exp
                 | Function Token [Declare] Tipo [Instruction] 
                 deriving (Eq)

-- Use of Show for I/O
instance Show Instruction where
  show t = case t of
   AssignmentInstruction t e -> "AssignmentInstruction\n" ++ "      " ++  show t ++ "\n      " ++ show e
   ConditionalInstruction e i -> "ConditionalInstruction\n  " ++ "Guardia: " ++ show e ++ "\n   " ++ "Exito: " ++ (unlines (map show i))
   ConditionalInstructionElse e i j -> "ConditionalInstructionElse " ++ show e ++ (unlines (map show i)) ++ (unlines (map show j))
   UndRepeatInstruction e i -> "UndRepeatInstruction " ++ show e ++ " " ++ (unlines (map show i))
   BaseDetRepeatInstruction e f i -> "BaseDetRepeatInstruction " ++ show e ++ " " ++ show f ++ " " ++ (unlines (map show i))
   DetRepeatInstruction t e f i -> "DetRepeatInstruction " ++ show t ++ " " ++ show e ++ " " ++ show f ++ " " ++ (unlines (map show i))
   ScopeInstruction d i -> "ScopeInstruction " ++ " " ++ (unlines (map show i))
   ReadInstruction t -> "ReadInstruction " ++ show t
   PrintInstruction e -> "PrintInstruction " ++ show e

-- Operator Type: Definition of
-- the available operators in Trinity
data Oper = 
      Suma
    | Resta
    | Mult
    | DivExacta
    | RestoExacto
    | DivEntera
    | RestoEntero
    | SumaCr
    | RestaCr
    | MultCr
    | DivExactaCr
    | DivEnteraCr
    | RestoExactoCr
    | RestoEnteroCr
    | Menor
    | MenorIgual
    | Mayor
    | MayorIgual
    | Conjuncion
    | Disyuncion
    | Negacion
    | Igual
    | Desigual
    | Traspuesta
    deriving (Eq, Show)        




type Numero = Integer

