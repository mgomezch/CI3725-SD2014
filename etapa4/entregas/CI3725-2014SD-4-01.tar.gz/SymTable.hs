-- Symbol Table

module SymTable(
  SymTable(..),
  Symbol(..),
  Tipo(..),
  SymValue(..),
  find,
  insert,
  isMember,
  replace)
    where

import qualified Data.Map as Map
import Token
import AST

data SymTable = SymTable (Maybe SymTable) (Map.Map String Symbol)
              deriving (Eq, Show)


data Symbol = SymDec [Token] Tipo 
            | SymInstr Instruccion
            | VarSymbol Token Tipo (Maybe SymValue)
            deriving (Eq, Show)

-- Instruction Args
data SymArgs = Tipo
             | Token
             | String Tipo
             deriving (Eq, Show)

-- Symbol values
data SymValue = Num Integer
              | Booleano Bool
              deriving (Eq, Show)

-- Replace an associated symbol in the table.

replace :: String -> Symbol -> SymTable -> SymTable
replace a b c = if isMember a c then findSpot a b c else c
    where
      findSpot a' b' (SymTable Nothing x) =
          SymTable Nothing (Map.alter f a' x)
              where f _ = Just b'
      findSpot a' b' (SymTable (Just s) x) =
          if Map.member a x
          then SymTable (Just s) (Map.alter f a x)
          else findSpot a' b' s
              where f _ = Just b'
             
-- Returns true if symbol is found

isMember :: String -> SymTable -> Bool
isMember a (SymTable Nothing x) = if Map.member a x then True else False
isMember a (SymTable (Just s) x) = if Map.member a x then True else isMember a s

-- Find an associated symbol

find :: String -> SymTable -> Maybe Symbol
find a (SymTable Nothing x) = if Map.member a x then Map.lookup a x else Nothing
find a (SymTable (Just s) x) = if Map.member a x then Map.lookup a x else find a s


-- Inserting a new symbol

insert :: String -> Symbol -> SymTable -> SymTable
insert a b c@(SymTable Nothing x)
  = if Map.member a x
    then
      error $ "La variable o instruccion '"++a++"' ya fue declarada."
    else
      SymTable Nothing (Map.insert a b x)
insert a b c@(SymTable (Just s) x)
  = if Map.member a x
    then
      error $ "La variable o funcion '"++a++"' ya fue declarada."
    else SymTable (Just s) (Map.insert a b x)

