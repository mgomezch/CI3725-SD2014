#!/usr/bin/env ruby 
# -*- coding: utf-8 -*-
# David Goudet 08-10479
# Susana Charara 08-10223

class ErrorEjecucion < RuntimeError
end

class DivisionEntreCero < ErrorEjecucion
end

class DimensionesMatriz < ErrorEjecucion
end
class IndexOutOfBounds < ErrorEjecucion
end
