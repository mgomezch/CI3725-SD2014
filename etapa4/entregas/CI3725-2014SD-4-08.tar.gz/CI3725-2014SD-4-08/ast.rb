#!/usr/bin/env ruby 
# -*- coding: utf-8 -*-
# David Goudet 08-10479
# Susana Charara 08-10223
require_relative 'SymTable'
require_relative 'AlcanceFunciones'
require_relative 'TablaValores'
require_relative 'clasesTipos'
require_relative 'erroresContexto'
require_relative 'erroresEjecucion'
require 'matrix'

class AST; end
class Programa < AST 
	def initialize(program)
    	@program = program
    end
    def check()
    	@program.check($tabla)    	
	end	
	def exec()
		@program.exec($tablaValores)
	end
end

class ProgConFuncion < AST
	def initialize(funciones, instrucciones)		
    	@funciones = funciones
    	@instrucciones = instrucciones
    end
    def check(tabla)
    	@funciones.agregar(tabla)
        @funciones.check(tabla)
        unless @instrucciones.nil? then
        	@instrucciones.check(tabla)
        end
    end
    def exec(tabla)
        unless @instrucciones.nil? then
        	@instrucciones.exec(tabla)
        end
    end

end
class ProgSinFuncion < AST
	def initialize(instrucciones)
    	@instrucciones = instrucciones
    end

    def check(tabla)
    	unless @instrucciones.nil? then
        	@instrucciones.check(tabla)
        end
    end
    def exec(tabla)
		unless @instrucciones.nil? then
        	@instrucciones.exec(tabla)
        end
	end
end
class ListaFunciones
	def initialize(primeraFuncion, restoFunciones)

		@primeraFuncion = primeraFuncion
		@restoFunciones = restoFunciones
	end
	def agregar(tabla)		
		@primeraFuncion.agregar(tabla)
		unless @restoFunciones.nil? then
			@restoFunciones.agregar(tabla)
		end
	end
	#def agregarTablaValores(tabla)		
	#	@primeraFuncion.agregarTablaValores(tabla)
	#	unless @restoFunciones.nil? then
	#		@restoFunciones.agregarTablaValores(tabla)
	#	end
	#end
	def check(tabla)
		@primeraFuncion.check(tabla)
		unless @restoFunciones.nil? then
			@restoFunciones.check(tabla)
		end
	end
end
class FuncionConParametro
	def initialize(nombre, param, rtrn, instrucciones)
		@nombre = nombre
		@param = param
		@rtrn = rtrn
		@instrucciones = instrucciones
	end
	def agregar(tabla)		
		@tipo = @rtrn.check(tabla)		
		a = AlcanceFunciones::new(tabla,@tipo,@nombre.to_s)
		tabla.agregarFuncion(@nombre.to_s,@tipo,a)
		a.agregarInstrucciones(@instrucciones)
		@param.check(a)
	end
	def check(tabla)
		a = tabla.dameFuncion(@nombre.to_s)
		unless @instrucciones.nil? then
			@instrucciones.check(a)
		end
	end

end

class FuncionSinParametro
	def initialize(nombre, rtrn, instrucciones)
		@nombre = nombre
		@rtrn = rtrn
		@instrucciones = instrucciones	
	end
	def agregar(tabla)
		@tipo = @rtrn.check(tabla)
		a = AlcanceFunciones::new(tabla,@tipo,@nombre.to_s)
		tabla.agregarFuncion(@nombre.to_s,@tipo,a)
		a.agregarInstrucciones(@instrucciones)
	end
	def check(tabla)
		a = tabla.dameFuncion(@nombre.to_s)
		#@param.check(a)
		unless @instrucciones.nil? then
			@instrucciones.check(a)
		end
	end
end
class ParametroFuncion
	def initialize(tipo, parametro)
		@tipo = tipo
		@parametro = parametro
	end
	def check(tabla)
		t = @tipo.check(tabla)
		n = @parametro.to_s
		tabla.agregarParametro(n,t)
	end
end
class ListaParametros
	def initialize(primerParametro, restoParametros)
		@primerParametro = primerParametro
		@restoParametros = restoParametros
	end
	def check(tabla)
		@primerParametro.check(tabla)
		unless @restoParametros.nil? then
			@restoParametros.check(tabla)
		end
	end
end

class Matriz
	def initialize(filas, columnas)
		@filas = filas
		@columnas = columnas
	end
	def check(tabla)
		typeFil = @filas.check(tabla)
		typeCol = @columnas.check(tabla)
		if (typeFil.is_a?(TipoNum) && typeCol.is_a?(TipoNum)) # Se chequea que las dimensiones sean numeros
			f = @filas.to_s.to_f
			c = @columnas.to_s.to_f
			if (f <= 0 || c <= 0 || (f - f.to_i != 0) || (c - c.to_i != 0)) # Se chequea que las dimensiones sean enteros positivos
				raise ErrorDimensionesMatriz::new()
			else
				return TipoMatriz::new(@filas.to_s, @columnas.to_s)
			end
		elsif not typeFil.is_a?(TipoNum)
			raise ErrorTipo::new(@filas, typeFil,TipoNum::new())
		else 
			raise ErrorTipo::new(@columnas, typeCol,TipoNum::new())
		end
	end
	def to_s
		return "Matriz"
	end
	def numeroFilas
		return @filas.to_s.to_i
	end
	def numeroColumnas
		return @columnas.to_s.to_i
	end
end
class VectorFila
	def initialize(columnas)
		@columnas = columnas
	end

	def check(tabla)
		typeCol = @columnas.check(tabla)
		if (typeCol.is_a?(TipoNum)) # Se chequea que las dimensiones sean numeros
			c = @columnas.to_s.to_f
			if (c <= 0 ||(c - c.to_i != 0)) # Se chequea que las dimensiones sean enteros positivos
				raise ErrorDimensionesMatriz::new()
			else
				return TipoMatriz::new("1", @columnas.to_s)
			end
		elsif not typeFil.is_a?(TipoNum)
			raise ErrorTipo::new(@columnas, @typeCol,TipoNum::new())
		end
	end
	def tipo
		return "Matriz(1,#{@columnas.to_s})"
	end
end
class VectorColumna
	def initialize(filas)
		@filas = filas
	end	
	def check(tabla)
		typeFil = @filas.check(tabla)
		if (typeFil.is_a?(TipoNum)) # Se chequea que las dimensiones sean numeros
			f = @filas.to_s.to_f
			if (f <= 0 ||(f - f.to_i != 0)) # Se chequea que las dimensiones sean enteros positivos
				raise ErrorDimensionesMatriz::new()
			else
				return TipoMatriz::new(@filas.to_s, "1")
			end
		elsif not typeFil.is_a?(TipoNum)
			raise ErrorTipo::new(@filas, @typeFil,TipoNum::new())
		end
	end
	def tipo
		return "Matriz(#{@filas.to_s},1)"
	end
end
class LiteralMatricial
	def initialize(valor)
		@valor = valor
	end
	def check(tabla)
		return @valor.check(tabla)
	end

	def to_s
		"{#{@valor.to_s}}"
	end
	def exec(tabla)
		@string = @valor.to_s
		filas = @string.split(":")
		i = 0
		n = filas.length
		arregloColumnas = Array.new
		for i in filas do
			arregloColumnas <<i.split(",").map(&:to_i)
		end
		return Matrix.rows(arregloColumnas)
	end
end
class ColumnasLiteralMatricial
	def initialize(primeraColumna, restoColumnas, numeroCol)
		@primeraColumna = primeraColumna
		@restoColumnas = restoColumnas
		@numeroCol = numeroCol
	end
	def check(tabla)
		$nCol = $nCol + 1
		tipo = @primeraColumna.check(tabla)
		unless tipo.is_a?(TipoNum)
			raise ErrorTipo::new(@primeraColumna, tipo,TipoNum::new())
		end
		unless @restoColumnas.nil? then
			tipo = @restoColumnas.check(tabla)
		end
	end
	def to_s
		if @restoColumnas.nil? then 
			return "#{@primeraColumna.to_s}"
		else
			return "#{@primeraColumna.to_s},#{@restoColumnas.to_s}"
		end
	end
end
class FilasLiteralMatricial
	def initialize(primeraFila,restoFilas)
		@primeraFila = primeraFila
		@restoFilas = restoFilas
		$numeroFilas = 0
		$numeroColumnas = 0
	end
	def check(tabla)
		$nFil = $nCol
		$nCol = 0
		$numeroDeFilas = $numeroDeFilas + 1
		@primeraFila.check(tabla)
		numeroColumnas = $nCol
		unless $nFil == 0 then
			if $nFil != numeroColumnas 
						#$nCol
				raise ErrorLiteralMatricial::new()
			end
		end
		
		unless @restoFilas.nil? then
			@restoFilas.check(tabla)
		else
			t = TipoMatriz::new($numeroDeFilas,$nCol)
			$numeroFilas = $numeroDeFilas
			$numeroColumnas = $nCol
			$nCol = 0
			$nFil = 0
			$numeroDeFilas = 0
			return t
		end

	end
	def to_s
		if @restoFilas.nil? then 
			return "#{@primeraFila.to_s}"
		else
			return "#{@primeraFila.to_s}:#{@restoFilas.to_s}"
		end
	end
end
class Entero
	def initialize(valor)
		@valor = valor
	end
	def to_s
		"#{@valor.to_s}"
	end
	def check(tabla)
		return TipoNum::new()
	end
	def exec(tabla)
		return @valor.to_s.to_f
	end
end
class UsoVariable
	def initialize(valor)
		@valor = valor
	end
	def check(tabla)
		n = @valor.to_s
		existe = tabla.buscarTabla(n)
		if existe.nil?
			raise ErrorVariableNoExiste::new(n)
		else
			return existe
		end
	end
	def exec(tabla)
		n = @valor.to_s
		existe = tabla.buscarTablaVariable(n)
		return existe
	end
	def to_s
		"#{@valor.to_s}"
	end
end
class UsoVariableValor
	def initialize(valor)
		@valor = valor
	end
	def check(tabla)
		n = @valor.to_s
		existe = tabla.buscarTabla(n)
		if existe.nil?
			raise ErrorVariableNoExiste::new(n)
		else
			return existe
		end
	end
	def exec(tabla)
		n = @valor.to_s
		existe = tabla.buscarTablaValor(n)
		return existe
	end
	def to_s
		"#{@valor.to_s}"
	end
end

class Variable
	def initialize(valor)
		@valor = valor
	end
	def to_s
		"#{@valor.to_s}"
	end
	def exec(tabla)
		return @valor.to_s
	end

end
class Number
	def initialize(valor)
		@valor = valor
	end
	def check(tabla)
		return TipoNum::new()
	end
	def exec(tabla)
		return @valor
	end
end
class Boolean
	def initialize(valor)
		@valor = valor
	end
	def check(tabla)
		return TipoBool::new()
	end
end
class MenosUnario
	def initialize(expr)
		@expr = expr
	end
	def check(tabla)
		@tipoActual = @expr.check(tabla)
		unless @tipoActual.is_a?(TipoAritmetico) then
			raise ErrorTipo2::new(@expr, @tipoActual,TipoNum::new(),Matriz::new(0,0))
		end
		return @tipoActual
	end	
	def to_s
		"-#{@expr.to_s}"
	end
	def exec(tabla)
		valor = @expr.exec(tabla)
		if @tipoActual.is_a?(TipoNum)
			return -valor
		else
			@filas = @tipoActual.dameFilas.to_i
			@columnas = @tipoActual.dameColumnas.to_i
			nula = Matrix.zero(@filas,@columnas)
			return nula - valor
		end
	end
end
class Suma 
	def initialize(opIzq, opDer)
		@opIzq = opIzq
		@opDer = opDer
	end
	def check(tabla)
		@tipoIzq = @opIzq.check(tabla)
		@tipoDer = @opDer.check(tabla)
		unless (@tipoIzq.is_a?(TipoAritmetico) && @tipoDer.is_a?(TipoAritmetico)) then
			if not @tipoIzq.is_a?(TipoAritmetico)
				raise ErrorTipo2::new(@opIzq, @tipoIzq, TipoNum::new(), Matriz::new(0,0))
			else
				raise ErrorTipo2::new(@opDer, @tipoDer, TipoNum::new(), Matriz::new(0,0))
			end
		end
		unless @tipoIzq.to_s.eql? @tipoDer.to_s then
			raise ErrorTipo::new(@opDer,@tipoDer,@tipoIzq)
		else
			return @tipoIzq
		end
	end
	def to_s
		"#{@opIzq.to_s} + #{@opDer.to_s}"
	end
	def exec(tabla)
		#puts "suma"
		valorIzq = @opIzq.exec(tabla)
		valorDer = @opDer.exec(tabla)
		return valorIzq + valorDer
	end
end
class Resta  
	def initialize(opIzq, opDer)
		@opIzq = opIzq
		@opDer = opDer
	end
	def check(tabla)
		@tipoIzq = @opIzq.check(tabla)
		@tipoDer = @opDer.check(tabla)
		unless (@tipoIzq.is_a?(TipoAritmetico) && @tipoDer.is_a?(TipoAritmetico)) then
			if not @tipoIzq.is_a?(TipoAritmetico)
				raise ErrorTipo2::new(@opIzq, @tipoIzq, TipoNum::new(), Matriz::new(0,0))
			else
				raise ErrorTipo2::new(@opDer, @tipoDer, TipoNum::new(), Matriz::new(0,0))
			end
		end
		unless @tipoIzq.to_s.eql? @tipoDer.to_s then
			raise ErrorTipo::new(@opDer,@tipoDer,@tipoIzq)
		else
			return @tipoIzq
		end
	end	
	def to_s
		"#{@opIzq.to_s} - #{@opDer.to_s}"
	end
	def exec(tabla)
		valorIzq = @opIzq.exec(tabla)
		valorDer = @opDer.exec(tabla)
		return valorIzq - valorDer
	end
end
class Multiplicacion
	def initialize(opIzq, opDer)
		@opIzq = opIzq
		@opDer = opDer
	end
	def check(tabla)
		@tipoIzq = @opIzq.check(tabla)
		@tipoDer = @opDer.check(tabla)
		unless (@tipoIzq.is_a?(TipoAritmetico)) then
				
				raise ErrorTipo2::new(@opIzq, @tipoIzq, TipoNum::new(), Matriz::new(0,0))
		end
		unless (@tipoDer.is_a?(TipoAritmetico)) then
				raise ErrorTipo2::new(@opDer, @tipoDer, TipoNum::new(), Matriz::new(0,0))
		end
		if @tipoIzq.is_a?(TipoNum) then
			unless @tipoDer.is_a?(TipoNum) then
				raise ErrorTipo::new(@opDer,@tipoDer,@tipoIzq)
			end
		elsif @tipoIzq.is_a?(TipoMatriz)
			unless @tipoDer.is_a?(TipoMatriz) then
				@columnasIzq = @tipoIzq.dameColumnas
				raise ErrorTipo::new(@opDer,@tipoDer,TipoMatriz::new(@columnasIzq,TipoNum::new()))
			end
			@filasIzq = @tipoIzq.dameFilas
			@filasDer = @tipoDer.dameFilas
			@columnasIzq = @tipoIzq.dameColumnas
			@columnasDer = @tipoIzq.dameColumnas
			if @columnasIzq != @filasDer then
				raise ErrorTipo::new(@opDer, @tipoDer, TipoMatriz::new(@columnasIzq,TipoNum::new()))
			else
				return @tipoIzq
			end
		end
		return @tipoIzq
	end
	def to_s
		"#{@opIzq.to_s} * #{@opDer.to_s}"
	end
	def exec(tabla)
		valorIzq = @opIzq.exec(tabla)
		valorDer = @opDer.exec(tabla)
		return valorIzq * valorDer
	end
end
class Division
	def initialize(opIzq, opDer)
		@opIzq = opIzq
		@opDer = opDer
	end
	def check(tabla)
		@tipoIzq = @opIzq.check(tabla)
		@tipoDer = @opDer.check(tabla)
		unless (@tipoIzq.is_a?(TipoNum) && @tipoDer.is_a?(TipoNum)) then
			if not @tipoIzq.is_a?(TipoNum)
				raise ErrorTipo::new(@opIzq, @tipoIzq, TipoNum::new())
			else
				raise ErrorTipo::new(@opDer, @tipoDer, TipoNum::new())
			end
		else
			return @tipoIzq
		end
	end
	def exec(tabla)
		valorIzq = @opIzq.exec(tabla)
		valorDer = @opDer.exec(tabla)
		if valorDer.eql?(0.to_f)
			raise DivisionEntreCero
		end
		return valorIzq / valorDer
	end
end
class Modulo
	def initialize(opIzq, opDer)
		@opIzq = opIzq
		@opDer = opDer
	end
	def check(tabla)
		@tipoIzq = @opIzq.check(tabla)
		@tipoDer = @opDer.check(tabla)
		unless (@tipoIzq.is_a?(TipoNum) && @tipoDer.is_a?(TipoNum)) then
			if not @tipoIzq.is_a?(TipoNum)
				raise ErrorTipo::new(@opIzq, @tipoIzq, TipoNum::new())
			else
				raise ErrorTipo::new(@opDer, @tipoDer, TipoNum::new())
			end
		else
			return @tipoIzq
		end
	end
	def exec(tabla)
		valorIzq = @opIzq.exec(tabla)
		valorDer = @opDer.exec(tabla)
		if valorDer.eql?(0.to_f)
			raise DivisionEntreCero
		end
		return valorIzq % valorDer
	end
end
class Div
	def initialize(opIzq, opDer)
		@opIzq = opIzq
		@opDer = opDer
	end
	def check(tabla)
		@tipoIzq = @opIzq.check(tabla)
		@tipoDer = @opDer.check(tabla)
		unless (@tipoIzq.is_a?(TipoNum) && @tipoDer.is_a?(TipoNum)) then
			if not @tipoIzq.is_a?(TipoNum)
				raise ErrorTipo::new(@opIzq, @tipoIzq, TipoNum::new())
			else
				raise ErrorTipo::new(@opDer, @tipoDer, TipoNum::new())
			end
		else
			return @tipoIzq
		end
	end
	def exec(tabla)
		valorIzq = @opIzq.exec(tabla)
		valorDer = @opDer.exec(tabla)
		if valorDer.eql?(0.to_f)
			raise DivisionEntreCero
		end
		return valorIzq.to_i / valorDer.to_i
	end
end
class Mod
	def initialize(opIzq, opDer)
		@opIzq = opIzq
		@opDer = opDer
	end
	def check(tabla)
		@tipoIzq = @opIzq.check(tabla)
		@tipoDer = @opDer.check(tabla)
		unless (@tipoIzq.is_a?(TipoNum) && @tipoDer.is_a?(TipoNum)) then
			if not @tipoIzq.is_a?(TipoNum)
				raise ErrorTipo::new(@opIzq, @tipoIzq, TipoNum::new())
			else
				raise ErrorTipo::new(@opDer, @tipoDer, TipoNum::new())
			end
		else
			return @tipoIzq
		end
	end
	def exec(tabla)
		valorIzq = @opIzq.exec(tabla)
		valorDer = @opDer.exec(tabla)
		if valorDer.eql?(0.to_f)
			raise DivisionEntreCero
		end
		return valorIzq.to_i % valorDer.to_i
	end
end
class Traspuesta
	def initialize(matriz)
		@matriz = matriz
	end
	def check(tabla)
		@tipo = @matriz.check(tabla)
		if @tipo.is_a?(TipoMatriz)
			filas = @tipo.dameFilas
			columnas = @tipo.dameColumnas
			return TipoMatriz::new(columnas,filas)
		else
			raise ErrorTipo::new(@matriz, @tipo, Matriz::new(0,0))
		end
	end
	def exec(tabla)
		m = @matriz.exec(tabla)
		return m.transpose
	end
end
class SumaCruz
	def initialize(opIzq, opDer)
		@opIzq = opIzq
		@opDer = opDer
	end
	def check(tabla)
		@tipoIzq = @opIzq.check(tabla)
		@tipoDer = @opDer.check(tabla)
		if @tipoIzq.is_a?(TipoNum)
			if @tipoDer.is_a?(TipoMatriz)
				return @tipoDer
			else
				raise ErrorTipo::new(@opDer, @tipoDer, Matriz::new(0,0))
			end
		elsif @tipoIzq.is_a?(TipoMatriz)
			if @tipoDer.is_a?(TipoNum)
				return @tipoIzq
			else
				raise ErrorTipo::new(@opDer, @tipoDer, TipoNum::new())
			end
		else
			raise ErrorTipoCruz::new(@opIzq,@opDer,@tipoIzq,@tipoDer,TipoNum::new,Matriz::new(0,0))
		end
	end
	def exec(tabla)
		valorIzq = @opIzq.exec(tabla)
		valorDer = @opDer.exec(tabla)
		if @tipoIzq.is_a?(TipoNum)
			valorDer.collect { |e| valorIzq + e }
		else
			valorIzq.collect { |e| e + valorDer }
		end
	end
end
class RestaCruz
	def initialize(opIzq, opDer)
		@opIzq = opIzq
		@opDer = opDer
	end
	def check(tabla)
		@tipoIzq = @opIzq.check(tabla)
		@tipoDer = @opDer.check(tabla)
		if @tipoIzq.is_a?(TipoNum)
			if @tipoDer.is_a?(TipoMatriz)
				return @tipoDer
			else
				raise ErrorTipo::new(@opDer, @tipoDer, Matriz::new(0,0))
			end
		elsif @tipoIzq.is_a?(TipoMatriz)
			if @tipoDer.is_a?(TipoNum)
				return @tipoIzq
			else
				raise ErrorTipo::new(@opDer, @tipoDer, TipoNum::new())
			end
		else
			raise ErrorTipoCruz::new(@opIzq,@opDer,@tipoIzq,@tipoDer,TipoNum::new,Matriz::new(0,0))
		end
	end
	def exec(tabla)
		valorIzq = @opIzq.exec(tabla)
		valorDer = @opDer.exec(tabla)
		if @tipoIzq.is_a?(TipoNum)
			valorDer.collect { |e| valorIzq - e }
		else
			valorIzq.collect { |e| e - valorDer }
		end
	end
end
class MultiplicacionCruz
	def initialize(opIzq, opDer)
		@opIzq = opIzq
		@opDer = opDer
	end
	def check(tabla)
		@tipoIzq = @opIzq.check(tabla)
		@tipoDer = @opDer.check(tabla)
		if @tipoIzq.is_a?(TipoNum)
			if @tipoDer.is_a?(TipoMatriz)
				return @tipoDer
			else
				raise ErrorTipo::new(@opDer, @tipoDer, Matriz::new(0,0))
			end
		elsif @tipoIzq.is_a?(TipoMatriz)
			if @tipoDer.is_a?(TipoNum)
				return @tipoIzq
			else
				raise ErrorTipo::new(@opDer, @tipoDer, TipoNum::new())
			end
		else
			raise ErrorTipoCruz::new(@opIzq,@opDer,@tipoIzq,@tipoDer,TipoNum::new(),Matriz::new(0,0))
		end
	end
	def exec(tabla)
		valorIzq = @opIzq.exec(tabla)
		valorDer = @opDer.exec(tabla)
		if @tipoIzq.is_a?(TipoNum)
			valorDer.collect { |e| valorIzq * e }
		else
			valorIzq.collect { |e| e * valorDer }
		end
	end
end
class DivisionCruz
	def initialize(opIzq, opDer)
		@opIzq = opIzq
		@opDer = opDer
	end
	def check(tabla)
		@tipoIzq = @opIzq.check(tabla)
		@tipoDer = @opDer.check(tabla)
		if @tipoIzq.is_a?(TipoNum)
			if @tipoDer.is_a?(TipoMatriz)
				return @tipoDer
			else
				raise ErrorTipo::new(@opDer, @tipoDer, Matriz::new(0,0))
			end
		elsif @tipoIzq.is_a?(TipoMatriz)
			if @tipoDer.is_a?(TipoNum)
				return @tipoIzq
			else
				raise ErrorTipo::new(@opDer, @tipoDer, TipoNum::new())
			end
		else
			raise ErrorTipoCruz::new(@opIzq,@opDer,@tipoIzq,@tipoDer,TipoNum::new,Matriz::new(0,0))
		end
	end
	def exec(tabla)
		valorIzq = @opIzq.exec(tabla)
		valorDer = @opDer.exec(tabla)
		if @tipoIzq.is_a?(TipoNum)
			if valorIzq.eql?(0.to_f)
				raise DivisionEntreCero
			end
			valorDer.collect { |e| valorIzq / e }
		else
			if valorDer.eql?(0.to_f)
				raise DivisionEntreCero
			end
			valorIzq.collect { |e| e / valorDer }
		end
	end
end
class ModuloCruz
	def initialize(opIzq, opDer)
		@opIzq = opIzq
		@opDer = opDer
	end
	def check(tabla)
		@tipoIzq = @opIzq.check(tabla)
		@tipoDer = @opDer.check(tabla)
		if @tipoIzq.is_a?(TipoNum)
			if @tipoDer.is_a?(TipoMatriz)
				return @tipoDer
			else
				raise ErrorTipo::new(@opDer, @tipoDer, Matriz::new(0,0))
			end
		elsif @tipoIzq.is_a?(TipoMatriz)
			if @tipoDer.is_a?(TipoNum)
				return @tipoIzq
			else
				raise ErrorTipo::new(@opDer, @tipoDer, TipoNum::new())
			end
		else
			raise ErrorTipoCruz::new(@opIzq,@opDer,@tipoIzq,@tipoDer,TipoNum::new,Matriz::new(0,0))
		end
	end
	def exec(tabla)
		valorIzq = @opIzq.exec(tabla)
		valorDer = @opDer.exec(tabla)
		if @tipoIzq.is_a?(TipoNum)
			if valorIzq.eql?(0.to_f)
				raise DivisionEntreCero
			end
			valorDer.collect { |e| valorIzq % e }
		else
			if valorDer.eql?(0.to_f)
				raise DivisionEntreCero
			end
			valorIzq.collect { |e| e % valorDer }
		end
	end
end
class DivCruz
	def initialize(opIzq, opDer)
		@opIzq = opIzq
		@opDer = opDer
	end
	def check(tabla)
		@tipoIzq = @opIzq.check(tabla)
		@tipoDer = @opDer.check(tabla)
		if @tipoIzq.is_a?(TipoNum)
			if @tipoDer.is_a?(TipoMatriz)
				return @tipoDer
			else
				raise ErrorTipo::new(@opDer, @tipoDer, Matriz::new(0,0))
			end
		elsif @tipoIzq.is_a?(TipoMatriz)
			if @tipoDer.is_a?(TipoNum)
				return @tipoIzq
			else
				raise ErrorTipo::new(@opDer, @tipoDer, TipoNum::new())
			end
		else
			raise ErrorTipoCruz::new(@opIzq,@opDer,@tipoIzq,@tipoDer,TipoNum::new,Matriz::new(0,0))
		end
	end
	def exec(tabla)
		valorIzq = @opIzq.exec(tabla)
		valorDer = @opDer.exec(tabla)
		if @tipoIzq.is_a?(TipoNum)
			if valorIzq.eql?(0.to_f)
				raise DivisionEntreCero
			end
			valorDer.collect { |e| valorIzq.to_i / e.to_i }
		else
			if valorDer.eql?(0.to_f)
				raise DivisionEntreCero
			end
			valorIzq.collect { |e| e.to_i / valorDer.to_i }
		end
	end
end
class ModCruz
	def initialize(opIzq, opDer)
		@opIzq = opIzq
		@opDer = opDer
	end
	def check(tabla)
		@tipoIzq = @opIzq.check(tabla)
		@tipoDer = @opDer.check(tabla)
		if @tipoIzq.is_a?(TipoNum)
			if @tipoDer.is_a?(TipoMatriz)
				return @tipoDer
			else
				raise ErrorTipo::new(@opDer, @tipoDer, Matriz::new(0,0))
			end
		elsif @tipoIzq.is_a?(TipoMatriz)
			if @tipoDer.is_a?(TipoNum)
				return @tipoIzq
			else
				raise ErrorTipo::new(@opDer, @tipoDer, TipoNum::new())
			end
		else
			raise ErrorTipoCruz::new(@opIzq,@opDer,@tipoIzq,@tipoDer,TipoNum::new,Matriz::new(0,0))
		end
	end
	def exec(tabla)
		valorIzq = @opIzq.exec(tabla)
		valorDer = @opDer.exec(tabla)
		if @tipoIzq.is_a?(TipoNum)
			if valorIzq.eql?(0.to_f)
				raise DivisionEntreCero
			end
			valorDer.collect { |e| valorIzq.to_i % e.to_i }
		else
			if valorDer.eql?(0.to_f)
				raise DivisionEntreCero
			end
			valorIzq.collect { |e| e.to_i % valorDer.to_i }
		end
	end
end
class True
	def check(tabla)
		return TipoBool::new()
	end
	def to_s
		"true"
	end
	def tipo
		"boolean"
	end
	def exec(tabla)
		return true
	end

end
class False
	def check(tabla)
		return TipoBool::new()
	end
	def to_s
		"false"
	end
	def tipo
		"boolean"
	end
	def exec(tabla)
		return false
	end
end
class Not
	def initialize(expr)
		@expr = expr
	end
	def check(tabla)
		tipoActual = @expr.check(tabla)
		unless tipoActual.is_a?(TipoBool) then
			raise ErrorTipo::new(@expr, tipoActual,TipoBool::new())
		end
		return tipoActual
	end
	def to_s
		"not #{@expr.to_s}"
	end
	def exec(tabla)
		return (!@expr.exec(tabla))
	end

end
class And
	def initialize(opIzq, opDer)
		@opIzq = opIzq
		@opDer = opDer
	end
	def check(tabla)
		@tipoIzq = @opIzq.check(tabla)
		@tipoDer = @opDer.check(tabla)
		unless @tipoIzq.is_a?(TipoBool) then
			raise ErrorTipo::new(@opIzq, @tipoIzq,TipoBool::new())
		end
		unless @tipoDer.is_a?(TipoBool) then
			raise ErrorTipo::new(@opDer, @tipoDer,TipoBool::new())
		end
		return @tipoIzq
	end
	def exec(tabla)
		valorIzq = @opIzq.exec(tabla)
		if valorIzq.eql?(false)
			return valorIzq
		else
			valorDer = @opDer.exec(tabla)
			return valorIzq && valorDer
		end
	end
end
class Or	
	def initialize(opIzq, opDer)
		@opIzq = opIzq
		@opDer = opDer
	end
	def check(tabla)
		@tipoIzq = @opIzq.check(tabla)
		@tipoDer = @opDer.check(tabla)
		unless @tipoIzq.is_a?(TipoBool) then
			raise ErrorTipo::new(@opIzq, @tipoIzq,TipoBool::new())
		end
		unless @tipoDer.is_a?(TipoBool) then
			raise ErrorTipo::new(@opDer, @tipoDer,TipoBool::new())
		end
		return @tipoIzq
	end
	def exec(tabla)
		valorIzq = @opIzq.exec(tabla)
		if valorIzq.eql?(true)
			return valorIzq
		else
			valorDer = @opDer.exec(tabla)
			return valorIzq || valorDer
		end
	end
end
class Equivalencia
	def initialize(opIzq, opDer)
		@opIzq = opIzq
		@opDer = opDer
	end
	def check(tabla)
		@tipoIzq = @opIzq.check(tabla)
		@tipoDer = @opDer.check(tabla)
		unless @tipoIzq.to_s.eql?(@tipoDer.to_s) then
			raise ErrorTipo::new(@opDer, @tipoDer,@tipoIzq)
		end
		return TipoBool::new()
	end
	def exec(tabla)
		valorIzq = @opIzq.exec(tabla)		
		valorDer = @opDer.exec(tabla)
		return valorIzq.eql?(valorDer)
	end
end
class Inequivalencia
	def initialize(opIzq, opDer)
		@opIzq = opIzq
		@opDer = opDer
	end
	def check(tabla)
		@tipoIzq = @opIzq.check(tabla)
		@tipoDer = @opDer.check(tabla)
		unless @tipoIzq.to_s.eql? @tipoDer.to_s then
			raise ErrorTipo::new(@opDer, @tipoDer,@tipoIzq)
		end
		return TipoBool::new()
	end
	def exec(tabla)
		valorIzq = @opIzq.exec(tabla)		
		valorDer = @opDer.exec(tabla)
		return !valorIzq.eql?(valorDer)
	end
end

class Menor
	def initialize(opIzq, opDer)
		@opIzq = opIzq
		@opDer = opDer
	end
	def check(tabla)
		@tipoIzq = @opIzq.check(tabla)
		@tipoDer = @opDer.check(tabla)
		unless (@tipoIzq.is_a?(TipoNum) && @tipoDer.is_a?(TipoNum)) then
			if not @tipoIzq.is_a?(TipoNum)
				raise ErrorTipo::new(@opIzq, @tipoIzq, TipoNum::new())
			else
				raise ErrorTipo::new(@opDer, @tipoDer, TipoNum::new())
			end
		else
			return TipoBool::new()
		end
	end
	def exec(tabla)
		valorIzq = @opIzq.exec(tabla)		
		valorDer = @opDer.exec(tabla)
		return valorIzq < valorDer
	end
end
class MenorOIgual
	def initialize(opIzq, opDer)
		@opIzq = opIzq
		@opDer = opDer
	end
	def check(tabla)
		@tipoIzq = @opIzq.check(tabla)
		@tipoDer = @opDer.check(tabla)
		unless (@tipoIzq.is_a?(TipoNum) && @tipoDer.is_a?(TipoNum)) then
			if not @tipoIzq.is_a?(TipoNum)
				raise ErrorTipo::new(@opIzq, @tipoIzq, TipoNum::new())
			else
				raise ErrorTipo::new(@opDer, @tipoDer, TipoNum::new())
			end
		else
			return TipoBool::new()
		end
	end
	def exec(tabla)
		valorIzq = @opIzq.exec(tabla)		
		valorDer = @opDer.exec(tabla)
		return valorIzq <= valorDer
	end
end
class Mayor
	def initialize(opIzq, opDer)
		@opIzq = opIzq
		@opDer = opDer
	end
	def check(tabla)
		@tipoIzq = @opIzq.check(tabla)
		@tipoDer = @opDer.check(tabla)
		unless (@tipoIzq.is_a?(TipoNum) && @tipoDer.is_a?(TipoNum)) then
			if not @tipoIzq.is_a?(TipoNum)
				raise ErrorTipo::new(@opIzq, @tipoIzq, TipoNum::new())
			else
				raise ErrorTipo::new(@opDer, @tipoDer, TipoNum::new())
			end
		else
			return TipoBool::new()
		end
	end
	def exec(tabla)
		valorIzq = @opIzq.exec(tabla)		
		valorDer = @opDer.exec(tabla)
		return valorIzq > valorDer
	end
end
class MayorOIgual
	def initialize(opIzq, opDer)
		@opIzq = opIzq
		@opDer = opDer
	end
	def check(tabla)
		@tipoIzq = @opIzq.check(tabla)
		@tipoDer = @opDer.check(tabla)
		unless (@tipoIzq.is_a?(TipoNum) && @tipoDer.is_a?(TipoNum)) then
			if not @tipoIzq.is_a?(TipoNum)
				raise ErrorTipo::new(@opIzq, @tipoIzq, TipoNum::new())
			else
				raise ErrorTipo::new(@opDer, @tipoDer, TipoNum::new())
			end
		else
			return TipoBool::new()
		end
	end
	def exec(tabla)
		valorIzq = @opIzq.exec(tabla)		
		valorDer = @opDer.exec(tabla)
		return valorIzq >= valorDer
	end
end
class Expresion
	def initialize(expresion)
		@expresion = expresion
	end
	def check(tabla)
		@expresion.check(tabla)
	end
	def exec(tabla)
		@expresion.exec(tabla)
	end
end
class ListaExpresiones 
	def initialize(primeraExpresion, restoExpresiones)
		@primeraExpresion = primeraExpresion
		@restoExpresiones = restoExpresiones
	end
	def check(tabla)
		@primeraExpresion.check(tabla)
		unless @restoExpresiones.nil? then
			@restoExpresiones.check(tabla)
		end
	end
	def impresionMatriz(matriz)
		puts ""
		matriz.to_a.each {|r| puts r.inspect}
	end
	def exec(tabla)
		@str = @primeraExpresion.exec(tabla)
		if @str.is_a?(String)
			#impresionString(@str)
			#print "#{@str.to_s}"
			eval(@str)
		elsif @str.is_a?(Matrix)
			impresionMatriz(@str)
		else
			print @str
		end
		unless @restoExpresiones.nil? then
			@restoExpresiones.exec(tabla)
		end
	end
end
class Instruccion
	def initialize(instruccion)
		@instruccion = instruccion
	end
end
class ListaInstrucciones
	def initialize(primeraInstruccion, restoInstrucciones)
		@primeraInstruccion = primeraInstruccion
		@restoInstrucciones = restoInstrucciones
	end
	def check(tabla)
		@primeraInstruccion.check(tabla)		
		unless @restoInstrucciones.nil?
			@restoInstrucciones.check(tabla)
		end

	end
	def exec(tabla)
		@a = @primeraInstruccion.exec(tabla)
		unless (@primeraInstruccion.is_a?(InstruccionReturn) || @restoInstrucciones.nil?)
			@restoInstrucciones.exec(tabla)
		end
		return @a
	end
end
class NuevaVariable
	def initialize(valor)
		@valor = valor
	end
	def to_s
		"#{@valor.to_s}"
	end
end

class DeclaracionSinInit
	def initialize(tipo, identificador)
		@tipo = tipo
		@identificador = identificador

	end
	def check(tabla)
		@t = @tipo.check(tabla)
		@n = @identificador.to_s
		tabla.agregarTabla(@n,@t)
	end
	def exec(tabla)
		if @t.is_a?(TipoNum)
			@valor = 0.0
		elsif @t.is_a?(TipoBool)
			@valor = false
		else
			@filas = @t.dameFilas.to_i
			@columnas = @t.dameColumnas.to_i
			@valor = Matrix.zero(@filas,@columnas)
		end
		tabla.agregarTablaValores(@n,@valor)

	end
end
class DeclaracionConInit
	def initialize(tipo, identificador, expresion)
		@tipo = tipo
		@identificador = identificador
		@expresion = expresion
	end
	def check(tabla)		
		t = @tipo.check(tabla)
		n = @identificador.to_s
		e = @expresion.check(tabla)
		unless t.to_s.eql? e.to_s then
			raise ErrorTipo::new(@expresion, e, t)
		end
		tabla.agregarTabla(n,t)
	end
	def exec(tabla)
		n = @identificador.to_s
		exp = @expresion.exec(tabla)
		tabla.agregarTablaValores(n,exp)
	end
end
class ListaDeclaraciones
	def initialize(primeraDeclaracion, restoDeclaraciones)
		@primeraDeclaracion = primeraDeclaracion
		@restoDeclaraciones = restoDeclaraciones
	end
	def check(tabla)
		@primeraDeclaracion.check(tabla)
		@restoDeclaraciones.check(tabla)
	end
	def exec(tabla)
		@primeraDeclaracion.exec(tabla)
		@restoDeclaraciones.exec(tabla)
	end
end
class LiteralCadena
	def initialize(valor)
		@valor = valor
	end
	def check(tabla)
		return "string"
	end
	def exec(tabla)
		#@str = ""
		#str << @valor.to_s[1,@valor.to_s.length - 2]
		#puts "#{@valor.to_s}"
		return "print #{@valor.to_s}"
	end
end
class ProyeccionMatriz
	def initialize(expr, fila, columna)
		@expr = expr
		@fila = fila
		@columna = columna
	end
	def check(tabla)
		@typeExpr = @expr.check(tabla)
		typeFil = @fila.check(tabla)
		typeCol = @columna.check(tabla)
		unless @typeExpr.is_a?(TipoMatriz) then
			raise ErrorTipo::new(@expr,@typeExpr,Matriz::new(0,0))
		end
		if (typeFil.is_a?(TipoNum) && typeCol.is_a?(TipoNum)) # Se chequea que las dimensiones sean numeros
			f = @fila.to_s.to_f
			c = @columna.to_s.to_f
			if (f < 0 || c < 0 || (f - f.to_i != 0) || (c - c.to_i != 0)) # Se chequea que las dimensiones sean enteros positivos
				raise ErrorDimensionesMatriz::new()
			else
				return TipoNum::new()
			end
		elsif not typeFil.is_a?(TipoNum)
			raise ErrorTipo::new(@fila, typeFil,TipoNum::new())
		else 
			raise ErrorTipo::new(@columna, typeCol,TipoNum::new())
		end
	end
	def exec(tabla)
		m = @expr.exec(tabla)
		i = @fila.exec(tabla).to_i
		if (i < 1 || i > @typeExpr.dameFilas.to_i)
			raise DimensionesMatriz
		end
		j = @columna.exec(tabla).to_i
		if (j < 1 || j > @typeExpr.dameColumnas.to_i)
			raise DimensionesMatriz
		end
		return m[i-1,j-1]
	end
end
class ProyeccionVector
	def initialize(expr, vector)
		@expr = expr
		@vector = vector
	end
	def check(tabla)

		@typeExpr = @expr.check(tabla)
		typeVector = @vector.check(tabla)		
		unless @typeExpr.is_a?(TipoMatriz) then
			raise ErrorTipo::new(@expr,@typeExpr,Matriz::new(0,0))
		end
		if (typeVector.is_a?(TipoNum)) # Se chequea que las dimensiones sean numeros
			v = @vector.to_s.to_f
			if (v < 0 || (v - v.to_i != 0) ) # Se chequea que las dimensiones sean enteros positivos
				raise ErrorDimensionesMatriz::new()
			else
				return TipoNum::new()
			end
		else 
			raise ErrorTipo::new(@vector,typeVector,TipoNum::new())
		end

	end
	def exec(tabla)
		m = @expr.exec(tabla)
		i = @vector.exec(tabla).to_i
		if @typeExpr.dameFilas == 1# Es un vector columna
			if (i < 1 || i > @typeExpr.dameColumnas.to_i)
				raise DimensionesMatriz
			end

		return m[0,i-1]
		else
			if (i < 1 || i > @typeExpr.dameFilas.to_i)
				raise DimensionesMatriz
			end

		return m[i-1,0]
		end
	end
end
class Imprime
	def initialize(string)
		@string = string
	end
	def check(tabla)
		@tipo = @string.check(tabla)
		
		#unless @tipo.is_a?(Tipo) or @tipo.eql? "string" then 
		#	raise ErrorImpresion::new(@tipo)
		#end
	end

	def exec(tabla)	
		@str = @string.exec(tabla)		
	end
end
class Lee
	def initialize(identificador)
		@identificador = identificador
	end
	def check(tabla)
		@tipoId = @identificador.check(tabla)
		unless (@tipoId.is_a?(TipoNum) || @tipoId.is_a?(TipoBool)) then
			raise ErrorTipo2::new(@identificador,@tipoId,TipoNum::new(),TipoBool::new())
		end
	end
	def exec(tabla)
		valorIzq = @identificador.exec(tabla)
		valorDer = $stdin.gets
		if !(valorDer.eql?(true) || valorDer.eql?(false))
			if @tipoId.is_a?(TipoNum)
				valorDer = valorDer.to_f
			else
				raise ErrorEjecucion
			end
		end
		tabla.actualizarTabla(valorIzq,valorDer)
	end
end
class DeclaracionVariableFor
	def initialize(identificador)
		@tipo = TipoNum::new()
		@identificador = identificador
		@expresion = 1
	end
	def check(tabla)
		#puts "entre"
		t = @tipo
		n = @identificador.to_s
		tabla.agregarTabla(n,t)
	end
	def exec(tabla)
		n = @identificador.to_s
		tabla.actualizarTabla(n,1)
	end
end

class BloqueUse
	def initialize(declaraciones, instrucciones)
		@declaraciones = declaraciones
		@instrucciones = instrucciones
	end
	def check(tabla)
		a = Alcance::new(tabla)
		tabla.naceHijoTabla(a)
		unless @declaraciones.nil? then
			@declaraciones.check(a)
		end
		unless @instrucciones.nil? then
			@instrucciones.check(a)
		end
	end
	def exec(tabla)
		a = TablaDeValores::new(tabla)
		tabla.naceHijoTabla(a)
		unless @declaraciones.nil? then
			@declaraciones.exec(a)
		end
		unless @instrucciones.nil? then
			@instrucciones.exec(a)
		end
	end
end
class Asignacion
	def initialize(ladoIzq, ladoDer)
		@ladoIzq = ladoIzq
		@ladoDer = ladoDer
	end
	def check(tabla)
		tipoIzq = @ladoIzq.check(tabla)
		tipoDer = @ladoDer.check(tabla)
		unless tipoIzq.to_s.eql? tipoDer.to_s then
			raise ErrorTipo::new(@ladoDer, tipoDer, tipoIzq)
		end
	end
	def exec(tabla)
		valorIzq = @ladoIzq.exec(tabla)
		valorDer = @ladoDer.exec(tabla)
		tabla.actualizarTabla(valorIzq,valorDer)
	end
end
class AsignacionMatricial
	def initialize(ladoIzq,fila,columna,valor)
		@ladoIzq = ladoIzq
		@fila = fila
		@columna = columna
		@valor = valor
	end
	def check(tabla)
		@tipoIzq = @ladoIzq.check(tabla)
		@tipoDer = @valor.check(tabla)
		@typeFil = @fila.check(tabla)
		@typeCol = @columna.check(tabla)
		unless @tipoIzq.is_a?(TipoMatriz) then
			raise ErrorTipo::new(@ladoIzq,@tipoIzq,Matriz::new(0,0))
		end
		unless @tipoDer.is_a?(TipoNum) then
			raise ErrorTipo::new(@ladoDer,@tipoDer,TipoNum)
		end
		if (@typeFil.is_a?(TipoNum) && @typeCol.is_a?(TipoNum)) # Se chequea que las dimensiones sean numeros
			f = @fila.to_s.to_f
			c = @columna.to_s.to_f
			if (f < 0 || c < 0 || (f - f.to_i != 0) || (c - c.to_i != 0)) # Se chequea que las dimensiones sean enteros positivos
				raise ErrorDimensionesMatriz::new()
			else
				return TipoNum::new()
			end
		elsif not typeFil.is_a?(TipoNum)
			raise ErrorTipo::new(@fila, @typeFil,TipoNum::new())
		else 
			raise ErrorTipo::new(@columna, @typeCol,TipoNum::new())
		end
	end
	def exec(tabla)
		m = @ladoIzq.exec(tabla)
		i = @fila.exec(tabla).to_i
		if (i < 1 || i > @tipoIzq.dameFilas.to_i)
			raise DimensionesMatriz
		end
		j = @columna.exec(tabla).to_i
		if (j < 1 || j > @tipoIzq.dameColumnas.to_i)
			raise DimensionesMatriz
		end
		v = @valor.exec(tabla)
		matriz = m.to_a
		#puts matriz.is_a?(Array)
		#puts m
		matriz[i-1][j-1] = v
		#puts matriz[i-1][j-1]
		#print matriz
		tabla.actualizarTabla(@ladoIzq.to_s,Matrix.rows(matriz))
	end
end
class AsignacionVectorial
	def initialize(ladoIzq,fila,valor)
		@ladoIzq = ladoIzq
		@fila = fila
		@valor = valor
	end
	def check(tabla)
		@tipoIzq = @ladoIzq.check(tabla)
		@tipoDer = @valor.check(tabla)
		@typeFil = @fila.check(tabla)
		unless @tipoIzq.is_a?(TipoMatriz) then
			raise ErrorTipo::new(@ladoIzq,@tipoIzq,Matriz::new(0,0))
		end
		unless @tipoDer.is_a?(TipoNum) then
			raise ErrorTipo::new(@ladoDer,@tipoDer,TipoNum)
		end
		if (@typeFil.is_a?(TipoNum)) # Se chequea que las dimensiones sean numeros
			f = @fila.to_s.to_f
			c = @columna.to_s.to_f
			if (f < 0 || (f - f.to_i != 0) ) # Se chequea que las dimensiones sean enteros positivos
				raise ErrorDimensionesMatriz::new()
			else
				return TipoNum::new()
			end
		else
			raise ErrorTipo::new(@fila, @typeFil,TipoNum::new())
		end
	end
	def exec(tabla)
		m = @ladoIzq.exec(tabla)
		i = @fila.exec(tabla).to_i
		v = @valor.exec(tabla)
		matriz = m.to_a
		if @tipoIzq.dameFilas == 1# Es un vector columna
			if (i < 1 || i > @tipoIzq.dameColumnas.to_i)
				raise DimensionesMatriz
			end

			matriz[0][i-1] = v		
			tabla.actualizarTabla(@ladoIzq.to_s,Matrix.rows(matriz))
		else
			if (i < 1 || i > @tipoIzq.dameFilas.to_i)
				raise DimensionesMatriz
			end
			matriz[i-1][0] = v		
			tabla.actualizarTabla(@ladoIzq.to_s,Matrix.rows(matriz))
		end
	end

end
class Lectura; end
class IfThen
	def initialize(expresion,instrucciones)
		@expresion = expresion
		@instrucciones = instrucciones
	end
	def check(tabla)
		tipoExpr = @expresion.check(tabla)
		unless tipoExpr.is_a?(TipoBool) then
			raise ErrorTipo::new(@expresion, tipoExpr,TipoBool::new())
		end
		unless @instrucciones.nil? then
			@instrucciones.check(tabla)
		end
	end
	def exec(tabla)
		condicion = @expresion.exec(tabla)
		if condicion
			@instrucciones.exec(tabla)
		end
	end
end
class IfThenElse
	def initialize(expresionIf,instruccionesIf,instruccionesElse)
		@expresionIf = expresionIf
		@instruccionesIf = instruccionesIf
		@instruccionesElse = instruccionesElse
	end
	def check(tabla)
		tipoExpr = @expresionIf.check(tabla)		
		unless tipoExpr.is_a?(TipoBool) then
			raise ErrorTipo::new(@expresionIf, tipoExpr,TipoBool::new())
		end

		unless @instruccionesIf.nil?
			@instruccionesIf.check(tabla)
		end
		unless @instruccionesElse.nil?
			@instruccionesElse.check(tabla)
		end
	end
	def exec(tabla)
		condicion = @expresionIf.exec(tabla)
		if condicion
			unless @instruccionesIf.nil?
				@instruccionesIf.exec(tabla)
			end
		else
			unless @instruccionesElse.nil?
				@instruccionesElse.exec(tabla)
			end
		end
	end
end
class IteracionWhile
	def initialize(expresion, instrucciones)
		@expresion = expresion
		@instrucciones = instrucciones
	end
	def check(tabla)
		tipoExpr = @expresion.check(tabla)
		unless tipoExpr.is_a?(TipoBool) then
			raise ErrorTipo::new(@expresion, tipoExpr,TipoBool::new())
		end
		unless @instrucciones.nil? then
			@instrucciones.check(tabla)
		end
	end
	def exec(tabla)
		while @expresion.exec(tabla)
			unless @instrucciones.nil?
				@instrucciones.exec(tabla)
			end
		end

	end
end
class IteracionFor
	def initialize(indice,rango,instrucciones)
		@tipoIndice = TipoNum::new()
		@indice = indice
		@rango = rango
		@instrucciones = instrucciones
	end
	def check(tabla)
		t = @tipoIndice
		n = @indice.to_s
		a = Alcance::new(tabla)		
		tabla.naceHijoTabla(a)
		a.agregarTabla(n,t)
		#tipoIndice = @indice.check(tabla)
		tipoRango = @rango.check(tabla)
		#unless tipoIndice.is_a?(TipoNum) then
		#	raise ErrorTipo::new(@indice, tipoIndice,TipoNum::new())
		#end
		unless tipoRango.is_a?(TipoMatriz) then
			raise ErrorTipo::new(@rango, tipoRango,Matriz::new(0,0))
		end
		unless @instrucciones.nil? then
			@instrucciones.check(a)
		end

	end
	def exec(tabla)
		a = TablaDeValores::new(tabla)
		tabla.naceHijoTabla(a)		
		a.agregarTablaValores(@indice,1)
		mat = @rango.exec(tabla)
		matriz = mat.to_a
		#print matriz
		filas = mat.row_size()
		columnas = mat.column_size()
		for j in (1..filas)
			for k in (1..columnas)
				a.actualizarTabla(@indice,matriz[j-1][k-1].to_f)
				unless @instrucciones.nil?
					@instrucciones.exec(a)
				end
			end
		end
	end
end
class LlamadaFuncionConArgs
	def initialize(nombre, argumentos)
		@nombre = nombre
		@argumentos = argumentos
	end
	def check(tabla)
		@tipoFuncion = tabla.buscarFuncion(@nombre.to_s)
		if @tipoFuncion.nil? then
			raise ErrorFuncionNoExiste::new(@nombre)
		else
			@funcion = tabla.dameFuncion(@nombre.to_s)
			if @funcion.nil? then
				raise ErrorFuncionNoExiste::new(@nombre)
			else
				(@parametros, @tipos) = @funcion.retornaParametros
				@misArgsTipos = Array.new
				@misArgsNombres = Array.new
				@argumentos.dameArgs(@misArgsTipos,@misArgsNombres,tabla)

				@funcion.verificaParametros(@misArgsTipos,@misArgsNombres,@tipos)
				return @tipoFuncion
			end
		end
	end
	def exec(tabla)
		@argumentos.exec(@funcion)
		@instrucciones = @funcion.dameInstrucciones
		unless @instrucciones.nil?
			a = @instrucciones.exec(@funcion)
		end
		#puts a
		return a
	end
end
class ListaArgumentos
	def initialize(primerArgumento, restoArgumentos)
		@primerArgumento = primerArgumento
		@restoArgumentos = restoArgumentos
	end
	def dameArgs(listaTipos,listaNombres,tabla)
		@tipoPrimerArg = @primerArgumento.check(tabla)
		listaTipos << @tipoPrimerArg
		listaNombres << @primerArgumento.to_s
		unless @restoArgumentos.nil? then
			@restoArgumentos.dameArgs(listaTipos,listaNombres,tabla)
		end
	end
	def exec(tabla)
		#puts tabla.nil?
		@primerArgumento.exec(tabla)
		unless @restoArgumento.nil?
			@restoArgumentos.exec(tabla)
		end
	end
end

class Argumento
	def initialize(arg)
		@arg = arg
	end
	def dameArgs(listaTipos,listaNombres,tabla)
		listaTipos << @arg.check(tabla)
		listaNombres << @arg.to_s
	end
	def check(tabla)
		return @arg.check(tabla)
	end
	def to_s
		"#{@arg.to_s}"
	end
	def exec(tabla)
		a = @arg.exec(tabla)
		tabla.agregarArgumento(a)
	end
end
class LlamadaFuncionSinArgs
	def initialize(nombre)
		@nombre = nombre
	end
	def check(tabla)
		@a = tabla.dameFuncion(@nombre.to_s)
		@tipoFuncion = tabla.buscarFuncion(@nombre.to_s)
		if @tipoFuncion.nil? then
			raise ErrorFuncionNoExiste::new(@nombre)
		else
			@funcion = tabla.dameFuncion(@nombre.to_s)

			if @funcion.nil? then
				raise ErrorFuncionNoExiste::new(@nombre)
			else
				(@parametros, @tipos) = @funcion.retornaParametros
				@funcion.verificaParametros(nil,nil,@tipos)
				return @tipoFuncion
			end
		end
	end
	def exec(tabla)
		@instrucciones = @a.dameInstrucciones
		unless @instrucciones.nil?
			a = @instrucciones.exec(@a)
		end
		#puts a
		return a
	end
end
class InstruccionReturn
	def initialize(expresionReturn)
		@expresionReturn = expresionReturn
	end
	def check(tabla)
		@a = tabla
		if not tabla.esFuncion
			raise ErrorReturn::new()
		end

		@tipoExpr = @expresionReturn.check(tabla)
		@tipoFuncion = tabla.tipo
		unless @tipoExpr.to_s.eql? @tipoFuncion.to_s then
			raise ErrorTipo::new(@expresionReturn, @tipoExpr, @tipoFuncion)
		end
	end
	def exec(tabla)
		@a.valorFuncion(@expresionReturn.exec(tabla))
		return @a.dameValorFuncion
	end
end

