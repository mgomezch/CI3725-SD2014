#!/usr/bin/env ruby 
# -*- coding: utf-8 -*-
# David Goudet 08-10479
# Susana Charara 08-10223

class ErrorContexto < RuntimeError
end
class ErrorTipo < ErrorContexto
	def initialize(expr, tipoActual, tipoEsperado)
		@expr = expr
		@tipoActual = tipoActual
		@tipoEsperado = tipoEsperado
	end
	def to_s
		"Error: La expresion '#{@expr.to_s}' tiene el tipo '#{@tipoActual.to_s}' y se esperaba el tipo '#{@tipoEsperado.to_s}'"
	end
end

class ErrorTipo2 < ErrorContexto
	def initialize(expr, tipoActual, tipoEsperado, tipoEsperado2)
		@expr = expr
		@tipoActual = tipoActual
		@tipoEsperado = tipoEsperado
		@tipoEsperado2 = tipoEsperado2
	end
	def to_s
		"Error: La expresion '#{@expr.to_s}' tiene el tipo '#{@tipoActual.to_s}' y se esperaba el tipo '#{@tipoEsperado.to_s}' o '#{@tipoEsperado2.to_s}'"
	end
end
class ErrorTiposDistintos < ErrorContexto
	def initialize(expr1, expr2)
		@expr1 = expr1
		@expr2 = expr2
	end
	def to_s
		"Error: Las expresiones '#{@expr1.to_s}' y '#{@expr2.to_s}' deben ser del mismo tipo"
	end
end
class ErrorTipoCruz < ErrorContexto
	def initialize(exprIzq, exprDer, tipoActual1, tipoActual2, tipoEsperado1, tipoEsperado2)
		@exprIzq = exprIzq
		@exprDer = exprDer
		@tipoActual1 = tipoActual1
		@tipoActual2 = tipoActual2		
		@tipoExperado1 = tipoEsperado1
		@tipoEsperado2 = tipoEsperado2
	end
	def to_s
		"Error: La expresion #{@exprIzq.to_s} tiene tipo '#{@tipoActual1.to_s}' y la expresion #{@exprDer.to_s}' tiene el tipo '#{@tipoActual2.to_s}', y se esperaban tipos '#{@tipoEsperado1.to_s}' y '#{@tipoEsperado2.to_s}'"
	end
end
class ErrorDimensionesMatriz < ErrorContexto
	def initialize()
	end
	def to_s
		"Error: Las dimensiones matriciales y vectoriales deben ser enteros positivos"
	end
end
class ErrorLiteralMatricial < ErrorContexto
	def initialize()
	end
	def to_s
		"Error: Literal matricial mal formado"
	end
end
class ErrorVariableYaDefinida < ErrorContexto
	def initialize(nombre)
		@nombre = nombre
	end
	def to_s
		"Error: variable '#{@nombre}' ya esta definida en este alcance"
	end
end
class ErrorVariableNoExiste < ErrorContexto
	def initialize(nombre)
		@nombre = nombre
	end
	def to_s
		"Error: variable '#{@nombre}' no esta definida en este alcance"
	end
end
class ErrorFuncionYaDefinida < ErrorContexto
	def initialize(nombre)
		@nombre = nombre
	end
	def to_s
		"Error: funcion '#{@nombre}' ya esta definida en este alcance"
	end
end
class ErrorFuncionNoExiste < ErrorContexto
	def initialize(nombre)
		@nombre = nombre
	end
	def to_s
		"Error: funcion '#{@nombre}' no esta definida en este alcance"
	end
end
class ErrorReturn < ErrorContexto
	def to_s
		"Error: No se esperaba instruccion 'return'"
	end
end
class ErrorNumeroParametros < ErrorContexto
	def initialize(nombre)
		@nombre = nombre
	end
	def to_s
		"Error en llamada a la funcion #{@nombre.to_s}: Numero de parametros incorrecto"
	end
end
class ErrorImpresion < ErrorContexto
	def initialize(tipo)
		@tipo = tipo
	end
	def to_s
		"Error: Instruccion print no es valida para tipo #{@tipo.to_s}"
	end
end

