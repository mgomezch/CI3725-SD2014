#!/usr/bin/env ruby 
# -*- coding: utf-8 -*-
# David Goudet 08-10479
# Susana Charara 08-10223

class TablaDeValores
	def initialize(padre)
		@tabla = {}
		@hijos = []
    	@padre = padre
    	@funciones = {}
    	@accesoFunciones = {} # SOlo para acceder a funciones
  	end
	def agregarTablaValores(nombre, valor)
		@tabla[nombre.to_s] = valor
	end
	def actualizarTabla(nombre, valor)
	    if @tabla.has_key?(nombre.to_s) then
			@tabla[nombre.to_s] = valor	
		else
			return @padre.actualizarTabla(nombre.to_s,valor)
		end

	end
	def agregarFuncion(nombre, alcanceFuncion)
		@accesoFunciones[nombre] = alcanceFuncion
	end
	def naceHijoTabla(hijo)
		@hijos << hijo
	end
	def dameFuncion(nombre)
		#puts @accesoFunciones.has_key?(nombre.to_s)	
		if @accesoFunciones.has_key?(nombre) then
			return @accesoFunciones[nombre]
		else
			unless @padre.nil? then
	      		return @padre.dameFuncion(nombre)
	      	else
	      		return nil
	      	end
	    	
	    end
	end
	def buscarTablaLocal(nombre)
	    if @tabla.has_key?(nombre.to_s) then
	    	return @tabla[nombre.to_s]
	    else
	    	return nil
	    end
	end
	def buscarTablaVariable(nombre)
	    if @tabla.has_key?(nombre) then
	    	return nombre
	    elsif @padre.nil? then
	      	return nil
	    else
			return @padre.buscarTablaVariable(nombre)
	    end
	end
	def buscarTablaValor(nombre)
	    if @tabla.has_key?(nombre) then
	    	return @tabla[nombre]
	    else
			return @padre.buscarTablaValor(nombre)
	    end
	end

	def agregarFuncion(nombre, tipo, alcanceFuncion)

		pertenece = buscarFuncionLocal(nombre)

		if pertenece.nil?

			@funciones[nombre] = tipo
			@accesoFunciones[nombre] = alcanceFuncion
	    else

	    	raise ErrorFuncionYaDefinida::new(nombre)
	    end
	end
	def buscarFuncionLocal(nombre) # SOLO SE USA PARA AGREGAR FUNCIONES
	    if @funciones.has_key?(nombre) then
	    	return @funciones[nombre]
	    else
	      	return nil

	    end
	end
	def buscarFuncion(nombre) #SOLO SE USA CUANDO SE LLAMAN FUNCIONES
	    if @funciones.has_key?(nombre) then
	    	return @funciones[nombre]
	    else
	    	unless @padre.nil? then
	      		return @padre.buscarFuncion(nombre)
	      	else
	      		return nil
	      	end
	    end
	end
	def simbolosTabla
		@string = ""
		@tabla.each do |k,v|
			@string << "\"#{k}\": \"#{v.to_s}\","
		end
		return @string
	end
	def hijosTabla
		@str = ""
		n = @hijos.length
		for i in (0..n-1)
			if i == n-1 then				
				@str << @hijos[i].tablaTo_s
			else
				@str << @hijos[i].tablaTo_s + ","
			end
		end
		return @str
	end

	def tablaTo_s
		
		return "{#{simbolosTabla} \"Hijos\":  [#{hijosTabla}]}"
	end
	def tipo
		if not @padre.nil?
			return @padre.tipo
		else
			return nil
		end
	end
	def funcionesTo_s
		@accesoFunciones.each do |key,value| 
			puts "Alcance funcion #{key}:\n"
			puts JSON.pretty_generate(JSON.parse(value.tablaTo_s)) 
		end
		

	end
	def esFuncion
		if @tipo.nil?
			if not @padre.nil?
				if @padre.tipo.nil?
					return @padre.esFuncion
				else
					return true
				end
			else
				return false
			end
		else
			return true
		end
	end

end
