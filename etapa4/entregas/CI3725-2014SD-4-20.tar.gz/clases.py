# -*- coding: UTF-8 -*-
################################################################################
#        Clases empleadas para la gramática establecida para Trinity
#                                                                   
# Elaborado por 
#               Fabio Castro 10-10132
#               Donato Rolo  10-10640
#                                              
################################################################################
import sys
import SymTable
import math
import copy

# Clase: Lista
# Descripción: da lugar a una lista genérica de elementos para varios fines.
class Lista:
    def __init__(self, elem=None):
        if elem is not None:
            self.elem=[elem]
            #self.elem.append(elem)
        else:
            self.elem = []

    def set_lista(self):
        return self.elem

    def agregar(self, elem):
        self.elem.append(elem)

    def imprimir(self, sangria):
        prt = " "
        sangria = sangria + "  "
        for i in self.elem:
            prt = prt + sangria + i.imprimir(sangria)
        return prt

    def __str__(self):
        aux = " "
        for i in self.elem:
            aux = aux + " " + str(i)
        return aux

# Clase: Program
# Descripción: permite el reconocimiento del inicio de un programa gracias a la
#              palabra PROGRAM, seguido de la instrucción correspondiente.
class Program:
    def __init__(self, list_fun, lista_inst):
        self.list_fun = list_fun
        self.lista_inst = lista_inst
        self.tabla = None

    def imprimir(self,sangria):
        sangria = sangria + " "
        return "Alcance Program:\n" + sangria + "Hijos:" + self.lista_inst.imprimir(sangria)
    def __str__(self):
        return "PROGRAM \n %s" %(self.inst)

    def verificar(self):
      tabla = SymTable.SymTable()
      self.tabla = tabla
      errores = []
      if (not(self.list_fun == [])):
        auxlista = self.list_fun.set_lista()
        for inst in auxlista:
            lista = SymTable.Simbolo(inst.id,True)
            lista.setRetorno = inst.tiporetorno
            lista.setValor(inst)
            tabla.insert(Lista(lista), inst.funcion)
            errores = errores + inst.verificar(tabla)
      auxlista = self.lista_inst.set_lista()
      for inst in auxlista:
          errores = errores + inst.verificar(tabla)
      return  errores

    def ejecutar(self):
      # self.list_fun.ejecutar()
      auxlista = self.lista_inst.set_lista()
      for inst in auxlista:
          # print inst
          inst.ejecutar()

# Clase: Asignación
# Descripción: permite que el reconocedor identifique las partes de una asignación
#              (variable y valor dado)
class Asignacion:
    def __init__(self, var, valor):
        self.var = var
        self.valor = valor
        self.tabla = None

    def imprimir(self,sangria):
      return "ASIGNACION"

    def __str__(self):
        return "\nASIGNACION \n var: %s \n valor: %s" %(self.var, self.valor)

    def verificar(self, symtab):
            self.tabla = symtab
            auxsymtab = symtab
            auxsym = symtab.find(self.var.identif)
            symtab = self.tabla
            if(self.var.esBool(symtab) == []):
              if(self.valor.esBool(symtab) != []):
                return ["errorAsignacion"]
            if(self.var.esInt(symtab) == []):
              if(self.valor.esInt(symtab) != []):
                return ["errorAsignacion"]
            if(self.var.esMatrix(symtab) == []):
              if(self.valor.esMatrix(symtab) != []):
                return ["errorAsignacion"]
              else:
                pass
                print float(str(auxsym.getFila()))
                print float(str(self.valor.filas))
                print float(str(auxsym.getColumna()))
                print float(str(self.valor.col))
                if(float(str(auxsym.getColumna()))!=float(str(self.valor.col)))or(float(str(auxsym.getFila()))!=float(str(self.valor.filas))):
                  return ["errorAsignacion"]
            # try:
            #   if callable(getattr(self.var, 'esFunc')):
            #     return self.var.esFunc(symtab)
            # except ZeroDivisionError:
            #   pass          
            # if(self.var.esFunc):
              # return []
            if (not(auxsym is None)):
                if(auxsym.getModificable()):
                    symtype = auxsym.getTipo()
                    if(symtype=="boolean"):        
                       # print "PNONR" + str(self.valor) + "VARIABLE: " + str(self.var)                
                        errores = self.valor.esBool(self.tabla)
                       # print "SALIO"
                        #uxsym.setValor(0)   #Inicializacion momentanea
                        return errores
                    elif(symtype== "number"):
                        errores = self.valor.esInt(self.tabla)
                        #auxsym.setValor(0)   #Inicializacion momentanea
                        return errores
                else:
                    return ["ERROR en la linea "+ \
                           str(self.var.linea)+ ", columna " + \
                           str(self.var.columna) + \
                           ": La variable \""+ self.var.identif+ \
                           "\" pertenece a una iteracion y no" + \
                           " puede ser modificada"] + self.valor.esInt(self.tabla)                   
            else:
                    return ["ERROR en la linea "+ \
                           str(self.var.linea)+ ", columna " + \
                           str(self.var.columna) + \
                           ": La variable \""+ self.var.identif+ \
                           "\" no ha sido declarada en nigun bloque" + \
                           " con alcance a esta aparicion"] + self.valor.esValida(auxsymtab)

    def ejecutar(self):
        auxsym = self.tabla.find(self.var.identif)
        #print auxsym.imprimir(" ")
        valor = self.valor.evaluar(self.tabla)
        if(auxsym.getTipo()=="int"):
            verificarnumero(valor)
        auxsym.setValor(valor)
              

# Clase: Asignación Matriz
# Descripción: p
class AsignacionMatrix:

    def __init__(self, var, posic, valor):
        self.var = var
        self.posic = posic
        self.valor = valor
        self.tabla = None

    def imprimir(self,sangria):
      return str()
    # def imprimir(self, sangria):
    #     prt =  sangria + "ASIGNACION MATRIZ"
    #     sangria = sangria + "  "  
    #     prt = prt + "\n"+ sangria + "var: " + self.var.imprimir(sangria)
    #     prt = prt + "\n"+ sangria + "valor: " + self.valor.imprimir(sangria)
    #     return prt

    def __str__(self):
        return "\nASIGNACION DE MATGUEBORIZ \n var: %s \n valor: %s" %(self.var, self.valor)


    def verificar(self, symtab):
            self.tabla = symtab  
            auxsymtab = symtab
            auxsym = symtab.find(self.var.identif)
            symtab = self.tabla
            if (symtab.find(self.valor)==None):
              # print "ESTO ES"
              # print self.valor
              # print "AQUI TERMINA"
              #print self.valor.esInt(symtab)
              if(self.valor is not None):
                if(self.valor.esInt(symtab)!=[])and(self.valor.esBool(symtab)!=[])and(self.valor.esMatrix(symtab)!=[]):
                  return ["errorAsigMatrix"]
            for i in self.posic.set_lista():
              if i is not None:
                if(i.esInt(symtab)!=[]):
                  j = symtab.find(i)
                  if(j is not None):
                    if(j.esInt(symtab)!=[]):
                      return ["errorAsigMatrix"]
                    else:
                      return j.verificar(symtab)
                      # if():
                      #   return ["error"]
                  else:
                    return ["errorAsigMatrix"]
            # print self.var
            # print symtab.find(self.var)
            # print "HOLA"
            # print symtab.imprimir(" ")
            x = symtab.find(self.var)
            if x is not None:
              if(x.getTipo() != "matrix" ):
                return ["errorAsigMatrix"]
            if (not(auxsym is None)):
                if(auxsym.getModificable()):
                    symtype = auxsym.getTipo()
                    if(symtype=="boolean"):                        
                        errores = self.valor.esBool(self.tabla)
                        auxsym.setValor(0)   #Inicializacion momentanea
                        return errores
                    elif(symtype== "number"):
                        errores = self.valor.esInt(self.tabla)
                        auxsym.setValor(0)   #Inicializacion momentanea
                        return errores
                else:
                    return ["ERROR en la linea "+ \
                           str(self.var.linea)+ ", columna " + \
                           str(self.var.columna) + \
                           ": La variable \""+ self.var.identif+ \
                           "\" pertenece a una iteracion y no" + \
                           " puede ser modificada"] + self.valor.esInt(self.tabla)                   
            else:
                    return ["ERROR en la linea "+ \
                           str(self.var.linea)+ ", columna " + \
                           str(self.var.columna) + \
                           ": La variable \""+ self.var.identif+ \
                           "\" no ha sido declarada en nigun bloque" + \
                           " con alcance a esta aparicion"] + self.valor.esValida(auxsymtab)
    def ejecutar(self):
          posiclist = self.posic.set_lista()
          posrow = int(posiclist[0].evaluar(self.tabla) - 1)
          poscol = int(posiclist[1].evaluar(self.tabla) - 1)
          valor = self.valor.evaluar(self.tabla)
          matriz = self.tabla.find(self.var.identif)
          auxiliar = matriz.getValor().elementos.set_lista()[posrow]
          auxiliar.set_lista()[poscol] = Numero(valor, 0 , 0)


class AsignacionColRow:
    
    def __init__(self, var, posic_column_row, valor):
        self.var = var
        self.posic_column_row = posic_column_row
        self.valor = 0
        self.tabla = None

    def imprimir(self,sangria):
      return str()

    def verificar(self, symtab):
        self.tabla = symtab
        auxsymtab = symtab
        auxsym = symtab.find(self.var.identif)
        symtab = self.tabla
        if (not(auxsym is None)):
            if(auxsym.getModificable()):
                symtype = auxsym.getTipo()
                if(symtype=="boolean"):                        
                    errores = self.valor.esBool(self.tabla)
                    auxsym.setValor(0)   #Inicializacion momentanea
                    return errores
                elif(symtype== "number"):
                    errores = self.valor.esInt(self.tabla)
                    auxsym.setValor(0)   #Inicializacion momentanea
                    return errores
            else:
                return ["ERROR en la linea "+ \
                       str(self.var.linea)+ ", columna " + \
                       str(self.var.columna) + \
                       ": La variable \""+ self.var.identif+ \
                       "\" pertenece a una iteracion y no" + \
                       " puede ser modificada"] + self.valor.esInt(self.tabla)                   
        else:
                return ["ERROR en la linea "+ \
                       str(self.var.linea)+ ", columna " + \
                       str(self.var.columna) + \
                       ": La variable \""+ self.var.identif+ \
                       "\" no ha sido declarada en nigun bloque" + \
                       " con alcance a esta aparicion"] + self.valor.esValida(auxsymtab)

# Clase: ExpresionBin
# Descripción: esta clase permite que el reconocedor identifique las expresiones
#              binarias, primero el operador, luego el operando izquierdo y 
#              finalmente el derecho
class ExpresionBin:
    def __init__(self, operador, operand1, operand2, linea, columna):
        self.operador = operador
        self.tipo = None
        self.operand1 = operand1
        self.operand2 = operand2
        self.linea = linea       
        self.columna = columna
        self.tabla = None

    def imprimir(self,sangria):
      return str()

    def __str__(self):
        return "EXPRESION_BIN \n operador: %s \n operando izq: %s \n operando der: %s" %(self.operador, self.operand1, self.operand2)  


    def esBool(self, symtab):
        if (self.operador == "AND"):
            expbool = self.operand1.esBool(symtab) + self.operand2.esBool(symtab)      
            if (not (expbool)): 
                return []
            return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "conjuncion"+ \
                  "\" necesita de operandos booleanos para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab)
        elif(self.operador == "OR"):
            expbool = self.operand1.esBool(symtab) + self.operand2.esBool(symtab)      
            if (not (expbool)): 
                return []
            return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "disyuncion"+ \
                  "\" necesita de operandos booleanos para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab)
        elif(self.operador == "IGUAL"):
            expbool = self.operand1.esBool(symtab) + self.operand2.esBool(symtab);
            if (not (expbool)):
                self.tipo = 2
                return []
            expmatriz = self.operand1.esMatrix(symtab) + self.operand2.esMatrix(symtab);
            if (not (expmatriz)):
                self.tipo = 3
                return []
                # self.operand1.Dimesiones(self.operand2)
            expint = self.operand1.esInt(symtab) + self.operand2.esInt(symtab) 
            if (not (expint)):
                self.tipo = 1 
                return []     
            return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "equivalencia"+ \
                  "\" necesita de operandos del mismo tipo para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab) 
        elif(self.operador == "DIFERENTE"):
            expbool = self.operand1.esBool(symtab) + self.operand2.esBool(symtab)      
            if (not (expbool)):
                self.tipo = 2
                return []
            expmatriz = self.operand1.esMatrix(symtab) + self.operand2.esMatrix(symtab);
            if (not (expmatriz)): 
                self.tipo = 3
                return self.operand1.Dimesiones(self.operand2)
            expint = self.operand1.esInt(symtab) + self.operand2.esInt(symtab)      
            if (not (expint)):
                self.tipo = 1 
                return []     
            return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "desigualdad"+ \
                  "\" necesita de operandos del mismo tipo para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab) 
        elif(self.operador == "MAYOR"): 
            expint = self.operand1.esInt(symtab) + self.operand2.esInt(symtab)      
            if (not (expint)):
                self.tipo = 1
                return []     
            return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "mayor"+ \
                  "\" necesita de operandos del mismo tipo para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab) 
        elif(self.operador == "MENOR"):
            expint = self.operand1.esInt(symtab) + self.operand2.esInt(symtab)
            if (not (expint)):
                self.tipo = 1 
                return []     
            return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "menor"+ \
                  "\" necesita de operandos del mismo tipo para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab) 
        elif(self.operador == "MAYORIGUAL"):
            expint = self.operand1.esInt(symtab) + self.operand2.esInt(symtab)
            if (not (expint)):
                self.tipo = 1
                return []     
            return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "mayor o igual"+ \
                  "\" necesita de operandos del mismo tipo para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab) 
        elif(self.operador == "MENORIGUAL"):
            expint = self.operand1.esInt(symtab) + self.operand2.esInt(symtab)
            if (not (expint)):
                self.tipo = 1 
                return []     
            return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "menor o igual"+ \
                  "\" necesita de operandos del mismo tipo para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab) 
        else:
           return ["ERROR en la linea " + str(self.linea) + \
                  ", columna " + str(self.columna) + ": El operador \"" +  
                  self.operador.lower() + \
                  "\" no devuelve una expresion de tipo bool"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab) 

    def esInt(self, symtab):
        if(self.operador == "MAS"):
            #print self.operand1
            expint = self.operand1.esInt(symtab) + self.operand2.esInt(symtab)      
            if (not (expint)):
                self.tipo = 1
                return []
            return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "suma"+ \
                  "\" necesita de operandos enteros para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab)
        elif(self.operador == "MULTIPLICAR"):
            expint = self.operand1.esInt(symtab) + self.operand2.esInt(symtab)      
            if (not (expint)):
                self.tipo = 1
                return []
            return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "multiplicacion"+ \
                  "\" necesita de operandos enteros para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab)
        elif(self.operador == "MENOS"):
            expint = self.operand1.esInt(symtab) + self.operand2.esInt(symtab)      
            if (not (expint)): 
                return []
            return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "resta"+ \
                  "\" necesita de operandos enteros para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab)
        elif(self.operador == "DIVISION"):
            expint = self.operand1.esInt(symtab) + self.operand2.esInt(symtab)      
            if (not (expint)): 
                return []
            return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "division"+ \
                  "\" necesita de operandos enteros para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab)        
        elif(self.operador == "DIV"):
            expint = self.operand1.esInt(symtab) + self.operand2.esInt(symtab)      
            if (not (expint)): 
                return []
            return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "division"+ \
                  "\" necesita de operandos enteros para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab)
        elif(self.operador == "MOD"):
            expint = self.operand1.esInt(symtab) + self.operand2.esInt(symtab)      
            if (not (expint)): 
                return []
            return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "division"+ \
                  "\" necesita de operandos enteros para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab)
        elif(self.operador == "RESTO"):
            expint = self.operand1.esInt(symtab) + self.operand2.esInt(symtab)      
            if (not (expint)): 
                return []
            return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "division"+ \
                  "\" necesita de operandos enteros para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab)
        else:
           return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  self.operador.lower()+ \
                  "\" no devuelve una expresion de tipo int"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab) 

    def esMatrix(self, symtab):
        if(self.operador == "MAS"):
            expma = self.operand1.esMatrix(symtab) + self.operand2.esMatrix(symtab)
            if (not (expma)): 
                self.tipo=3
                return []
                 # self.operand1.Dimesiones(self.operand2)   
            return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "suma"+ \
                  "\" necesita de operandos enteros para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab)
        elif(self.operador == "MULTIPLICAR"):
            expma = self.operand1.esMatrix(symtab) + self.operand2.esMatrix(symtab)   
            if (not (expma)): 
                self.tipo=3
                return []
            return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "suma"+ \
                  "\" necesita de operandos enteros para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab)
        elif(self.operador == "MENOS"):
            expma = self.operand1.esMatrix(symtab) + self.operand2.esMatrix(symtab)    
            if (not (expma)): 
                self.tipo=3
                return []
            return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "suma"+ \
                  "\" necesita de operandos enteros para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab)
        elif(self.operador == "DIVISION"):
            expma = self.operand1.esMatrix(symtab) + self.operand2.esMatrix(symtab)      
            if ((expma)): 
                  return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "suma"+ \
                  "\" necesita de operandos enteros para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab)
        elif(self.operador == "MOD"):
            expma = self.operand1.esMatrix(symtab) + self.operand2.esMatrix(symtab)      
            if ((expma)):  
                  return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "suma"+ \
                  "\" necesita de operandos enteros para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab)
        elif(self.operador == "MATRIX_DIVISION"):
            expma = self.operand1.esMatrix(symtab) + self.operand2.esInt(symtab)
            expma2 = self.operand1.esInt(symtab) + self.operand2.esMatrix(symtab)   
            if (not (expma))or(not (expma2)): 
                if(not expma):
                  self.tipo=3
                if(not expma2):
                  self.tipo=4
                return []
            return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "suma"+ \
                  "\" necesita de operandos enteros para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab)
        elif(self.operador == "MAS_MATRIX_NUMBER"):
            expma  = self.operand1.esMatrix(symtab) + self.operand2.esInt(symtab)
            expma2 = self.operand2.esMatrix(symtab) + self.operand1.esInt(symtab)         
            if (not (expma))or(not (expma2)): 
                if(not expma):
                  self.tipo=3
                if(not expma2):
                  self.tipo=4
                return []
            return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "suma"+ \
                  "\" necesita de operandos enteros para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab)
        elif(self.operador == "MENOS_MATRIX_NUMBER"):
            expma  = self.operand1.esMatrix(symtab) + self.operand2.esInt(symtab)
            expma2 = self.operand2.esMatrix(symtab) + self.operand1.esInt(symtab)         
            if (not (expma))or(not (expma2)): 
                if(not expma):
                  self.tipo=3
                if(not expma2):
                  self.tipo=4
                return []
            return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "suma"+ \
                  "\" necesita de operandos enteros para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab)
        elif(self.operador == "MATRIX_DIVISION"):
            expma  = self.operand1.esMatrix(symtab) + self.operand2.esInt(symtab)
            expma2 = self.operand2.esMatrix(symtab) + self.operand1.esInt(symtab)         
            if (not (expma))or(not (expma2)): 
                if(not expma):
                  self.tipo=3
                if(not expma2):
                  self.tipo=4
                return []
            return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "suma"+ \
                  "\" necesita de operandos enteros para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab)
        elif(self.operador == "MENOS_MATRIX_NUMBER"):
            expma  = self.operand1.esMatrix(symtab) + self.operand2.esInt(symtab)
            expma2 = self.operand2.esMatrix(symtab) + self.operand1.esInt(symtab)         
            if (not (expma))or(not (expma2)): 
                if(not expma):
                  self.tipo=3
                if(not expma2):
                  self.tipo=4
                return []
            return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "suma"+ \
                  "\" necesita de operandos enteros para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab)
        elif(self.operador == "MATRIX_RESTO"):
            expma  = self.operand1.esMatrix(symtab) + self.operand2.esInt(symtab)
            expma2 = self.operand2.esMatrix(symtab) + self.operand1.esInt(symtab)         
            if (not (expma))or(not (expma2)): 
                if(not expma):
                  self.tipo=3
                if(not expma2):
                  self.tipo=4
                return []
            return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "suma"+ \
                  "\" necesita de operandos enteros para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab)
        elif(self.operador == "MATRIX_DIVISION_ENTERA"):
            expma  = self.operand1.esMatrix(symtab) + self.operand2.esInt(symtab)
            expma2 = self.operand2.esMatrix(symtab) + self.operand1.esInt(symtab)         
            if (not (expma))or(not (expma2)): 
                if(not expma):
                  self.tipo=3
                if(not expma2):
                  self.tipo=4
                return []
            return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "suma"+ \
                  "\" necesita de operandos enteros para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab)
        elif(self.operador == "MATRIX_RESTO_ENTERO"):
            expma  = self.operand1.esMatrix(symtab) + self.operand2.esInt(symtab)
            expma2 = self.operand2.esMatrix(symtab) + self.operand1.esInt(symtab)         
            if (not (expma))or(not (expma2)): 
                if(not expma):
                  self.tipo=3
                if(not expma2):
                  self.tipo=4
                return []
            return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "suma"+ \
                  "\" necesita de operandos enteros para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab)
        elif(self.operador == "MATRIX_DIVISION_ENTERA"):
            expma  = self.operand1.esMatrix(symtab) + self.operand2.esInt(symtab)
            expma2 = self.operand2.esMatrix(symtab) + self.operand1.esInt(symtab)         
            if (not (expma))or(not (expma2)): 
                if(not expma):
                  self.tipo=3
                if(not expma2):
                  self.tipo=4
                return []
            return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "suma"+ \
                  "\" necesita de operandos enteros para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab)
        elif(self.operador == "MULTIPLICAR_MATRIX_NUMBER"):
            expma  = self.operand1.esMatrix(symtab) + self.operand2.esInt(symtab)
            expma2 = self.operand2.esMatrix(symtab) + self.operand1.esInt(symtab)         
            if (not (expma))or(not (expma2)): 
                if(not expma):
                  self.tipo=3
                if(not expma2):
                  self.tipo=4
                return []
            return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  "suma"+ \
                  "\" necesita de operandos enteros para ser valido"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab)
        else:
           return ["ERROR en la linea "+ str(self.linea)+ \
                  ", columna " + str(self.columna)+ ": El operador \""+  
                  self.operador.lower()+ \
                  "\" no devuelve una expresion de tipo int"] + \
                  self.operand1.esValida(symtab) + self.operand2.esValida(symtab) 

    def verificar(self, symtab):
        return  self.esValida(symtab)

    def esValida(self, symtab):
        return  self.operand1.esValida(symtab) + self.operand2.esValida(symtab)

    def evaluar(self, symtab):
        if (self.operador == "AND"):
            return self.operand1.evaluar(symtab) and self.operand2.evaluar(symtab)   
        elif(self.operador == "OR"):
            return self.operand1.evaluar(symtab) or self.operand2.evaluar(symtab)
        elif(self.operador == "IGUAL"):
            if(self.tipo<=2):
                exp1 = self.operand1.evaluar(symtab)
                exp2 = self.operand2.evaluar(symtab)
                if(self.tipo==1):
                    verificarnumero(exp1)
                    verificarnumero(exp2)
                return (exp1==exp2)
            elif(self.tipo==3):
                exp1 = self.operand1.evaluar(symtab)
                exp2 = self.operand2.evaluar(symtab)
                for i in range(0,len(exp1.set_lista()[0].set_lista())):
                  temp3 = Lista()
                  for j in range(0,(len(exp2.set_lista()))):
                      valor =  exp1.set_lista()[i].set_lista()[j].evaluar(symtab) == exp2.set_lista()[i].set_lista()[j].evaluar(symtab)
                      if not valor:
                        break
                return valor
        elif(self.operador == "DIFERENTE"):
            if(self.tipo<=2):
                exp1 = self.operand1.evaluar(symtab)
                exp2 = self.operand2.evaluar(symtab)
                if(self.tipo==1):
                    verificarnumero(exp1)
                    verificarnumero(exp2)
                return (exp1!=exp2)
            elif(self.tipo==3):
                exp1 = self.operand1.evaluar(symtab)
                exp2 = self.operand2.evaluar(symtab)
                for i in range(0,len(exp1.set_lista()[0].set_lista())):
                  temp3 = Lista()
                  for j in range(0,(len(exp2.set_lista()))):
                      valor =  exp1.set_lista()[i].set_lista()[j].evaluar(symtab) != exp2.set_lista()[i].set_lista()[j].evaluar(symtab)
                      if not valor:
                        break
                return valor
        elif(self.operador == "MAYOR"):
            if(self.tipo<=2):
                exp1 = self.operand1.evaluar(symtab)
                exp2 = self.operand2.evaluar(symtab)
                verificarnumero(exp1)
                verificarnumero(exp2)
                return (exp1>exp2)
            return (self.operand1.evaluar(symtab)[0]>self.operand2.evaluar(symtab)[1])
        elif(self.operador == "MENOR"):
            if(self.tipo<=2):           
                exp1 = self.operand1.evaluar(symtab)
                exp2 = self.operand2.evaluar(symtab)
                verificarnumero(exp1)
                verificarnumero(exp2)
                return exp1<exp2
            return (self.operand1.evaluar(symtab)[1]<self.operand2.evaluar(symtab)[0])
        elif(self.operador == "MAYORIGUAL"):
            if(self.tipo<=2):
                exp1 = self.operand1.evaluar(symtab)
                exp2 = self.operand2.evaluar(symtab)
                verificarnumero(exp1)
                verificarnumero(exp2)
                return (exp1>=exp2)
            return (self.operand1.evaluar(symtab)[0]>=self.operand2.evaluar(symtab)[1])
        elif(self.operador == "MENORIGUAL"):
            if(self.tipo<=2):
                exp1 = self.operand1.evaluar(symtab)
                exp2 = self.operand2.evaluar(symtab)
                verificarnumero(exp1)
                verificarnumero(exp2)
                return (exp1<=exp2)
            return (self.operand1.evaluar(symtab)[1]<=self.operand2.evaluar(symtab)[0]) 
        elif(self.operador == "MAS"):
            if(self.tipo<=2):
                exp1 = self.operand1.evaluar(symtab)
                exp2 = self.operand2.evaluar(symtab)
                verificarnumero(exp1)
                verificarnumero(exp2)
                exp3=exp2+exp1
                verificarnumero(exp3)
                return exp3
            elif(self.tipo==3):
                exp1 = self.operand1.evaluar(symtab)
                exp2 = self.operand2.evaluar(symtab)
                exp3 = Lista()
                for i in range(0,(len(exp1.set_lista()))):
                    temp1 = exp1.set_lista()[i]
                    temp2 = exp2.set_lista()[i]
                    temp3 = Lista()
                    for j in range(0,len(temp1.set_lista())):
                      temp3.agregar(Numero(temp1.set_lista()[j].evaluar(symtab) + temp2.set_lista()[j].evaluar(symtab), 0 , 0))
                      # + temp2.set_lista()[j].evaluar)
                    exp3.agregar(temp3)
                return exp3
            enteroizq = self.operand1.evaluar(symtab)
            enteroder = self.operand2.evaluar(symtab)
            res = [0,0]
            if(enteroizq[0]<enteroder[0]):
                res[0]= enteroizq[0]
            else:
                res[0] = enteroder[0]

            if(enteroizq[1]<enteroder[1]):
                res[1]= enteroder[1]
            else:
                res[1] = enteroizq[1]
            verificarrango(res)
            return res #REVISAR
        elif(self.operador == "MULTIPLICAR"):
            if(self.tipo<=2):
                exp1 = self.operand1.evaluar(symtab)
                exp2 = self.operand2.evaluar(symtab)
                verificarnumero(exp1)
                verificarnumero(exp2)
                # print "AQUI ENTRA"
                exp3= exp1*exp2
                verificarnumero(exp3)
                return exp3
            if(self.tipo==3):
                exp1 = self.operand1.evaluar(symtab)
                exp2 = self.operand2.evaluar(symtab)
                exp3 = Lista()
                temp1 = exp1.set_lista()
                for i in range(0,len(exp1.set_lista()[0].set_lista())):
                  temp3 = Lista()
                  for j in range(0,(len(exp2.set_lista()))):
                    valor_posicion = 0
                    for r in range(0, len(exp1.set_lista())):
                      # for q in range(0, (len(exp2.set_lista()))):
                        valor_posicion = valor_posicion + exp1.set_lista()[i].set_lista()[r].evaluar(symtab) * exp2.set_lista()[r].set_lista()[j].evaluar(symtab)
                    temp3.agregar(Numero(valor_posicion, 0 , 0))
                  exp3.agregar(temp3)
                return exp3
        elif(self.operador == "MENOS"):
            if(self.tipo<=2):
                exp1 = self.operand1.evaluar(symtab)
                exp2 = self.operand2.evaluar(symtab)
                verificarnumero(exp1)
                verificarnumero(exp2)
                exp3=exp1-exp2
                verificarnumero(exp3)
                return exp3
            elif(self.tipo==3):
                exp1 = self.operand1.evaluar(symtab)
                exp2 = self.operand2.evaluar(symtab)
                exp3 = Lista()
                for i in range(0,(len(exp1.set_lista()))):
                    temp1 = exp1.set_lista()[i]
                    temp2 = exp2.set_lista()[i]
                    temp3 = Lista()
                    for j in range(0,len(temp1.set_lista())):
                      temp3.agregar(Numero(temp1.set_lista()[j].evaluar(symtab) - temp2.set_lista()[j].evaluar(symtab), 0 , 0))
                      # + temp2.set_lista()[j].evaluar)
                    exp3.agregar(temp3)
                return exp3
        elif(self.operador == "DIV"):
            if(self.tipo==1):
              try:
                  exp1 = self.operand1.evaluar(symtab)
                  exp2 = self.operand2.evaluar(symtab)
                  verificarnumero(exp1)
                  verificarnumero(exp2)
                  exp3 = exp1 // exp2
                  verificarnumero(exp3)
                  return exp3
              except ZeroDivisionError:
                  print "\nERROR: Intento de división por cero"
                  sys.exit(0)    
        elif(self.operador == "DIVISION"):
            try:
                exp1 = self.operand1.evaluar(symtab)
                exp2 = self.operand2.evaluar(symtab)
                verificarnumero(exp1)
                verificarnumero(exp2)
                exp3 = exp1/exp2
                verificarnumero(exp3)
                return exp3
            except ZeroDivisionError:
                print "\nERROR: Intento de división por cero"
                sys.exit(0)
        elif(self.operador == "MOD"):
            try:
                exp1 = self.operand1.evaluar(symtab)
                exp2 = self.operand2.evaluar(symtab)
                verificarnumero(exp1)
                verificarnumero(exp2)
                exp3 = math.floor(exp1)%exp2
                # print exp3
                verificarnumero(exp3)
                return exp3
            except ZeroDivisionError:
                print "\nERROR: Intento de módulo por cero"
                sys.exit(0)        
        elif(self.operador == "RESTO"):
            try:
                exp1 = self.operand1.evaluar(symtab)
                exp2 = self.operand2.evaluar(symtab)
                verificarnumero(exp1)
                verificarnumero(exp2)
                exp3 = exp1%exp2
                # print exp3
                verificarnumero(exp3)
                return exp3
            except ZeroDivisionError:
                print "\nERROR: Intento de módulo por cero"
                sys.exit(0)
        elif(self.operador == "MAS_MATRIX_NUMBER"):
          if(self.tipo==3):
              try:
                exp1 = self.operand1.evaluar(symtab)
                exp2 = self.operand2.evaluar(symtab)
                exp3 = Lista()
                for i in range(0,(len(exp1.set_lista()))):
                    temp1 = exp1.set_lista()[i]
                    temp3 = Lista()
                    for j in range(0,len(temp1.set_lista())):
                      temp3.agregar(Numero(temp1.set_lista()[j].evaluar(symtab) + exp2, 0 , 0))
                      # + temp2.set_lista()[j].evaluar)
                    exp3.agregar(temp3)
                return exp3
              except ZeroDivisionError:
                print "\nERROR: Intento de división por cero"
                sys.exit(0)     
          elif(self.tipo==4):
              try:
                exp1 = self.operand1.evaluar(symtab)
                exp2 = self.operand2.evaluar(symtab)
                exp3 = Lista()
                for i in range(0,(len(exp2.set_lista()))):
                  temp2 = exp2.set_lista()[i]
                  temp3 = Lista()
                  for j in range(0,len(temp2.set_lista())):
                    # print exp1
                    # print temp2.set_lista()[j].evaluar(symtab)
                    # print exp1 // temp2.set_lista()[j].evaluar(symtab)
                    # print "  "
                    temp3.agregar(Numero(exp1 + temp2.set_lista()[j].evaluar(symtab), 0 , 0))
                    # + temp2.set_lista()[j].evaluar)
                  exp3.agregar(temp3)
                return exp3
              except ZeroDivisionError:
                print "\nERROR: Intento de división por cero"
                sys.exit(0) 
        elif(self.operador == "MATRIX_DIVISION"):
          if(self.tipo==3):
              try:
                exp1 = self.operand1.evaluar(symtab)
                exp2 = self.operand2.evaluar(symtab)
                exp3 = Lista()
                for i in range(0,(len(exp1.set_lista()))):
                    temp1 = exp1.set_lista()[i]
                    temp3 = Lista()
                    for j in range(0,len(temp1.set_lista())):
                      temp3.agregar(Numero(temp1.set_lista()[j].evaluar(symtab) // exp2, 0 , 0))
                      # + temp2.set_lista()[j].evaluar)
                    exp3.agregar(temp3)
                return exp3
              except ZeroDivisionError:
                print "\nERROR: Intento de división por cero"
                sys.exit(0)     
          elif(self.tipo==4):
              try:
                exp1 = self.operand1.evaluar(symtab)
                exp2 = self.operand2.evaluar(symtab)
                exp3 = Lista()
                for i in range(0,(len(exp2.set_lista()))):
                  temp2 = exp2.set_lista()[i]
                  temp3 = Lista()
                  for j in range(0,len(temp2.set_lista())):
                    # print exp1
                    # print temp2.set_lista()[j].evaluar(symtab)
                    # print exp1 // temp2.set_lista()[j].evaluar(symtab)
                    # print "  "
                    temp3.agregar(Numero(exp1 // temp2.set_lista()[j].evaluar(symtab), 0 , 0))
                    # + temp2.set_lista()[j].evaluar)
                  exp3.agregar(temp3)
                return exp3
              except ZeroDivisionError:
                print "\nERROR: Intento de división por cero"
                sys.exit(0) 
        elif(self.operador == "MENOS_MATRIX_NUMBER"):
          if(self.tipo==3):
              try:
                exp1 = self.operand1.evaluar(symtab)
                exp2 = self.operand2.evaluar(symtab)
                exp3 = Lista()
                for i in range(0,(len(exp1.set_lista()))):
                    temp1 = exp1.set_lista()[i]
                    temp3 = Lista()
                    for j in range(0,len(temp1.set_lista())):
                      temp3.agregar(Numero(temp1.set_lista()[j].evaluar(symtab) - exp2, 0 , 0))
                      # + temp2.set_lista()[j].evaluar)
                    exp3.agregar(temp3)
                return exp3
              except ZeroDivisionError:
                print "\nERROR: Intento de división por cero"
                sys.exit(0)     
          elif(self.tipo==4):
              try:
                exp1 = self.operand1.evaluar(symtab)
                exp2 = self.operand2.evaluar(symtab)
                exp3 = Lista()
                for i in range(0,(len(exp2.set_lista()))):
                  temp2 = exp2.set_lista()[i]
                  temp3 = Lista()
                  for j in range(0,len(temp2.set_lista())):
                    temp3.agregar(Numero(exp1 - temp2.set_lista()[j].evaluar(symtab), 0 , 0))
                  exp3.agregar(temp3)
                return exp3
              except ZeroDivisionError:
                print "\nERROR: Intento de división por cero"
                sys.exit(0) 
        elif(self.operador == "MATRIX_RESTO"):
          if(self.tipo==3):
              try:
                exp1 = self.operand1.evaluar(symtab)
                exp2 = self.operand2.evaluar(symtab)
                exp3 = Lista()
                for i in range(0,(len(exp1.set_lista()))):
                    temp1 = exp1.set_lista()[i]
                    temp3 = Lista()
                    for j in range(0,len(temp1.set_lista())):
                      temp3.agregar(Numero(temp1.set_lista()[j].evaluar(symtab) % exp2, 0 , 0))
                    exp3.agregar(temp3)
                return exp3
              except ZeroDivisionError:
                print "\nERROR: Intento de división por cero"
                sys.exit(0)     
          elif(self.tipo==4):
              try:
                exp1 = self.operand1.evaluar(symtab)
                exp2 = self.operand2.evaluar(symtab)
                exp3 = Lista()
                for i in range(0,(len(exp2.set_lista()))):
                  temp2 = exp2.set_lista()[i]
                  temp3 = Lista()
                  for j in range(0,len(temp2.set_lista())):
                    temp3.agregar(Numero(exp1 % temp2.set_lista()[j].evaluar(symtab), 0 , 0))
                  exp3.agregar(temp3)
                return exp3
              except ZeroDivisionError:
                print "\nERROR: Intento de división por cero"
                sys.exit(0)         
        elif(self.operador == "MATRIX_RESTO_ENTERO"):
          if(self.tipo==3):
              try:
                exp1 = self.operand1.evaluar(symtab)
                exp2 = self.operand2.evaluar(symtab)
                exp3 = Lista()
                for i in range(0,(len(exp1.set_lista()))):
                    temp1 = exp1.set_lista()[i]
                    temp3 = Lista()
                    for j in range(0,len(temp1.set_lista())):
                      temp3.agregar(Numero(math.floor(temp1.set_lista()[j].evaluar(symtab)) % exp2, 0 , 0))
                    exp3.agregar(temp3)
                return exp3
              except ZeroDivisionError:
                print "\nERROR: Intento de división por cero"
                sys.exit(0)     
          elif(self.tipo==4):
              try:
                exp1 = self.operand1.evaluar(symtab)
                exp2 = self.operand2.evaluar(symtab)
                exp3 = Lista()
                for i in range(0,(len(exp2.set_lista()))):
                  temp2 = exp2.set_lista()[i]
                  temp3 = Lista()
                  for j in range(0,len(temp2.set_lista())):
                    temp3.agregar(Numero(math.floor(exp1) % temp2.set_lista()[j].evaluar(symtab), 0 , 0))
                  exp3.agregar(temp3)
                return exp3
              except ZeroDivisionError:
                print "\nERROR: Intento de división por cero"
                sys.exit(0) 
        elif(self.operador == "MATRIX_DIVISION_ENTERA"):
          if(self.tipo==3):
              try:
                exp1 = self.operand1.evaluar(symtab)
                exp2 = self.operand2.evaluar(symtab)
                exp3 = Lista()
                for i in range(0,(len(exp1.set_lista()))):
                    temp1 = exp1.set_lista()[i]
                    temp3 = Lista()
                    for j in range(0,len(temp1.set_lista())):
                      temp3.agregar(Numero(temp1.set_lista()[j].evaluar(symtab) // exp2, 0 , 0))
                    exp3.agregar(temp3)
                return exp3
              except ZeroDivisionError:
                print "\nERROR: Intento de división por cero"
                sys.exit(0)     
          elif(self.tipo==4):
              try:
                exp1 = self.operand1.evaluar(symtab)
                exp2 = self.operand2.evaluar(symtab)
                exp3 = Lista()
                for i in range(0,(len(exp2.set_lista()))):
                  temp2 = exp2.set_lista()[i]
                  temp3 = Lista()
                  for j in range(0,len(temp2.set_lista())):
                    temp3.agregar(Numero(exp1 // temp2.set_lista()[j].evaluar(symtab), 0 , 0))
                  exp3.agregar(temp3)
                return exp3
              except ZeroDivisionError:
                print "\nERROR: Intento de división por cero"
                sys.exit(0) 
        elif(self.operador == "MULTIPLICAR_MATRIX_NUMBER"):
          if(self.tipo==3):
              try:
                exp1 = self.operand1.evaluar(symtab)
                exp2 = self.operand2.evaluar(symtab)
                exp3 = Lista()
                for i in range(0,(len(exp1.set_lista()))):
                    temp1 = exp1.set_lista()[i]
                    temp3 = Lista()
                    for j in range(0,len(temp1.set_lista())):
                      temp3.agregar(Numero(temp1.set_lista()[j].evaluar(symtab) * exp2, 0 , 0))
                    exp3.agregar(temp3)
                return exp3
              except ZeroDivisionError:
                print "\nERROR: Intento de división por cero"
                sys.exit(0)     
          elif(self.tipo==4):
              try:
                exp1 = self.operand1.evaluar(symtab)
                exp2 = self.operand2.evaluar(symtab)
                exp3 = Lista()
                for i in range(0,(len(exp2.set_lista()))):
                  temp2 = exp2.set_lista()[i]
                  temp3 = Lista()
                  for j in range(0,len(temp2.set_lista())):
                    temp3.agregar(Numero(exp1 * temp2.set_lista()[j].evaluar(symtab), 0 , 0))
                  exp3.agregar(temp3)
                return exp3
              except ZeroDivisionError:
                print "\nERROR: Intento de división por cero"
                sys.exit(0) 



# Clase: ExpresionUn
# Descripción: esta clase permite que el reconocedor identifique las expresiones
#              unarias, primero el operador, luego el operando.
class ExpresionUn:
    def __init__(self, operador, operand, linea, columna):
        self.operador = operador
        self.operand = operand
        self.linea = linea       
        self.columna = columna

    def imprimir(self,sangria):
      return str("")

    def __str__(self):
        return "EXPRESION_UN \n operador: %s \n operando %s" %(self.operador, self.operand) 

    def esBool(self, symtab):
        if (self.operador == "NOT"):
            return self.operand.esBool(symtab)
        else:
            return ["ERROR en la linea "+ \
            str(self.linea) + ", columna " + str(self.columna)  + \
            ": El operador unario \""+str(self.operador).lower()+ \
            "\" no es compatible con el tipo bool"] + \
            self.operand.esBool(symtab)


    def esInt(self, symtab):
        if(self.operador == "MENOS"):
            return self.operand.esInt(symtab)
        else:
            return ["ERROR en la linea "+ \
            str(self.linea) + ", columna " + str(self.columna)  + \
            ": El operador unario \""+str(self.operador).lower()+ \
            "\" no es compatible con el tipo int"] +  \
            self.operand.esInt(symtab)

    def esMatrix(self, symtab):
        if(self.operador == "TRASPUESTO"):
            return self.operand.esMatrix(symtab)
        elif(self.operador == "MENOS"):
            return self.operand.esMatrix(symtab)
        else:
            return ["ERROR en la linea "+ \
            str(self.linea) + ", columna " + str(self.columna)  + \
            ": El operador unario \""+str(self.operador).lower()+ \
            "\" no es compatible con el tipo int"] +  \
            self.operand.esInt(symtab)

    def esValida(self, symtab):
        return  self.operand.esValida(symtab)

    def evaluar(self, symtab):
        if (self.operador == "MENOS"):
            numero = - self.operand.evaluar(symtab)
            verificarnumero(numero)
            return numero   
        elif(self.operador == "NOT"):
            return (not self.operand.evaluar(symtab)) 
        elif(self.operador == "TRASPUESTO"):
            exp = self.operand.evaluar(symtab)
            exp3 = Lista()
            for i in range(0,(len(exp.set_lista()))):
                temp3 = Lista()
                for j in range(0,len(exp.set_lista()[i].set_lista())):
                  temp3.agregar(Numero(exp.set_lista()[j].set_lista()[i].evaluar(symtab), 0 , 0))
                exp3.agregar(temp3)
            return exp3

# Clase: Condicional
# Descripción: da lugar a la instrucción de selección tanto simple como con else
class Condicional:
    def __init__(self, condicion, list_inst, list_inst2):
        self.condicion = condicion
        self.list_inst = list_inst
        self.tabla = None
        self.list_inst2 = list_inst2

    def imprimir(self,sangria):
      if not(self.list_inst is None):
          lista=self.list_inst.set_lista()
          tamano = len(lista)
          i=0
          prt = ""
          sangria = sangria + " "
          while (i<tamano):            
            prt = prt + lista[i].imprimir(sangria) 
            if (i != (tamano-1)):
                if not prt:
                  prt = prt + "\n" + sangria
            i = i+1

      if not(self.list_inst2 is None):
          lista=self.list_inst2.set_lista()
          tamano = len(lista)
          i=0
          prt = ""
          sangria = sangria + " "
          while (i<tamano):            
            prt = prt + lista[i].imprimir(sangria) 
            if (i != (tamano-1)):
                if not prt:
                  prt = prt + "\n" + sangria
            i = i+1
      return prt

    def __str__(self):
    
        prt = "\nCONDICIONAL \n condicion: %s \n instruccion: %s" %(self.condicion, self.list_inst)
        
        if not(self.list_inst2 is None):
            prt = "\n%s CONDICIONAL ELSE \n %s" %(prt, self.list_inst2)

        return prt

    def verificar(self, symtab):
        self.tabla = symtab
        if (self.condicion.esBool(self.tabla)!=[]):
          return ["errorCondicional"]
        errores = []
        errores = self.condicion.esBool(symtab)
        symtab = self.tabla

        auxlista = self.list_inst.set_lista()
        errores = self.tabla.getErrores()

        for list_inst in auxlista:
            errores = errores + list_inst.verificar(self.tabla)
        if (not(self.list_inst2 is None)):
            auxlista2 = self.list_inst2.set_lista()
            errores = self.tabla.getErrores()
            i=-1
            for list_inst2 in auxlista2:
                i+=1
                errores = errores + list_inst2.verificar(self.tabla)
        return errores

    def ejecutar(self):
        if(self.condicion.evaluar(self.tabla)):
          auxlista = self.list_inst.set_lista()
          for inst in auxlista:
            if isinstance(inst,Retorno):
                var = self.tabla.find('retorno')
                if var.getRetornable() == 1:
                  var.setValor(inst.ejecutar());
                  var.setRetornable(0)
            else:
              inst.ejecutar()
        else:
          if(not(self.list_inst2 is None)):
            auxlista = self.list_inst2.set_lista()
            for inst in auxlista:
              if isinstance(inst,Retorno):
                  var = self.tabla.find('retorno')
                  if var.getRetornable() == 1:
                    var.setValor(inst.ejecutar());
                    var.setRetornable(0)
              else:
                inst.ejecutar()

# Clase: Print
# Descripción: permite reconocer qué se imprimirá en pantalla al invocar PRINT
class Print:
    def __init__(self, prt):
        self.prt = prt
        self.tabla =None

    def imprimir(self,sangria):
      return str()
     
    def __str__(self):
        return "\nPRINT %s" %(self.prt)

    def verificar(self, symtab):
        self.tabla = symtab
        if (symtab is not None):
          errores = []
          lista=self.prt.set_lista()
          for i in lista:
              if(not(i.esInt(symtab))):
                  pass
              elif(not(i.esMatrix(symtab))):
                  pass
              elif(not(i.esBool(symtab))):
                  pass
              elif(isinstance(i,String)):
                  pass
              else:
                  errores =  errores + \
                             ["ERROR en la linea "+ \
                             str(i.linea)+ ", columna " + \
                             str(i.columna) + \
                             ": La expresion es incorrecta y " + \
                             "no se puede imprimir"] + \
                             i.esValida(symtab)
          self.tabla=symtab
        return errores

    def ejecutar(self):
        lista=self.prt.set_lista()

        res = ""
        for i in lista:
            valor = i.evaluar(self.tabla)
            if(isinstance(valor, int)):
                verificarnumero(valor)
            res = res + str(valor)
        sys.stdout.write(res)


# Clase: Read
# Descripción: permite reconocer que se le pedirá al usuario la introducción de
#              un valor por consola
class IExpr:
    def __init__(self, expr_):
        self.expr = expr_
        self.tabla = None

    def imprimir(self,sangria):
      return str()

    def __str__(self):
        return "\nIEXPR \n expresion: %s " %(self.id)

    def verificar(self, symtab):
      self.tabla = symtab
      en = []
      try:
          if callable(getattr(self.expr, 'esInt')):
              en = self.expr.esInt(symtab)
      except AttributeError, e:
          print e
      eb = []
      try:
          if callable(getattr(self.expr, 'esBool')):
              eb = self.expr.esBool(symtab)
      except AttributeError, e:
          print e
      em = []
      try:
          if callable(getattr(self.expr, 'esMatrix')):
              em = self.expr.esMatrix(symtab)

      except AttributeError, e:
          print e
      if eb == [] or en == [] or em == [] :
          try:
            if callable(getattr(self.expr, 'esValida')):
              en = self.expr.esValida(symtab)
              return en
          except AttributeError, e:
            print e
      else:
          print "meh ):"
          sys.exit(1)
      return [] 

class Read:
    def __init__(self, id_):
        self.id = id_
        self.tabla = None

    def imprimir(self,sangria):
      return str()
      
    def __str__(self):
        return "\nREAD \n variable: %s " %(self.id)

    def verificar(self, symtab):
        self.tabla = symtab
        sym = symtab.find(self.id.identif)
        symtab = self.tabla
        if(not (sym is None)):
          if(sym.getModificable()):
            sym.setValor(0)   #Inicializacion momentanea
            if(not(self.id.esMatrix(symtab))):
              return ["errorRead"]
            else:
              return []
          else:
            return ["ERROR en la linea "+ \
                   str(self.id.linea)+ ", columna " + \
                   str(self.id.columna) + \
                   ": La variable \""+ self.id.identif+ \
                   "\" pertenece a una iteracion y no" + \
                   " puede ser modificada" ]
        else:
            return ["ERROR en la linea "+ \
            str(self.id.linea)+ ", columna " + \
            str(self.id.columna) + \
            ": La variable \""+ self.id.identif+ \
            "\" no ha sido declarada en nigun bloque" + \
            " con alcance a esta aparicion"] 

    def verificarEntrada(self, entrada, tipo):

        if(tipo=="number"):
            try:
                entero = int(entrada)
                if ((entero>=float(2147483648))or(entero<-float(2147483648))):
                        return None, False
                return entero, True 
            except ValueError:
                return None, False

        if(tipo=="bool"):
            exp= re.compile("(\s)*(false|true)(\s)*") #expresion regular
            numpalabras = len(entrada.split())
            if((len(exp.findall(entrada))==1)and(numpalabras==1)):
                if("false" in entrada):
                    return False, True
                if("true" in entrada):
                    return True, True 
            return None, False
        return None, False

    def ejecutar(self):
        permitido = False
        sym = self.tabla.find(self.id.identif)
        while(not(permitido)):
            entrada = raw_input()
            # print sym.getTipo()
            valor, permitido = self.verificarEntrada(entrada, sym.getTipo())
            if(permitido):
                self.tabla.update(self.id.identif, valor)
            else:
                print "Intentelo de nuevo: "

# Clase: Bloque
# Descripción: permite reconocer los elementos que pueden incluirse en un bloque
#              (nada, declaraciones, instrucciones o una combinación de ambas)
class Bloque:
    def __init__(self, lista_decl, lista_inst):
      self.tablasimbolos = lista_decl
      self.lista_inst = lista_inst
      self.tabla = None

    def imprimir(self, sangria):
      prt = "\n"+ sangria + "Alcance Bloque:"
      sangria = sangria + " "

      if not(self.tablasimbolos is None):
          prt = prt + self.tablasimbolos.imprimir(sangria)

      if not(self.lista_inst is None):
          lista=self.lista_inst.set_lista()
          tamano = len(lista)
          i=0
          prt = prt + "\n" + sangria + "Hijos: "
          sangria = sangria + " "
          while (i<tamano):            
            prt = prt + lista[i].imprimir(sangria) 
            if (i != (tamano-1)):
                if not prt:
                  prt = prt + "\n" + sangria
            i = i+1
      return prt

    def __str__(self):

        prt = "\nBLOQUE"

        if not(self.tablasimbolos is None):
            prt = "\n%s DECLARACIONES %s" %(prt, self.tablasimbolos)

        if not(self.lista_inst is None):
            prt = "\n%s%s" %(prt, self.lista_inst)

        return prt

    def verificar(self, symtab):
        self.tabla = symtab
        self.tablasimbolos.setpadretabla(symtab) 
        auxlista = self.lista_inst.set_lista()
        errores = []
        errores= errores + self.tablasimbolos.getErrores()
        for inst in auxlista:
            temporal = inst.verificar(self.tablasimbolos)
            if (temporal is not None):
              errores = errores + temporal
        for i in self.tablasimbolos.getTabla():
          errores = errores + i.getErrores();
        return self.verificarVariables() + errores

    def verificarVariables(self):
        warnings = []
        for sym in self.tablasimbolos.tabla:
            if(sym.getValor() is None):
                warnings.append("WARNING en la linea "+ \
                          str(sym.nombre.linea)+ ", columna " + \
                          str(sym.nombre.columna) + \
                          ": La variable \""+ sym.nombre.identif+ \
                          "\" no es usada durante la ejecucion del programa")
        return warnings

    def ejecutar(self):
        auxlista = self.lista_inst.set_lista()
        for inst in auxlista:
          if isinstance(inst,Retorno):
              var = self.tabla.find('retorno')
              if var.getRetornable() == 1:
                var.setValor(inst.ejecutar());
                var.setRetornable(0)
          else:
            inst.ejecutar()

# Clase: IterDet
# Descripción: permite reconocer que nos encontramos ante una instrucción for.
#              Incluye la variable, el rango en el que vivirá y la instrucción.
class IterDet:
    def __init__(self, var, rango, lista_inst):
        self.var = var
        self.rango = rango
        self.lista_inst = lista_inst
        self.tabla = None

    def imprimir(self,sangria):
      if not(self.lista_inst is None):
          lista=self.lista_inst.set_lista()
          tamano = len(lista)
          i=0
          prt = "\n" + sangria + "Hijos: "
          sangria = sangria + " "
          while (i<tamano):            
            prt = prt + lista[i].imprimir(sangria) 
            if (i != (tamano-1)):
                if not prt:
                  prt = prt + "\n" + sangria
            i = i+1

      return prt

    def __str__(self):
        return "\nINSTRUCCION: ITER_DET \n VARIABLE: %s \n RANGO: %s \n INSTRUCCION: %s" %(self.var, self.rango, self.lista_inst)

    def verificar(self, symtab):
            self.tabla = symtab
            # if (self.rango.esMatrix(symtab) != []):
            #   return []
              #return ["errorIterDet"]
            simbo = SymTable.Simbolo(self.var,True)
            simbo.setValor(0)
            tabla = SymTable.SymTable()
            tabla.insert(Lista(simbo), "number")
            self.tabla.concatenar(tabla)
            errores = []
            errores = errores + self.rango.esMatrix(self.tabla)
            auxlista = self.lista_inst.set_lista()
            errores = self.tabla.getErrores()
            for inst in auxlista:
                errores = errores  + inst.verificar(self.tabla)
            return errores
            print 

    def ejecutar(self):
        print self.tabla.imprimir(" ")
        tabla = self.tabla
        try:
          if(getattr(self.rango,'identif')):
            rango = self.tabla.find(self.rango.identif)
            exp1 = rango.getValor().set_lista()
        except:
          exp1 = self.rango.evaluar(self.tabla).set_lista()

        lista_inst = self.lista_inst.set_lista()
        for i in exp1:
          for j in (i.set_lista()):
            for inst in lista_inst:
              self.tabla.update(self.var.identif, j)
              inst.ejecutar()

# Clase: IterIndet
# Descripción: permite reconocer que nos encontramos ante una instrucción while.
#              Incluye la variable, la guardia a revisar y la instrucción.
class IterIndet:
    def __init__(self, guardia, lista_inst):
        self.guardia = guardia
        self.lista_inst = lista_inst
        self.tabla = None

    def imprimir(self,sangria):
      if not(self.lista_inst is None):
          lista=self.lista_inst.set_lista()
          tamano = len(lista)
          i=0
          prt = "\n" + sangria + "Hijos: "
          sangria = sangria + " "
          while (i<tamano):            
            prt = prt + lista[i].imprimir(sangria) 
            if (i != (tamano-1)):
                if not prt:
                  prt = prt + "\n" + sangria
            i = i+1
      return prt

    def __str__(self):
        return "\nINSTRUCCION: ITER_INDET \n GUARDIA: %s \n INSTRUCCION: %s" %(self.guardia, self.inst)

    def verificar(self, symtab):
            self.tabla = symtab
            if self.guardia.esBool(symtab)!=[]:
              return ["errorIterIndet"]
            auxsymtab = symtab
            errores = []
            symtab = auxsymtab

            auxlista = self.lista_inst.set_lista()
            errores = self.tabla.getErrores()
            for inst in auxlista:
                errores = errores + inst.verificar(self.tabla)
            return errores

    def ejecutar(self):
        auxlista = self.lista_inst.set_lista()
        while(self.guardia.evaluar(self.tabla)):
            for inst in auxlista:
              if isinstance(inst,Retorno):
                  var = self.tabla.find('retorno')
                  if var.getRetornable() == 1:
                    var.setValor(inst.ejecutar());
                    var.setRetornable(0)
              else:
                inst.ejecutar()

# Clase: Decl
# Descripción: permite reconocer las variables que se declaran y su respectivo
#              tipo.
class Decl:
    def __init__(self, lista_id, tipo):
        self.lista_id = lista_id
        self.tipo = tipo

    def imprimir(self,sangria):
      return str()

    def __str__(self):
        return " TIPO: %s \n VARIABLES: %s\n" %(self.lista_id, self.tipo)

# Clase: Id
# Descripción: permite el reconocimiento de los ID imprimibles en un programa
class Id:
    def __init__(self, identif, linea, columna):
        self.identif = identif 
        self.linea = linea       
        self.columna = columna     

    def imprimir(self,sangria):
      return str()

    def __str__(self):
        return str(self.identif) 

    def esBool(self, symtab):
        sym = symtab.find(self.identif)
        if (sym is None):                       
                return ["ERROR en la linea "+ \
                str(self.linea)+ ", columna " + \
                str(self.columna) + \
                ": La variable \""+ self.identif+ \
                "\" no ha sido declarada en nigun bloque" + \
                " con alcance a esta aparicion"] 
        if(sym.getTipo() == "boolean"):
            if(sym.getValor() is None):
                return ["ERROR en la linea "+ \
                str(self.linea)+", columna " + str(self.columna) +\
                 ": La variable \""+str(self.identif) +\
                "\" no ha sido inicializada antes de su aparicion" ]          
            else:
                return []
        else:
            return ["ERROR en la linea "+ \
                   str(self.linea) + ", columna " + \
                   str(self.columna)+ ": La variable \""+ \
                   str(self.identif)+ "\" no coincide con el tipo bool"]

    def esInt(self, symtab):
        sym = symtab.find(self.identif)
        if (sym is None):
                return ["ERROR en la linea "+ \
                str(self.linea)+ ", columna " + \
                str(self.columna) + \
                ": La variable \""+ self.identif+ \
                "\" no ha sido declarada en nigun bloque" + \
                " con alcance a esta aparicion"] 
        if(sym.getTipo() == "number"):
            if(sym.getValor() is None):
                return ["ERROR en la linea "+ \
                str(self.linea)+", columna " + str(self.columna) +\
                 ": La variable \""+str(self.identif) +\
                "\" no ha sido inicializada antes de su aparicion" ]          
            else:
                return []
        else:
            return ["ERROR en la linea "+ \
                   str(self.linea) + ", columna " + \
                   str(self.columna)+ ": La variable \""+ \
                   str(self.identif)+ "\" no coincide con el tipo int"]

    def esMatrix(self, symtab):
        sym = symtab.find(self.identif)
        if (sym is None):
                return ["ERROR en la linea "+ \
                str(self.linea)+ ", columna " + \
                str(self.columna) + \
                ": La variable \""+ self.identif+ \
                "\" no ha sido declarada en nigun bloque" + \
                " con alcance a esta aparicion"] 
        if(sym.getTipo() == "matrix")or(sym.getTipo() == "col")or(sym.getTipo() == "row"):
            if(sym.getValor() is None):
                return ["ERROR en la linea "+ \
                str(self.linea)+", columna " + str(self.columna) +\
                 ": La variable \""+str(self.identif) +\
                "\" no ha sido inicializada antes de su aparicion" ]          
            else:
                return []
        else:
            return ["ERROR en la linea "+ \
                   str(self.linea) + ", columna " + \
                   str(self.columna)+ ": La variable \""+ \
                   str(self.identif)+ "\" no coincide con el tipo rango"]

    def esValida(self, symtab):
        sym = symtab.find(self.identif)
        if (sym is None):
                return ["ERROR en la linea "+ \
                str(self.linea)+ ", columna " + \
                str(self.columna) + \
                ": La variable \""+ self.identif+ \
                "\" no ha sido declarada en nigun bloque" + \
                " con alcance a esta aparicion"] 
        if(sym.getValor() is None):
            return ["ERROR en la linea "+ \
            str(self.linea)+", columna " + str(self.columna) +\
            ": La variable \""+str(self.identif) +\
            "\" no ha sido inicializada antes de su aparicion" ] 
        return []

    def evaluar(self, symtab):
        # print " ENTONCES"
        # print symtab.imprimir(" ")
        sym = symtab.find(self.identif)
        valor = sym.getValor()
        # print self.identif
        try:
            if callable(getattr(valor, 'evaluar')):
              valor = valor.evaluar(symtab)
        except AttributeError, e:
            pass
         # print  "ID: " + str(valor)
        #print self.identif
        if(valor is None):
            print "\nERROR: Variable", self.identif, "no inicializada"
            sys.exit(0)
        return valor

    # def Dimesiones(self, otra):
    #       sym = symtab.find(self.identif)
    #     valor = sym.getValor()
    #       try:
    #         if callable(getattr(Dimesiones, 'set_lista')):
    #       except AttributeError, e:
    #         print e
    #     if (self.filas == otra.filas)and(self.col == otra.col):
    #       return []
    #     else:
    #       return ["Error de Dimesiones"]


# Clase: Numero
# Descripción: permite el reconocimiento de los numero
class Numero:
    def __init__(self, numero, linea, columna):
        self.numero=numero
        self.linea = linea      
        self.columna = columna 

    def imprimir(self,sangria):
      return str()
    # def imprimir(self, sangria):
    #     return "\n "+ sangria + "elemento: " + "%.2f" %(self.numero)

    def __str__(self):
        return str(self.numero)

    def esBool(self, symtab):
        return ["ERROR en la linea "+ \
               str(self.linea)+", columna " + \
              str(self.columna)+": El numero \""+str(self.numero) + \
               "\" no es de tipo bool"]

    def esInt(self, symtab):
        return []

    def esMatrix(self, symtab):
        return ["ERROR en la linea "+ \
               str(self.linea)+", columna " + \
              str(self.columna)+": El numero \""+str(self.numero) + \
               "\" no es de tipo esMatrix"]

    def verificar(self, symtab):
        return []

    def esValida(self, symtab):
        return  []

    def evaluar(self, symtab):     
        return self.numero



# Clase: String
# Descripción: permite el reconocimiento de las cadenas imprimibles en un programa
class String:
    def __init__(self, valor):
        self.valor = valor
        
    def imprimir(self,sangria):
      return str()

    def __str__(self):
        return self.valor

    def esBool(self, symtab):
        return ["ERROR"]

    def esInt(self, symtab):
        return ["ERROR"]

    def esMatrix(self, symtab):
        return ["ERROR"]

    def esValida(self, symtab):
        return  []

    def evaluar(self, symtab):
        
        res=""
        tamano = len(self.valor)
        i=0
        while(i<tamano):
         
            if(self.valor[i]=="\\"):
                i=i+1
                if(self.valor[i]=="n"):
                    res= res+"\n"
                elif(self.valor[i]=="\""):
                    res=res+"\""
                elif(self.valor[i]=="\\"):
                    res=res+"\\"
            else:
                res=res+self.valor[i]
            i=i+1 
        return res

# Clase: Boolean
# Descripción: permite el reconocimiento de constantes booleanas que se mandan
#              a imprimir en un programa
class Boolean:
    def __init__(self, valor, linea, columna):
        self.valor=valor
        self.linea = linea       
        self.columna = columna

    def imprimir(self,sangria):
      return str()
    # def imprimir(self, sangria):
    #     prt =  "CONSTANTE_BOOL"
    #     sangria = sangria + "  "  
    #     prt = prt + "\n"+ sangria +"valor: " + str(self.valor)
    #     return prt

    def __str__(self):
        return self.valor

    def esBool(self, symtab):
        return []

    def esInt(self, symtab):
        return ["ERROR en la linea "+ \
               str(self.linea)+", columna " + \
               str(self.columna)+": La expresion booleana \""+ \
                str(self.valor)+"\" no es de tipo int"]

    def verificar(self, symtab):
        return []

    def esMatrix(self, symtab):
        return ["ERROR en la linea "+ \
               str(self.linea)+", columna " + \
               str(self.columna)+": La expresion booleana \""+ \
                str(self.valor)+"\" no es de tipo Matriz"]

    def esValida(self, symtab):
        return  []

    def evaluar(self, symtab):
        if(self.valor == "true"):
            return True
        return False

class Matriz:
    def __init__(self, numero, filas, col, linea, columna):
        self.filas = filas
        self.col = col
        self.elementos = numero
        self.linea = linea       
        self.columna = columna 


    def imprimir(self,sangria):
      return str()
    # def imprimir(self, sangria):
    #     return "\n "+ sangria + "elemento: " + "%.2f" %(self.numero)

    def __str__(self):
      return str(self.elementos)

    def esBool(self, symtab):
        return ["ERROR en la linea "+ \
               str(self.linea)+", columna " + \
              str(self.columna)+ \
               "\" no es de tipo bool"]

    def esInt(self, symtab):
        return ["ERROR en la linea "+ \
               str(self.linea)+", columna " + \
              str(self.columna)+ \
               "\" no es de tipo Entero"]

    def esMatrix(self, symtab):
        return []

    def verificar(self, symtab):
        lista = self.elementos.set_lista()
        for i in lista:
          try:
            if callable(getattr(i, 'set_lista')):
              for j in i.set_lista():
                # print (symtab.find(j)==None)and((j.esInt(symtab))!=[])
                # print (symtab.find(j)==None)
               # print not(j.esInt(symtab))
                if (symtab.find(j)==None)and((j.esInt(symtab))!=[]):
                  return["ERROR en la linea "+ \
                 str(self.linea)+", columna " + \
                str(self.columna)+": El tamaño es invalido"]
            else:
                if (symtab.find(j)==None)and((j.esInt(symtab))!=[]):
                  return["ERROR en la linea "+ \
                 str(self.linea)+", columna " + \
                str(self.columna)+": El tamaño es invalido"]
          except AttributeError, e:
            print e
          if self.filas<=0 or self.columna<=0:
               return["ERROR en la linea "+ \
               str(self.linea)+", columna " + \
              str(self.columna)+": El tamaño es invalido"]
        return []

    def Dimesiones(self, otra):
        if (self.filas == otra.filas)and(self.col == otra.col):
          return []
        else:
          return ["Error de Dimesiones"]

    def DimensionesMultiplicacion(self, otra):
        if (self.filas == otra.col)and(self.col == otra.filas):
          return []
        else:
          return ["Error de Dimensiones"]

    def esValida(self, symtab):
        lista = self.elementos.set_lista()
        for i in lista:
          #print "  COLUMNAS: " + str(self.col) + "FILAS: " +str(self.filas) + "  TAMLISTA: "+str(len(i.set_lista()))
          #print " " 
          if self.filas<=0 or self.col<=0:
             return["ERROR en la linea "+ \
             str(self.linea)+", columna " + \
            str(self.columna)+": El tamaño es invalido"]
          if len(i.set_lista()) != self.filas:
              return["ERROR en la linea "+ \
             str(self.linea)+", columna " + \
            str(self.columna)+": El numero tamaño es invalido"]
          for j in i.set_lista():
            try:
              if callable(getattr(j, 'set_lista')):
                if len(j.set_lista()) != self.col:
                   return["ERROR en la linea "+ \
                  str(self.linea)+", columna " + \
                 str(self.columna)+": El numero tamaño es invalido"]
              else:
                if 1 != self.filas and self.col != 1:
                   return["ERROR en la linea "+ \
                  str(self.linea)+", columna " + \
                 str(self.columna)+": El numero tamaño es invalido"]
            except AttributeError, e:
                print e
            
        return [] + self.verificar(symtab)
    def evaluar(self, symtab):
        return  self.elementos; 

class AccesoMatrix:
    
    def __init__(self, identif,expresion):
        self.identif=identif
        self.expresion = expresion

    def imprimir(self,sangria):
      return str()

    def esValida(self, symtab):
      var = symtab.find(self.identif)
      #print symtab.find(self.identif)
      if(var == None):
        return ["errorAccesoMatrix"]
      else:
        if(len(expresion)>2):
          return ["errorAccesoMatrix"]
        else:
          if (var.col <= expresion[0])or(var.filas == expresion[1]):
            return ["errorAccesoMatrix"]

    # def imprimir(self, sangria):
    #     prt = "\n"+ sangria + "ASIGNACION DE FILA O COLUMNA"
    #     sangria = sangria + "  "  
    #     prt = prt + "\n"+ sangria + "variable: " + self.identif.imprimir(sangria)
    #     prt = prt + "\n"+ sangria + " fila:" + self.expresion.imprimir(sangria) 
    #     prt = prt + "\n"+ sangria + " columna: " + self.expresion2.imprimir(sangria) 
    #     return prt

class DeclMatrix:
    
    def __init__(self, identif,expresion,expresion2):
        self.identif=identif
        self.expresion = expresion
        self.expresion2 = expresion2

    def imprimir(self,sangria):
      return str()
    # def imprimir(self, sangria):
    #     prt = "\n"+ sangria + "MATRIX"
    #     sangria = sangria + "  "  
    #     prt = prt + "\n"+ sangria + "fila:" + self.expresion.imprimir(sangria) 
    #     prt = prt + "\n"+ sangria + "columna: " + self.expresion2.imprimir(sangria) 
    #     prt = prt + "\n"+ sangria + "variable: " + self.identif.imprimir(sangria)
    #     return prt

class DeclRowCol:
    
    def __init__(self, identif,expresion):
        self.identif=identif
        self.expresion = expresion
        self.tablasimbolos = None

    def imprimir(self,sangria):
      return str()
    # def imprimir(self, sangria):
    #     prt = "\n"+ sangria + "COL o ROW"
    #     sangria = sangria + "   "  
    #     prt = prt + "\n"+ sangria + " fila o columna:" + self.expresion.imprimir(sangria) 
    #     prt = prt + "\n"+ sangria + "  variable: " + self.identif.imprimir(sangria)
    #     return prt

class Funcion:
    def __init__(self, id_, lista_param, tipo, lista_inst, funcion):
        self.id=id_
        self.lista_param = lista_param
        self.tiporetorno = tipo
        self.lista_inst = lista_inst
        self.funcion = funcion
        self.tabla =  None

    def imprimir(self,sangria):
      return str()
    # def immprimir(self, sangria):
    #         return []

    def esValida(self, symtab):
      errores = []
      if self.lista_param is not None:
        #print self.tablasimbolos.imprimir(" ")
        self.lista_param.setpadretabla(symtab) 
        auxlista = self.lista_inst.set_lista()
        errores= self.lista_param.getErrores()
        for inst in auxlista:
            temporal = inst.verificar(self.lista_param)
            if (temporal is not None):
              errores = errores + temporal
      return errores    

    def verificar(self, symtab):
      self.tabla = symtab;
      errores = []
      if self.lista_param is not None:
       # print self.tabla.imprimir(" ")
        self.lista_param.setpadretabla(symtab) 
        auxlista = self.lista_inst.set_lista()
        errores= self.lista_param.getErrores()
        for inst in auxlista:
            temporal = inst.verificar(self.lista_param)
            if (temporal is not None):
              errores = errores + temporal
      return errores

class AccederFuncion:
    def __init__(self, id_, lista_param):
        self.id=id_
        self.tablasimbolos = None
        self.lista_param = lista_param
    
    def imprimir(self,sangria):
      return "\n" + str(self.id)

    def esValida(self, symtab):
      errores = []
      #print self.tablasimbolos.imprimir(" ")
      self.tablasimbolos.setpadretabla(symtab) 
      auxlista = self.lista_param.set_lista()
      fun = symtab.find(self.id)
      #print symtab.imprimir(" ")
      if(fun is None):
        return ["errorAccederFuncion"]
      return errores

    def esBool(self, symtab):
      return []

    def esInt(self, symtab):
      return []

    def esMatrix(self, symtab):
      return []

    def esFunc(self, symtab):
      return []

    def evaluar(self, symtab):
      print symtab.imprimir(" ");
      x = symtab.find(self.id.identif)
      y = copy.copy(x).getValor()
      tabla = copy.copy(y.lista_param)
      for i in range(0,len(tabla.tabla)-1):
        if tabla.tabla[i].getTipo() == 'matrix':
          tabla.tabla[i].setValor(x.getValor().lista_param.tabla[i].getValor());
      # print y.lista_param.tabla[0];
      # print y.lista_param.tabla[1

      print tabla.imprimir(" ")
      for i in range(0,len(y.lista_param.tabla)-1):
        try:
          if callable(getattr(self.lista_param.set_lista()[i], 'evaluar')):
            tabla.update(y.lista_param.tabla[i].getNombre(), self.lista_param.set_lista()[i].evaluar(symtab))
        except:
          tabla.update(y.lista_param.tabla[i].getNombre(), self.lista_param.set_lista()[i])
          #pass 
      tabla2 = SymTable.SymTable();



      simbo = SymTable.Simbolo(Id('retorno',0,0),True);
      simbo.setValor(0)
      tabla2.insert(Lista(simbo),y.tiporetorno)
      tabla.concatenar(tabla2);
      # print tabla.imprimir(" ");
      # print  y.lista_param.tabla[i].getNombre()
      # print self.lista_param.set_lista()[i]
      # print tabla.imprimir(" ")
      for i in y.lista_inst.set_lista():
        # print  " AQUIIII"+ str(tabla.imprimir(" "));
        if isinstance(i,Retorno):
          var = tabla.find('retorno')
          if var.getRetornable() == 1:
            var.setValor(i.ejecutar());
            var.setRetornable(0)
        else:
          try:
            if callable(getattr(i, 'verificar')):
              i.verificar(tabla)
          except ZeroDivisionError:
            pass 
          #print tabla.imprimir(" ")
          i.ejecutar()
      return tabla.find('retorno').getValor()

      #   symtab.find(y.lista_param.set_lista()[i].identif).getTipo()
      #   simbo = SymTable.Simbolo(y.lista_param.set_lista()[i].identif,True)
      #   simbo.setValor(self.lista_param.set_lista()[i].evaluar(symtab),tipo)
      #   tabla2 = SymTable.SymTable()
      #   tabla2.insert(clases.Lista(simbo),tipo)
      #   tabla.concatenar(tabla2)
      # p[0] = SymTable.SymTable()
      # lista = SymTable.Simbolo(p[7],True)
      # lista.setValor(0)
      # lista.setFila(p[3])
      # lista.setColumna(p[5])
class Retorno:
  
  def __init__ (self, valor):
    self.valor = valor
    self.tabla = None

  def verificar(self, symtab):
    self.tabla = symtab  
    return []

  def ejecutar(self):
    return self.valor.evaluar(self.tabla)

  def imprimir(self, tab):
    return "\n" + "RETORNO:  " + str(self.valor.imprimir(" "))

def verificarnumero(numero):

    # if ((int(str(numero))<2147483648)and(int(numero)>=-2147483648)):
        return True
    # print "\nERROR: Overflow detectado, número no permitido"
    # sys.exit(0)
